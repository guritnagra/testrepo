CREATE TABLE already_migrated_entitlements AS
SELECT DISTINCT bridge_id FROM tbl_keybatches WHERE id IN (SELECT DISTINCT key_batch_id FROM tbl_keybatches_entitlements);

INSERT INTO `tbl_keybatches_entitlements` 
(ent_name, ent_type, key_batch_id, ent_credits, ent_is_reusable_credit, ent_is_copy_from_online, 
ent_online_days,ent_online_expires,ent_offline_days,ent_offline_expires, deleted) 
SELECT 'Full Credit',1,kb.id,br.full_credits,0,0,br.full_days,br.full_expires,br.offline_full_days,br.offline_full_expires,br.deleted
FROM tbl_bridge AS br, tbl_keybatches AS kb
WHERE br.id NOT IN (SELECT * FROM already_migrated_entitlements) AND br.full_credits IS NOT NULL AND kb.bridge_id=br.id AND kb.notes = 'AUTO-GENERATED';

INSERT INTO `tbl_keybatches_entitlements` 
(ent_name, ent_type, key_batch_id, ent_credits, ent_is_reusable_credit, ent_is_copy_from_online, 
ent_online_days,ent_online_expires,ent_offline_days,ent_offline_expires, deleted) 
SELECT 'Rental Credit',1,kb.id,br.rental_credits,0,0,br.rental_days,br.rental_expires,br.offline_rental_days,br.offline_rental_expires,br.deleted
FROM tbl_bridge AS br, tbl_keybatches AS kb
WHERE br.id NOT IN (SELECT * FROM already_migrated_entitlements) AND br.rental_credits IS NOT NULL AND kb.bridge_id=br.id AND kb.notes = 'AUTO-GENERATED';


INSERT INTO `tbl_keybatches_entitlements` 
(ent_name, ent_type, key_batch_id, ent_credits, ent_is_reusable_credit, ent_is_copy_from_online, 
ent_online_days,ent_online_expires,ent_offline_days,ent_offline_expires, deleted) 
SELECT 'Comp Credit',2,kb.id,br.trial_credits,0,0,br.trial_days,br.trial_expires,br.offline_trial_days,br.offline_trial_expires,br.deleted
FROM tbl_bridge AS br, tbl_keybatches AS kb
WHERE br.id NOT IN (SELECT * FROM already_migrated_entitlements) AND br.trial_credits IS NOT NULL AND kb.bridge_id=br.id AND kb.notes = 'AUTO-GENERATED';


UPDATE tbl_keybatches AS kb, tbl_bridge AS br
SET kb.concurrency_ent_name = 'Concurrency Credit',
    kb.concurrency_ent_type = IFNULL(br.concurrency_comp_type,'2'),
    kb.concurrency_credits = br.concurrency_credits,
    kb.concurrency_days = br.concurrency_days,
    kb.concurrency_expires = br.concurrency_expires,
    kb.offline_concurrency_days = br.offline_concurrency_days,
    kb.offline_concurrency_expires = br.offline_concurrency_expires
WHERE br.concurrency_credits IS NOT NULL AND kb.bridge_id=br.id;


INSERT INTO `tbl_keybatches_entitlements` 
(ent_name, ent_type, key_batch_id, ent_credits, ent_is_reusable_credit, ent_is_copy_from_online, 
ent_online_days,ent_online_expires,ent_offline_days,ent_offline_expires, deleted) 
SELECT 'Full Credit',1,KB.id, KB.full_credits,0,0,
br.full_days,br.full_expires,br.offline_full_days,br.offline_full_expires, 0
FROM tbl_keybatches AS KB, tbl_bridge AS br 
WHERE br.id NOT IN (SELECT * FROM already_migrated_entitlements) AND KB.notes <> 'AUTO-GENERATED' AND KB.full_credits<>0 AND br.id=KB.bridge_id;

INSERT INTO `tbl_keybatches_entitlements` 
(ent_name, ent_type, key_batch_id, ent_credits, ent_is_reusable_credit, ent_is_copy_from_online, 
ent_online_days,ent_online_expires,ent_offline_days,ent_offline_expires, deleted) 
SELECT 'Rental Credit',1,KB.id, KB.rental_credits,0,0,
br.rental_days,br.rental_expires,br.offline_rental_days,br.offline_rental_expires, 0
FROM tbl_keybatches AS KB, tbl_bridge AS br 
WHERE br.id NOT IN (SELECT * FROM already_migrated_entitlements) AND KB.notes <> 'AUTO-GENERATED' AND KB.rental_credits<>0 AND br.id=KB.bridge_id;

INSERT INTO `tbl_keybatches_entitlements` 
(ent_name, ent_type, key_batch_id, ent_credits, ent_is_reusable_credit, ent_is_copy_from_online, 
ent_online_days,ent_online_expires,ent_offline_days,ent_offline_expires, deleted) 
SELECT 'Comp Credit',1,KB.id, KB.trial_credits,0,0,
br.trial_days,br.trial_expires,br.offline_trial_days,br.offline_trial_expires, 0
FROM tbl_keybatches AS KB, tbl_bridge AS br 
WHERE br.id NOT IN (SELECT * FROM already_migrated_entitlements) AND KB.notes <> 'AUTO-GENERATED' AND KB.trial_credits<>0 AND br.id=KB.bridge_id;



UPDATE tbl_keybatches_entitlements
SET ent_online_days=30
WHERE ent_type=2 AND ent_online_days IS NULL AND ent_online_expires IS NULL;

UPDATE tbl_keybatches_entitlements
SET ent_offline_days=30
WHERE ent_type=2 AND ent_offline_days IS NULL AND ent_offline_expires IS NULL;

UPDATE tbl_keybatches_entitlements
SET ent_online_days=365
WHERE ent_type=1 AND ent_online_days IS NULL AND ent_online_expires IS NULL;

UPDATE tbl_keybatches_entitlements
SET ent_offline_days=365
WHERE ent_type=1 AND ent_offline_days IS NULL AND ent_offline_expires IS NULL;

UPDATE tbl_keybatches SET concurrency_days=30 WHERE concurrency_ent_type=2 AND concurrency_days IS NULL AND concurrency_expires IS NULL;
UPDATE tbl_keybatches SET offline_concurrency_days=30 WHERE concurrency_ent_type=2 AND offline_concurrency_days IS NULL AND offline_concurrency_expires IS NULL;

UPDATE tbl_keybatches SET concurrency_days=365 WHERE concurrency_ent_type=1 AND concurrency_days IS NULL AND concurrency_expires IS NULL;
UPDATE tbl_keybatches SET offline_concurrency_days=30 WHERE concurrency_ent_type=1 AND offline_concurrency_days IS NULL AND offline_concurrency_expires IS NULL;




