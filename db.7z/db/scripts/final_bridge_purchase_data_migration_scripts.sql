CREATE TABLE already_migrated_purchases AS SELECT DISTINCT  bridge_id FROM tbl_bridge_purchase WHERE deleted=0;

INSERT INTO `tbl_bridge_purchase` 
(bridge_id, purchase_name, purchase_url, display_pricing, deleted) 
SELECT id,'RENT E-TEXT',rental_url,rental_url_price,deleted FROM tbl_bridge WHERE id NOT IN (SELECT * FROM already_migrated_purchases) AND rental_url <>'';

INSERT INTO `tbl_bridge_purchase` 
(bridge_id, purchase_name, purchase_url, display_pricing, deleted) 
SELECT id,'BUY E-TEXT',full_url,full_url_price,deleted FROM tbl_bridge WHERE id NOT IN (SELECT * FROM already_migrated_purchases) AND full_url <>'';

INSERT INTO `tbl_bridge_purchase` 
(bridge_id, purchase_name, purchase_url, display_pricing, deleted) 
SELECT id,'BUY PRINT TEXT',textbook_url,textbook_url_price,deleted FROM tbl_bridge WHERE id NOT IN (SELECT * FROM already_migrated_purchases) AND textbook_url <>'';

UPDATE tbl_bridge_purchase AS tbp
SET purchase_url = REPLACE(purchase_url, '${ISBN10}', '${EISBN10}')
WHERE purchase_name = 'RENT E-TEXT';

UPDATE tbl_bridge_purchase AS tbp
SET purchase_url = REPLACE(purchase_url, '${ISBN13}', '${EISBN13}')
WHERE purchase_name = 'RENT E-TEXT' 

UPDATE tbl_bridge_purchase AS tbp
SET purchase_url = REPLACE(purchase_url, '${ISBN10}', '${EISBN10}')
WHERE purchase_name = 'BUY E-TEXT';

UPDATE tbl_bridge_purchase AS tbp
SET purchase_url = REPLACE(purchase_url, '${ISBN13}', '${EISBN13}')
WHERE purchase_name = 'BUY E-TEXT';

UPDATE tbl_bridge_purchase AS tbp
SET purchase_url = REPLACE(purchase_url, '${ISBN10}', '${PISBN10}')
WHERE purchase_name = 'BUY PRINT TEXT';

UPDATE tbl_bridge_purchase AS tbp
SET purchase_url = REPLACE(purchase_url, '${ISBN13}', '${PISBN13}')
WHERE purchase_name = 'BUY PRINT TEXT';

UPDATE `tbl_bridge` b LEFT JOIN `tbl_bridge_purchase` bp ON b.id=bp.`bridge_id` SET b.is_purchases_enabled=1 WHERE bp.purchase_url IS NOT NULL OR b.bridge_type_id=2;

UPDATE `tbl_bridge` SET `defer_sign_in`=0 WHERE `defer_sign_in` IS NULL;