
CREATE TABLE used_type_keybatches_mapping AS 
 SELECT buba.key_assign_id,buba.used_type,kbk.key_batch_id,NULL AS entitlement_id FROM `tbl_bridgeuser_bookassign` buba,`tbl_bridgeuser_keyassign` buka , `tbl_keybatches_keys` kbk
  WHERE buba.key_assign_id= buka.id AND buka.key_id =kbk.id AND (buba.used_type IN ('full','trial','rental') OR used_type LIKE 'concurrent%');
  
  
 ALTER TABLE `used_type_keybatches_mapping` CHANGE `entitlement_id` `entitlement_id` VARCHAR(64) NULL; 
  

UPDATE used_type_keybatches_mapping t1, tbl_keybatches_entitlements t2 SET t1.entitlement_id = t2.id WHERE 
t2.ent_name ='Full Credit' AND t2.deleted=0 AND t1.key_batch_id=t2.key_batch_id AND used_type='full';

UPDATE used_type_keybatches_mapping t1, tbl_keybatches_entitlements t2 SET t1.entitlement_id = t2.id WHERE 
t2.ent_name ='Comp Credit' AND t2.deleted=0 AND t1.key_batch_id=t2.key_batch_id AND used_type='trial';

UPDATE used_type_keybatches_mapping t1, tbl_keybatches_entitlements t2 SET t1.entitlement_id = t2.id WHERE 
t2.ent_name ='Rental Credit' AND t2.deleted=0 AND t1.key_batch_id=t2.key_batch_id AND used_type='rental';

UPDATE used_type_keybatches_mapping t1,tbl_keybatches t2 SET t1.entitlement_id = 'concurrent' WHERE 
t1.key_batch_id=t2.id AND used_type LIKE 'concurrent%';


UPDATE `tbl_bridgeuser_bookassign` t1,used_type_keybatches_mapping t2 SET t1.used_type= t2.entitlement_id, t1.key_batch_id=t2.key_batch_id WHERE entitlement_id IS NOT NULL AND t2.key_assign_id=t1.key_assign_id;


