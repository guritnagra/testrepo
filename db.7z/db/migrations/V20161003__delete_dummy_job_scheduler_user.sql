delete from `tbl_adminuser` where email='jobscheduler@vsapplications.com';
