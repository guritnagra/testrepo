ALTER TABLE `tbl_bridge_books_cache` CHANGE `last_updated` `last_modified_date` TIMESTAMP  NULL  DEFAULT NULL;
ALTER TABLE `tbl_bridge_books_cache` ADD `updated_date` TIMESTAMP  NULL  DEFAULT CURRENT_TIMESTAMP  ON UPDATE CURRENT_TIMESTAMP AFTER `last_modified_date`;

