ALTER TABLE `tbl_keybatches` ADD CONSTRAINT `tbl_keybatches_ibfk_4` FOREIGN KEY (`concurrency_ent_type`) REFERENCES `tbl_code_types`(`id`); 
