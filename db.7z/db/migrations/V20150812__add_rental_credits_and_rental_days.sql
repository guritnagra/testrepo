ALTER TABLE  `tbl_keybatches_keys` ADD COLUMN `rental_credits` INT(4) DEFAULT 0 NULL AFTER `trial_credits`, 
	ADD COLUMN `rental_days` INT(4) DEFAULT 0 NULL AFTER `rental_credits`; 
	
ALTER TABLE  `tbl_keybatches` ADD COLUMN `rental_credits` INT(4) DEFAULT 0 NULL AFTER `trial_credits`, 
	ADD COLUMN `rental_days` INT(4) DEFAULT 0 NULL AFTER `rental_credits`; 
	
ALTER TABLE `tbl_bridge` CHANGE `eText_url` `full_url` VARCHAR(256) CHARSET latin1 COLLATE latin1_swedish_ci NULL; 

ALTER TABLE `tbl_keybatches` CHANGE `purchase_credits` `full_credits` INT(4) DEFAULT 0 NOT NULL; 

ALTER TABLE `tbl_keybatches_keys` CHANGE `purchase_credits` `full_credits` INT(4) DEFAULT 0 NOT NULL; 


