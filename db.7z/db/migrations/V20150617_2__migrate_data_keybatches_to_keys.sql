UPDATE `tbl_keybatches_keys` AS k 
	INNER JOIN ( 
		SELECT `id`,`purchase_credits`,`num_users_per_key`,`trial_credits`,`expires` 
		FROM `tbl_keybatches` 
	) AS batch 
	ON k.`key_batch_id`= batch.`id` 
	SET k.`purchase_credits` = batch.`purchase_credits`, 
		k.`num_users_per_key`= batch.`num_users_per_key`, 
		k.`trial_credits`=batch.`trial_credits`, 
		k.`expires`=batch.`expires`; 
		
ALTER TABLE `tbl_libraries` RENAME TO `tbl_company`;

ALTER TABLE `tbladmin_groups` RENAME TO  `tbl_admingroups`;

ALTER TABLE `tbladmin_groups_libraries` RENAME TO  `tbl_admingroups_companyassign` ;

ALTER TABLE `tbladmin_libraries` RENAME TO  `tbl_adminuser_companyassign` ;

ALTER TABLE `tbladmins_groups` RENAME TO  `tbl_adminuser_groupassign` ;

ALTER TABLE `tblportals` RENAME TO  `tbl_bridge` ;

ALTER TABLE `tblportal_config` RENAME TO  `tbl_bridge_config` ;

ALTER TABLE `tblportal_library_books` RENAME TO  `tbl_bridge_books` ;

ALTER TABLE `tbluser_log` RENAME TO  `tbl_bridge_log` ;

ALTER TABLE `tblusers` RENAME TO  `tbl_bridgeuser` ;

ALTER TABLE `tbluser_roles` RENAME TO  `tbl_bridgeuser_roles` ;

ALTER TABLE `tbluser_sessions` RENAME TO  `tbl_bridgeuser_sessions` ;

ALTER TABLE `tbluser_bookassign` RENAME TO  `tbl_bridgeuser_bookassign` ;

ALTER TABLE `tbluser_keyassign` RENAME TO  `tbl_bridgeuser_keyassign` ;

ALTER TABLE `tbladmins` DROP FOREIGN KEY `tbladmins_ibfk_4`;
ALTER TABLE `tbladmins` RENAME TO  `tbl_adminuser` ;

ALTER TABLE `tbladmin_roles` RENAME TO  `tbl_adminuser_roles` ;

ALTER TABLE `tbladmin_sessions` RENAME TO  `tbl_adminuser_sessions` ;

ALTER TABLE `tbladmin_favorite_portals` RENAME TO  `tbl_adminuser_favoritebridges` ;

ALTER TABLE `tbl_password_resets` RENAME TO  `tbl_adminuser_passwordresets` ;

ALTER TABLE `tbl_bridge_books` DROP FOREIGN KEY `tbl_bridge_books_ibfk_1`;
  
DROP TABLE `tblcache_licenses`;

DROP TABLE `tblfailed_transactions`;

DROP TABLE `tbl_transactions`;

DROP TABLE `tbllogs`;