ALTER TABLE `tbl_bridge_books_cache` ADD `ancillary_id` INT(16)  NULL  DEFAULT NULL  AFTER `concurrency_limit`;
ALTER TABLE `tbl_ancillary` ADD `title` VARCHAR(512)  CHARACTER SET utf8mb4  COLLATE utf8mb4_unicode_ci NULL  DEFAULT NULL AFTER `id`;
ALTER TABLE `tbl_ancillary` ADD `completed` TINYINT(2)  NULL  DEFAULT NULL  AFTER `bridge_id`;
ALTER TABLE `tbl_ancillary` ADD `file_size` INT(11)  NULL  DEFAULT NULL  AFTER `bridge_id`;
ALTER TABLE `tbl_ancillary` CHANGE `mime_type` `mime_type` VARCHAR(256)  CHARACTER SET utf8mb4  COLLATE utf8mb4_unicode_ci  NULL  DEFAULT '';
ALTER TABLE `tbl_ancillary` CHANGE `file_name` `file_name` VARCHAR(512)  CHARACTER SET utf8mb4  COLLATE utf8mb4_unicode_ci  NOT NULL  DEFAULT '';
