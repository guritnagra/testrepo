ALTER TABLE `tbl_bridge` ADD CONSTRAINT `tbl_bridge_ibfk_2` FOREIGN KEY (`bridge_type_id`) REFERENCES `tbl_bridge_types`(`id`); 
