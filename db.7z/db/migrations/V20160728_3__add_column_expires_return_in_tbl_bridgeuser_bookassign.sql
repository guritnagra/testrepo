ALTER TABLE `tbl_bridgeuser_bookassign` 
ADD COLUMN `expires` TIMESTAMP NULL AFTER `bookshelf_code`, 
ADD COLUMN `return_date` TIMESTAMP NULL AFTER `expires`;