ALTER TABLE `tbl_bridge` 
ADD COLUMN `offline_trial_days` INT(4) NULL AFTER `trial_days`, 
ADD COLUMN `offline_trial_expires` TIMESTAMP NULL AFTER `trial_expires`,
ADD COLUMN `offline_rental_days` INT(4) NULL AFTER `rental_days`,
ADD COLUMN `offline_rental_expires` TIMESTAMP NULL AFTER `rental_expires`,
ADD COLUMN `offline_full_days` INT(4) NULL AFTER `full_days`,
ADD COLUMN `offline_full_expires` TIMESTAMP NULL AFTER `full_expires`;