ALTER TABLE `tbl_adminuser` DROP COLUMN `phone`; 

ALTER TABLE `tbl_adminuser_favoritebridges` DROP INDEX `user_id`, ADD INDEX `user_id` (`admin_id`); 