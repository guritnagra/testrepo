ALTER TABLE `tbl_bridge` DROP COLUMN `favorite`; 

ALTER TABLE `tbl_adminuser_favoritebridges` DROP COLUMN `favorite`; 