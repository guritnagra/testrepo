UPDATE `tbl_bridge_config`
SET `deleted`=1
WHERE `key_name` LIKE 'questions.%';