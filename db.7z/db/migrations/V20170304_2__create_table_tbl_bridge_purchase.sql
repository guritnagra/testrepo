CREATE TABLE `tbl_bridge_purchase` (
  `id` INT(10) NOT NULL AUTO_INCREMENT,
  `bridge_id` INT(10) DEFAULT NULL,
  `purchase_name` VARCHAR(64) CHARACTER SET utf8 DEFAULT NULL,
  `purchase_url` VARCHAR(256) CHARACTER SET utf8 DEFAULT NULL,
  `display_pricing` VARCHAR(64) CHARACTER SET utf8 DEFAULT NULL,
  `last_updated` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` TINYINT(2) DEFAULT NULL,
  `version_id` INT(10) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tbl_bridge_purchase_ibfk_1` (`bridge_id`),
  CONSTRAINT `tbl_bridge_purchase_ibfk_1` FOREIGN KEY (`bridge_id`) REFERENCES `tbl_bridge` (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;