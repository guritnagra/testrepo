CREATE TABLE `tbl_job_task`( `id` INT(8) NOT NULL AUTO_INCREMENT, `bridge_id` INT(8) NOT NULL, `bc_tenant_id` INT(8) NOT NULL, `job_status` VARCHAR(64),
 `job_type` VARCHAR(64), `record_type` VARCHAR(64), `error_desc` LONGTEXT,
 `created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 `version_id` INT(11), PRIMARY KEY (`id`) ); 
