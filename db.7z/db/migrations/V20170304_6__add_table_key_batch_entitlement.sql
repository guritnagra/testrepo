CREATE TABLE `tbl_keybatches_entitlements` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `key_batch_id` int(8) DEFAULT NULL,
  `ent_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ent_type` int(8) DEFAULT NULL,
  `ent_credits` int(8) DEFAULT NULL,
  `ent_online_days` int(8) DEFAULT NULL,
  `ent_online_expires` timestamp NULL DEFAULT NULL,
  `ent_is_reusable_credit` int(4) NOT NULL DEFAULT '0',
  `ent_offline_days` int(8) DEFAULT NULL,
  `ent_offline_expires` timestamp NULL DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `expires` timestamp NULL DEFAULT NULL,
  `ent_is_copy_from_online` int(11) NOT NULL DEFAULT '0',
  `version_id` INT(10) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

