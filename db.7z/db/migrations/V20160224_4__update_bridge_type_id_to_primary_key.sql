ALTER TABLE `tbl_bridge_types` CHANGE `id` `id` INT(8) NOT NULL AUTO_INCREMENT, CHANGE `version_id` `version_id` INT(11) DEFAULT 0 NULL, ADD PRIMARY KEY (`id`); 

ALTER TABLE `tbl_bridge_types` CHANGE `type` `type` VARCHAR(48) CHARSET utf8 COLLATE utf8_general_ci NOT NULL; 

