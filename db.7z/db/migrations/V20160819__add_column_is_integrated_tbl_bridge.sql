ALTER TABLE `tbl_bridge` ADD COLUMN `is_integrated` TINYINT(2) DEFAULT 0 NULL AFTER `concurrency_limit`, ADD COLUMN `bc_tenant_id` INT(8) NULL AFTER `is_integrated`; 
