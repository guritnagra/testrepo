ALTER TABLE tblportals CHANGE contact_name contact_name varchar(128) DEFAULT NULL;
ALTER TABLE tblportals CHANGE contact_phone contact_phone varchar(32) DEFAULT NULL;
