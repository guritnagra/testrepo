ALTER TABLE `tbl_adminuser` ADD COLUMN `label` INT(8) DEFAULT 1 NOT NULL AFTER `group_id`, ADD CONSTRAINT `tbl_adminuser_ibfk_4` FOREIGN KEY (`label`) REFERENCES `tbl_adminuser_label`(`id`); 
