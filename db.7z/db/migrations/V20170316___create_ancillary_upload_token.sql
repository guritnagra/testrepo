CREATE TABLE `tbl_ancillary_uploadtoken` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `upload_token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bridge_id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expired` timestamp NULL DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `version_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `bridge_id` (`bridge_id`),
  CONSTRAINT `tbl_ancillary_uploadtoken_fk1` FOREIGN KEY (`bridge_id`) REFERENCES `tbl_bridge` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;