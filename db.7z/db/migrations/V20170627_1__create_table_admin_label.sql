CREATE TABLE `tbl_adminuser_label`( `id` INT(8) NOT NULL AUTO_INCREMENT, `label` VARCHAR(64) NOT NULL, `version_id` INT(11) DEFAULT 0, PRIMARY KEY (`id`) ); 
