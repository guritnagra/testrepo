ALTER TABLE  `tbl_bridge_log` ADD COLUMN `bridge_id` INT(8) NULL AFTER `user_id`, ADD CONSTRAINT `tbl_bridge_log_ibfk_2` FOREIGN KEY (`bridge_id`) REFERENCES `tbl_bridge`(`id`); 
