INSERT INTO tbladmin_roles (id, name, code) VALUES (3, 'viewonly', 3);
UPDATE tbladmins SET role_id='2' WHERE id='1';
UPDATE tbladmin_roles SET name='superAdmin' WHERE id='2';
