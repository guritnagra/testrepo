CREATE TABLE `tbl_bridge_books_pricing`( `id` INT(16) NOT NULL AUTO_INCREMENT, `book_cache_id` INT(16) NOT NULL, `sku` VARCHAR(32), 
`digital_price` VARCHAR(32), `publisher_price` VARCHAR(32), `rental_type` VARCHAR(32), `deleted` TINYINT(4) DEFAULT 0, `version_id` TINYINT(4) DEFAULT 11, PRIMARY KEY (`id`) ); 

 


