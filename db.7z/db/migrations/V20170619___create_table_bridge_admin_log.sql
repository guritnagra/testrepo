CREATE TABLE `tbl_bridge_admin_log` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `admin_id` int(8) DEFAULT NULL,
  `bridge_id` int(8) DEFAULT NULL,
  `action` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext COLLATE utf8mb4_unicode_ci,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `version_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `bridge_admin_log_admin_id` (`admin_id`),
  KEY `bridge_admin_log_action` (`action`),
  KEY `tbl_bridge_admin_log_ibfk_2` (`bridge_id`),
  CONSTRAINT `tbl_bridge_admin_log_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `tbl_adminuser` (`id`),
  CONSTRAINT `tbl_bridge_admin_log_ibfk_2` FOREIGN KEY (`bridge_id`) REFERENCES `tbl_bridge` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;