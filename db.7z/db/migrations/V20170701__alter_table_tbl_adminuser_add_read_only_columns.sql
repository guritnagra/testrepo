ALTER TABLE `tbl_adminuser` ADD COLUMN `is_read_only` TINYINT(1) DEFAULT 0 NOT NULL AFTER `edit_access`;
