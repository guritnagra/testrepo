UPDATE `tbl_bridge_log` SET `action`='BOOK_FULL'
WHERE `action` LIKE 'ACTIVATE_BOOK';

UPDATE `tbl_bridge_log` SET `action`='BOOK_LAUNCH'
WHERE `action` LIKE 'LAUNCH_BOOK';

UPDATE `tbl_bridge_log` SET `action`='CART_FULL'
WHERE `action` LIKE 'PURCHASE_EBOOK';


UPDATE `tbl_bridge_log` SET `action`='BOOK_PRINT'
WHERE `action` LIKE 'PURCHASE_TEXTBOOK';

UPDATE `tbl_bridge_log` SET `action`='CART_RENT'
WHERE `action` LIKE 'RENTAL_EBOOK';

UPDATE `tbl_bridge_log` SET `action`='BOOK_FULL'
WHERE `action` LIKE 'LICENSE_BOOK';