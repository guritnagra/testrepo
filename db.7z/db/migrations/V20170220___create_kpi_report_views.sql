CREATE VIEW v_bridge_count AS
SELECT COUNT(*) AS bridge_count
FROM `tbl_bridge`
WHERE deleted=0
;

CREATE VIEW v_bridge_user_count AS
SELECT COUNT(DISTINCT email) AS bridge_user_count
FROM `tbl_bridgeuser`
WHERE deleted IS NULL
;

CREATE VIEW v_admin_user_count AS
SELECT COUNT(DISTINCT email) AS admin_user_count
FROM `tbl_adminuser`
WHERE deleted=0
;

CREATE VIEW v_unique_asset_count AS
SELECT COUNT(DISTINCT vbid) AS unique_asset_count
FROM `tbl_bridge_books_cache`
WHERE deleted=0
;

CREATE VIEW v_activation_count AS
SELECT COUNT(*) AS activation_count
FROM `tbl_bridgeuser_bookassign`
;

CREATE VIEW v_kpi_data AS 
SELECT 1 AS id,  
`bridges`.`bridge_count` AS bridge_sites,
`bridgeusers`.`bridge_user_count` AS bridge_users,
`adminusers`.`admin_user_count` AS bridge_admins,
`unique_assets`.`unique_asset_count` AS unique_assets,
`activations`.`activation_count` AS activations,
0 AS deleted,
0 AS version_id
FROM `v_bridge_count` bridges,
`v_bridge_user_count` bridgeusers,
`v_admin_user_count` adminusers,
`v_unique_asset_count` unique_assets,
`v_activation_count` activations
;

