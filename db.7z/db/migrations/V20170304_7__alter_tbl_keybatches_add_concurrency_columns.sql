ALTER TABLE `tbl_keybatches` ADD COLUMN `count` INT(8) NULL AFTER `full_credits`,
 ADD COLUMN `concurrency_ent_name` VARCHAR(256) NULL AFTER `concurrency_credits`,
 ADD COLUMN `concurrency_ent_type` INT(4) NULL AFTER `concurrency_ent_name`,
 ADD COLUMN `concurrency_days` INT(4) NULL AFTER `concurrency_ent_type`,
 ADD COLUMN `concurrency_expires` TIMESTAMP NULL AFTER `concurrency_days`,
 ADD COLUMN `offline_concurrency_days` INT(4) NULL AFTER `concurrency_expires`,
 ADD COLUMN `offline_concurrency_expires` TIMESTAMP NULL AFTER `offline_concurrency_days`; 
