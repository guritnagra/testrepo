ALTER TABLE `tbl_bridge_books_cache` CHANGE `last_modified_date` `last_updated` TIMESTAMP  NULL  DEFAULT NULL;
ALTER TABLE `tbl_bridge_books_cache` CHANGE `updated_date` `bridge_update_date` TIMESTAMP  NULL  DEFAULT CURRENT_TIMESTAMP  ON UPDATE CURRENT_TIMESTAMP;

