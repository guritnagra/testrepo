ALTER TABLE `tbl_bridgeuser` DROP COLUMN `password`, DROP COLUMN `phone`, DROP COLUMN `promo_code`, DROP COLUMN `survey_subscription`, DROP COLUMN `question_id`, DROP COLUMN `question_response`; 
