ALTER TABLE `tbl_bridge_books_cache` ADD `category` VARCHAR(32)  CHARACTER SET utf8mb4  COLLATE utf8mb4_general_ci  NOT NULL  DEFAULT 'OTHER'  AFTER `file_type`;
ALTER TABLE `tbl_bridge_books_cache` CHANGE `file_type` `file_type` VARCHAR(32)  CHARACTER SET utf8mb4  COLLATE utf8mb4_general_ci  NOT NULL  DEFAULT 'OTHER';

