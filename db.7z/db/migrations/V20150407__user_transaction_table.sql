CREATE TABLE tbluser_log (
  id int(8) NOT NULL AUTO_INCREMENT,
  user_id int(8) DEFAULT NULL,
  action varchar(45) DEFAULT NULL,
  value varchar(128) DEFAULT NULL,
  data text,
  timestamp timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX(user_id),
  INDEX(action),
  CONSTRAINT FOREIGN KEY (user_id) REFERENCES tblusers (id)
);