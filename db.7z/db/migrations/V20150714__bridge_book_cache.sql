CREATE TABLE `tbl_bridge_books_cache` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `bridge_id` int(8) NOT NULL,
  `api_key` varchar(32) DEFAULT NULL,
  `vbid` varchar(32) DEFAULT NULL,
  `ebook_isbn` varchar(32) DEFAULT NULL,
  `textbook_isbn` varchar(32) DEFAULT NULL,
  `title` varchar(512) DEFAULT NULL,
  `description` text,
  `cover_image_url` varchar(512) DEFAULT NULL,
  `author` varchar(512) DEFAULT NULL,
  `last_updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(4) DEFAULT '0',
  `version_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tbl_bridge_books_cache_ibfk_1` (`bridge_id`),
  CONSTRAINT `tbl_bridge_books_cache_ibfk_1` FOREIGN KEY (`bridge_id`) REFERENCES `tbl_bridge` (`id`)
);
