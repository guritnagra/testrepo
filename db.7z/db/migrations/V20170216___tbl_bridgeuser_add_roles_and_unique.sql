ALTER TABLE `tbl_bridgeuser` ADD `role_id` INT(11)  NOT NULL  DEFAULT '1'  AFTER `tenant_user_id`;
ALTER TABLE `tbl_bridgeuser` ADD CONSTRAINT `fk_bridgeuser_bridgeuser_role` FOREIGN KEY (`role_id`) REFERENCES `tbl_bridgeuser_roles` (`id`);
ALTER TABLE `tbl_bridgeuser` DROP INDEX `guid`;
ALTER TABLE `tbl_bridgeuser` ADD UNIQUE INDEX `bridge_id_guid_roles` (`bridge_id`, `guid`, `role_id`);



