ALTER TABLE `tbl_bridge` ADD COLUMN `purchase_eText_url` VARCHAR(256) NULL AFTER `purchase_textbook_url`; 

UPDATE `tbl_bridge` tblb
INNER JOIN `tbl_bridge_config` tblc ON tblb.id = tblc.`bridge_id`
SET tblb.`purchase_eText_url`= (SELECT tblc.`key_val`)
WHERE tblc.`key_name` LIKE 'purchasing.eText.url'; 

ALTER TABLE `tbl_bridge` DROP COLUMN `purchase_eText_url`; 

ALTER TABLE `tbl_bridge` CHANGE `purchase_url` `eText_url` VARCHAR(256) CHARSET latin1 COLLATE latin1_swedish_ci NULL, CHANGE `purchase_textbook_url` `textbook_url` VARCHAR(256) CHARSET latin1 COLLATE latin1_swedish_ci NULL; 

UPDATE `tbl_bridge` tblb
INNER JOIN `tbl_bridge_config` tblc ON tblb.id = tblc.`bridge_id`
SET tblb.`eText_url`= (SELECT tblc.`key_val`)
WHERE tblc.`key_name` LIKE 'purchasing.eText.url';


DELETE FROM `tbl_bridge_config`
WHERE `key_name` LIKE 'purchasing.eText.url';


UPDATE `tbl_bridge` tblb
INNER JOIN `tbl_bridge_config` tblc ON tblb.id = tblc.`bridge_id`
SET tblb.`rental_url`= (SELECT tblc.`key_val`)
WHERE tblc.`key_name` LIKE 'purchasing.rental.url';

DELETE FROM `tbl_bridge_config`
WHERE `key_name` LIKE 'purchasing.rental.url';

UPDATE `tbl_bridge` tblb
INNER JOIN `tbl_bridge_config` tblc ON tblb.id = tblc.`bridge_id`
SET tblb.`textbook_url`= (SELECT tblc.`key_val`)
WHERE tblc.`key_name` LIKE 'purchasing.textBook.url';

DELETE FROM `tbl_bridge_config`
WHERE `key_name` LIKE 'purchasing.textBook.url';