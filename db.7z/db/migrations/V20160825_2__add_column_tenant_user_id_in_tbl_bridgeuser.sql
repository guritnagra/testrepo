ALTER TABLE `tbl_bridgeuser` ADD COLUMN `tenant_user_id` VARCHAR(64) NULL AFTER `source_id`;
