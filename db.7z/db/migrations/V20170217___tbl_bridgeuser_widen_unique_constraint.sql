ALTER TABLE `tbl_bridgeuser` DROP INDEX `bridge_id_guid_roles`;
ALTER TABLE `tbl_bridgeuser` ADD UNIQUE INDEX `unique_bridge_user` (`bridge_id`, `guid`, `role_id`, `tenant_user_id`);

