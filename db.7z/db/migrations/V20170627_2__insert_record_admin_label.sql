INSERT INTO `tbl_adminuser_label` (`id`, `label`) VALUES ('1', 'VST Admin'); 
INSERT INTO `tbl_adminuser_label` (`id`, `label`) VALUES ('2', 'Instructor'); 