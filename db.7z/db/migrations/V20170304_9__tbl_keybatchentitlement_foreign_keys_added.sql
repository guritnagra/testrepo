ALTER TABLE `tbl_keybatches_entitlements` 
ADD CONSTRAINT `tbl_keybatches_entitlement_ibfk_1` FOREIGN KEY (`key_batch_id`) REFERENCES `tbl_keybatches`(`id`), 
ADD CONSTRAINT `tbl_keybatches_entitlement_ibfk_2` FOREIGN KEY (`ent_type`) REFERENCES `tbl_code_types`(`id`); 

