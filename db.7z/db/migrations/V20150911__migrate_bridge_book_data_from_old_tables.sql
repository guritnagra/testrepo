ALTER TABLE  `tbl_bridge_books` ADD COLUMN `tmp_book_vbid_id` VARCHAR(45) NULL AFTER `book_vbid_id`, CHANGE `last_modified_date` `last_modified_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL; 

ALTER TABLE  `tbl_bridge_books` CHANGE `book_vbid_id` `book_vbid_id` INT(45) NOT NULL; 

UPDATE `tbl_bridge_books` tbb
INNER JOIN `tblcache_library_books` tclb
ON tbb.`book_vbid_id` = tclb.id 
SET tbb.`tmp_book_vbid_id` = tclb.`vbid`;

ALTER TABLE  `tbl_bridge_books` DROP INDEX `portal_id`, DROP INDEX `book_id`; 

ALTER TABLE  `tbl_bridge_books` DROP COLUMN `book_vbid_id`, DROP INDEX `PIndex`, ADD INDEX `PIndex` (`bridge_id`); 

ALTER TABLE `tbl_bridge_books` CHANGE `tmp_book_vbid_id` `book_vbid_id` VARCHAR(45) CHARSET latin1 COLLATE latin1_swedish_ci NOT NULL; 