RENAME TABLE `tbl_groupassets` TO `tbl_bridgegroups_books`; 
RENAME TABLE `tbl_groupusers` TO `tbl_bridgegroups_bridgeuser`; 


