ALTER TABLE `tbl_bridgeuser_bookassign` ADD COLUMN `used_type` INT NULL AFTER `from_stack_key_credit`; 

ALTER TABLE `tbl_bridgeuser_bookassign` CHANGE `used_type` `used_type` VARCHAR(50) NULL; 