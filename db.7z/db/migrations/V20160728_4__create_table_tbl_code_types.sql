CREATE TABLE `tbl_code_types`( `id` INT(4) NOT NULL AUTO_INCREMENT,
 `type` VARCHAR(32) NOT NULL,
 `version_id` INT(11) DEFAULT 0, PRIMARY KEY (`id`) );