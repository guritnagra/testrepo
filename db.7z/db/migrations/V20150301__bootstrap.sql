-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: dbstack
-- ------------------------------------------------------
-- Server version	5.6.22-log

--
-- Table structure for table `tbladmin_roles`
--
CREATE TABLE `tbladmin_roles` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `code` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`code`)
);

--
-- Table structure for table `tbluser_roles`
--
CREATE TABLE `tbluser_roles` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `code` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`code`)
);

--
-- Table structure for table `tbl_libraries`
--
CREATE TABLE `tbl_libraries` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `apikey` varchar(32) NOT NULL,
  `type` varchar(16) DEFAULT 'INSTITUTIONAL',
  `creator_id` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
);

--
-- Table structure for table `tblportals`
--
CREATE TABLE `tblportals` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `contact_name` varchar(64) DEFAULT NULL,
  `contact_email` varchar(128) DEFAULT NULL,
  `contact_phone` varchar(16) DEFAULT NULL,
  `library_id` int(8) NOT NULL DEFAULT '0',
  `domain` varchar(64) NOT NULL,
  `favorite` tinyint(1) DEFAULT '0',
  `language` varchar(8) NOT NULL DEFAULT 'en',
  `last_editor` int(8) DEFAULT '0',
  `last_edit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pending_approval` tinyint(2) DEFAULT '0',
  `purchase_credits` int(4) DEFAULT NULL,
  `trial_credits` int(4) DEFAULT NULL,
  `show_all_books` tinyint(1) DEFAULT '0',
  `purchase_promo_code` varchar(64) DEFAULT NULL,
  `rental_promo_code` varchar(64) DEFAULT NULL,
  `purchase_url` varchar(256) DEFAULT NULL,
  `rental_url` varchar(256) DEFAULT NULL,
  `purchase_textbook_url` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`library_id`),
  KEY `library_id` (`library_id`),
  KEY `last_editor` (`last_editor`),
  KEY `PIndex` (`id`,`library_id`,`domain`),
  CONSTRAINT `tblportals_ibfk_1` FOREIGN KEY (`library_id`) REFERENCES `tbl_libraries` (`id`)
);

--
-- Table structure for table `tbladmin_groups`
--
CREATE TABLE `tbladmin_groups` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
);

--
-- Table structure for table `tbladmins`
--
CREATE TABLE `tbladmins` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(64) DEFAULT NULL,
  `last_name` varchar(64) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `role_id` int(4) NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `group_id` int(8) NOT NULL DEFAULT '0',
  `password` varchar(32) NOT NULL,
  `phone` varchar(16) DEFAULT NULL,
  `creator_id` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `role` (`role_id`),
  KEY `group_id` (`group_id`),
  KEY `creator_id` (`creator_id`),
  KEY `PIndex` (`email`,`id`),
  CONSTRAINT `tbladmins_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `tbladmin_groups` (`id`),
  CONSTRAINT `tbladmins_ibfk_3` FOREIGN KEY (`role_id`) REFERENCES `tbladmin_roles` (`id`)
);

--
-- Table structure for table `tblusers`
--
CREATE TABLE `tblusers` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(64) DEFAULT NULL,
  `last_name` varchar(64) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `guid` varchar(64) DEFAULT NULL,
  `access_token` varchar(64) DEFAULT NULL,
  `portal_id` int(8) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `password` varchar(32) NOT NULL,
  `phone` varchar(16) DEFAULT NULL,
  `promo_code` tinyint(1) DEFAULT '0',
  `survey_subscription` tinyint(1) DEFAULT '0',
  `question_id` int(8) DEFAULT '-1',
  `question_response` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`,`portal_id`),
  KEY `portal_id` (`portal_id`),
  KEY `PIndex` (`email`,`id`),
  CONSTRAINT `tblusers_ibfk_1` FOREIGN KEY (`portal_id`) REFERENCES `tblportals` (`id`)
);

--
-- Table structure for table `tbl_keybatches`
--
CREATE TABLE `tbl_keybatches` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `portal_id` int(8) NOT NULL,
  `role_id` int(4) NOT NULL,
  `notes` varchar(256) DEFAULT NULL,
  `purchase_credits` int(4) NOT NULL DEFAULT '0',
  `num_users_per_key` int(4) NOT NULL DEFAULT '0',
  `trial_credits` int(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `creator_id` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `portal_id` (`portal_id`),
  KEY `creator_id` (`creator_id`),
  KEY `role_id` (`role_id`),
  KEY `KBIndex` (`id`,`portal_id`),
  CONSTRAINT `tbl_keybatches_ibfk_1` FOREIGN KEY (`portal_id`) REFERENCES `tblportals` (`id`),
  CONSTRAINT `tbl_keybatches_ibfk_2` FOREIGN KEY (`creator_id`) REFERENCES `tbladmins` (`id`),
  CONSTRAINT `tbl_keybatches_ibfk_3` FOREIGN KEY (`role_id`) REFERENCES `tbluser_roles` (`id`)
);

--
-- Table structure for table `tbl_keys`
--
CREATE TABLE `tbl_keys` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `key_code` varchar(32) DEFAULT NULL,
  `key_batch_id` int(8) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keycode` (`key_code`),
  KEY `key_batch` (`key_batch_id`),
  KEY `KBIndex` (`key_batch_id`,`key_code`),
  CONSTRAINT `tbl_keys_ibfk_3` FOREIGN KEY (`key_batch_id`) REFERENCES `tbl_keybatches` (`id`)
);

--
-- Table structure for table `tbl_password_resets`
--
CREATE TABLE `tbl_password_resets` (
  `user_id` int(11) NOT NULL,
  `token` varchar(64) DEFAULT NULL,
  `used` tinyint(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `PIndex` (`user_id`)
);

--
-- Table structure for table `tbl_transactions`
--
CREATE TABLE `tbl_transactions` (
  `user_id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` varchar(256) NOT NULL,
  KEY `PIndex` (`user_id`)
);



--
-- Table structure for table `tbladmin_groups_libraries`
--
CREATE TABLE `tbladmin_groups_libraries` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `group_id` int(4) NOT NULL,
  `library_id` int(8) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`library_id`),
  KEY `library_id` (`library_id`),
  KEY `PIndex` (`group_id`,`library_id`),
  CONSTRAINT `tbladmin_groups_libraries_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `tbladmin_groups` (`id`),
  CONSTRAINT `tbladmin_groups_libraries_ibfk_2` FOREIGN KEY (`library_id`) REFERENCES `tbl_libraries` (`id`)
);

--
-- Table structure for table `tbladmin_libraries`
--
CREATE TABLE `tbladmin_libraries` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `user_id` int(8) DEFAULT NULL,
  `library_id` int(8) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_id` (`user_id`,`library_id`),
  KEY `library_id` (`library_id`),
  KEY `PIndex` (`user_id`,`library_id`),
  CONSTRAINT `tbladmin_libraries_ibfk_1` FOREIGN KEY (`library_id`) REFERENCES `tbl_libraries` (`id`),
  CONSTRAINT `tbladmin_libraries_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `tbladmins` (`id`)
);


--
-- Table structure for table `tbladmin_sessions`
--
CREATE TABLE `tbladmin_sessions` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `user_id` int(8) NOT NULL DEFAULT '0',
  `session_id` varchar(64) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_access` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `user_id` (`user_id`),
  KEY `PIndex` (`user_id`,`session_id`,`last_access`),
  CONSTRAINT `tbladmin_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbladmins` (`id`)
);



--
-- Table structure for table `tblcache_library_books`
--
CREATE TABLE `tblcache_library_books` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `library_id` int(8) NOT NULL,
  `vbid` varchar(32) DEFAULT NULL,
  `ebook_isbn` varchar(32) DEFAULT NULL,
  `textbook_isbn` varchar(32) DEFAULT NULL,
  `name` varchar(128) DEFAULT NULL,
  `description` varchar(512) DEFAULT NULL,
  `cover_image_url` varchar(64) DEFAULT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `author` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `library_id` (`library_id`,`vbid`),
  KEY `PIndex` (`vbid`,`library_id`),
  CONSTRAINT `tblcache_library_books_ibfk_1` FOREIGN KEY (`library_id`) REFERENCES `tbl_libraries` (`id`)
);

--
-- Table structure for table `tblcache_licenses`
--
CREATE TABLE `tblcache_licenses` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `sku` varchar(32) NOT NULL,
  `user_id` int(16) NOT NULL,
  `code` varchar(32) DEFAULT NULL,
  `expires` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku` (`sku`,`user_id`),
  KEY `user_id` (`user_id`),
  KEY `PIndex` (`sku`,`user_id`),
  CONSTRAINT `tblcache_licenses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tblusers` (`id`)
);

--
-- Table structure for table `tblconfig`
--
CREATE TABLE `tblconfig` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `key_name` varchar(255) NOT NULL,
  `key_val` varchar(512) DEFAULT NULL,
  `portal_id` int(8) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `portal_id` (`portal_id`,`key_name`),
  KEY `PIndex` (`key_name`)
);

--
-- Table structure for table `tblfailed_transactions`
--
CREATE TABLE `tblfailed_transactions` (
  `thread` varchar(32) NOT NULL,
  `input_json` varchar(512) NOT NULL,
  `input_params` varchar(128) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
);

--
-- Table structure for table `tblkey_assign`
--
CREATE TABLE `tblkey_assign` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `user_id` int(8) NOT NULL,
  `key_id` int(8) NOT NULL,
  `activation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`key_id`),
  KEY `key_id` (`key_id`),
  KEY `PIndex` (`key_id`,`user_id`),
  CONSTRAINT `tblkey_assign_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tblusers` (`id`),
  CONSTRAINT `tblkey_assign_ibfk_2` FOREIGN KEY (`key_id`) REFERENCES `tbl_keys` (`id`)
);

--
-- Table structure for table `tbllogs`
--
CREATE TABLE `tbllogs` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `portal_id` int(8) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `action` varchar(32) DEFAULT NULL,
  `value` varchar(64) DEFAULT NULL,
  `data` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `portal_id` (`portal_id`),
  CONSTRAINT `tbllogs_ibfk_1` FOREIGN KEY (`portal_id`) REFERENCES `tblportals` (`id`)
);

--
-- Table structure for table `tblportal_library_books`
--
CREATE TABLE `tblportal_library_books` (
  `portal_id` int(8) NOT NULL,
  `book_id` int(16) NOT NULL,
  `is_selected` tinyint(1) DEFAULT '1',
  UNIQUE KEY `portal_id` (`portal_id`,`book_id`),
  KEY `book_id` (`book_id`),
  KEY `PIndex` (`portal_id`,`book_id`),
  CONSTRAINT `tblportal_library_books_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `tblcache_library_books` (`id`),
  CONSTRAINT `tblportal_library_books_ibfk_2` FOREIGN KEY (`portal_id`) REFERENCES `tblportals` (`id`)
);

--
-- Table structure for table `tbluser_bookassign`
--
CREATE TABLE `tbluser_bookassign` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `key_assign_id` int(8) NOT NULL,
  `vbid` varchar(64) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `from_stack_key_credit` tinyint(1) DEFAULT '1',
  `last_access` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vbid` (`vbid`,`key_assign_id`),
  KEY `key_id` (`key_assign_id`),
  KEY `PIndex` (`vbid`,`key_assign_id`),
  CONSTRAINT `tbluser_bookassign_ibfk_2` FOREIGN KEY (`key_assign_id`) REFERENCES `tblkey_assign` (`id`)
);

--
-- Table structure for table `tbluser_sessions`
--
CREATE TABLE `tbluser_sessions` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `user_id` int(8) NOT NULL DEFAULT '0',
  `session_id` varchar(64) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_access` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `user_id` (`user_id`),
  KEY `PIndex` (`user_id`,`session_id`,`last_access`),
  CONSTRAINT `tbluser_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tblusers` (`id`)
);



-- Dump completed on 2015-03-06 18:25:23
