CREATE TABLE tbladmin_favorite_portals (
  id int(8) NOT NULL AUTO_INCREMENT,
  user_id int(8) DEFAULT NULL,
  portal_id int(8) DEFAULT NULL,
  favorite tinyint(1) DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY (user_id,portal_id),
  CONSTRAINT FOREIGN KEY (portal_id) REFERENCES tblportals (id),
  CONSTRAINT FOREIGN KEY (user_id) REFERENCES tbladmins (id)
);

ALTER TABLE tblportal_library_books CHANGE COLUMN is_selected is_selected tinyint(1) DEFAULT NULL;
ALTER TABLE tbluser_log CHANGE COLUMN timestamp created timestamp NULL DEFAULT CURRENT_TIMESTAMP;
RENAME TABLE tblkey_assign TO tbluser_keyassign;
RENAME TABLE tblconfig TO tblportal_config;