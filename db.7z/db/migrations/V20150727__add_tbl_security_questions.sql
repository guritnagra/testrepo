CREATE TABLE `tbl_security_questions`( `id` INT(8) NOT NULL AUTO_INCREMENT, `text` VARCHAR(256), PRIMARY KEY (`id`) ); 

ALTER TABLE `tbl_security_questions` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `text`; 

INSERT INTO `tbl_security_questions` (`text`) VALUES ('What is your mother\'s maiden name?'); 
INSERT INTO  `tbl_security_questions` (`text`) VALUES ('What is your Student ID number?');
INSERT INTO  `tbl_security_questions` (`text`) VALUES ('What is your favorite color?'); 
INSERT INTO `tbl_security_questions` (`text`) VALUES ('In what city were you born?'); 
INSERT INTO `tbl_security_questions` (`text`) VALUES ('What is your pet\'s name?'); 
