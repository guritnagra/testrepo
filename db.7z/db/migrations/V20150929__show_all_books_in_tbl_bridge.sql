UPDATE `tbl_bridge`
SET `show_all_books`=0;

ALTER TABLE `tbl_bridge` CHANGE `show_all_books` `show_all_books` TINYINT(1) DEFAULT 0 NOT NULL; 