INSERT INTO `tbl_bridgegroups`(`name`,`bridge_id`,`created_by`,`created_date`,`modified_by`,`modified_date`,`deleted`)
SELECT 'Universal Assets',id,1,NOW(),1,NOW(),0 FROM `tbl_bridge`;

INSERT INTO `tbl_bridgegroups_books`(`group_id`,`vbid`,`is_selected`)
SELECT groups.id,books.`book_vbid_id`,books.`is_selected` FROM `tbl_bridge_books` books
INNER JOIN `tbl_bridgegroups` groups ON groups.`bridge_id`= books.`bridge_id` AND groups.`name` LIKE '%Universal Assets%';