CREATE TABLE `tbl_bridgeroster_log`( `id` INT(8) NOT NULL AUTO_INCREMENT, `bridge_id` INT(8) NOT NULL,
 `file_type` VARCHAR(64) NOT NULL, `file_url` VARCHAR(256) NOT NULL, `status` VARCHAR(64),
`created` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, `created_by` INT(8), `version_id` INT(11), PRIMARY KEY (`id`) ); 



