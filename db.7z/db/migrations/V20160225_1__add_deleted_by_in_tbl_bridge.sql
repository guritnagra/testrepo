ALTER TABLE `tbl_bridge` ADD COLUMN `deleted_by` int(8) NULL AFTER `deleted`;



