ALTER TABLE `tbl_bridgegroups` ADD COLUMN `course_id` VARCHAR(64) NULL AFTER `expired_date`,ADD COLUMN `is_active` TINYINT(2) DEFAULT 1 NULL AFTER `source_id`;


