ALTER TABLE `tbl_keybatches_keys` 
ADD COLUMN `concurrency_credits` INT(4) DEFAULT 0 NULL AFTER `rental_credits`;