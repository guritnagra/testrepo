UPDATE `tbl_bridge_config`
SET `deleted` = 1 
WHERE `bridge_id` NOT IN (SELECT `id` FROM `tbl_bridge`) OR `bridge_id` IS NULL;