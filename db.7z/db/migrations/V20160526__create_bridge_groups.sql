CREATE TABLE `tbl_bridgegroups`( 
    `id` INT NOT NULL AUTO_INCREMENT, 
    `name` VARCHAR(256), 
    `bridge_id` INT NOT NULL, 
    `start_date` TIMESTAMP, 
    `expired_date` TIMESTAMP, 
    `created_by` INT NOT NULL, 
    `created_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
    `modified_by` INT NOT NULL, 
    `modified_date` TIMESTAMP DEFAULT '2016-07-01 00:00:00', 
    `deleted` TINYINT DEFAULT 0, 
    `deleted_by` INT, 
    `deleted_date` TIMESTAMP, 
    `version_id` INT DEFAULT 0, 
    PRIMARY KEY (`id`), 
    
    CONSTRAINT `tbl_bridgegroups_ibfk_1` FOREIGN KEY (`bridge_id`) REFERENCES `tbl_bridge`(`id`), 
    CONSTRAINT `tbl_bridgegroups_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `tbl_adminuser`(`id`), 
    CONSTRAINT `tbl_bridgegroups_ibfk_3` FOREIGN KEY (`modified_by`) REFERENCES `tbl_adminuser`(`id`), 
    CONSTRAINT `tbl_bridgegroups_ibfk_4` FOREIGN KEY (`deleted_by`) REFERENCES `tbl_adminuser`(`id`) 
) ENGINE=INNODB; 


ALTER TABLE `tbl_bridgegroups` CHANGE `start_date` `start_date` TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NULL, 
CHANGE `expired_date` `expired_date` TIMESTAMP NULL, 
CHANGE `deleted_date` `deleted_date` TIMESTAMP NULL; 


CREATE TABLE `tbl_groupusers`( 
    `id` INT NOT NULL AUTO_INCREMENT, 
    `group_id` INT NOT NULL, `user_id` INT NOT NULL, 
    `is_selected` TINYINT NOT NULL DEFAULT 1, 
    `version_id` INT DEFAULT 0, PRIMARY KEY (`id`) 
) ENGINE=INNODB; 

ALTER TABLE `tbl_groupusers` ADD CONSTRAINT `tbl_groupusers_fk1` FOREIGN KEY (`group_id`) REFERENCES `tbl_bridgegroups`(`id`), 
ADD CONSTRAINT `tbl_groupusers_fk2` FOREIGN KEY (`user_id`) REFERENCES `tbl_bridgeuser`(`id`); 


CREATE TABLE `tbl_groupassets`( 
    `id` INT NOT NULL AUTO_INCREMENT, `group_id` INT NOT NULL, `vbid` VARCHAR(32) NOT NULL, 
    `is_selected` TINYINT NOT NULL DEFAULT 1, 
    `version_id` INT DEFAULT 0, 
    PRIMARY KEY (`id`), 
    UNIQUE INDEX `unique` (`group_id`, `vbid`, `is_selected`) 
)ENGINE=INNODB;; 
