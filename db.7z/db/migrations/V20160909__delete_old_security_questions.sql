DELETE FROM `tbl_security_questions` WHERE id=1 AND TEXT = 'What is your mother\'s maiden name?';
DELETE FROM `tbl_security_questions` WHERE id=2 AND TEXT = 'What is your Student ID number?';
DELETE FROM `tbl_security_questions` WHERE id=3 AND TEXT = 'What is your favorite color?';
DELETE FROM `tbl_security_questions` WHERE id=4 AND TEXT = 'In what city were you born?';
DELETE FROM `tbl_security_questions` WHERE id=5 AND TEXT = 'What is your pet\'s name?';