CREATE TABLE `tbl_bridge_login_attempt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) DEFAULT NULL,
  `ip_address` varchar(64) DEFAULT NULL,
  `last_success_time` timestamp NULL DEFAULT NULL,
  `last_failure_time` timestamp NULL DEFAULT NULL,
  `failure_count` int(11) NOT NULL DEFAULT '0',
  `version_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_username` (`username`)
) 
