ALTER TABLE `tbl_bridge` ADD COLUMN `defer_sign_in` TINYINT(4) DEFAULT 0 NULL AFTER `password`, 
ADD COLUMN `keys_required` TINYINT(4) NULL AFTER `defer_sign_in`; 
