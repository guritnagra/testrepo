ALTER TABLE `tbl_bridgeuser` ADD COLUMN `promotion_subscription` TINYINT DEFAULT 0 NULL AFTER `bridge_id`, 
ADD COLUMN `survey_subscription` TINYINT DEFAULT 0 NULL AFTER `promotion_subscription`; 
