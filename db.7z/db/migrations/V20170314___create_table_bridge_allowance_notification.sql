CREATE TABLE `tbl_bridge_allowance_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bridge_id` int(11) NOT NULL,
  `last_notification` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `version_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tbl_bridge_allowance_notification_ibfk_1` (`bridge_id`),
  CONSTRAINT `tbl_bridge_allowance_notification_ibfk_1` FOREIGN KEY (`bridge_id`) REFERENCES `tbl_bridge` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

