ALTER TABLE `tbl_admingroups_companyassign` DROP FOREIGN KEY `tbl_admingroups_companyassign_ibfk_2`; 
ALTER TABLE `tbl_admingroups_companyassign` CHANGE `library_id` `company_id` INT(8) NOT NULL; 
ALTER TABLE `tbl_admingroups_companyassign` ADD CONSTRAINT `tbl_admingroups_companyassign_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `tbl_company`(`id`); 

ALTER TABLE `tbl_adminuser_favoritebridges` DROP FOREIGN KEY `tbl_adminuser_favoritebridges_ibfk_1`; 
ALTER TABLE `tbl_adminuser_favoritebridges` CHANGE `portal_id` `bridge_id` INT(8) NULL; 
ALTER TABLE `tbl_adminuser_favoritebridges` ADD CONSTRAINT `tbl_adminuser_favoritebridges_ibfk_1` FOREIGN KEY (`bridge_id`) REFERENCES `tbl_bridge`(`id`); 


ALTER TABLE `tbl_adminuser_favoritebridges` DROP FOREIGN KEY `tbl_adminuser_favoritebridges_ibfk_2`; 
ALTER TABLE `tbl_adminuser_favoritebridges` CHANGE `user_id` `admin_id` INT(8) NULL;
ALTER TABLE `tbl_adminuser_favoritebridges` ADD CONSTRAINT `tbl_adminuser_favoritebridges_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `tbl_adminuser`(`id`); 


ALTER TABLE `tbl_adminuser_companyassign` DROP FOREIGN KEY `tbl_adminuser_companyassign_ibfk_2`; 
ALTER TABLE `tbl_adminuser_companyassign` CHANGE `user_id` `admin_id` INT(8) NOT NULL;
ALTER TABLE `tbl_adminuser_companyassign` ADD CONSTRAINT `tbl_adminuser_companyassign_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `tbl_adminuser`(`id`); 


ALTER TABLE `tbl_adminuser_companyassign` DROP FOREIGN KEY `tbl_adminuser_companyassign_ibfk_1`; 
ALTER TABLE `tbl_adminuser_companyassign` CHANGE `library_id` `company_id` INT(8) NOT NULL; 
ALTER TABLE `tbl_adminuser_companyassign` ADD CONSTRAINT `tbl_adminuser_companyassign_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `tbl_company`(`id`); 


ALTER TABLE `tbl_adminuser_groupassign` DROP FOREIGN KEY `tbl_adminuser_groupassign_ibfk_2`; 
ALTER TABLE `tbl_adminuser_groupassign` CHANGE `user_id` `admin_id` INT(8) NOT NULL; 
ALTER TABLE `tbl_adminuser_groupassign` ADD CONSTRAINT `tbl_adminuser_groupassign_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `tbl_adminuser`(`id`); 



ALTER TABLE `tbl_adminuser_sessions` DROP FOREIGN KEY `tbl_adminuser_sessions_ibfk_1`;
ALTER TABLE `tbl_adminuser_sessions` CHANGE `user_id` `admin_id` INT(8) DEFAULT 0 NOT NULL; 
ALTER TABLE `tbl_adminuser_sessions` ADD CONSTRAINT `tbl_adminuser_sessions_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `tbl_adminuser`(`id`); 


ALTER TABLE `tbl_bridge_books` DROP FOREIGN KEY `tbl_bridge_books_ibfk_2`;
ALTER TABLE `tbl_bridge_books` CHANGE `portal_id` `bridge_id` INT(8) NOT NULL;
ALTER TABLE `tbl_bridge_books` ADD CONSTRAINT `tbl_bridge_books_ibfk_2` FOREIGN KEY (`bridge_id`) REFERENCES `tbl_bridge`(`id`); 


ALTER TABLE `tbl_keybatches` DROP FOREIGN KEY `tbl_keybatches_ibfk_1`;
ALTER TABLE `tbl_keybatches` CHANGE `portal_id` `bridge_id` INT(8) NOT NULL;
ALTER TABLE `tbl_keybatches` ADD CONSTRAINT `tbl_keybatches_ibfk_1` FOREIGN KEY (`bridge_id`) REFERENCES `tbl_bridge`(`id`);


ALTER TABLE `tbl_bridge` DROP FOREIGN KEY `tbl_bridge_ibfk_1`;
ALTER TABLE `tbl_bridge` CHANGE `library_id` `company_id` INT(8) DEFAULT 0 NOT NULL; 
ALTER TABLE `tbl_bridge` ADD CONSTRAINT `tbl_bridge_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `tbl_company`(`id`); 


ALTER TABLE `tbl_bridgeuser` DROP FOREIGN KEY `tbl_bridgeuser_ibfk_1`;
ALTER TABLE `tbl_bridgeuser` CHANGE `portal_id` `bridge_id` INT(8) DEFAULT 0 NOT NULL; 
ALTER TABLE `tbl_bridgeuser` ADD CONSTRAINT `tbl_bridgeuser_ibfk_1` FOREIGN KEY (`bridge_id`) REFERENCES `tbl_bridge`(`id`);