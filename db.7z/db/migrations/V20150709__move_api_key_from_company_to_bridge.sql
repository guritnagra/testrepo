ALTER TABLE `tbl_bridge` ADD COLUMN `api_key` VARCHAR(32) NULL AFTER `purchase_textbook_url`; 

UPDATE `tbl_bridge` bridge 
JOIN `tbl_company` company
ON company.`id`=bridge.`company_id`
SET bridge.`api_key` = company.`apikey`;

ALTER TABLE `tbl_company` DROP COLUMN `apikey`;