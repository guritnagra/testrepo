DELETE FROM `tbl_bridge_config`
WHERE `deleted`=1;

ALTER TABLE `tbl_bridge_config` ADD CONSTRAINT `tbl_bridge_config_ibfk_1` FOREIGN KEY (`bridge_id`) REFERENCES `tbl_bridge`(`id`); 
