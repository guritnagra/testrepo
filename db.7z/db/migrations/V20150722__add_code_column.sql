ALTER TABLE `tbl_bridge` CHANGE `domain` `domain` VARCHAR(64) CHARSET latin1 COLLATE latin1_swedish_ci NULL, ADD COLUMN `code` VARCHAR(64) NULL AFTER `domain`; 

UPDATE `tbl_bridge` tblb1 INNER JOIN  `tbl_bridge` tblb2 ON tblb1.`id`= tblb2.`id`
SET tblb1.`code` = (SELECT SUBSTRING_INDEX(tblb2.`domain`,".",1));