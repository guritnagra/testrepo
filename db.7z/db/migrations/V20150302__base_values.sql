-- insert global config values: questions
INSERT INTO tblconfig (key_name, key_val) VALUES ('questions.question1', 'What is your Student ID number?');
INSERT INTO tblconfig (key_name, key_val) VALUES ('questions.question2', 'What is your favorite color?');
INSERT INTO tblconfig (key_name, key_val) VALUES ('questions.question3', 'In what city were you born?');
INSERT INTO tblconfig (key_name, key_val) VALUES ('questions.question4', 'What is your pet\'s name?');
INSERT INTO tblconfig (key_name, key_val) VALUES ('questions.question5', 'What is your mother\'s maiden name?');

-- insert user roles
INSERT INTO tbluser_roles (name, code) VALUES ('student', '1');
INSERT INTO tbluser_roles (name, code) VALUES ('teacher', '99');

-- insert admin roles
INSERT INTO tbladmin_roles (name, code) VALUES ('admin', '1');
INSERT INTO tbladmin_roles (name, code) VALUES ('superadmin', '2');

-- insert into table with a foregin key constraint to itself
INSERT INTO tbladmin_groups (name) VALUES ('changeThisGroupName');
INSERT INTO tbladmins (first_name, last_name, email, role_id, group_id, password, phone, creator_id) VALUES ('Change','This','changeme@mailinator.com',1,1,'password','617 617-6176',1);
ALTER TABLE tbladmins ADD FOREIGN KEY (creator_id) REFERENCES tbladmins(id);
