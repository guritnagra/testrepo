INSERT INTO `tbl_bridgeuser_roles` (`name`, `code`) VALUES ('parent', '2'); 
INSERT INTO `tbl_bridgeuser_roles` (`name`, `code`) VALUES ('guardian', '3'); 
INSERT INTO `tbl_bridgeuser_roles` (`name`, `code`) VALUES ('relative', '4'); 
INSERT INTO `tbl_bridgeuser_roles` (`name`, `code`) VALUES ('aide', '5'); 
INSERT INTO `tbl_bridgeuser_roles` (`name`, `code`) VALUES ('administrator', '6');
