CREATE TABLE `tbl_bridge_types` (`id` INT (8),`type` VARCHAR (48),`version_id` INT (11));

INSERT INTO `tbl_bridge_types` (`id`,`type`, `version_id`) VALUES('1','INSTITUTIONAL','0');
INSERT INTO `tbl_bridge_types` (`id`,`type`, `version_id`) VALUES('2','PUBLISHER','0');
INSERT INTO `tbl_bridge_types` (`id`,`type`, `version_id`) VALUES('3','SAMPLER','0');