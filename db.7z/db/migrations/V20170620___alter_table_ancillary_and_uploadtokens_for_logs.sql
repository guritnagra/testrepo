ALTER TABLE `tbl_ancillary` ADD `updated_by` INT(11)  NOT NULL DEFAULT '1' AFTER `updated_at`;
ALTER TABLE `tbl_ancillary` ADD CONSTRAINT `ancillary_admin_update_FK` FOREIGN KEY (`updated_by`) REFERENCES `tbl_adminuser` (`id`);
ALTER TABLE `tbl_ancillary` ADD `upload_token_id` INT(11)  NOT NULL DEFAULT '1' AFTER `completed`;
ALTER TABLE `tbl_ancillary` ADD CONSTRAINT `ancillary_upload_token_FK` FOREIGN KEY (`upload_token_id`) REFERENCES `tbl_ancillary_uploadtoken` (`id`);

ALTER TABLE `tbl_ancillary_uploadtoken` ADD `admin_id` INT(11)  NOT NULL  DEFAULT '1'  AFTER `bridge_id`;
ALTER TABLE `tbl_ancillary_uploadtoken` ADD CONSTRAINT `anclllary_uploadtoken_admin_FK` FOREIGN KEY (`admin_id`) REFERENCES `tbl_adminuser` (`id`);





