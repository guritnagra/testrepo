ALTER TABLE tbladmins DROP FOREIGN KEY tbladmins_ibfk_2;

CREATE TABLE tbladmins_groups (
  user_id int(8) NOT NULL,
  group_id int(8) NOT NULL,
  UNIQUE KEY admin_id (user_id,group_id),
  KEY PIndex (user_id,group_id),
  CONSTRAINT tbladmins_groups_ibfk_1 FOREIGN KEY (group_id) REFERENCES tbladmin_groups (id),
  CONSTRAINT tbladmins_groups_ibfk_2 FOREIGN KEY (user_id) REFERENCES tbladmins (id)
);