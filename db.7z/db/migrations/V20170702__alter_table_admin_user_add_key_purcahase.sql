ALTER TABLE `tbl_adminuser` ADD COLUMN `edit_key` TINYINT(1) DEFAULT 0 NOT NULL AFTER `edit_access`, 
ADD COLUMN `edit_purchase` TINYINT(1) DEFAULT 0 NOT NULL AFTER `edit_key`, 
CHANGE `is_read_only` `is_read_only` TINYINT(1) DEFAULT 1 NOT NULL; 
