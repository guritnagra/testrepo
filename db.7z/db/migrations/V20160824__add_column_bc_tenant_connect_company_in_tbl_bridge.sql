ALTER TABLE `tbl_bridge` ADD COLUMN `bc_tenant_name` VARCHAR(256) NULL AFTER `bc_tenant_id`, ADD COLUMN `connect_company` VARCHAR(256) NULL AFTER `bc_tenant_name`; 
