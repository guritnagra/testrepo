ALTER TABLE  `tbl_adminuser_passwordresets` ADD CONSTRAINT `tbl_adminuser_passwordresets_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES  `tbl_adminuser`(`id`); 
