ALTER TABLE `tbl_bridge` 
ADD COLUMN `concurrency_credits` INT(4) NULL AFTER `offline_full_expires`, 
ADD COLUMN `concurrency_days` INT(4) NULL AFTER `concurrency_credits`,
ADD COLUMN `concurrency_expires` TIMESTAMP NULL AFTER `concurrency_days`, 
ADD COLUMN `offline_concurrency_days` INT(4) NULL AFTER `concurrency_expires`,
ADD COLUMN `offline_concurrency_expires` TIMESTAMP NULL AFTER `offline_concurrency_days`, 
ADD COLUMN `concurrency_comp_type` INT(4) NULL AFTER `offline_concurrency_expires`;