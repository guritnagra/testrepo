ALTER TABLE `tbl_adminuser` ADD COLUMN `system_user_id` INT(8) NULL AFTER `password`,
 ADD COLUMN `edit_system_user` TINYINT(1) DEFAULT 0 NOT NULL AFTER `system_user_id`,
 ADD COLUMN `edit_bridge` TINYINT(1) DEFAULT 0 NOT NULL AFTER `edit_system_user`,
 ADD COLUMN `edit_basic_info` TINYINT(1) DEFAULT 0 NOT NULL AFTER `edit_bridge`,
 ADD COLUMN `edit_styling` TINYINT(1) DEFAULT 0 NOT NULL AFTER `edit_basic_info`,
 ADD COLUMN `edit_manage` TINYINT(1) DEFAULT 0 NOT NULL AFTER `edit_styling`,
 ADD COLUMN `edit_users` TINYINT(1) DEFAULT 0 NOT NULL AFTER `edit_manage`,
 ADD COLUMN `edit_user_limit` TINYINT(1) DEFAULT 0 NOT NULL AFTER `edit_users`,
 ADD COLUMN `edit_user_concurrency` TINYINT(1) DEFAULT 0 NOT NULL AFTER `edit_user_limit`,
 ADD COLUMN `allow_content_upload` TINYINT(1) DEFAULT 0 NOT NULL AFTER `edit_user_concurrency`,
 ADD COLUMN `edit_allowance` TINYINT(1) DEFAULT 0 NOT NULL AFTER `allow_content_upload`,
 ADD COLUMN `edit_access` TINYINT(1) DEFAULT 0 NOT NULL AFTER `edit_allowance`; 


ALTER TABLE `tbl_adminuser` CHANGE `password` `password` VARCHAR(32) CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci NULL; 