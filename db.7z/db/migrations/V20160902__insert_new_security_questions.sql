INSERT INTO `tbl_security_questions` (`id`, `text`) VALUES ('6', 'What is your favorite sport?'); 
INSERT INTO `tbl_security_questions` (`id`, `text`) VALUES ('7', 'What is your favorite flavor of ice cream?'); 
INSERT INTO `tbl_security_questions` (`id`, `text`) VALUES ('8', 'What is the name of your favorite pet?'); 
INSERT INTO `tbl_security_questions` (`id`, `text`) VALUES ('9', 'When you were young, what did you want to be when you grew up?'); 
INSERT INTO `tbl_security_questions` (`id`, `text`) VALUES ('10', 'What was the last name of your favorite teacher?');