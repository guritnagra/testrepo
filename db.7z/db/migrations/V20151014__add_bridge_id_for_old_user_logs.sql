UPDATE `tbl_bridge_log` bl
LEFT JOIN `tbl_bridgeuser` bu ON bu.`id`=bl.`user_id`
SET bl.`bridge_id` = bu.`bridge_id`;