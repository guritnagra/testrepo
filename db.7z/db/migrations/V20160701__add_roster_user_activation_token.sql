CREATE TABLE    `tbl_bridgeusers_inittoken`( 
    `id` INT NOT NULL AUTO_INCREMENT, 
    `bridge_id` INT NOT NULL, 
    `email` VARCHAR(256), 
    `created_time` TIMESTAMP NOT NULL, 
    `activation_time` TIMESTAMP, 
    `deleted` TINYINT DEFAULT 0, 
    `version_id` INT DEFAULT 0, 
    PRIMARY KEY (`id`), 
    CONSTRAINT `tbl_bridgeusers_inittoken_fk1` FOREIGN KEY (`bridge_id`) REFERENCES `tbl_bridge`(`id`) 
) ENGINE=INNODB; 


ALTER TABLE `tbl_bridgeusers_inittoken` ADD COLUMN `used` TINYINT DEFAULT 0 NULL AFTER `email`, 
CHANGE `created_time` `created_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NULL, 
CHANGE `activation_time` `activation_time` TIMESTAMP NULL; 


ALTER TABLE `tbl_bridgeusers_inittoken` CHANGE `email` `email` VARCHAR(256) CHARSET utf8 COLLATE utf8_general_ci NOT NULL, 
ADD COLUMN `token` VARCHAR(256) NULL AFTER `email`; 

