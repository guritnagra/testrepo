ALTER TABLE  `tbl_bridge` CHANGE `last_editor` `last_editor` INT(8) DEFAULT 0 NOT NULL, ADD CONSTRAINT `tbl_bridge_ibfk_2` FOREIGN KEY (`last_editor`) REFERENCES  `tbl_adminuser`(`id`); 

ALTER TABLE  `tbl_company` ADD CONSTRAINT `tbl_company_ibfk_1` FOREIGN KEY (`creator_id`) REFERENCES `tbl_adminuser`(`id`); 

