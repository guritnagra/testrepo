$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};

$(function()
{
	$.ajax(
	{
		type:"GET",
		url:"../api/application.wadl",
		dataType: "xml",
		success: function(data)
		{
			var pr_restuls = $('<table width="100%" cellspacing="0" cellpadding="10" style="width:100%;word-wrap:break-word;table-layout: fixed;"></table>');
			
			var xmldata = $(data);
console.log("xmldata "+ xmldata);
			var namespace = "ns2\\:";
			
			var application = $(namespace+"application",xmldata);
console.log("application.length "+ application.length);

			if(application.length==0)
			{
				application = $("application",xmldata);
console.log("application2.length "+ application.length);
			}
			var resources   = application.children(namespace+"resources");
console.log("resources.length "+ resources.length);

			var base = resources.attr("base");
			if(base.indexOf("http://")==0)
			{
				base = base.substring(5);
			}
			else if(base.indexOf("https://")==0)
			{
				base = base.substring(6);
			}
			//hack to fix issues with Jersy 1 not reflecting the correct pre-proxy path
			//base = "/admin/api/";
			base = "/api/";
			pr_restuls.append('<tr class="dark"><td ></td></tr>');
			pr_restuls.append('<tr><th ><h1>'+base+'</h1></th></tr>');
			
			var resourcearray = resources.children(namespace+"resource");
			var resourceparams = [];
			
			resourcearray = resourcearray.sort(function(a,b) { return $(a).attr("path") > $(b).attr("path"); } );
			
			for(var rai = 0; rai < resourcearray.length; rai++)
			{
				var resource = $(resourcearray[rai]);
				
				var prefix = resource.attr("path");
				prefix = prefix.replace(/\/{2,}/g,"/");
				
				pr_restuls.append('<tr class="dark"><td ></td></tr>');
				pr_restuls.append('<tr><th >'+prefix+'</th></tr>');
//console.log("pr_restuls "+ pr_restuls);				
				var resource_hash = {};
				
				var tpr_restuls = $("<table/>");
				
				processResource(tpr_restuls,resource,base,"",resourceparams, resource_hash);
				
				var resource_hash_keys = Object.keys(resource_hash);
				resource_hash_keys.sort();
				for(var rhi = 0; rhi < resource_hash_keys.length; rhi++)
				{
					var rkey = resource_hash_keys[rhi];
					pr_restuls.append(resource_hash[rkey]);
				}
			}
			
			$('head',$('#rest')[0].contentWindow.document).append($('<link rel="stylesheet" type="text/css" href="css/wadl.css">'));
			$('body',$('#rest')[0].contentWindow.document).append(pr_restuls);
			
			$(".svc_header",$('#rest')[0].contentWindow.document).click(function(e)
			{
				e.preventDefault();
				$(this).parent().parent().next().toggle().next().toggle();
			});
			
			$('form',$('#rest')[0].contentWindow.document).submit(function()
			{
				var t_method = $(this).attr("method");
console.log("t_method "+ t_method);
				var t_action = $(this).attr("action");
				var t_data   = $(this).serializeObject();
				
				delete t_data["_jsondata"];
				
				var new_action = t_action;
				for(var ai in t_data)
				{
					if( new_action.indexOf("{"+ai+"}")>=0)
					{
						if(!t_data[ai])
						{
							alert(ai+" is required");
							return false;
						}
						new_action = new_action.replace("{"+ai+"}",t_data[ai]);
					}
					else
					{
						new_action = new_action+(new_action.indexOf("?")>=0?"&":"?")+ai+"="+t_data[ai];
					}
				}
				
				if($(this).find("#_jsondata").length > 0)
				{
					$.ajax(
				    {  
				    	type: t_method,  
				        url: new_action,
				        data: $(this).find("#_jsondata").val(),
				        contentType: 'application/json',
				        complete: function(jqXHR, textStatus)
						{
				        	var html = "<style><!--H1 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:22px;} H2 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:16px;} H3 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:14px;} BODY {font-family:Tahoma,Arial,sans-serif;color:black;background-color:white;} B {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;} P {font-family:Tahoma,Arial,sans-serif;background:white;color:black;font-size:12px;}A {color : black;}A.name {color : black;}HR {color : #525D76;}--></style><div style='position:absolute;left:0;right:0;top:0;bottom:0;'>";
				        	html += "<div style='width:100%;position:absolute;top:0;left:0;right:0;height:120px;overflow-y:scroll;border:1px solid #000000;'>";
				        	html += "method: " + t_method + "<br/>";
				        	html += "action: " + new_action + "<br/>";
				        	html += "status: " + jqXHR.status + " " + jqXHR.statusText + "<br/>";
				        	html += "date: " + (new Date()) + "<br/>";
				        	html += "</div>";
				        	html += "<div style='width:100%;position:absolute;top:120px;left:0;right:0;bottom:0;overflow-y:none;border:1px solid #000000;'>";
				        	html += "<iframe style='width:100%;height:100%;border: 0;' id='cont'>";
				        	html += "</iframe>";
				        	html += "</div>";
				        	html += "</div>";
//console.log("html: "+ html);				        	
				        	if(jqXHR.getResponseHeader("Content-Type")=="text/html"|| jqXHR.status == 0)
				        	{
				        		$($('body',$('#restframe')[0].contentWindow.document)[0]).html(html);
				        		$("#cont",$($('body',$('#restframe')[0].contentWindow.document)[0])).attr("src",new_action);
				        	}
				        	else
				        	{
				        		$($('body',$('#restframe')[0].contentWindow.document)[0]).html(html);
				        		$($("#cont",$($('body',$('#restframe')[0].contentWindow.document)[0]))[0].contentWindow.document.body).html("<style>pre {outline: 1px solid #ccc; padding: 5px; margin: 5px; overflow-x: auto; /* Use horizontal scroller if needed; for Firefox 2, not needed in Firefox 3 */\n white-space: pre-wrap; /* css-3 */\n white-space: -moz-pre-wrap !important; /* Mozilla, since 1999 */\n white-space: -pre-wrap; /* Opera 4-6 */\n white-space: -o-pre-wrap; /* Opera 7 */\n /* width: 99%; */\n word-wrap: break-word; /* Internet Explorer 5.5+ */\n}\n.string { color: green; }\n.number { color: darkorange; }\n.boolean { color: blue; }\n.null { color: magenta; }\n.key { color: red; }</style>");
				        		$($("#cont",$($('body',$('#restframe')[0].contentWindow.document)[0]))[0].contentWindow.document.body).append($("<pre />").text(JSON.stringify(JSON.parse(jqXHR.responseText), undefined, 4)));
				        	}
						}
					});
					return false;
				}
				
				
				
				if(t_method=="GET" || t_method=="DELETE")
				{
					
					$.ajax(
						    {  
						    	type: t_method,  
						        url: new_action,
						        complete: function(jqXHR, textStatus)
								{
						        	var html = "<style><!--H1 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:22px;} H2 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:16px;} H3 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:14px;} BODY {font-family:Tahoma,Arial,sans-serif;color:black;background-color:white;} B {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;} P {font-family:Tahoma,Arial,sans-serif;background:white;color:black;font-size:12px;}A {color : black;}A.name {color : black;}HR {color : #525D76;}--></style><div style='position:absolute;left:0;right:0;top:0;bottom:0;'>";
						        	html += "<div style='width:100%;position:absolute;top:0;left:0;right:0;height:120px;overflow-y:scroll;border:1px solid #000000;'>";
						        	html += "method: " + t_method + "<br/>";
						        	html += "action: " + new_action + "<br/>";
						        	html += "status: " + jqXHR.status + " " + jqXHR.statusText + "<br/>";
						        	html += "date: " + (new Date()) + "<br/>";
						        	html += "</div>";
						        	html += "<div style='width:100%;position:absolute;top:120px;left:0;right:0;bottom:0;overflow-y:none;border:1px solid #000000;'>";
						        	html += "<iframe style='width:100%;height:100%;border: 0;' id='cont'>";
						        	html += "</iframe>";
						        	html += "</div>";
						        	html += "</div>";
				//console.log("html2: "+ html);			        	
						        	if(jqXHR.getResponseHeader("Content-Type")=="text/html" || jqXHR.status == 0)
						        	{
						        		$($('body',$('#restframe')[0].contentWindow.document)[0]).html(html);
						        		$("#cont",$($('body',$('#restframe')[0].contentWindow.document)[0])).attr("src",new_action);
						        	}
						        	else
						        	{
						        		$($('body',$('#restframe')[0].contentWindow.document)[0]).html(html);
						        		$($("#cont",$($('body',$('#restframe')[0].contentWindow.document)[0]))[0].contentWindow.document.body).html("<style>pre {outline: 1px solid #ccc; padding: 5px; margin: 5px; overflow-x: auto; /* Use horizontal scroller if needed; for Firefox 2, not needed in Firefox 3 */\n white-space: pre-wrap; /* css-3 */\n white-space: -moz-pre-wrap !important; /* Mozilla, since 1999 */\n white-space: -pre-wrap; /* Opera 4-6 */\n white-space: -o-pre-wrap; /* Opera 7 */\n /* width: 99%; */\n word-wrap: break-word; /* Internet Explorer 5.5+ */\n}\n.string { color: green; }\n.number { color: darkorange; }\n.boolean { color: blue; }\n.null { color: magenta; }\n.key { color: red; }</style>");
						        		$($("#cont",$($('body',$('#restframe')[0].contentWindow.document)[0]))[0].contentWindow.document.body).append($("<pre />").text(JSON.stringify(JSON.parse(jqXHR.responseText), undefined, 4)));
						        	}
						        	
								}
							});
				}
				else
				{
					$.ajax(
				    {  
				    	type: t_method,  
				        url: new_action,
				        data: t_data,
				        complete: function(jqXHR, textStatus)
						{
				        	var html = "<style><!--H1 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:22px;} H2 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:16px;} H3 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:14px;} BODY {font-family:Tahoma,Arial,sans-serif;color:black;background-color:white;} B {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;} P {font-family:Tahoma,Arial,sans-serif;background:white;color:black;font-size:12px;}A {color : black;}A.name {color : black;}HR {color : #525D76;}--></style><div style='position:absolute;left:0;right:0;top:0;bottom:0;'>";
				        	html += "<div style='width:100%;position:absolute;top:0;left:0;right:0;height:120px;overflow-y:scroll;border:1px solid #000000;'>";
				        	html += "method: " + t_method + "<br/>";
				        	html += "action: " + t_action + "<br/>";
				        	html += "data: " + t_data + "<br/>";
				        	html += "status: " + jqXHR.status + " " + jqXHR.statusText + "<br/>";
				        	html += "date: " + (new Date()) + "<br/>";
				        	html += "</div>";
				        	html += "<div style='width:100%;position:absolute;top:120px;left:0;right:0;bottom:0;overflow-y:scroll;border: 1px solid #000000;' id='cont'>";
			        		html += "</div>";
				        	html += "</div>";
//console.log("html3: "+ html);	
				        	$($('body',$('#restframe')[0].contentWindow.document)[0]).html(html);
				        	$("#cont",$($('body',$('#restframe')[0].contentWindow.document)[0])).text(jqXHR.responseText);
						}
					});
				}
				return false;
			});
			
		}
	});
});
function processResource(restultable,res,base,pfx,resourceparams,resource_hash)
{
	var prefix = pfx+"/"+res.attr("path");
	prefix = prefix.replace(/\/{2,}/g,"/");
	var namespaceprefix = "ns2:";
	var namespace = "ns2\\:";

	resourceparams.push(res.children("ns2\\:param"));
	
	var reschildren = res.children();
console.log("reschildren.length "+reschildren.length);
	for(var ri = 0; ri < reschildren.length; ri++)
	{
		var reschild = $(reschildren[ri]);
		var nn = reschild[0].nodeName;
console.log("nn "+nn);
		if(nn==namespaceprefix+"method")
		{
		console.log("reschild "+reschild);
	processMethod(restultable,reschild,base,prefix,resourceparams,resource_hash);
		}
		else if(nn=="ns2:resource")
		{
			processResource(restultable,reschild,base,prefix,resourceparams,resource_hash);
		}
			
	}
	
	resourceparams.pop();
}
function processMethod(restultable,met,base,pfx,resourceparams,resource_hash)
{
	var name  = $(met).attr("name");
console.log("name "+name);
	var path  = pfx;
	var docnotes  = $(met).children("ns2\\:doc").text()+"";
console.log("docnotes "+docnotes);
	var comments = docnotes.split("\n").join("<br/>");
console.log("comments "+comments);
	var notes     = "";//"<tr><td colspan='2'>"++"</td></tr>";
	var t_action = base+pfx.substring(1);
	
	var resps = $(met).children("ns2\\:response");
	for(var respsi = 0; respsi < resps.length; respsi++)
	{
		var resp = $(resps[respsi]);
		
		var status = resp.attr("status");
		var doctext = "";
		var docsa  = resp.children("ns2\\:representation").children("ns2\\:doc");
		
		for(var docsai = 0; docsai < docsa.length; docsai++)
		{
			var doc = $(docsa[docsai]);
			
			var doc_children = doc.children("ns3\\:p");
			
			if(doc_children.length>0)
			{
				
			}
			else
			{
				doctext += doc.text().split("\n").join("<br/>");
			}
		}
		
		for(var docsai = 0; docsai < docsa.length; docsai++)
		{
			var doc = $(docsa[docsai]);
			
			var doc_children = doc.children("ns3\\:p");
			
			if(doc_children.length>0)
			{
				doctext += " "+$(doc_children).html().split("ns3:").join("");
			}
			else
			{
				
			}
		}
		
		notes += '<div style="display: inline-block;width:100%;border-bottom: 1px solid #E0E0E0;vertical-align:top;"><div style="display: inline-block;width: 33.3%;vertical-align:top;padding:4px;box-sizing: border-box;ms-box-sizing: border-box;webkit-box-sizing: border-box;moz-box-sizing: border-box;">'+status+'</div><div style="display: inline-block;width: 66.6%;word-wrap:break-word;border-left: 1px solid #E0E0E0;border-collapse:collapse;vertical-align:top;padding:4px;box-sizing: border-box;ms-box-sizing: border-box;webkit-box-sizing: border-box;moz-box-sizing: border-box;white-space: nowrap;">'+doctext+'</div></div>';
	}
	
	var toret1 = $("<tr></tr>");
	
	toret1.append($("<td><h4 class='svc_header'>"+name+" - "+path+"</h4></td>"));
	
	var toret2 = $("<tr style='display:none;'></tr>");
	toret2.append($('<td>'+comments+'<br/><br/><div cellspacing="0" cellpadding="0" border="1" style="display: block;max-width: 100%;border-top: 1px solid #E0E0E0;border-right: 1px solid #E0E0E0;border-left: 1px solid #E0E0E0;border-collapse:collapse;word-wrap:break-word;">'+notes+"</div></td>"));
	
	var toret3 = $("<tr style='display:none;'></tr>");
	var formcol = $("<td></td>");
	
	var form = $('<form class="resttestform" action="'+t_action+'" method="'+name+'" target="_restframe"></form>');
	
	var table = $('<table cellspacing="0" cellpadding="0" border="1" style="width:100%;border: 1px solid #E0E0E0;border-collapse:collapse;word-wrap:break-word;"></table>');
	
	var params = $(met).children("ns2\\:request").children("ns2\\:param");
	var params2 = $(met).children("ns2\\:request").children("ns2\\:representation").children("ns2\\:param");
	
	if(name=="POST" || name=="PUT")
	{
		table.append(rawPostData());
	}
	
	for(var rpi = 0; rpi < resourceparams.length; rpi++)
	{
		var rlevelparams = resourceparams[rpi];
		for(var rlpi = 0; rlpi < rlevelparams.length; rlpi++)
		{
			var rlevelparam = $(rlevelparams[rlpi]);
			
			table.append(processParam(rlevelparam));
			
		}
	}
	
	for(var pi = 0; pi < params.length; pi++)
	{
		var param = $(params[pi]);
		table.append(processParam(param));
	}
	for(var pi = 0; pi < params2.length; pi++)
	{
		var param = $(params2[pi]);
		table.append(processParam(param));
	}
	
	table.append('<tr><td style="width:33%"></td><td  style="width:33%"></td><td  style="width:33%"><input type="submit" value="SUBMIT"></td></tr>');
	
	form.append(table);
	formcol.append(form);
	toret3.append(formcol);
	
	restultable.append('<tr class="dark"><td ></td></tr>');
	restultable.append(toret1);
	restultable.append(toret2);
	restultable.append(toret3);
	
	var resource_key = path+" - "+name;
	var resource_value = "";
	resource_value += '<tr class="dark"><td ></td></tr>';
	resource_value += '<tr class="dark">'+toret1.html()+'</tr>';
	resource_value += '<tr class="dark" style="display:none;">'+toret2.html()+'</tr>';
	resource_value += '<tr class="dark" style="display:none;">'+toret3.html()+'</tr>';
console.log("resource_value: "+ resource_value);	
	resource_hash[resource_key.toLowerCase()] = resource_value;
}

function processParam(param)
{
	var ptype = param.attr("style");
	
	if(ptype=="header")
	{
		return $("<tr><td style='width:33%;'>"+param.attr("name")+"</td><td style='width:33%;'>"+param.children("ns2\\:doc").text()+"</td><td style='width:33%;'>"+param.attr("path")+"</div></td></tr>");
	}
	else if(ptype="template")
	{
		return $("<tr><td style='width:33%;'>"+param.attr("name")+'</td><td style="width:33%;">'+param.children("ns2\\:doc").text()+'</td><td style="width:33%;"><input type="text" name="'+param.attr("name")+'" style="width:100%;"></input></div></td></tr>');
	}
	else if(ptyle="query")
	{
		return $("<tr><td style='width:33%;'>"+param.attr("name")+'</td><td style="width:33%;">'+param.children("ns2\\:doc").text()+'</td><td style="width:33%;"><input type="text" name="'+param.attr("name")+'" style="width:100%;"></input></div></td></tr>');
	}
		
}

function rawPostData()
{
	return $("<tr><td style='width:33%;'>Raw Post Data</td><td style='width:33%;'></td><td style='width:33%;'><input type='text' name='_jsondata' id='_jsondata' style='width:100%;'></input></div></td></tr>");
}
