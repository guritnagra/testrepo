package com.vst.bridge.user.rest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vst.bridge.rest.central.IApplicationServiceHandler;
import com.vst.bridge.rest.config.AuthenticatedRestAction;
import com.vst.bridge.rest.config.UnAuthenticatedRestAction;
import com.vst.bridge.rest.input.vo.OldPolicyPasswordVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.user.UpdatePasswordVO;
import com.vst.bridge.rest.response.vo.user.UserDetailsVO;
import com.vst.bridge.rest.response.vo.user.UserEmailVO;
import com.vst.bridge.util.constant.ApplicationConstants;

import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;

/**
 * REST web-services endpoints for /user/* URLs.
 **/
@RestController
@RequestMapping(value="/user")
@io.swagger.annotations.Api(value = "/User")
public class User {
	
	UriInfo uriInfo;
	
	Request request;
	
	//private static Logger log = LogManager.getLogger(User.class);
	
	@Autowired
	private IApplicationServiceHandler applicationServiceHandler;
	
	@RequestMapping(method=RequestMethod.POST)
	@io.swagger.annotations.ApiOperation(value = "Get user",notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK")})
	public ResponseEntity<RestResponse> addUser(@RequestBody UserDetailsVO userDetails, HttpServletRequest request,HttpServletResponse response) {
		return applicationServiceHandler.process(UnAuthenticatedRestAction.POST_USER, com.vst.bridge.rest.config.PortalPermissionType.user, null, request,response, uriInfo,userDetails);
	}

	
	@RequestMapping(method=RequestMethod.PUT)
	@io.swagger.annotations.ApiOperation(value = "Get user",notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK")})
	public ResponseEntity<RestResponse> updateUser(@CookieValue(value=ApplicationConstants.BRIDGE_SESSIONID,defaultValue="") String sessionId,@RequestBody UserDetailsVO userDetails,  HttpServletRequest request,HttpServletResponse response){
		return applicationServiceHandler.process(AuthenticatedRestAction.PUT_USER, com.vst.bridge.rest.config.PortalPermissionType.user, sessionId, userDetails, request,response, uriInfo);
	}


	@RequestMapping(method=RequestMethod.GET,value="questions")
	@io.swagger.annotations.ApiOperation(value = "Get user",notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK")})
	public ResponseEntity<RestResponse> getSecurityQuestions( HttpServletRequest request,HttpServletResponse response) {
		return applicationServiceHandler.process(UnAuthenticatedRestAction.GET_QUESTIONS,com.vst.bridge.rest.config.PortalPermissionType.user,null,request,response,uriInfo,null);
	}
	
	
	@RequestMapping(method=RequestMethod.GET)
	@io.swagger.annotations.ApiOperation(value = "Get user",notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK")})
	public ResponseEntity<RestResponse> getUser( HttpServletRequest httpRequest, @CookieValue(value=ApplicationConstants.BRIDGE_SESSIONID,defaultValue="") String sessionId,HttpServletResponse response) {
		return applicationServiceHandler.process(AuthenticatedRestAction.GET_USER, com.vst.bridge.rest.config.PortalPermissionType.user, sessionId, null, httpRequest,response, uriInfo);
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/checkMail")
	@io.swagger.annotations.ApiOperation(value = "Get user",notes = "checkMail")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK")})
	public ResponseEntity<RestResponse> checkUserEmail(@RequestBody UserEmailVO userEmailVO, HttpServletRequest request,HttpServletResponse response) {
		return applicationServiceHandler.process(UnAuthenticatedRestAction.POST_USER_EMAIL, com.vst.bridge.rest.config.PortalPermissionType.user, null, request,response, uriInfo,userEmailVO);
	}
	
	@RequestMapping(method=RequestMethod.GET,value="{" + ApplicationConstants.TOKEN + "}/validate")
	@io.swagger.annotations.ApiOperation(value = "Validate token",notes = "To validate token")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK")})
	public ResponseEntity<RestResponse> getDetailsForToken( HttpServletRequest httpRequest, @CookieValue(value=ApplicationConstants.BRIDGE_SESSIONID,defaultValue="") String sessionId,
			@ApiParam(value = "Token", required = false) @PathVariable(ApplicationConstants.TOKEN) String  token,
			HttpServletResponse response) {
		return applicationServiceHandler.process(UnAuthenticatedRestAction.VALIDATE_TOKEN, com.vst.bridge.rest.config.PortalPermissionType.user, sessionId, httpRequest,response, uriInfo,token);
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/resetPassword")
	@io.swagger.annotations.ApiOperation(value = "Reset password Request",notes = "To Reset password Request")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK")})
	public ResponseEntity<RestResponse> resetPasswordRequest(@RequestBody UserEmailVO userEmailVO, HttpServletRequest request,HttpServletResponse response) {
		return applicationServiceHandler.process(UnAuthenticatedRestAction.POST_RESET_PASSWORD_REQUEST, com.vst.bridge.rest.config.PortalPermissionType.user, null, request,response, uriInfo,userEmailVO);
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/updatePassword")
	@io.swagger.annotations.ApiOperation(value = "Update password",notes = "To Update password")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK")})
	public ResponseEntity<RestResponse> updatePassword(@RequestBody UpdatePasswordVO updatePasswordVO, HttpServletRequest request,HttpServletResponse response) {
		return applicationServiceHandler.process(UnAuthenticatedRestAction.POST_UPDATE_PASSWORD, com.vst.bridge.rest.config.PortalPermissionType.user, null, request,response, uriInfo,updatePasswordVO);
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/updateOldPassword")
	@io.swagger.annotations.ApiOperation(value = "Update old policy password",notes = "Update Old policy password")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK")})
	public ResponseEntity<RestResponse> updateOldPolicyPassword(@RequestBody OldPolicyPasswordVO oldPolicyPasswordVO, HttpServletRequest request,HttpServletResponse response) {
		return applicationServiceHandler.process(UnAuthenticatedRestAction.POST_UPDATE_OLD_POLICY_PASSWORD, com.vst.bridge.rest.config.PortalPermissionType.user, null, request,response, uriInfo,oldPolicyPasswordVO);
	}
	
}
