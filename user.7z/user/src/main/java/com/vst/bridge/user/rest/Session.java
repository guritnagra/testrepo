package com.vst.bridge.user.rest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vst.bridge.rest.central.IApplicationServiceHandler;
import com.vst.bridge.rest.config.AuthenticatedRestAction;
import com.vst.bridge.rest.config.PortalPermissionType;
import com.vst.bridge.rest.config.UnAuthenticatedRestAction;
import com.vst.bridge.rest.input.vo.ReCaptchaLoginVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.util.constant.ApplicationConstants;

import io.swagger.annotations.ApiResponse;

/**
 * REST web-services endpoints for pre-logged in user.
 **/
@RestController
@RequestMapping(value="/session")
@io.swagger.annotations.Api(value = "/Session")
public class Session {
	
	@Context
	UriInfo uriInfo;
	
	@Context
	Request request;
	
	@Autowired
	private IApplicationServiceHandler applicationServiceHandler;
	
	
	@RequestMapping(method={RequestMethod.GET})
	@io.swagger.annotations.ApiOperation(value = "Get user",notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK")})
	public ResponseEntity<RestResponse> isLoggedIn(@CookieValue(value =ApplicationConstants.BRIDGE_SESSIONID,defaultValue="") String sessionId,HttpServletRequest request,HttpServletResponse response) {
		return applicationServiceHandler.process(AuthenticatedRestAction.GET_SESSION, PortalPermissionType.user, sessionId, null, request, response,uriInfo);
	}
	

	@RequestMapping(method={RequestMethod.POST})
	@io.swagger.annotations.ApiOperation(value = "Get user",notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK")})
	public ResponseEntity<RestResponse> login(@RequestBody ReCaptchaLoginVO reCaptchaLloginInfoVO,HttpServletRequest httpRequest,HttpServletResponse response) { 
		return applicationServiceHandler.process(UnAuthenticatedRestAction.POST_SESSION, PortalPermissionType.user, null, httpRequest, response,uriInfo,reCaptchaLloginInfoVO);
	}
	

	@RequestMapping(method={RequestMethod.DELETE})
	@io.swagger.annotations.ApiOperation(value = "Get user",notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK")})
	public ResponseEntity<RestResponse> logout(@CookieValue(value =ApplicationConstants.BRIDGE_SESSIONID,defaultValue="") String sessionId,HttpServletRequest request,HttpServletResponse response) { 
		return applicationServiceHandler.process(UnAuthenticatedRestAction.DELETE_SESSION, PortalPermissionType.user, sessionId, request, response,uriInfo,null);
	}
}
