package com.vst.bridge.user.rest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vst.bridge.rest.central.IApplicationServiceHandler;
import com.vst.bridge.rest.config.AuthenticatedRestAction;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.user.CreateKeysVO;
import com.vst.bridge.util.constant.ApplicationConstants;

import io.swagger.annotations.ApiResponse;

/**
 * REST web-services endpoints for /keys/* URLs.
 **/
@RestController
@RequestMapping(value="/keys")
@io.swagger.annotations.Api(value = "/Keys")
public class Keys {
	
	UriInfo uriInfo;
	
	Request request;
	
	//private static Logger log = LogManager.getLogger(Keys.class);
	
	@Autowired
	private IApplicationServiceHandler applicationServiceHandler;
	
	@RequestMapping(method=RequestMethod.GET)
	@io.swagger.annotations.ApiOperation(value = "Get user",notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK")})
	public ResponseEntity<RestResponse> getUserKeys(@CookieValue(value=ApplicationConstants.BRIDGE_SESSIONID,defaultValue="") String sessionId,  HttpServletRequest httpRequest,HttpServletResponse response){
		return applicationServiceHandler.process(AuthenticatedRestAction.GET_KEYS,com.vst.bridge.rest.config.PortalPermissionType.user, sessionId, null, httpRequest,response, uriInfo);
	}
	
	@RequestMapping(method=RequestMethod.POST)
	@io.swagger.annotations.ApiOperation(value = "Get user",notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK")})
	public ResponseEntity<RestResponse> addKeyToUser(@CookieValue(value=ApplicationConstants.BRIDGE_SESSIONID,defaultValue="") String sessionId,@RequestBody CreateKeysVO createKey,  HttpServletRequest httpRequest,HttpServletResponse response){
		return applicationServiceHandler.process(AuthenticatedRestAction.POST_KEY,com.vst.bridge.rest.config.PortalPermissionType.user, sessionId, createKey, httpRequest,response, uriInfo);
	}
}
