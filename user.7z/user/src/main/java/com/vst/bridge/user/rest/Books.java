package com.vst.bridge.user.rest;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vst.bridge.VstUtils;
import com.vst.bridge.rest.central.IApplicationServiceHandler;
import com.vst.bridge.rest.config.AuthenticatedRestAction;
import com.vst.bridge.rest.config.PortalPermissionType;
import com.vst.bridge.rest.config.UnAuthenticatedRestAction;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.books.BookUrl;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;

import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;

@RestController
@RequestMapping(value = "/books")
@io.swagger.annotations.Api(value = "/Books")
public class Books {

	UriInfo uriInfo;

	Request request;

	// private static Logger log = LogManager.getLogger(Books.class);

	@Autowired
	private IApplicationServiceHandler applicationServiceHandler;

	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@RequestMapping(method = RequestMethod.GET)
	@io.swagger.annotations.ApiOperation(value = "Get user", notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public ResponseEntity<RestResponse> getBooks(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			HttpServletRequest request, HttpServletResponse response,
			@ApiParam(value = "Unique project token", required = false) @RequestParam(value = ApplicationConstants.PAGINATION_LICENSED, required = false) Boolean licensed,
			@ApiParam(value = "Unique project token", required = false) @RequestParam(value = ApplicationConstants.PAGINATION_PAGE, required = false) Integer page,
			@ApiParam(value = "Unique project token", required = false) @RequestParam(value = ApplicationConstants.PAGINATION_LIMIT, required = false) Integer limit,
			@ApiParam(value = "Unique project token", required = false) @RequestParam(value = ApplicationConstants.PAGINATION_ORDERBY, required = false) String orderby,
			@ApiParam(value = "Unique project token", required = false) @RequestParam(value = ApplicationConstants.PAGINATION_ORDER, required = false) String order,
			@ApiParam(value = "Unique project token", required = false) @RequestParam(value = ApplicationConstants.PAGINATION_SEARCH, required = false) String search) {
		if(search!=null && StringUtils.isNotEmpty(search)){
 			try { 				
 				search = new String(search.getBytes("ISO-8859-1"), "UTF-8"); 				
 			} catch (UnsupportedEncodingException e) {
 				// TODO Auto-generated catch block
 				e.printStackTrace();
 			}
 		}
		RestResponse restResponse = new RestResponse(Response.Status.UNAUTHORIZED.getStatusCode(),
				ApplicationCode.UNEXPECTED_ERROR.getCodeId(),
				localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()));
		BridgePaginationVo bridgePaginationVo = new BridgePaginationVo(null, null, page, limit, null, orderby, order,	search, licensed, null);
		HttpStatus status = HttpStatus.OK;
		try {
			SessionStatusVO sessionStatusVO = applicationServiceHandler.checkSessionAndGetUserInfo(sessionId,
					PortalPermissionType.user);
			if (null != sessionStatusVO && null != sessionStatusVO.getAdminId())
				return applicationServiceHandler.process(AuthenticatedRestAction.GET_BOOKS, PortalPermissionType.user,
						sessionId, bridgePaginationVo, request, response, uriInfo);

			// TODO else return response.buildResponse();
			
		} catch (BridgeException BridgeException) {
			// logger.error(localeMessageUtility.getErrorMessage(BridgeException.getErrorCode().getCodeId()),
			// BridgeException);
			switch (BridgeException.getErrorCode()) {
			
			case SESSION_EXPIRED:
				status = HttpStatus.BAD_REQUEST;
				return applicationServiceHandler.process(UnAuthenticatedRestAction.GET_BOOKS_FOR_DEFER,
						PortalPermissionType.user, sessionId, request, response, uriInfo, bridgePaginationVo);
			default:
				status = HttpStatus.INTERNAL_SERVER_ERROR;
				restResponse = new RestResponse(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(),
						ApplicationCode.UNEXPECTED_ERROR.getCodeId(),
						localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()));
			}

		}

		return ResponseEntity.status(status).body(restResponse);
	}

	@RequestMapping(method = RequestMethod.GET, value = "{" + ApplicationConstants.BRIDGE_BOOK_VBID_ID + "}")
	@io.swagger.annotations.ApiOperation(value = "Get user", notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public ResponseEntity<RestResponse> getBookForVbid(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			HttpServletRequest request, HttpServletResponse response,
			@PathVariable(ApplicationConstants.BRIDGE_BOOK_VBID_ID) String vbid) {

		Map<String, Object> params = new HashMap<String, Object>();
		params.put(ApplicationConstants.BRIDGE_BOOK_VBID_ID, vbid);
		try{
		return applicationServiceHandler.process(AuthenticatedRestAction.GET_BOOKS_FOR_VBID, PortalPermissionType.user,
				sessionId, params, request, response, uriInfo);
		}catch(BridgeException e){
			return ResponseEntity.status(HttpStatus.FOUND.value()).header("Location", request.getRequestURL().toString()).body(null);
		}
	}

	@RequestMapping(method = RequestMethod.GET, value = "{" + ApplicationConstants.BRIDGE_BOOK_VBID_ID + "}/launch")
	@io.swagger.annotations.ApiOperation(value = "Get user", notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public void launchVbid(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			@PathVariable(ApplicationConstants.BRIDGE_BOOK_VBID_ID) String vbid,
			@ApiParam(value = "Deep link location", required = false) @RequestParam(value = ApplicationConstants.DEEPLINK_LOCATION, required = false, defaultValue = "") String linkLocation,
			HttpServletRequest request, HttpServletResponse response) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put(ApplicationConstants.BRIDGE_BOOK_VBID_ID, vbid);
		params.put(ApplicationConstants.DEEPLINK_LOCATION, linkLocation);
		ResponseEntity<RestResponse> responseEntity = applicationServiceHandler.process(
				AuthenticatedRestAction.LAUNCH_BOOK_FOR_VBID, PortalPermissionType.user, sessionId, params, request,
				response, uriInfo);
		RestResponse restResponse = (RestResponse) responseEntity.getBody();
		if (restResponse.getCode() == 200) {
			BookUrl bookUrl = (BookUrl) restResponse.getData();
			if (null != bookUrl) {
				response.setHeader("Location", bookUrl.getUrl());
				response.setStatus(HttpStatus.FOUND.value());
			}
			
		} else {
			try {
				String domain = VstUtils.getUrlWithProtocol(request, VstUtils.getDomain(uriInfo, request));
				response.setHeader("Location", domain + ApplicationConstants.BRIDGE_BOOK_DETAILS + vbid);
				response.setStatus(HttpStatus.FOUND.value());
			} catch (MalformedURLException e) {
			}
		}

	}

	@RequestMapping(method = RequestMethod.GET, value = "{" + ApplicationConstants.BRIDGE_BOOK_VBID_ID + "}/try")
	@io.swagger.annotations.ApiOperation(value = "Get user", notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public ResponseEntity<RestResponse> tryVbid(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			@PathVariable(ApplicationConstants.BRIDGE_BOOK_VBID_ID) String vbid, HttpServletRequest request,
			HttpServletResponse response) {
		/*
		 * ResponseEntity<RestResponse> responseEntity =
		 * applicationServiceHandler.process(AuthenticatedRestAction.
		 * TRY_BOOK_FOR_VBID, PortalPermissionType.user, sessionId, vbid,
		 * request, response,uriInfo); RestResponse restResponse =
		 * (RestResponse) responseEntity.getBody();
		 * if(restResponse.getCode()==200){ BookUrl bookUrl = (BookUrl)
		 * restResponse.getData(); response.setHeader("Location",
		 * bookUrl.getUrl()); response.setStatus(302); }
		 */
		return applicationServiceHandler.process(AuthenticatedRestAction.TRY_BOOK_FOR_VBID, PortalPermissionType.user,
				sessionId, vbid, request, response, uriInfo);
	}

	@RequestMapping(method = RequestMethod.GET, value = "{" + ApplicationConstants.BRIDGE_BOOK_VBID_ID + "}/rent")
	@io.swagger.annotations.ApiOperation(value = "Get user", notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public ResponseEntity<RestResponse> rentVbid(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			@PathVariable(ApplicationConstants.BRIDGE_BOOK_VBID_ID) String vbid, HttpServletRequest request,
			HttpServletResponse response) {

		/*
		 * ResponseEntity<RestResponse> responseEntity =
		 * applicationServiceHandler.process(AuthenticatedRestAction.
		 * RENT_BOOK_FOR_VBID, PortalPermissionType.user, sessionId, vbid,
		 * request,response, uriInfo); RestResponse restResponse =
		 * (RestResponse) responseEntity.getBody();
		 * if(restResponse.getCode()==200){ BookUrl bookUrl = (BookUrl)
		 * restResponse.getData(); response.setHeader("Location",
		 * bookUrl.getUrl()); response.setStatus(302); }
		 */
		return applicationServiceHandler.process(AuthenticatedRestAction.RENT_BOOK_FOR_VBID, PortalPermissionType.user,
				sessionId, vbid, request, response, uriInfo);
	}

	@RequestMapping(method = RequestMethod.GET, value = "{" + ApplicationConstants.BRIDGE_BOOK_VBID_ID + "}/full")
	@io.swagger.annotations.ApiOperation(value = "Get user", notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public ResponseEntity<RestResponse> fullVbid(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			@PathVariable(ApplicationConstants.BRIDGE_BOOK_VBID_ID) String vbid, HttpServletRequest request,
			HttpServletResponse response) {

		/*
		 * ResponseEntity<RestResponse> responseEntity =
		 * applicationServiceHandler.process(AuthenticatedRestAction.
		 * FULL_BOOK_FOR_VBID, PortalPermissionType.user, sessionId, vbid,
		 * request,response, uriInfo); RestResponse restResponse =
		 * (RestResponse) responseEntity.getBody();
		 * if(restResponse.getCode()==200){ BookUrl bookUrl = (BookUrl)
		 * restResponse.getData(); response.setHeader("Location",
		 * bookUrl.getUrl()); response.setStatus(302); }
		 */
		return applicationServiceHandler.process(AuthenticatedRestAction.FULL_BOOK_FOR_VBID, PortalPermissionType.user,
				sessionId, vbid, request, response, uriInfo);
	}

	/*
	 * @RequestMapping(method=RequestMethod.GET,value="{"+ApplicationConstants.
	 * BRIDGE_BOOK_VBID_ID+"}/print")
	 * 
	 * @io.swagger.annotations.ApiOperation(value = "Get user",notes =
	 * "To get logged in user information")
	 * 
	 * @io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200,
	 * message = "OK")}) public ResponseEntity<RestResponse>
	 * printVbid(@CookieValue(value=ApplicationConstants.BRIDGE_SESSIONID,
	 * defaultValue="") String
	 * sessionId, @PathVariable(ApplicationConstants.BRIDGE_BOOK_VBID_ID) String
	 * vbid, HttpServletRequest request,HttpServletResponse response ) { return
	 * applicationServiceHandler.process(AuthenticatedRestAction.
	 * PRINT_BOOK_FOR_VBID, PortalPermissionType.user, sessionId, vbid, request,
	 * response,uriInfo); }
	 */

	@RequestMapping(method = RequestMethod.GET, value = "{" + ApplicationConstants.BRIDGE_BOOK_VBID_ID
			+ "}/rentpurchase")
	@io.swagger.annotations.ApiOperation(value = "Get user", notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public void rentPurchaseForVbid(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			@PathVariable(ApplicationConstants.BRIDGE_BOOK_VBID_ID) String vbid, HttpServletRequest request,
			HttpServletResponse response) {

		ResponseEntity<RestResponse> responseEntity = applicationServiceHandler.process(
				AuthenticatedRestAction.RENT_PURCHASE_FOR_VBID, PortalPermissionType.user, sessionId, vbid, request,
				response, uriInfo);
		RestResponse restResponse = (RestResponse) responseEntity.getBody();
		if (restResponse.getCode() == 200) {
			BookUrl bookUrl = (BookUrl) restResponse.getData();
			if (null != bookUrl) {
				response.setHeader("Location", bookUrl.getUrl());
			}
			response.setStatus(302);
		}
	}

	@RequestMapping(method = RequestMethod.GET, value = "{" + ApplicationConstants.BRIDGE_BOOK_VBID_ID
			+ "}/printpurchase")
	@io.swagger.annotations.ApiOperation(value = "Get user", notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public void printPurchaseForVbid(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			@PathVariable(ApplicationConstants.BRIDGE_BOOK_VBID_ID) String vbid, HttpServletRequest request,
			HttpServletResponse response) {
		ResponseEntity<RestResponse> responseEntity = applicationServiceHandler.process(
				AuthenticatedRestAction.PRINT_PURCHASE_FOR_VBID, PortalPermissionType.user, sessionId, vbid, request,
				response, uriInfo);
		RestResponse restResponse = (RestResponse) responseEntity.getBody();
		if (restResponse.getCode() == 200) {
			BookUrl bookUrl = (BookUrl) restResponse.getData();
			if (null != bookUrl) {
				response.setHeader("Location", bookUrl.getUrl());
			}
			response.setStatus(302);
		}
	}

	@RequestMapping(method = RequestMethod.GET, value = "{" + ApplicationConstants.BRIDGE_BOOK_VBID_ID
			+ "}/fullpurchase")
	@io.swagger.annotations.ApiOperation(value = "Get user", notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public void fullPurchaseForVbid(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			@PathVariable(ApplicationConstants.BRIDGE_BOOK_VBID_ID) String vbid, HttpServletRequest request,
			HttpServletResponse response) {
		ResponseEntity<RestResponse> responseEntity = applicationServiceHandler.process(
				AuthenticatedRestAction.FULL_PURCHASE_FOR_VBID, PortalPermissionType.user, sessionId, vbid, request,
				response, uriInfo);
		RestResponse restResponse = (RestResponse) responseEntity.getBody();
		if (restResponse.getCode() == 200) {
			BookUrl bookUrl = (BookUrl) restResponse.getData();
			if (null != bookUrl) {
				response.setHeader("Location", bookUrl.getUrl());
			}
			response.setStatus(302);
		}
	}

	
	@RequestMapping(method = RequestMethod.GET, value = "{" + ApplicationConstants.BRIDGE_BOOK_VBID_ID
			+ "}/purchase/{"+ApplicationConstants.BRIDGE_PURCHASE_ID+"}")
	@io.swagger.annotations.ApiOperation(value = "Get purchase URL", notes = "To get purchase URL for book")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public void purchaseForVbid(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			@PathVariable(ApplicationConstants.BRIDGE_BOOK_VBID_ID) String vbid, HttpServletRequest request,
			@PathVariable(ApplicationConstants.BRIDGE_PURCHASE_ID)String purchaseId,
			HttpServletResponse response) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put(ApplicationConstants.BRIDGE_BOOK_VBID_ID, vbid);
		params.put(ApplicationConstants.BRIDGE_PURCHASE_ID, purchaseId);
		ResponseEntity<RestResponse> responseEntity = applicationServiceHandler.process(
				AuthenticatedRestAction.PURCHASE_FOR_VBID, PortalPermissionType.user, sessionId, params, request,
				response, uriInfo);
		RestResponse restResponse = (RestResponse) responseEntity.getBody();
		if (restResponse.getCode() == 200) {
			BookUrl bookUrl = (BookUrl) restResponse.getData();
			if (null != bookUrl) {
				response.setHeader("Location", bookUrl.getUrl());
			}
			response.setStatus(302);
		}
	}
	
	
	@RequestMapping(method = RequestMethod.GET, value = "{" + ApplicationConstants.BRIDGE_BOOK_VBID_ID + "}/concurrent")
	@io.swagger.annotations.ApiOperation(value = "concurrencyVbid", notes = "concurrencyVbid")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public ResponseEntity<RestResponse> concurrencyVbid(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			@PathVariable(ApplicationConstants.BRIDGE_BOOK_VBID_ID) String vbid, HttpServletRequest request,
			HttpServletResponse response) {

		return applicationServiceHandler.process(AuthenticatedRestAction.CONCURRENCY_BOOK_FOR_VBID,
				PortalPermissionType.user, sessionId, vbid, request, response, uriInfo);
	}

	@RequestMapping(method = RequestMethod.GET, value = "{" + ApplicationConstants.BRIDGE_BOOK_VBID_ID + "}/return")
	@io.swagger.annotations.ApiOperation(value = "ReturnVbid", notes = "ReturnBook")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public ResponseEntity<RestResponse> returnVbid(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			@PathVariable(ApplicationConstants.BRIDGE_BOOK_VBID_ID) String vbid, HttpServletRequest request,
			HttpServletResponse response) {

		return applicationServiceHandler.process(AuthenticatedRestAction.RETURN_BOOK_FOR_VBID,
				PortalPermissionType.user, sessionId, vbid, request, response, uriInfo);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "{" + ApplicationConstants.BRIDGE_BOOK_VBID_ID + "}/{"+ApplicationConstants.ENTITLEMENT_ID+"}")
	@io.swagger.annotations.ApiOperation(value = "Redeem entitlement", notes = "Redeem entitlement on vbid")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public ResponseEntity<RestResponse> redeemVbid(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			@PathVariable(ApplicationConstants.BRIDGE_BOOK_VBID_ID) String vbid,@PathVariable(ApplicationConstants.ENTITLEMENT_ID) String entitlementId, HttpServletRequest request,
			HttpServletResponse response) {

		Map<String, String> putMap = new HashMap<String, String>();
		putMap.put(ApplicationConstants.BRIDGE_BOOK_VBID_ID, vbid);
		putMap.put(ApplicationConstants.ENTITLEMENT_ID, entitlementId);
		return applicationServiceHandler.process(AuthenticatedRestAction.REDEEM_BOOK_FOR_VBID, PortalPermissionType.user,
				sessionId, putMap, request, response, uriInfo);
	}

	
	@RequestMapping(method = RequestMethod.GET, value = "{" + ApplicationConstants.BRIDGE_BOOK_VBID_ID + "}/concurrent/{"+ApplicationConstants.CONCURRENCY_ENTITLEMENT_ID+"}")
	@io.swagger.annotations.ApiOperation(value = "Redeem concurrency entitlement", notes = "Redeem concurrency entitlement on vbid")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public ResponseEntity<RestResponse> redeemConcurrencyVbid(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			@PathVariable(ApplicationConstants.BRIDGE_BOOK_VBID_ID) String vbid,@PathVariable(ApplicationConstants.CONCURRENCY_ENTITLEMENT_ID) String concEntitlementId, HttpServletRequest request,
			HttpServletResponse response) {

		Map<String, String> putMap = new HashMap<String, String>();
		putMap.put(ApplicationConstants.BRIDGE_BOOK_VBID_ID, vbid);
		putMap.put(ApplicationConstants.CONCURRENCY_ENTITLEMENT_ID, concEntitlementId);
		return applicationServiceHandler.process(AuthenticatedRestAction.REDEEM_BOOK_FOR_CONCURRENCY_VBID, PortalPermissionType.user,
				sessionId, putMap, request, response, uriInfo);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "{" + ApplicationConstants.BRIDGE_BOOK_VBID_ID + "}/download")
	@io.swagger.annotations.ApiOperation(value = "Get user", notes = "To get logged in user information")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public ResponseEntity<RestResponse> downloadAncillary(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			@PathVariable(ApplicationConstants.BRIDGE_BOOK_VBID_ID) String vbid,
			HttpServletRequest request, HttpServletResponse response) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put(ApplicationConstants.BRIDGE_BOOK_VBID_ID, vbid);
		return applicationServiceHandler.process(
				AuthenticatedRestAction.DOWNLOAD_ANCILLARY, PortalPermissionType.user, sessionId, params, request,
				response, uriInfo);
	}
}
