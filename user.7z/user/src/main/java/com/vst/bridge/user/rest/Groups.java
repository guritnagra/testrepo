package com.vst.bridge.user.rest;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vst.bridge.rest.central.IApplicationServiceHandler;
import com.vst.bridge.rest.config.AuthenticatedRestAction;
import com.vst.bridge.rest.config.PortalPermissionType;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.util.constant.ApplicationConstants;

import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;

@RestController
@RequestMapping(value = "/groups")
@io.swagger.annotations.Api(value = "/Groups")
public class Groups {

	UriInfo uriInfo;

	Request request;

	// private static Logger log = LogManager.getLogger(Books.class);

	@Autowired
	private IApplicationServiceHandler applicationServiceHandler;


	@RequestMapping(method = RequestMethod.GET)
	@io.swagger.annotations.ApiOperation(value = "Get groups", notes = "Get groups")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public ResponseEntity<RestResponse> getGroups(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			HttpServletRequest request, HttpServletResponse response) {

		return applicationServiceHandler.process(AuthenticatedRestAction.GET_GROUPS, PortalPermissionType.user, sessionId, null, request, response, uriInfo);
	//	return ResponseEntity.status(status).body(restResponse);
	}

	
	@RequestMapping(method = RequestMethod.GET, value = "{" + ApplicationConstants.REST_PARAM_ID + "}/books")
	@io.swagger.annotations.ApiOperation(value = "Get group books by ID", notes = "Get group books by ID")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public ResponseEntity<RestResponse> getGroupByID(
			@CookieValue(value = ApplicationConstants.BRIDGE_SESSIONID, defaultValue = "") String sessionId,
			HttpServletRequest request, HttpServletResponse response,
			@PathVariable(ApplicationConstants.REST_PARAM_ID) int groupId,
			@ApiParam(value = "Unique project token", required = false) @RequestParam(value = ApplicationConstants.PAGINATION_PAGE, required = false) Integer page,
			@ApiParam(value = "Unique project token", required = false) @RequestParam(value = ApplicationConstants.PAGINATION_LIMIT, required = false) Integer limit,
			@ApiParam(value = "Unique project token", required = false) @RequestParam(value = ApplicationConstants.PAGINATION_ORDERBY, required = false) String orderby,
			@ApiParam(value = "Unique project token", required = false) @RequestParam(value = ApplicationConstants.PAGINATION_ORDER, required = false) String order,
			@ApiParam(value = "Unique project token", required = false) @RequestParam(value = ApplicationConstants.PAGINATION_SEARCH, required = false) String search) {
		if(search!=null && StringUtils.isNotEmpty(search)){
 			try { 				
 				search = new String(search.getBytes("ISO-8859-1"), "UTF-8"); 				
 			} catch (UnsupportedEncodingException e) {
 				// TODO Auto-generated catch block
 				e.printStackTrace();
 			}
 		}
		BridgePaginationVo paginationVo = new BridgePaginationVo(null,null,page, limit, null, orderby, order, search, null,null);
				
		Map<String, Object> params = new HashMap<String, Object>();
		params.put(ApplicationConstants.BRIDGE_GROUP_ID, groupId);
		params.put(ApplicationConstants.PUT_REQUEST_OBJECT, paginationVo);
		return applicationServiceHandler.process(AuthenticatedRestAction.GET_GROUP_BY_ID, PortalPermissionType.user,
				sessionId, params, request, response, uriInfo);
	}
	
}
