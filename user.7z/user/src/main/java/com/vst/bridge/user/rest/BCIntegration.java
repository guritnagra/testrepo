package com.vst.bridge.user.rest;

import java.net.MalformedURLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.UriInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vst.bridge.VstUtils;
import com.vst.bridge.rest.central.IApplicationServiceHandler;
import com.vst.bridge.rest.config.PortalPermissionType;
import com.vst.bridge.rest.config.UnAuthenticatedRestAction;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.util.constant.ApplicationConstants;

import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;

/**
 * REST web-services endpoints for /user/* URLs.
 **/
@RestController
@io.swagger.annotations.Api(value = "/BCIntegration")
public class BCIntegration {
	@Autowired
	private IApplicationServiceHandler applicationServiceHandler;

	@RequestMapping(method = RequestMethod.GET, value = "/sso")
	@io.swagger.annotations.ApiOperation(value = "Get user", notes = "sso api")
	@io.swagger.annotations.ApiResponses(value = { @ApiResponse(code = 200, message = "OK") })
	public void createUserFromContextToken(
			@ApiParam(value = "Unique project token", required = true) @RequestParam(value = ApplicationConstants.REST_BC_CONTEXT_TOKEN, required = true) String contextToken,
			HttpServletRequest request, HttpServletResponse response) {
		final String nullSessionId = null;
		UriInfo uriInfo = null;

		ResponseEntity<RestResponse> responseEntity = applicationServiceHandler.process(
				UnAuthenticatedRestAction.POST_CONTEXT_TOKEN, PortalPermissionType.user, nullSessionId, request,
				response, uriInfo, contextToken);
		RestResponse restResponse = (RestResponse) responseEntity.getBody();
		String domain = null;
		String location = setLocationFromRestResponse(restResponse);
		try {
			domain = VstUtils.getUrlWithProtocol(request, VstUtils.getDomain(uriInfo, request));

		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		if (restResponse.getCode() == HttpStatus.OK.value()) {
			response.setStatus(HttpStatus.FOUND.value());
			if (null != domain) {
				response.setHeader("Location", domain + location);
			}
		}else{
			response.setStatus(HttpStatus.FOUND.value());
			if (null != domain) {
				response.setHeader("Location", domain + ApplicationConstants.USER_ERROR_PAGE);
			}
		}
	}

	@SuppressWarnings("unchecked")
	private String setLocationFromRestResponse(RestResponse restResponse) {
		String location = ApplicationConstants.BRIDGE_COLLECTION;
		Object responseData = restResponse.getMetadata() ;

		if (responseData instanceof Map){
			Map<String,String> metadata = (Map<String, String>) responseData;
			location = null == metadata.get("location") ? location: metadata.get("location");
		}
		return location;
	}
}
