package com.vst.bridge.entity.bridge;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Cascade;

import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.base.SoftDelete;
import com.vst.bridge.entity.company.Company;

/**
 * This class represents Bridge in this Application.
 *  
 * @author Irfan.Tamboli
 *
 */


@Entity
@Table(name="tbl_bridge")
public class Bridge extends SoftDelete{

	private static final long serialVersionUID = 1L;
	private String name;
	private String contactName;
	private String contactNo;
	private String email;
	private String domain;
	private String code;
	private String language;
	private AdminUser lastModifier;
	private Date modifiedDate;
	private Boolean pendingApproved = Boolean.TRUE;
	private Integer purchaseCredits;
	private Integer trialCredits;
	private Boolean showAllBooks = Boolean.FALSE;
	private String purchasePromoCode;
	private String rentalPromoCode;
	private String fullURL;
	private String rentalURL;
	private String printBookURL;
//	private String purchaseETextURL;
	private Company company;
	private String apiKey;
	private String domainAlias;
	
	private Set<BridgeConfig> configs = new HashSet<BridgeConfig>(0);
	private Boolean passwordProtected=Boolean.FALSE;
	private String password;
	private BridgeType bridgeType;
	private Integer deletedBy;
	private Date deletedTime;
	private String bookshelfUrl;
	private Integer trialDays;
	private Date trialExpires;
	private Integer rentalCredits;
	private Integer rentalDays;
	private Date rentalExpires;
	private Integer fullCredits;
	private Integer fullDays;
	private Date fullExpires;
	
	private Boolean derefedSignIn=Boolean.FALSE;
	
	private Boolean keysRequired=Boolean.TRUE;
	
	private Boolean isRostered=Boolean.FALSE;
	
	private Integer offlineTrialDays;
	private Date offlineTrialExpires;
	private Integer offlineRentalDays;
	private Date offlineRentalExpires;
	private Integer offlineFullDays;
	private Date offlineFullExpires;
	
	private Integer concurrencyLimit;
	
	private String eTextPrice;
	private String rentalPrice;
	private String textBookPrice;
	private Boolean concurrencyEnabled=Boolean.FALSE;
	private Integer concurrencyCredits;
	private Integer concurrencyDays;
	private Date concurrencyExpires;
	private Integer offlineConcurrencyDays;
	private Date offlineConcurrencyExpires;
	private CodeTypes codeType;
	private Boolean isIntegrated=Boolean.FALSE;
	private Integer bcTenantId;
	private String bcTenantName;
	private String connectCompany;
	private Boolean isSampler=Boolean.FALSE;
	private String integrationRedirectUrl;
	private Boolean isPurchasesEnabled;
	private Boolean isEmbeddedEnabled;
	
	@Column(name="trial_days")
	public Integer getTrialDays() {
		return trialDays;
	}
	public void setTrialDays(Integer trialDays) {
		this.trialDays = trialDays;
	}
	
	@Column(name="trial_expires")
	public Date getTrialExpires() {
		return trialExpires;
	}
	public void setTrialExpires(Date trialExpires) {
		this.trialExpires = trialExpires;
	}
	
	@Column(name="rental_credits")
	public Integer getRentalCredits() {
		if(null!=rentalCredits)
			rentalCredits= rentalCredits==0 ? null :rentalCredits;
		return rentalCredits;
	}
	public void setRentalCredits(Integer rentalCredits) {
		this.rentalCredits = rentalCredits;
	}
	
	@Column(name="rental_days")
	public Integer getRentalDays() {
		return rentalDays;
	}
	public void setRentalDays(Integer rentalDays) {
		this.rentalDays = rentalDays;
	}
	
	@Column(name="rental_expires")
	public Date getRentalExpires() {
		return rentalExpires;
	}
	public void setRentalExpires(Date rentalExpires) {
		this.rentalExpires = rentalExpires;
	}
	
	@Column(name="full_credits")
	public Integer getFullCredits() {
		if(null!=fullCredits){
			fullCredits = fullCredits==0?null:fullCredits;
		}
		return fullCredits;
	}
	public void setFullCredits(Integer fullCredits) {
		this.fullCredits = fullCredits;
	}
	
	@Column(name="full_days")
	public Integer getFullDays() {
		return fullDays;
	}
	public void setFullDays(Integer fullDays) {
		this.fullDays = fullDays;
	}
	
	@Column(name="full_expires")
	public Date getFullExpires() {
		return fullExpires;
	}
	public void setFullExpires(Date fullExpires) {
		this.fullExpires = fullExpires;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
		
	@Column(name="api_key",length=32)
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	@Column(name="name",length=128)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(name="contact_name",length=128)
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	@Column(name="contact_phone",length=32)
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	@Column(name="contact_email",length=128)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Column(name="domain",length=64)
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	@Column(name="language",length=8)
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	@ManyToOne
	@JoinColumn(name="last_editor", nullable=false)
	public AdminUser getLastModifier() {
		return lastModifier;
	}
	public void setLastModifier(AdminUser lastModifier) {
		this.lastModifier = lastModifier;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_edit", nullable = false)
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	@Column(name="purchase_credits")
	public Integer getPurchaseCredits() {
		return purchaseCredits;
	}
	public void setPurchaseCredits(Integer purchaseCredits) {
		this.purchaseCredits = purchaseCredits;
	}
	@Column(name="pending_approval")
	public Boolean getPendingApproved() {
		return pendingApproved;
	}
	public void setPendingApproved(Boolean pendingApproved) {
		this.pendingApproved = pendingApproved;
	}
	
	@Column(name="trial_credits")
	public Integer getTrialCredits() {
		if(null !=trialCredits)
			trialCredits= trialCredits==0 ? null:trialCredits;
		return trialCredits;
	}
	public void setTrialCredits(Integer trialCredits) {
		this.trialCredits = trialCredits;
	}
	@Column(name="show_all_books")
	public Boolean getShowAllBooks() {
		return showAllBooks;
	}
	public void setShowAllBooks(Boolean showAllBooks) {
		this.showAllBooks = showAllBooks;
	}
	@Column(name="purchase_promo_code")
	public String getPurchasePromoCode() {
		return purchasePromoCode;
	}
	public void setPurchasePromoCode(String purchasePromoCode) {
		this.purchasePromoCode = purchasePromoCode;
	}
	@Column(name="rental_promo_code")
	public String getRentalPromoCode() {
		return rentalPromoCode;
	}
	public void setRentalPromoCode(String rentalPromoCode) {
		this.rentalPromoCode = rentalPromoCode;
	}
	@Column(name="full_url",length=256)
	public String getFullURL() {
		return fullURL;
	}
	public void setFullURL(String fullURL) {
		this.fullURL = fullURL;
	}
	@Column(name="rental_url",length=256)
	public String getRentalURL() {
		return rentalURL;
	}
	public void setRentalURL(String rentalURL) {
		this.rentalURL = rentalURL;
	}
	@Column(name="textbook_url",length=256)
	public String getPrintBookURL() {
		return printBookURL;
	}
	public void setPrintBookURL(String printBookURL) {
		this.printBookURL = printBookURL;
	}

	@ManyToOne
	@JoinColumn(name="company_id")
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}	
	@OneToMany(mappedBy="bridge")
	@Cascade(org.hibernate.annotations.CascadeType.SAVE_UPDATE)
	public Set<BridgeConfig> getConfigs() {
		return configs;
	}
	public void setConfigs(Set<BridgeConfig> configs) {
		this.configs = configs;
	}
	@Column(name="code",length=64)
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	@Column(name="domain_alias",length=256)
	public String getDomainAlias() {
		return domainAlias;
	}
	public void setDomainAlias(String domainAlias) {
		this.domainAlias = domainAlias;
	}
	@Column(name="password_protected")
	public Boolean getPasswordProtected() {
		return passwordProtected;
	}
	public void setPasswordProtected(Boolean passwordProtected) {
		this.passwordProtected = passwordProtected;
	}
	@Column(name="password",length=128)
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@ManyToOne
	@JoinColumn(name="bridge_type_id")
	public BridgeType getBridgeType() {
		return bridgeType;
	}
	public void setBridgeType(BridgeType bridgeType) {
		this.bridgeType = bridgeType;
	}
	@Column(name="deleted_by")
	public Integer getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(Integer deletedBy) {
		this.deletedBy = deletedBy;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="deleted_time")
	public Date getDeletedTime() {
		return deletedTime;
	}
	public void setDeletedTime(Date deletedTime) {
		this.deletedTime = deletedTime;
	}
	@Column(name="bookshelf_url",length=256)
	public String getBookshelfUrl() {
		return bookshelfUrl;
	}
	public void setBookshelfUrl(String bookshelfUrl) {
		this.bookshelfUrl = bookshelfUrl;
	}
	@Column(name="defer_sign_in")
	public Boolean getDerefedSignIn() {
		return derefedSignIn;
	}
	public void setDerefedSignIn(Boolean derefedSignIn) {
		this.derefedSignIn = derefedSignIn;
	}
	@Column(name="keys_required")
	public Boolean getKeysRequired() {
		return keysRequired;
	}
	public void setKeysRequired(Boolean keysRequired) {
		this.keysRequired = keysRequired;
	}
	@Column(name="offline_trial_days")
	public Integer getOfflineTrialDays() {
		return offlineTrialDays;
	}
	public void setOfflineTrialDays(Integer offlineTrialDays) {
		this.offlineTrialDays = offlineTrialDays;
	}
	@Column(name="offline_trial_expires")
	public Date getOfflineTrialExpires() {
		return offlineTrialExpires;
	}
	public void setOfflineTrialExpires(Date offlineTrialExpires) {
		this.offlineTrialExpires = offlineTrialExpires;
	}
	@Column(name="offline_rental_days")
	public Integer getOfflineRentalDays() {
		return offlineRentalDays;
	}
	public void setOfflineRentalDays(Integer offlineRentalDays) {
		this.offlineRentalDays = offlineRentalDays;
	}
	@Column(name="offline_rental_expires")
	public Date getOfflineRentalExpires() {
		return offlineRentalExpires;
	}
	public void setOfflineRentalExpires(Date offlineRentalExpires) {
		this.offlineRentalExpires = offlineRentalExpires;
	}
	@Column(name="offline_full_days")
	public Integer getOfflineFullDays() {
		return offlineFullDays;
	}
	public void setOfflineFullDays(Integer offlineFullDays) {
		this.offlineFullDays = offlineFullDays;
	}
	@Column(name="offline_full_expires")
	public Date getOfflineFullExpires() {
		return offlineFullExpires;
	}
	public void setOfflineFullExpires(Date offlineFullExpires) {
		this.offlineFullExpires = offlineFullExpires;
	}
	@Column(name="is_rostered",nullable = false)
	public Boolean getIsRostered() {
		return isRostered;
	}
	public void setIsRostered(Boolean isRostered) {
		this.isRostered = isRostered;
	}
	
	@Column(name="concurrency_limit")
	public Integer getConcurrencyLimit() {
		return concurrencyLimit;
	}
	public void setConcurrencyLimit(Integer concurrencyLimit) {
		this.concurrencyLimit = concurrencyLimit;
	}
	@Column(name="full_url_price")
	public String geteTextPrice() {
		return eTextPrice;
	}
	public void seteTextPrice(String eTextPrice) {
		this.eTextPrice = eTextPrice;
	}
	@Column(name="rental_url_price")
	public String getRentalPrice() {
		return rentalPrice;
	}
	public void setRentalPrice(String rentalPrice) {
		this.rentalPrice = rentalPrice;
	}
	@Column(name="textbook_url_price")
	public String getTextBookPrice() {
		return textBookPrice;
	}
	public void setTextBookPrice(String textBookPrice) {
		this.textBookPrice = textBookPrice;
	}
	@Column(name="concurrency_enabled")
	public Boolean getConcurrencyEnabled() {
		return concurrencyEnabled;
	}
	public void setConcurrencyEnabled(Boolean concurrencyEnabled) {
		this.concurrencyEnabled = concurrencyEnabled;
	}
	@Column(name="concurrency_credits")
	public Integer getConcurrencyCredits() {
		return concurrencyCredits;
	}
	public void setConcurrencyCredits(Integer concurrencyCredits) {
		this.concurrencyCredits = concurrencyCredits;
	}
	@Column(name="concurrency_days")
	public Integer getConcurrencyDays() {
		return concurrencyDays;
	}
	public void setConcurrencyDays(Integer concurrencyDays) {
		this.concurrencyDays = concurrencyDays;
	}
	@Column(name="concurrency_expires")
	public Date getConcurrencyExpires() {
		return concurrencyExpires;
	}
	public void setConcurrencyExpires(Date concurrencyExpires) {
		this.concurrencyExpires = concurrencyExpires;
	}
	@Column(name="offline_concurrency_days")
	public Integer getOfflineConcurrencyDays() {
		return offlineConcurrencyDays;
	}
	public void setOfflineConcurrencyDays(Integer offlineConcurrencyDays) {
		this.offlineConcurrencyDays = offlineConcurrencyDays;
	}
	@Column(name="offline_concurrency_expires")
	public Date getOfflineConcurrencyExpires() {
		return offlineConcurrencyExpires;
	}
	public void setOfflineConcurrencyExpires(Date offlineConcurrencyExpires) {
		this.offlineConcurrencyExpires = offlineConcurrencyExpires;
	}
	@ManyToOne
	@JoinColumn(name="concurrency_comp_type")
	public CodeTypes getCodeType() {
		return codeType;
	}
	public void setCodeType(CodeTypes codeType) {
		this.codeType = codeType;
	}
	@Column(name="is_integrated")
	public Boolean getIsIntegrated() {
		return isIntegrated;
	}
	public void setIsIntegrated(Boolean isIntegrated) {
		this.isIntegrated = isIntegrated;
	}
	@Column(name="bc_tenant_id")
	public Integer getBcTenantId() {
		return bcTenantId;
	}
	public void setBcTenantId(Integer bcTenantId) {
		this.bcTenantId = bcTenantId;
	}
	@Column(name="bc_tenant_name")
	public String getBcTenantName() {
		return bcTenantName;
	}
	public void setBcTenantName(String bcTenantName) {
		this.bcTenantName = bcTenantName;
	}
	@Column(name="connect_company")
	public String getConnectCompany() {
		return connectCompany;
	}
	public void setConnectCompany(String connectCompany) {
		this.connectCompany = connectCompany;
	}
	@Column(name="is_sampler")
	public Boolean getIsSampler() {
		return isSampler;
	}
	public void setIsSampler(Boolean isSampler) {
		this.isSampler = isSampler;
	}
	@Column(name="redirect_url")
	public String getIntegrationRedirectUrl() {
		return integrationRedirectUrl;
	}
	public void setIntegrationRedirectUrl(String integrationRedirectUrl) {
		this.integrationRedirectUrl = integrationRedirectUrl;
	}
	@Column(name="is_purchases_enabled")
	public Boolean getIsPurchasesEnabled() {
		return isPurchasesEnabled;
	}
	public void setIsPurchasesEnabled(Boolean isPurchasesEnabled) {
		this.isPurchasesEnabled = isPurchasesEnabled;
	}
	@Column(name="is_embedded_enabled")
	public Boolean getIsEmbeddedEnabled() {
		return isEmbeddedEnabled;
	}
	public void setIsEmbeddedEnabled(Boolean isEmbeddedEnabled) {
		this.isEmbeddedEnabled = isEmbeddedEnabled;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((apiKey == null) ? 0 : apiKey.hashCode());
		result = prime * result + ((bcTenantId == null) ? 0 : bcTenantId.hashCode());
		result = prime * result + ((bcTenantName == null) ? 0 : bcTenantName.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bridge other = (Bridge) obj;
		if (apiKey == null) {
			if (other.apiKey != null)
				return false;
		} else if (!apiKey.equals(other.apiKey))
			return false;
		if (bcTenantId == null) {
			if (other.bcTenantId != null)
				return false;
		} else if (!bcTenantId.equals(other.bcTenantId))
			return false;
		if (bcTenantName == null) {
			if (other.bcTenantName != null)
				return false;
		} else if (!bcTenantName.equals(other.bcTenantName))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Bridge [Name=" + name + ", Id=" + getId() + "]";
	}	
	
		
}
