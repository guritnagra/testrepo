package com.vst.bridge.entity.question;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.vst.bridge.entity.base.BaseEntity;

@Entity
@Table(name="tbl_security_questions")
public class SecurityQuestion extends BaseEntity{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String text;

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}
