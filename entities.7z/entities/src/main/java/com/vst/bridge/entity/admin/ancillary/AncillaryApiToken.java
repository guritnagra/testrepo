package com.vst.bridge.entity.admin.ancillary;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.vst.bridge.entity.base.SoftDelete;

@Entity
@Table(name="tbl_ancillary_api_token")
public class AncillaryApiToken extends SoftDelete{

	private static final long serialVersionUID = 1L;
	private String apiToken;
	
	@Column(name="api_token", length=64, nullable=false)
	public String getApiToken() {
		return apiToken;
	}

	public void setApiToken(String apiToken) {
		this.apiToken = apiToken;
	}
	
}
