package com.vst.bridge.entity.group;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.vst.bridge.entity.base.BaseEntity;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.Role;

@Entity
@Table(name="tbl_bridgegroups_bridgeuser")
public class GroupUser extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BridgeGroup group;
	private BridgeUser user;
	private Boolean selected=true;
	private Role role;
	private String sourceId;
	

	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="group_id")
	public BridgeGroup getGroup() {
		return group;
	}
	public void setGroup(BridgeGroup group) {
		this.group = group;
	}
	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="user_id")
	public BridgeUser getUser() {
		return user;
	}
	public void setUser(BridgeUser user) {
		this.user = user;
	}
	@Column(name="is_selected",nullable=false)
	public Boolean getSelected() {
		return selected;
	}
	public void setSelected(Boolean selected) {
		this.selected = selected;
	}
	@ManyToOne
	@JoinColumn(name="role",nullable=true)
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	@Column(name="source_id")
	public String getSourceId() {
		return sourceId;
	}
	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((group == null) ? 0 : group.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		GroupUser other = (GroupUser) obj;
		if (group == null) {
			if (other.group != null)
				return false;
		} else if (!group.equals(other.group))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "GroupUser [group=" + group + ", user=" + user + ", selected=" + selected + "]";
	}	
	
}
