package com.vst.bridge.entity.job;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.vst.bridge.entity.base.BaseEntity;

@Entity
@Table(name="tbl_job_task")
public class JobTask extends BaseEntity {
	
	private static final long serialVersionUID = 1L;
	private Integer bridgeId;
	private Integer tenantId;
	private String jobStatus;
	private String jobType;
	private String recordType;
	private String errorDesc;
	
	@Column(name="bridge_id")
	public Integer getBridgeId() {
		return bridgeId;
	}
	public void setBridgeId(Integer bridgeId) {
		this.bridgeId = bridgeId;
	}
	@Column(name="bc_tenant_id")
	public Integer getTenantId() {
		return tenantId;
	}
	public void setTenantId(Integer tenantId) {
		this.tenantId = tenantId;
	}
	@Column(name="job_status")
	public String getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	@Column(name="job_type")
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	
	@Column(name="error_desc")
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	@Column(name="record_type")
	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
}
