package com.vst.bridge.entity.bridge.log;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.base.BaseEntity;
import com.vst.bridge.entity.bridge.Bridge;

@Entity
@Table(name="tbl_bridge_admin_log")
public class BridgeAdminLog extends BaseEntity{
	private static final long serialVersionUID = 1L;
	private AdminUser adminUser;
	private Bridge bridge;
	private String action;
	private String value;
	private String data;
	private Date createdDate;
	
	@ManyToOne
	@JoinColumn(name="admin_id")
	public AdminUser getAdminUser() {
		return adminUser;
	}
	public void setAdminUser(AdminUser adminUser) {
		this.adminUser = adminUser;
	}
	
	@ManyToOne
	@JoinColumn(name="bridge_id")
	public Bridge getBridge() {
		return bridge;
	}

	public void setBridge(Bridge bridge) {
		this.bridge = bridge;
	}
	@Column(name="action",length=45)
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	@Column(name="value",length=128)
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	@Column(name="data")
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created", nullable = false,updatable=false,insertable=false)
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
}
