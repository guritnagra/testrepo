package com.vst.bridge.entity.bc;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.base.BaseEntity;

@Entity
@Table(name="tbl_context_token")
public class ContextToken extends BaseEntity{

	private static final long serialVersionUID = 1L;
	private String contextToken;
	private Date createdDate;
	
	@Column(name="context_token",length=128)
	public String getContextToken() {
		return contextToken;
	}
	public void setContextToken(String contextToken) {
		this.contextToken = contextToken;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created", nullable = false,updatable=false,insertable=false)
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}	
}
