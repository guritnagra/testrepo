package com.vst.bridge.entity.bridge.user;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.base.SoftDelete;
import com.vst.bridge.entity.keys.Keys;

@Entity
@Table(name="tbl_bridgeuser_keyassign")
public class BridgeUserKey extends SoftDelete{

	private static final long serialVersionUID = 1L;
	private BridgeUser user;
	private Keys key;
	private Date activationDate;
	
	@ManyToOne
	@JoinColumn(name="user_id", nullable=false)
	public BridgeUser getUser() {
		return user;
	}
	public void setUser(BridgeUser user) {
		this.user = user;
	}
	@ManyToOne
	@JoinColumn(name="key_id", nullable=false)
	public Keys getKey() {
		return key;
	}
	public void setKey(Keys key) {
		this.key = key;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="activation_date",nullable=true)
	public Date getActivationDate() {
		return activationDate;
	}
	public void setActivationDate(Date activationDate) {
		this.activationDate = activationDate;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((key == null) ? 0 : key.getId().hashCode());
		result = prime * result + ((user == null) ? 0 : user.getId().hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof BridgeUserKey){
			BridgeUserKey newObj = (BridgeUserKey) obj;
			return ((newObj.user.getId() == this.user.getId()) &&(newObj.getKey().getId()== this.getKey().getId())) ? true : false ; 
		}
		return false;
	}
	
	
}
