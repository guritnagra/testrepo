package com.vst.bridge.entity.bridge;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.vst.bridge.entity.base.SoftDelete;

/**
 * This class represents Configuration Of Bridge in this Application.
 *  
 * @author Irfan.Tamboli
 *
 */

@Entity
@Table(name="tbl_bridge_config")
public class BridgeConfig extends SoftDelete{

	private static final long serialVersionUID = 1L;
	private String keyName;
	private String keyValue;
	private Bridge bridge;
	@Column(name="key_name",length=255)
	public String getKeyName() {
		return keyName;
	}
	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}
	@Column(name="key_val",length=512)
	public String getKeyValue() {
		return keyValue;
	}
	public void setKeyValue(String keyValue) {
		this.keyValue = keyValue;
	}
	@ManyToOne
	@JoinColumn(name="bridge_id", nullable=false)
	public Bridge getBridge() {
		return bridge;
	}
	public void setBridge(Bridge bridge) {
		this.bridge = bridge;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((bridge == null) ? 0 : bridge.getId().hashCode());
		result = prime * result + ((keyName == null) ? 0 : keyName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof BridgeConfig){
			BridgeConfig newObj = (BridgeConfig) obj;
			return ((newObj.bridge.getId() == this.bridge.getId()) &&(newObj.getKeyName().equals(this.keyName))) ? true : false ; 
		}
		return false;
	}
	@Override
	public String toString() {
		return "BridgeConfig [keyName=" + keyName + ", keyValue=" + keyValue + ", bridge=" + bridge + "]";
	}
}
