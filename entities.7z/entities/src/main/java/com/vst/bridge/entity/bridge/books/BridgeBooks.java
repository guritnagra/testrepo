package com.vst.bridge.entity.bridge.books;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.base.BaseEntity;
import com.vst.bridge.entity.bridge.Bridge;

@Entity
@Table(name="tbl_bridge_books")
public class BridgeBooks extends BaseEntity{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Bridge bridge;
	private String bookVbid;
	private Boolean seleted = Boolean.TRUE;
	private Date lastModifiedDate;
	
	@ManyToOne
	@JoinColumn(name="bridge_id", nullable=false)
	public Bridge getBridge() {
		return bridge;
	}
	public void setBridge(Bridge bridge) {
		this.bridge = bridge;
	}
	@Column(name="book_vbid_id")
	public String getBookVbid() {
		return bookVbid;
	}
	public void setBookVbid(String bookVbid) {
		this.bookVbid = bookVbid;
	}
	@Column(name="is_selected")
	public Boolean getSeleted() {
		return seleted;
	}
	public void setSeleted(Boolean seleted) {
		this.seleted = seleted;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="last_modified_date",updatable=true)
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
}
