package com.vst.bridge.entity.bridge.log;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.vst.bridge.entity.base.BaseEntity;

@Entity
@Table(name="tbl_bridge_login_attempt")
public class BridgeLoginAttempt extends BaseEntity{

	private static final long serialVersionUID = 1L;
	private String username;
	private String ipAddress;
	private Date lastSuccess;
	private Date lastFailure;
	private int failureCount;
	
	@Column(name="username")
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Column(name="ip_address")
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	@Column(name="last_success_time")
	public Date getLastSuccess() {
		return lastSuccess;
	}
	public void setLastSuccess(Date lastSuccess) {
		this.lastSuccess = lastSuccess;
	}
	@Column(name="last_failure_time")
	public Date getLastFailure() {
		return lastFailure;
	}
	public void setLastFailure(Date lastFailure) {
		this.lastFailure = lastFailure;
	}
	@Column(name="failure_count")
	public int getFailureCount() {
		return failureCount;
	}
	public void setFailureCount(int failureCount) {
		this.failureCount = failureCount;
	}

}
