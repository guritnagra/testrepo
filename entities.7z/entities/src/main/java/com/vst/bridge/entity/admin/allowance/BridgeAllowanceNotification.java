package com.vst.bridge.entity.admin.allowance;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.base.SoftDelete;
import com.vst.bridge.entity.bridge.Bridge;

@Entity
@Table(name="tbl_bridge_allowance_notification")
public class BridgeAllowanceNotification extends SoftDelete {
	
	private static final long serialVersionUID = 1L;
	private Bridge bridge;
	private Date lastNotification;
	
	@ManyToOne
	@JoinColumn(name="bridge_id", nullable=false)
	public Bridge getBridge() {
		return bridge;
	}
	public void setBridge(Bridge bridge) {
		this.bridge = bridge;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_notification", nullable = true)
	public Date getLastNotification() {
		return lastNotification;
	}
	public void setLastNotification(Date lastNotification) {
		this.lastNotification = lastNotification;
	}
	
}
