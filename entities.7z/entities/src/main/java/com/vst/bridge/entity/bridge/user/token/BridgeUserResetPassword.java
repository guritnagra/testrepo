package com.vst.bridge.entity.bridge.user.token;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.base.SoftDelete;

@Entity
@Table(name="tbl_bridgeuser_passwordreset")
public class BridgeUserResetPassword extends SoftDelete {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String email;
	private String token;
	private Boolean used;
	private Date createdDate;
	private Date activationDate;
	
	@Column(name="email")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Column(name="token")
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	@Column(name="used")
	public Boolean getUsed() {
		return used;
	}
	public void setUsed(Boolean used) {
		this.used = used;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_time",updatable=false)
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="activation_time")
	public Date getActivationDate() {
		return activationDate;
	}
	public void setActivationDate(Date activationDate) {
		this.activationDate = activationDate;
	}
	
}
