package com.vst.bridge.entity.admin.group;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.base.SoftDelete;

/**
 * This class represents the  Admin User Group.
 *  
 * @author Irfan.Tamboli
 *
 */
@Entity
@Table(name="tbl_admingroups")
public class Group extends SoftDelete{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private Date createdDate;
	
	@Column(name="name",length=32)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created", nullable = false,insertable = false, updatable = false)
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
}
