/**
 * @author Irfan.Tamboli
 * @version 1.0
 * @created 22 June 2015
 *
 * BaseEntity
 *
 */

package com.vst.bridge.entity.base;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * This class represents the base entity for all the modules of the Bridge. It
 * Contains all the common filed that will be part of all the Entities of the 
 * Bridge.
 *  
 * @author Irfan.Tamboli
 *
 */
@MappedSuperclass
public class BaseEntity implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	/**
	 * Represent the primary key column of the entities. Its represents identity
	 * column inside the database. 
	 * 
	 */
	private Integer id;
	
		
	/**
	 * Represents the column is how Hibernate performs optimistic locking. 
	 * If a record has been modified by another transaction, 
	 * your transaction�s version will be out of date, and an exception 
	 * will be thrown.
 	 */
	private Integer version= 0 ;
	
	/**
	 * Getter for the id.
	 * 
	 * @return id Represents the primary key column of the record.
	 */
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "id",nullable = false)
	public Integer getId() {
		return id;
	}
	/**
	 * Setter for the id.
	 * 
	 * @param id Represents the primary key column of the record.
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	/**
	 * Getter for the version.
	 * 
	 * @return version Represents the column is how Hibernate performs 
	 * 				   optimistic locking.
	 */
	//@Version
	@Column(name = "version_id",nullable = false)
	public Integer getVersion() {
		return version;
	}
	
	/**
	 * Setter for the version.
	 * 
	 * @param version Represents the column is how Hibernate performs 
	 * 				  optimistic locking.
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}
	
	/**
	 * Overridden object's equals method.
	 */
	@Override
    public boolean equals(final Object obj)
    {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof BaseEntity)) {
            return false;
        }
       
        final BaseEntity other = (BaseEntity) obj;
        
        if (null == this.getId() || null == other.getId()) {
        	return false;
        }
        return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
       
    }
	
	/**
	 * Overridden object's hashCode method.
	 */
	@Override
	public int hashCode() {
        return new HashCodeBuilder().append(getId()).toHashCode();
    }
	
}
