package com.vst.bridge.entity.bridge.books;

import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.vst.bridge.entity.admin.ancillary.Ancillary;
import com.vst.bridge.entity.base.SoftDelete;
import com.vst.bridge.entity.bridge.Bridge;


@Entity
@Table(name="tbl_bridge_books_cache")
public class BridgeBookCache extends SoftDelete{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Bridge bridge;
	private String apiKey;
	private String vbid;
	private String ebookIsbn;
	private String textbookIsbn;
	private String title;
	private String author;
	private String description;
	private URL coverImageUrl;
	private Date lastModifiedDate;
	
	private String edition;
	private List<BridgeBookPricing> bookPricing = new ArrayList<>(0);
	private Integer concurrencyLimit;
	private Ancillary ancillary;
	private String fileType;
	private String category;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="bridge_id", nullable=false)
	public Bridge getBridge() {
		return bridge;
	}
	public void setBridge(Bridge bridge) {
		this.bridge = bridge;
	}
	@Column(name="api_key",nullable=true)
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	@Column(name="vbid",nullable=true)
	public String getVbid() {
		return vbid;
	}
	public void setVbid(String vbid) {
		this.vbid = vbid;
	}
	@Column(name="ebook_isbn",nullable=true)
	public String getEbookIsbn() {
		return ebookIsbn;
	}
	public void setEbookIsbn(String ebookIsbn) {
		this.ebookIsbn = ebookIsbn;
	}
	@Column(name="textbook_isbn",nullable=true)
	public String getTextbookIsbn() {
		return textbookIsbn;
	}
	public void setTextbookIsbn(String textbookIsbn) {
		this.textbookIsbn = textbookIsbn;
	}
	@Column(name="title",nullable=true)
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Column(name="description",nullable=true)
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Column(name="author",nullable=true)
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	@Column(name="cover_image_url",nullable=true)
	public URL getCoverImageUrl() {
		return coverImageUrl;
	}
	public void setCoverImageUrl(URL coverImageUrl) {
		this.coverImageUrl = coverImageUrl;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_updated", nullable = true)
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	@Column(name="edition",nullable=true)
	public String getEdition() {
		return edition;
	}
	public void setEdition(String edition) {
		this.edition = edition;
	}
	@OneToMany(fetch=FetchType.LAZY,mappedBy="bookCache")
	@LazyCollection(LazyCollectionOption.EXTRA)
	@Cascade(org.hibernate.annotations.CascadeType.SAVE_UPDATE)
	@Fetch(FetchMode.SELECT)
		@BatchSize(size=10)
	public List<BridgeBookPricing> getBookPricing() {
		return bookPricing;
	}
	public void setBookPricing(List<BridgeBookPricing> bookPricing) {
		this.bookPricing = bookPricing;
	}
	@Column(name="concurrency_limit",nullable=true)
	public Integer getConcurrencyLimit() {
		return concurrencyLimit;
	}
	public void setConcurrencyLimit(Integer concurrencyLimit) {
		this.concurrencyLimit = concurrencyLimit;
	}
	@OneToOne(optional=true)
	@Cascade(value=org.hibernate.annotations.CascadeType.SAVE_UPDATE)
	@JoinColumn(name="ancillary_id", nullable=true)
	public Ancillary getAncillary() {
		return ancillary;
	}
	public void setAncillary(Ancillary ancillary) {
		this.ancillary = ancillary;
	}
	@Column(name="file_type", nullable=false)
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	@Column(name="category", nullable=false)
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((bridge == null || bridge.getId() == null) ? 0 : bridge.getId().hashCode());
		result = prime * result + ((vbid == null) ? 0 : vbid.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		BridgeBookCache other = (BridgeBookCache) obj;
		if (bridge == null || bridge.getId() == null) {
			if (other.getBridge() != null || other.getBridge().getId() != null)
				return false;
		} else if (!bridge.getId().equals(getBridge().getId()))
			return false;
		if (vbid == null) {
			if (other.vbid != null)
				return false;
		} else if (!vbid.equals(other.vbid))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "BridgeBookCache [bridge=" + bridge.getId() + ", vbid=" + vbid + ", title=" + title + ", fileType=" + fileType
				+ "]";
	}
	
	
	
}
