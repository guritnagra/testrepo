package com.vst.bridge.entity.admin.user;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.vst.bridge.entity.admin.group.Group;
import com.vst.bridge.entity.base.SoftDelete;

@Entity
@Table(name="tbl_adminuser_groupassign")
public class AdminGroup extends SoftDelete{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private AdminUser admin;
	private Group group;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="admin_id",nullable=false)
	public AdminUser getAdmin() {
		return admin;
	}
	public void setAdmin(AdminUser admin) {
		this.admin = admin;
	}
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="group_id",nullable=false)
	public Group getGroup() {
		return group;
	}
	public void setGroup(Group group) {
		this.group = group;
	}
}
