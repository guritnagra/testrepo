package com.vst.bridge.entity.keys;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.base.SoftDelete;
import com.vst.bridge.entity.bridge.CodeTypes;

@Entity
@Table(name="tbl_keybatches_entitlements")
public class KeyBatchEntitlement extends SoftDelete{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private KeyBatch keyBatch;
	private String entName;
	private CodeTypes entType;
	private Integer entCredits;
	private Integer entOnlineDays;
	private Date entOnlineExpires;
	private Boolean entIsReusableCredit;
	private Integer entOfflineDays;
	private Date entOfflineExpires;	
	private Boolean entIsCopyFromOnline;
	//private Boolean isConcurrencyCredit;
	private Date expires;
	
	
	
	public Date getExpires() {
		return expires;
	}
	public void setExpires(Date expires) {
		this.expires = expires;
	}
	
	@Column(name="ent_is_copy_from_online")
	public Boolean getEntIsCopyFromOnline() {
		return entIsCopyFromOnline;
	}
	public void setEntIsCopyFromOnline(Boolean entIsCopyFromOnline) {
		this.entIsCopyFromOnline = entIsCopyFromOnline;
	}
	
	/*@Column(name="ent_is_concurrency_credit")
	public Boolean getIsConcurrencyCredit() {
		return isConcurrencyCredit;
	}
	public void setIsConcurrencyCredit(Boolean isConcurrencyCredit) {
		this.isConcurrencyCredit = isConcurrencyCredit;
	}*/
	@ManyToOne
	@JoinColumn(name="key_batch_id", nullable=false)
	public KeyBatch getKeyBatch() {
		return keyBatch;
	}
	public void setKeyBatch(KeyBatch keyBatch) {
		this.keyBatch = keyBatch;
	}
	
	@Column(name="ent_name")
	public String getEntName() {
		return entName;
	}
	public void setEntName(String entName) {
		this.entName = entName;
	}
	
	@ManyToOne
	@JoinColumn(name="ent_type", nullable=false)
	public CodeTypes getEntType() {
		return entType;
	}
	public void setEntType(CodeTypes entType) {
		this.entType = entType;
	}
	
	@Column(name="ent_credits")
	public Integer getEntCredits() {
		return entCredits;
	}
	public void setEntCredits(Integer entCredits) {
		this.entCredits = entCredits;
	}
	
	@Column(name="ent_online_days")
	public Integer getEntOnlineDays() {
		return entOnlineDays;
	}
	public void setEntOnlineDays(Integer entOnlineDays) {
		this.entOnlineDays = entOnlineDays;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ent_online_expires", nullable = true,updatable=true,insertable=true)
	public Date getEntOnlineExpires() {
		return entOnlineExpires;
	}
	public void setEntOnlineExpires(Date entOnlineExpires) {
		this.entOnlineExpires = entOnlineExpires;
	}
	
	@Column(name="ent_is_reusable_credit")
	public Boolean getEntIsReusableCredit() {
		return entIsReusableCredit;
	}
	public void setEntIsReusableCredit(Boolean entIsReusableCredit) {
		this.entIsReusableCredit = entIsReusableCredit;
	}
	
	@Column(name="ent_offline_days")
	public Integer getEntOfflineDays() {
		return entOfflineDays;
	}
	public void setEntOfflineDays(Integer entOfflineDays) {
		this.entOfflineDays = entOfflineDays;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ent_offline_expires", nullable = true,updatable=true,insertable=true)
	public Date getEntOfflineExpires() {
		return entOfflineExpires;
	}
	public void setEntOfflineExpires(Date entOfflineExpires) {
		this.entOfflineExpires = entOfflineExpires;
	}

}
