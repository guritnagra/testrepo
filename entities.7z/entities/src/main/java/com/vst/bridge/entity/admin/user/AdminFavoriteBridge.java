package com.vst.bridge.entity.admin.user;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.vst.bridge.entity.base.SoftDelete;
import com.vst.bridge.entity.bridge.Bridge;

@Entity
@Table(name="tbl_adminuser_favoritebridges")
public class AdminFavoriteBridge extends SoftDelete{

	private static final long serialVersionUID = 1L;
	private AdminUser user;
	private Bridge bridge;

	
	@ManyToOne
	@JoinColumn(name="admin_id", nullable=false)
	public AdminUser getUser() {
		return user;
	}
	public void setUser(AdminUser user) {
		this.user = user;
	}
	
	@ManyToOne
	@JoinColumn(name="bridge_id", nullable=false)
	public Bridge getBridge() {
		return bridge;
	}
	public void setBridge(Bridge bridge) {
		this.bridge = bridge;
	}
}
