package com.vst.bridge.entity.keys;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.base.SoftDelete;

/**
 * This class represents Keys  in Bridge Application.
 *  
 * @author Irfan.Tamboli
 *
 */

@Entity
@Table(name="tbl_keybatches_keys")
public class Keys extends SoftDelete{
	private static final long serialVersionUID = 1L;
	private String keyCode;
	private KeyBatch keyBatch;
	private Integer fullCredits = 0;
	private Integer noOfUsers = 0;
	private Integer trialCredits =0;
	private Date expireDate;
	private Integer expireInMonth;
	private Integer expireInDays;
	
	private Integer rentalCredits=0;
	private Integer rentalDays;
	private Integer concurrencyCredits=0;
	
	@Column(name="key_code",length=32)
	public String getKeyCode() {
		return keyCode;
	}
	public void setKeyCode(String keyCode) {
		this.keyCode = keyCode;
	}
	@ManyToOne
	@JoinColumn(name="key_batch_id", nullable=true)
	public KeyBatch getKeyBatch() {
		return keyBatch;
	}
	public void setKeyBatch(KeyBatch keyBatch) {
		this.keyBatch = keyBatch;
	}
	@Column(name="full_credits")
	public Integer getFullCredits() {
		return fullCredits;
	}
	public void setFullCredits(Integer fullCredits) {
		this.fullCredits = fullCredits;
	}
	@Column(name="num_users_per_key")
	public Integer getNoOfUsers() {
		return noOfUsers;
	}
	public void setNoOfUsers(Integer noOfUsers) {
		this.noOfUsers = noOfUsers;
	}
	@Column(name="trial_credits")
	public Integer getTrialCredits() {
		return trialCredits;
	}
	public void setTrialCredits(Integer trialCredits) {
		this.trialCredits = trialCredits;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "expires")
	public Date getExpireDate() {
		return expireDate;
	}
	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}
	@Column(name="expire_months")
	public Integer getExpireInMonth() {
		return expireInMonth;
	}
	public void setExpireInMonth(Integer expireInMonth) {
		this.expireInMonth = expireInMonth;
	}
	@Column(name="expire_days")
	public Integer getExpireInDays() {
		return expireInDays;
	}
	public void setExpireInDays(Integer expireInDays) {
		this.expireInDays = expireInDays;
	}
	@Column(name="rental_credits")
	public Integer getRentalCredits() {
		return rentalCredits;
	}
	public void setRentalCredits(Integer rentalCredits) {
		this.rentalCredits = rentalCredits;
	}
	@Column(name="rental_days")
	public Integer getRentalDays() {
		return rentalDays;
	}
	public void setRentalDays(Integer rentalDays) {
		this.rentalDays = rentalDays;
	}
	@Column(name="concurrency_credits")
	public Integer getConcurrencyCredits() {
		return concurrencyCredits;
	}
	public void setConcurrencyCredits(Integer concurrencyCredits) {
		this.concurrencyCredits = concurrencyCredits;
	}
}
