package com.vst.bridge.entity.base;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

/**
 * This class represents the soft delete to the extended class.
 *  
 * @author Irfan.Tamboli
 *
 */
@MappedSuperclass
public class SoftDelete extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Boolean deleted = Boolean.FALSE;

	@Column(name = "deleted",nullable = false)
	public Boolean getDeleted() {
		return deleted;
	}

	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}
}
