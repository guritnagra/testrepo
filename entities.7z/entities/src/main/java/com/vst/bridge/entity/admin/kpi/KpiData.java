package com.vst.bridge.entity.admin.kpi;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import com.vst.bridge.entity.base.SoftDelete;

@Entity
@Immutable
@Table(name = "v_kpi_data")
public class KpiData extends SoftDelete {

	private static final long serialVersionUID = 1L;
	private Integer id;

	private Integer bridgeSites;

	private Integer bridgeUsers;

	private Integer bridgeAdmins;

	private Integer uniqueAssets;

	private Integer activations;
	
	@Column(name = "bridge_sites")
	public Integer getBridgeSites() {
		return bridgeSites;
	}

	
	public void setBridgeSites(Integer bridgeSites) {
		this.bridgeSites = bridgeSites;
	}

	@Column(name = "bridge_users")
	public Integer getBridgeUsers() {
		return bridgeUsers;
	}

	public void setBridgeUsers(Integer bridgeUsers) {
		this.bridgeUsers = bridgeUsers;
	}

	@Column(name = "bridge_admins")
	public Integer getBridgeAdmins() {
		return bridgeAdmins;
	}

	public void setBridgeAdmins(Integer bridgeAdmins) {
		this.bridgeAdmins = bridgeAdmins;
	}

	@Column(name = "unique_assets")
	public Integer getUniqueAssets() {
		return uniqueAssets;
	}

	public void setUniqueAssets(Integer uniqueAssets) {
		this.uniqueAssets = uniqueAssets;
	}

	@Column(name = "activations")
	public Integer getActivations() {
		return activations;
	}

	public void setActivations(Integer activations) {
		this.activations = activations;
	}

	@Override
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id", updatable = false, nullable = false)
	public Integer getId() {
		return id;
	}

	@Override
	public void setId(Integer id) {
		this.id = id;
	}

}
