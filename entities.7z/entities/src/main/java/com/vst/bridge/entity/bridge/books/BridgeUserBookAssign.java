package com.vst.bridge.entity.bridge.books;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.base.SoftDelete;
import com.vst.bridge.entity.bridge.user.BridgeUserKey;
import com.vst.bridge.entity.keys.KeyBatch;

@Entity
@Table(name="tbl_bridgeuser_bookassign")
public class BridgeUserBookAssign extends SoftDelete{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BridgeUserKey keyAssigned;
	private String vbid;
	private Date createdDate;
	private String usedType;
	private Date lastAccess;
	
	private String bookshelfRedeemCode;
	private Date expires;
	private Date returnDate;
	private KeyBatch keyBatch;
	
	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="key_assign_id")
	public BridgeUserKey getKeyAssigned() {
		return keyAssigned;
	}
	public void setKeyAssigned(BridgeUserKey keyAssigned) {
		this.keyAssigned = keyAssigned;
	}
	@Column(name="vbid",length=64)
	public String getVbid() {
		return vbid;
	}
	public void setVbid(String vbid) {
		this.vbid = vbid;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created", nullable = false,insertable = false, updatable = false)
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	@Column(name="used_type",length=50)
	public String getUsedType() {
		return usedType;
	}
	public void setUsedType(String usedType) {
		this.usedType = usedType;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_access")
	public Date getLastAccess() {
		return lastAccess;
	}
	public void setLastAccess(Date lastAccess) {
		this.lastAccess = lastAccess;
	}
	@Column(name="bookshelf_code")
	public String getBookshelfRedeemCode() {
		return bookshelfRedeemCode;
	}
	public void setBookshelfRedeemCode(String bookshelfRedeemCode) {
		this.bookshelfRedeemCode = bookshelfRedeemCode;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="expires")
	public Date getExpires() {
		return expires;
	}
	public void setExpires(Date expires) {
		this.expires = expires;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="return_date")
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}
	
	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="key_batch_id")
	public KeyBatch getKeyBatch() {
		return keyBatch;
	}
	public void setKeyBatch(KeyBatch ketBatch) {
		this.keyBatch = ketBatch;
	}
	
	
}
