package com.vst.bridge.entity.company;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.base.BaseEntity;

/**
 * This class represents Company in Bridge Application.
 *  
 * @author Irfan.Tamboli
 *
 */
@Entity
@Table(name="tbl_company")
public class Company extends BaseEntity{

	private static final long serialVersionUID = 1L;
	private String name;
	private String apiKey;
	private Integer companyId;
	private AdminUser createdBy;
	private Date createdDate;
	@Column(name="name",length=128)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
/*	@Column(name="apikey",length=32)
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}*/
	/*@Column(name="type",length=16)
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}*/
	@ManyToOne
	@JoinColumn(name="creator_id", nullable=false)
	public AdminUser getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(AdminUser createdBy) {
		this.createdBy = createdBy;
	}
	
	@Column(name="api_key",length=128)
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	@Column(name="company_id")
	public Integer getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created", nullable = false,insertable = false, updatable = false)
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	
	
}
