package com.vst.bridge.entity.admin.ancillary;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.base.SoftDelete;
import com.vst.bridge.entity.bridge.Bridge;

@Entity
@Table(name="tbl_ancillary")
public class Ancillary extends SoftDelete {

	private static final long serialVersionUID = 1L;
	private String fileName;
	private String title;
	private String mimeType;
	private String gcpSku;
	private String vbid;
	private Bridge bridge;
	private Integer fileSize;
	private Boolean completed;
	private AncillaryUploadToken uploadToken;
	private AdminUser updatedBy;

	private Date createdAt;
	private Date updatedAt;
	private Date deletedAt;
	
	@Column(name="file_name")
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	@Column(name="title")
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Column(name="mime_type")
	public String getMimeType() {
		return mimeType;
	}
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	@Column(name="gcp_sku")
	public String getGcpSku() {
		return gcpSku;
	}
	public void setGcpSku(String gcpSku) {
		this.gcpSku = gcpSku;
	}
	@Column(name="vbid")
	public String getVbid() {
		return vbid;
	}
	public void setVbid(String vbid) {
		this.vbid = vbid;
	}
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="bridge_id", nullable=false)
	public Bridge getBridge() {
		return bridge;
	}
	public void setBridge(Bridge bridge) {
		this.bridge = bridge;
	}
	@Column(name="file_size")
	public Integer getFileSize() {
		return fileSize;
	}
	public void setFileSize(Integer fileSize) {
		this.fileSize = fileSize;
	}
	@Column(name="completed")
	public Boolean isCompleted() {
		return completed;
	}
	public void setCompleted(Boolean completed) {
		this.completed = completed;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_at")
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_at")
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	@Column(name="deleted_at")
	public Date getDeletedAt() {
		return deletedAt;
	}
	public void setDeletedAt(Date deletedAt) {
		this.deletedAt = deletedAt;
	}
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="upload_token_id", nullable=false)
	public AncillaryUploadToken getUploadToken() {
		return uploadToken;
	}

	public void setUploadToken(AncillaryUploadToken uploadToken) {
		this.uploadToken = uploadToken;
	}
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="updated_by", nullable=false)
	public AdminUser getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(AdminUser updatedBy) {
		this.updatedBy = updatedBy;
	}
	

}
