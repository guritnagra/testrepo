package com.vst.bridge.entity.admin.purchase;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.base.SoftDelete;
import com.vst.bridge.entity.bridge.Bridge;

@Entity
@Table(name="tbl_bridge_purchase")
public class BridgePurchase extends SoftDelete {
	
	private static final long serialVersionUID = 1L;
	private String purchaseName;
	private String displayPricing;
	private String purchaseUrl;
	private Bridge bridge;
	private Date lastModifiedDate;
	
	@Column(name="purchase_name")
	public String getPurchaseName() {
		return purchaseName;
	}
	public void setPurchaseName(String purchaseName) {
		this.purchaseName = purchaseName;
	}
	@Column(name="display_pricing")
	public String getDisplayPricing() {
		return displayPricing;
	}
	public void setDisplayPricing(String displayPricing) {
		this.displayPricing = displayPricing;
	}
	@Column(name="purchase_url")
	public String getPurchaseUrl() {
		return purchaseUrl;
	}
	public void setPurchaseUrl(String purchaseUrl) {
		this.purchaseUrl = purchaseUrl;
	}
	
	@ManyToOne
	@JoinColumn(name="bridge_id", nullable=false)
	public Bridge getBridge() {
		return bridge;
	}
	public void setBridge(Bridge bridge) {
		this.bridge = bridge;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_updated", nullable = true)
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	
	

}
