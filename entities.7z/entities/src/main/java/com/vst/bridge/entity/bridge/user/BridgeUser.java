package com.vst.bridge.entity.bridge.user;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Cascade;

import com.vst.bridge.entity.base.BaseEntity;
import com.vst.bridge.entity.bridge.Bridge;

@Entity
@Table(name="tbl_bridgeuser")
public class BridgeUser extends BaseEntity{

	private static final long serialVersionUID = 1L;
	private String firstName;
	private String lastName;
	private String email;
	private String guid;
	private String accessToken;
	private Bridge bridge;
	private Date createdDate;
	
	private Integer deletedBy;
	
	private Date deleted;
	
	private Boolean promotionSubscription=false;
	private Boolean surveySubscription=false;
	private String sourceId;
	private String tenantUserId;
	private Role role;
		
	
	private Set<BridgeUserKey> assigedKeys = new HashSet<BridgeUserKey>();
	
	@Column(name="first_name",length=64)
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	@Column(name="last_name",length=64)
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Column(name="email",length=128)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Column(name="guid",length=64)
	public String getGuid() {
		return guid;
	}
	public void setGuid(String guid) {
		this.guid = guid;
	}
	@Column(name="access_token",length=64)
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	@ManyToOne
	@JoinColumn(name="bridge_id", nullable=false)
	public Bridge getBridge() {
		return bridge;
	}
	public void setBridge(Bridge bridge) {
		this.bridge = bridge;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created", nullable = false,updatable=false,insertable=false)
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@OneToMany(mappedBy="user",fetch=FetchType.LAZY)
	@Cascade(org.hibernate.annotations.CascadeType.SAVE_UPDATE)
	public Set<BridgeUserKey> getAssigedKeys() {
		return assigedKeys;
	}
	public void setAssigedKeys(Set<BridgeUserKey> assigedKeys) {
		this.assigedKeys = assigedKeys;
	}
	@Column(name="promotion_subscription")
	public Boolean getPromotionSubscription() {
		return promotionSubscription;
	}
	public void setPromotionSubscription(Boolean promotionSubscription) {
		this.promotionSubscription = promotionSubscription;
	}
	@Column(name="survey_subscription")
	public Boolean getSurveySubscription() {
		return surveySubscription;
	}
	public void setSurveySubscription(Boolean surveySubscription) {
		this.surveySubscription = surveySubscription;
	}
	@ManyToOne
	@JoinColumn(name = "role_id")
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	@Column(name="deleted_by")
	public Integer getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(Integer deletedBy) {
		this.deletedBy = deletedBy;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "deleted", nullable = true)
	public Date getDeleted() {
		return deleted;
	}
	public void setDeleted(Date deleted) {
		this.deleted = deleted;
	}
	@Column(name="source_id")
	public String getSourceId() {
		return sourceId;
	}
	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}
	@Column(name="tenant_user_id")
	public String getTenantUserId() {
		return tenantUserId;
	}
	public void setTenantUserId(String tenantUserId) {
		this.tenantUserId = tenantUserId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((accessToken == null) ? 0 : accessToken.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((guid == null) ? 0 : guid.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((tenantUserId == null) ? 0 : tenantUserId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		BridgeUser other = (BridgeUser) obj;
		if (accessToken == null) {
			if (other.accessToken != null)
				return false;
		} else if (!accessToken.equals(other.accessToken))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (guid == null) {
			if (other.guid != null)
				return false;
		} else if (!guid.equals(other.guid))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (tenantUserId == null) {
			if (other.tenantUserId != null)
				return false;
		} else if (!tenantUserId.equals(other.tenantUserId))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "BridgeUser [bridge=" + bridge + ", tenantUserId=" + tenantUserId + ", getId()=" + getId() + "]";
	}
	
	
}	
