package com.vst.bridge.entity.admin.session;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.base.SoftDelete;
/**
 * This class represents the  session associated with Admin user.
 *  
 * @author Irfan.Tamboli
 *
 */
@Entity
@Table(name="tbl_adminuser_sessions")
public class AdminSession extends SoftDelete{
	private static final long serialVersionUID = 1L;
	private AdminUser admin;
	private String sessionId;
	private Date createdDate;
	private Date lastAccessDate;
	
	@ManyToOne
	@JoinColumn(name="admin_id", nullable=false)
	public AdminUser getAdmin() {
		return admin;
	}
	public void setAdmin(AdminUser admin) {
		this.admin = admin;
	}
	@Column(name="session_id",length=64)
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created", nullable = false,insertable = false, updatable = false)
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_access")
	public Date getLastAccessDate() {
		return lastAccessDate;
	}
	public void setLastAccessDate(Date lastAccessDate) {
		this.lastAccessDate = lastAccessDate;
	}
}
