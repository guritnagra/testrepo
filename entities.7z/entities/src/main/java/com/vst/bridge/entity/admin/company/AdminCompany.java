package com.vst.bridge.entity.admin.company;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.base.SoftDelete;
import com.vst.bridge.entity.company.Company;

@Entity
@Table(name="tbl_adminuser_companyassign")
public class AdminCompany extends SoftDelete{

	private static final long serialVersionUID = 1L;
	private AdminUser admin;
	private Company company;

	@ManyToOne
	@JoinColumn(name="company_id", nullable=false)
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	@ManyToOne
	@JoinColumn(name="admin_id", nullable=false)
	public AdminUser getAdmin() {
		return admin;
	}
	public void setAdmin(AdminUser admin) {
		this.admin = admin;
	}

}
