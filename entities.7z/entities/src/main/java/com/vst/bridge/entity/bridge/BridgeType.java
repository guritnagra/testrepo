package com.vst.bridge.entity.bridge;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.vst.bridge.entity.base.BaseEntity;

@Entity
@Table(name="tbl_bridge_types")
public class BridgeType extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Column(name="type",length=32)
	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	

}
