package com.vst.bridge.entity.admin.allowance;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.base.SoftDelete;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.CodeTypes;

@Entity
@Table(name="tbl_bridge_entitlements")
public class BridgeEntitlement extends SoftDelete {
	
	private static final long serialVersionUID = 1L;
	private String entitlementName;
	private CodeTypes entitlementType;
	private Bridge bridge;
	private Integer credits;
	private Boolean isReusableCredit;
	private Integer onlineDays;
	private Date onlineExpires;
	private Integer offlineDays;
	private Date offlineExpires;
	private Boolean isConcurrencyCredit;
	private Date lastModifiedDate;
	
	@Column(name="entitlement_name")
	public String getEntitlementName() {
		return entitlementName;
	}
	public void setEntitlementName(String entitlementName) {
		this.entitlementName = entitlementName;
	}
	
	@ManyToOne
	@JoinColumn(name="entitlement_type")
	public CodeTypes getEntitlementType() {
		return entitlementType;
	}
	public void setEntitlementType(CodeTypes entitlementType) {
		this.entitlementType = entitlementType;
	}	
	
	@ManyToOne
	@JoinColumn(name="bridge_id", nullable=false)
	public Bridge getBridge() {
		return bridge;
	}
	

	public void setBridge(Bridge bridge) {
		this.bridge = bridge;
	}
	
	@Column(name="credits")
	public Integer getCredits() {
		return credits;
	}
	public void setCredits(Integer credits) {
		this.credits = credits;
	}
	
	@Column(name="is_reusable_credit")
	public Boolean getIsReusableCredit() {
		return isReusableCredit;
	}
	public void setIsReusableCredit(Boolean isReusableCredit) {
		this.isReusableCredit = isReusableCredit;
	}
	@Column(name="online_days")
	public Integer getOnlineDays() {
		return onlineDays;
	}
	public void setOnlineDays(Integer onlineDays) {
		this.onlineDays = onlineDays;
	}
	
	@Column(name="online_expires")
	public Date getOnlineExpires() {
		return onlineExpires;
	}
	public void setOnlineExpires(Date onlineExpires) {
		this.onlineExpires = onlineExpires;
	}
	
	@Column(name="offline_days")
	public Integer getOfflineDays() {
		return offlineDays;
	}
	public void setOfflineDays(Integer offlineDays) {
		this.offlineDays = offlineDays;
	}
	
	@Column(name="offline_expires")
	public Date getOfflineExpires() {
		return offlineExpires;
	}
	public void setOfflineExpires(Date offlineExpires) {
		this.offlineExpires = offlineExpires;
	}
	
	@Column(name="is_concurrency_credit")
	public Boolean getIsConcurrencyCredit() {
		return isConcurrencyCredit;
	}
	public void setIsConcurrencyCredit(Boolean isConcurrencyCredit) {
		this.isConcurrencyCredit = isConcurrencyCredit;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_updated", nullable = true)
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	
	
	
	

}
