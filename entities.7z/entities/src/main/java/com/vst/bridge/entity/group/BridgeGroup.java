package com.vst.bridge.entity.group;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.base.SoftDelete;
import com.vst.bridge.entity.bridge.Bridge;

@Entity
@Table(name="tbl_bridgegroups")
public class BridgeGroup extends SoftDelete{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String name;
	private Bridge bridge;
	private Date startDate;
	private Date expiredDate;
	private AdminUser createdBy;	
	private AdminUser modifiedBy;	
	private AdminUser deletedBy;
	private Date createdDate;
	private Date modifiedDate;
	private Date deletedDate;
	private String sourceId;
	private String courseId;
	private Boolean isActive=Boolean.TRUE;
	private Boolean isAutoAssignUser=Boolean.FALSE;
	private Boolean isHidden = Boolean.FALSE;
	private Boolean isAutoAssignAsset=Boolean.FALSE;
	
	public BridgeGroup(){
	}
	
	@Column(name="name",length=256)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@ManyToOne
	@JoinColumn(name="bridge_id", nullable=false)
	public Bridge getBridge() {
		return bridge;
	}
	public void setBridge(Bridge bridge) {
		this.bridge = bridge;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "start_date", nullable = true)
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "expired_date", nullable = true)
	public Date getExpiredDate() {
		return expiredDate;
	}
	public void setExpiredDate(Date expiredDate) {
		this.expiredDate = expiredDate;
	}
	
	@ManyToOne
	@JoinColumn(name="created_by", nullable=false)
	public AdminUser getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(AdminUser createdBy) {
		this.createdBy = createdBy;
	}
	
	@ManyToOne
	@JoinColumn(name="modified_by", nullable=false)
	public AdminUser getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(AdminUser modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	@ManyToOne
	@JoinColumn(name="deleted_by",nullable = true)
	public AdminUser getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(AdminUser deletedBy) {
		this.deletedBy = deletedBy;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false,insertable=true,updatable=false)
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date", nullable = false,insertable=true,updatable=true)
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "deleted_date", nullable = true)
	public Date getDeletedDate() {
		return deletedDate;
	}
	public void setDeletedDate(Date deletedDate) {
		this.deletedDate = deletedDate;
	}
	@Column(name="source_id")
	public String getSourceId() {
		return sourceId;
	}
	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}
	@Column(name="course_id")
	public String getCourseId() {
		return courseId;
	}
	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}
	@Column(name="is_active")
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((bridge == null) ? 0 : bridge.hashCode());
		result = prime * result + ((courseId == null) ? 0 : courseId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		BridgeGroup other = (BridgeGroup) obj;
		if (bridge == null) {
			if (other.bridge != null)
				return false;
		} else if (!bridge.equals(other.bridge))
			return false;
		if (courseId == null) {
			if (other.courseId != null)
				return false;
		} else if (!courseId.equals(other.courseId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "BridgeGroup [bridge=" + bridge + ", courseId=" + courseId + ", isActive=" + isActive + ", getId()="
				+ getId() + "]";
	}

	@Column(name="is_auto_assign_user")
	public Boolean getIsAutoAssignUser() {
		return isAutoAssignUser;
	}

	public void setIsAutoAssignUser(Boolean isAutoAssignUser) {
		this.isAutoAssignUser = isAutoAssignUser;
	}

	@Column(name="is_hidden")
	public Boolean getIsHidden() {
		return isHidden;
	}

	public void setIsHidden(Boolean isHidden) {
		this.isHidden = isHidden;
	}
	
	@Column(name="is_auto_assign_asset")
	public Boolean getIsAutoAssignAsset() {
		return isAutoAssignAsset;
	}

	public void setIsAutoAssignAsset(Boolean isAutoAssignAsset) {
		this.isAutoAssignAsset = isAutoAssignAsset;
	}
	
}
