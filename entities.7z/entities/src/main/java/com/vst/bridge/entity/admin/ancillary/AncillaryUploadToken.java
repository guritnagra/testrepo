package com.vst.bridge.entity.admin.ancillary;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.base.SoftDelete;
import com.vst.bridge.entity.bridge.Bridge;

@Entity
@Table(name="tbl_ancillary_uploadtoken")
public class AncillaryUploadToken extends SoftDelete {

	private static final long serialVersionUID = 1L;
	private String token;
	private Bridge bridge;
	private Date expiresOn;
	private AdminUser admin;
	private List<Ancillary> ancillary = new ArrayList<>(0);
	
	public AncillaryUploadToken(){
		
	}
	public AncillaryUploadToken(String uploadToken, Date expiresOn, Bridge bridge, AdminUser admin){
		this.token = uploadToken;
		this.expiresOn = expiresOn;
		this.bridge = bridge;
		this.admin = admin;
	}

	@Column(name="upload_token", length=64, nullable=false)
	public String getToken() {
		return token;
	}
	public void setToken(String uploadToken) {
		this.token = uploadToken;
	}
	@ManyToOne
	@JoinColumn(name="bridge_id", nullable=false)
	public Bridge getBridge() {
		return bridge;
	}
	public void setBridge(Bridge bridge) {
		this.bridge = bridge;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="expired")
	public Date getExpiresOn() {
		return expiresOn;
	}
	public void setExpiresOn(Date expiresOn) {
		this.expiresOn = expiresOn;
	}
	@OneToMany(fetch=FetchType.LAZY,mappedBy="uploadToken")
	@LazyCollection(LazyCollectionOption.EXTRA)
	@Cascade(org.hibernate.annotations.CascadeType.SAVE_UPDATE)
	@Fetch(FetchMode.SELECT)
		@BatchSize(size=10)
	public List<Ancillary> getAncillary() {
		return ancillary;
	}
	public void setAncillary(List<Ancillary> ancillary) {
		this.ancillary = ancillary;
	}
	@ManyToOne
	@JoinColumn(name="admin_id", nullable=false)
	public AdminUser getAdmin() {
		return admin;
	}
	public void setAdmin(AdminUser admin) {
		this.admin = admin;
	}
}
