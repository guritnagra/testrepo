package com.vst.bridge.entity.admin.role;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.vst.bridge.entity.base.BaseEntity;


/**
 * This class represents the  Admin User Role.
 *  
 * @author Irfan.Tamboli
 *
 */
@Entity
@Table(name="tbl_adminuser_roles")
public class AdminRole extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String code;
	
	@Column(name="name",length=32)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(name="code",length=32)
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
}
