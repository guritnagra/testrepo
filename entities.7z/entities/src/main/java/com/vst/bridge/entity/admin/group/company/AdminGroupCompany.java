package com.vst.bridge.entity.admin.group.company;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.vst.bridge.entity.admin.group.Group;
import com.vst.bridge.entity.base.SoftDelete;
import com.vst.bridge.entity.company.Company;

@Entity
@Table(name="tbl_admingroups_companyassign")
public class AdminGroupCompany extends SoftDelete{

	private static final long serialVersionUID = 1L;
	private Group group;
	private Company company;
	
	@ManyToOne
	@JoinColumn(name="group_id", nullable=false)
	public Group getGroup() {
		return group;
	}
	public void setGroup(Group group) {
		this.group = group;
	}
	@ManyToOne
	@JoinColumn(name="company_id", nullable=false)
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
}
