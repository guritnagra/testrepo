package com.vst.bridge.entity.group;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.base.BaseEntity;

@Entity
@Table(name="tbl_bridgegroups_books")
public class GroupAsset extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private BridgeGroup group;
	private String vbid;
	private Boolean selected = true;
	private Date lastUpdated;
	
	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="group_id")
	public BridgeGroup getGroup() {
		return group;
	}
	public void setGroup(BridgeGroup group) {
		this.group = group;
	}
	
	@Column(name="vbid",length=32,nullable=false)
	public String getVbid() {
		return vbid;
	}
	public void setVbid(String vbid) {
		this.vbid = vbid;
	}
	
	@Column(name="is_selected",nullable=false)
	public Boolean getSelected() {
		return selected;
	}
	public void setSelected(Boolean selected) {
		this.selected = selected;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="last_updated")
	public Date getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	
	
}
