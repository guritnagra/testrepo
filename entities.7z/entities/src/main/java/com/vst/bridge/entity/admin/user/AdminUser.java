package com.vst.bridge.entity.admin.user;

import java.util.Date;
import java.util.List;
import java.util.Vector;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Cascade;

import com.vst.bridge.entity.admin.company.AdminCompany;
import com.vst.bridge.entity.admin.role.AdminRole;
import com.vst.bridge.entity.base.SoftDelete;


/**
 * This class represents the  Admin user information.
 *  
 * @author Irfan.Tamboli
 *
 */

@Entity
@Table(name = "tbl_adminuser")
public class AdminUser extends SoftDelete{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String firstName;
	private String lastName;
	private String email;
	private Date createdDate;
	private String password;
	private AdminUser createdBy;
	private AdminRole role;
	private AdminUserLabel label;
	private Integer systemUserId;
	private List<AdminGroup> groups = new Vector<AdminGroup>(0);
	
	private List<AdminCompany> companies = new Vector<AdminCompany>(0);
	
	private List<AdminFavoriteBridge> favoriteBridges = new Vector<AdminFavoriteBridge>(0);
	
	private Integer deletedBy;
	
	private Date deletedTime;
	
	private Boolean editSystemUser;
	private Boolean editBridge;	
	private Boolean editBasicInfo;
	private Boolean editStyling;
	private Boolean editManage;
	private Boolean editUsers;
	private Boolean editUserLimit;
	private Boolean editUserConcurrency; 
	private Boolean allowContentUpload;
	private Boolean editAllowance;
	private Boolean editAccess;
	private Boolean isReadOnly;
	private Boolean editKey;
	private Boolean editPurchase;
		
	@Column(name="first_name",length=64)
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	@Column(name="last_name",length=64)
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Column(name="email",length=128)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created", nullable = false,insertable = false, updatable = false)
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@Column(name="password",length=32)
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="creator_id")
	public AdminUser getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(AdminUser createdBy) {
		this.createdBy = createdBy;
	}
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="role_id", nullable=false)
	public AdminRole getRole() {
		return role;
	}
	public void setRole(AdminRole role) {
		this.role = role;
	}
	@OneToMany(fetch=FetchType.LAZY,mappedBy="admin")
	@Cascade(org.hibernate.annotations.CascadeType.SAVE_UPDATE)
	public List<AdminGroup> getGroups() {
		return groups;
	}
	public void setGroups(List<AdminGroup> groups) {
		this.groups = groups;
	}
	@OneToMany(fetch=FetchType.LAZY,mappedBy="admin")
	@Cascade(org.hibernate.annotations.CascadeType.SAVE_UPDATE)
	public List<AdminCompany> getCompanies() {
		return companies;
	}
	public void setCompanies(List<AdminCompany> companies) {
		this.companies = companies;
	}
	@OneToMany(mappedBy="user",fetch=FetchType.LAZY)
	@Cascade(org.hibernate.annotations.CascadeType.SAVE_UPDATE)
	public List<AdminFavoriteBridge> getFavoriteBridges() {
		return favoriteBridges;
	}
	public void setFavoriteBridges(List<AdminFavoriteBridge> favoriteBridges) {
		this.favoriteBridges = favoriteBridges;
	}
	@Column(name="deleted_by")
	public Integer getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(Integer deletedBy) {
		this.deletedBy = deletedBy;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="deleted_time")
	public Date getDeletedTime() {
		return deletedTime;
	}
	public void setDeletedTime(Date deletedTime) {
		this.deletedTime = deletedTime;
	}
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="label", nullable=true)
	public AdminUserLabel getLabel() {
		return label;
	}
	public void setLabel(AdminUserLabel label) {
		this.label = label;
	}
	@Column(name="system_user_id")
	public Integer getSystemUserId() {
		return systemUserId;
	}
	public void setSystemUserId(Integer systemUserId) {
		this.systemUserId = systemUserId;
	}
	@Column(name="edit_system_user")
	public Boolean getEditSystemUser() {
		return editSystemUser;
	}
	public void setEditSystemUser(Boolean editSystemUser) {
		this.editSystemUser = editSystemUser;
	}
	@Column(name="edit_bridge")
	public Boolean getEditBridge() {
		return editBridge;
	}
	public void setEditBridge(Boolean editBridge) {
		this.editBridge = editBridge;
	}
	@Column(name="edit_basic_info")
	public Boolean getEditBasicInfo() {
		return editBasicInfo;
	}
	public void setEditBasicInfo(Boolean editBasicInfo) {
		this.editBasicInfo = editBasicInfo;
	}
	@Column(name="edit_styling")
	public Boolean getEditStyling() {
		return editStyling;
	}
	public void setEditStyling(Boolean editStyling) {
		this.editStyling = editStyling;
	}
	@Column(name="edit_manage")
	public Boolean getEditManage() {
		return editManage;
	}
	public void setEditManage(Boolean editManage) {
		this.editManage = editManage;
	}
	@Column(name="edit_users")
	public Boolean getEditUsers() {
		return editUsers;
	}
	public void setEditUsers(Boolean editUsers) {
		this.editUsers = editUsers;
	}
	@Column(name="edit_user_limit")
	public Boolean getEditUserLimit() {
		return editUserLimit;
	}
	public void setEditUserLimit(Boolean editUserLimit) {
		this.editUserLimit = editUserLimit;
	}
	@Column(name="edit_user_concurrency")
	public Boolean getEditUserConcurrency() {
		return editUserConcurrency;
	}
	public void setEditUserConcurrency(Boolean editUserConcurrency) {
		this.editUserConcurrency = editUserConcurrency;
	}
	@Column(name="allow_content_upload")
	public Boolean getAllowContentUpload() {
		return allowContentUpload;
	}
	public void setAllowContentUpload(Boolean allowContentUpload) {
		this.allowContentUpload = allowContentUpload;
	}
	@Column(name="edit_allowance")
	public Boolean getEditAllowance() {
		return editAllowance;
	}
	public void setEditAllowance(Boolean editAllowance) {
		this.editAllowance = editAllowance;
	}
	@Column(name="edit_access")
	public Boolean getEditAccess() {
		return editAccess;
	}
	public void setEditAccess(Boolean editAccess) {
		this.editAccess = editAccess;
	}
	@Column(name="is_read_only")
	public Boolean getIsReadOnly() {
		return isReadOnly;
	}
	public void setIsReadOnly(Boolean isReadOnly) {
		this.isReadOnly = isReadOnly;
	}
	@Column(name="edit_key")
	public Boolean getEditKey() {
		return editKey;
	}
	public void setEditKey(Boolean editKey) {
		this.editKey = editKey;
	}
	@Column(name="edit_purchase")
	public Boolean getEditPurchase() {
		return editPurchase;
	}
	public void setEditPurchase(Boolean editPurchase) {
		this.editPurchase = editPurchase;
	}
	
	
}
