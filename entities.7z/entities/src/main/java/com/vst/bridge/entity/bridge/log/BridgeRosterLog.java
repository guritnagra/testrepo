package com.vst.bridge.entity.bridge.log;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.base.BaseEntity;
import com.vst.bridge.entity.bridge.Bridge;


/*CREATE TABLE `tbl_bridgeroster_log`( `id` INT(8) NOT NULL AUTO_INCREMENT, `bridge_id` INT(8) NOT NULL,
 `file_type` VARCHAR(64) NOT NULL, `file_url` VARCHAR(256) NOT NULL, `status` VARCHAR(64),
`created` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, `creater` INT(8), `version_id` INT(11), PRIMARY KEY (`id`) ); 
*/

@Entity
@Table(name = "tbl_bridgeroster_log")
public class BridgeRosterLog extends BaseEntity {
	
	private static final long serialVersionUID = 1L;
	private Bridge bridge;
	private String fileType;
	private String fileName;
	private String fileURL;
	private String status;
	private Date createdDate;
	private AdminUser creator;
	private String errorDescription;

	@ManyToOne
	@JoinColumn(name = "bridge_id")
	public Bridge getBridge() {
		return bridge;
	}

	public void setBridge(Bridge bridge) {
		this.bridge = bridge;
	}

	@Column(name = "file_type", length =64)
	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	
	@Column(name = "file_url", length =256)
	public String getFileURL() {
		return fileURL;
	}

	public void setFileURL(String fileURL) {
		this.fileURL = fileURL;
	}
	
	@Column(name = "status", length =64)
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created", nullable = false, updatable = false, insertable = false)
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@ManyToOne
	@JoinColumn(name="created_by", nullable=false)
	public AdminUser getCreator() {
		return creator;
	}

	public void setCreator(AdminUser creator) {
		this.creator = creator;
	}
	
	@Column(name = "error_desc")
	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	@Column(name = "file_name",length =256)
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	

	

	
}
