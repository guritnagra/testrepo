package com.vst.bridge.entity.keys;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Cascade;

import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.base.BaseEntity;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.CodeTypes;
import com.vst.bridge.entity.bridge.user.Role;

@Entity
@Table(name="tbl_keybatches")
public class KeyBatch extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Bridge bridge;
	private Role role;
	private String note;
	private Date createdDate;
	private AdminUser createdBy;
	
	private Integer fullCredits=0;
	private Integer noOfUsers=0;
	private Integer trialCredits=0;
	private Date expireDate;
	
	private Integer rentalCredits=0;
	private Integer rentalDays;
	private Integer concurrencyCredits=0;
	
	private List<Keys> keys = new ArrayList<Keys>(0);
	private List<KeyBatchEntitlement> entitlements = new ArrayList<KeyBatchEntitlement>(0);
	private Integer count;
	private Integer concurrencyDays;
	private Date concurrencyExpires;
	private Integer offlineConcurrencyDays;
	private Date offlineConcurrencyExpires;
	private String concurrencyEntitlementName;
	private CodeTypes concCodeType;
	private Boolean isReturn;
	
	@ManyToOne
	@JoinColumn(name="bridge_id", nullable=false)
	public Bridge getBridge() {
		return bridge;
	}
	public void setBridge(Bridge bridge) {
		this.bridge = bridge;
	}
	@ManyToOne
	@JoinColumn(name="role_id", nullable=false)
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	@Column(name="notes",length=256)
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created", nullable = false,updatable=false,insertable=false)
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@ManyToOne
	@JoinColumn(name="creator_id", nullable=false)
	public AdminUser getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(AdminUser createdBy) {
		this.createdBy = createdBy;
	}
	
	@OneToMany(fetch=FetchType.LAZY,mappedBy="keyBatch")
	@Cascade(org.hibernate.annotations.CascadeType.SAVE_UPDATE)
	public List<Keys> getKeys() {
		return keys;
	}
	public void setKeys(List<Keys> keys) {
		this.keys = keys;
	}
	
	@OneToMany(fetch=FetchType.LAZY,mappedBy="keyBatch")
	@Cascade(org.hibernate.annotations.CascadeType.SAVE_UPDATE)
	public List<KeyBatchEntitlement> getEntitlements(){
		return entitlements;
	}
	public void setEntitlements(List<KeyBatchEntitlement> entitlements){
		this.entitlements=entitlements;
	}
	
	@Column(name="full_credits")
	public Integer getFullCredits() {
		return fullCredits;
	}
	public void setFullCredits(Integer fullCredits) {
		this.fullCredits = fullCredits;
	}
	/*	@Column(name="full_credits")
	public Integer getPurchaseCredits() {
		return fullCredits;
	}
	public void setPurchaseCredits(Integer purchaseCredits) {
		this.fullCredits = purchaseCredits;
	}*/
	@Column(name="num_users_per_key")
	public Integer getNoOfUsers() {
		return noOfUsers;
	}
	public void setNoOfUsers(Integer noOfUsers) {
		this.noOfUsers = noOfUsers;
	}
	@Column(name="trial_credits")
	public Integer getTrialCredits() {
		return trialCredits;
	}
	public void setTrialCredits(Integer trialCredits) {
		this.trialCredits = trialCredits;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "expires")
	public Date getExpireDate() {
		return expireDate;
	}
	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}
	@Column(name="rental_credits")
	public Integer getRentalCredits() {
		return rentalCredits;
	}
	public void setRentalCredits(Integer rentalCredits) {
		this.rentalCredits = rentalCredits;
	}
	@Column(name="rental_days")
	public Integer getRentalDays() {
		return rentalDays;
	}
	public void setRentalDays(Integer rentalDays) {
		this.rentalDays = rentalDays;
	}
	@Column(name="concurrency_credits")
	public Integer getConcurrencyCredits() {
		return concurrencyCredits;
	}
	public void setConcurrencyCredits(Integer concurrencyCredits) {
		this.concurrencyCredits = concurrencyCredits;
	}
	@Column(name="count")
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	@Column(name="concurrency_days")
	public Integer getConcurrencyDays() {
		return concurrencyDays;
	}
	public void setConcurrencyDays(Integer concurrencyDays) {
		this.concurrencyDays = concurrencyDays;
	}
	@Column(name="concurrency_expires")
	public Date getConcurrencyExpires() {
		return concurrencyExpires;
	}
	public void setConcurrencyExpires(Date concurrencyExpires) {
		this.concurrencyExpires = concurrencyExpires;
	}
	@Column(name="offline_concurrency_days")
	public Integer getOfflineConcurrencyDays() {
		return offlineConcurrencyDays;
	}
	public void setOfflineConcurrencyDays(Integer offlineConcurrencyDays) {
		this.offlineConcurrencyDays = offlineConcurrencyDays;
	}
	@Column(name="offline_concurrency_expires")
	public Date getOfflineConcurrencyExpires() {
		return offlineConcurrencyExpires;
	}
	public void setOfflineConcurrencyExpires(Date offlineConcurrencyExpires) {
		this.offlineConcurrencyExpires = offlineConcurrencyExpires;
	}
	@ManyToOne
	@JoinColumn(name="concurrency_ent_type")
	public CodeTypes getConcCodeType() {
		return concCodeType;
	}
	public void setConcCodeType(CodeTypes concCodeType) {
		this.concCodeType = concCodeType;
	}
	@Column(name="concurrency_ent_name")
	public String getConcurrencyEntitlementName() {
		return concurrencyEntitlementName;
	}
	public void setConcurrencyEntitlementName(String concurrencyEntitlementName) {
		this.concurrencyEntitlementName = concurrencyEntitlementName;
	}
	@Column(name="is_return")
	public Boolean getIsReturn() {
		return isReturn;
	}
	public void setIsReturn(Boolean isReturn) {
		this.isReturn = isReturn;
	}
	
}
