package com.vst.bridge.entity.bridge.books;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.vst.bridge.entity.base.SoftDelete;

@Entity
@Table(name="tbl_bridge_books_pricing")
public class BridgeBookPricing extends SoftDelete {

	private static final long serialVersionUID = 1L;
	private BridgeBookCache bookCache;
	private String sku;
	private String digitalPrice;
	private String publisherPrice;
	private String priceType;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="book_cache_id", nullable=true)
	public BridgeBookCache getBookCache() {
		return bookCache;
	}
	public void setBookCache(BridgeBookCache bookCache) {
		this.bookCache = bookCache;
	}
	@Column(name="sku",nullable=true)
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	@Column(name="digital_price",nullable=true)
	public String getDigitalPrice() {
		return digitalPrice;
	}
	public void setDigitalPrice(String digitalPrice) {
		if(digitalPrice!=null && digitalPrice.equals("0.00")){
			digitalPrice=null;
		}
		this.digitalPrice = digitalPrice;
	}
	@Column(name="publisher_price",nullable=true)
	public String getPublisherPrice() {
		return publisherPrice;
	}
	public void setPublisherPrice(String publisherPrice) {
		if(publisherPrice!=null && publisherPrice.equals("0.00")){
			publisherPrice=null;
		}
		this.publisherPrice = publisherPrice;
	}
	@Column(name="rental_type",nullable=true)
	public String getPriceType() {
		return priceType;
	}
	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}
	
	
	
	
	
}