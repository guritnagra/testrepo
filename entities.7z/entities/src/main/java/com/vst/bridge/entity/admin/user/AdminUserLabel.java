package com.vst.bridge.entity.admin.user;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.vst.bridge.entity.base.BaseEntity;

@Entity
@Table(name="tbl_adminuser_label")
public class AdminUserLabel extends BaseEntity {

	private static final long serialVersionUID = 1L;
	private String label;
	
	@Column(name="label",length=32)
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	
	
}
