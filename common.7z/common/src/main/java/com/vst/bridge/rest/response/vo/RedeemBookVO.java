package com.vst.bridge.rest.response.vo;

import java.util.Date;

public class RedeemBookVO {
	
	private Integer onlineDays;
	private Date onlineDate;
	private String codeType;
	private Integer offlineDays;
	private Date offlineDate;
	
	public Integer getOnlineDays() {
		return onlineDays;
	}
	public void setOnlineDays(Integer onlineDays) {
		this.onlineDays = onlineDays;
	}
	public Date getOnlineDate() {
		return onlineDate;
	}
	public void setOnlineDate(Date onlineDate) {
		this.onlineDate = onlineDate;
	}
	public String getCodeType() {
		return codeType;
	}
	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}
	public Integer getOfflineDays() {
		return offlineDays;
	}
	public void setOfflineDays(Integer offlineDays) {
		this.offlineDays = offlineDays;
	}
	public Date getOfflineDate() {
		return offlineDate;
	}
	public void setOfflineDate(Date offlineDate) {
		this.offlineDate = offlineDate;
	}
	

}
