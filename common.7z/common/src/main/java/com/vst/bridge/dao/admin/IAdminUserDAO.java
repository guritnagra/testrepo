package com.vst.bridge.dao.admin;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.rest.response.vo.user.AdminInfoVo;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminUserDAO extends IGenericDAO<AdminUser, Integer>{
	AdminUser authonticateAdminUser(final String email,final String password)throws BridgeException;
	Boolean checkPasswordExistInDb(final String password)throws BridgeException;
	Boolean checkEmailExistInDb(final String email)throws BridgeException;
	AdminUser getAdminUserForSessionId(final String sessionId)throws BridgeException;
	List<AdminUser> getAllUsersForAdmin(Integer startIndex, BridgePaginationVo paginationVo)throws BridgeException;
	AdminUser getForEmail(final String email)throws BridgeException;
	Integer getUserCount(BridgePaginationVo bridgePaginationVo)throws BridgeException;
	
	List<AdminInfoVo> getSuperAdmins()throws BridgeException;
	
	AdminUser getDummyJobUser() throws BridgeException;
	AdminUser getAdminForSystemUserId(Integer systemUserId) throws BridgeException;
	
}
