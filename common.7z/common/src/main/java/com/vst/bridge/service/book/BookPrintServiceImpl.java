package com.vst.bridge.service.book;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookCacheDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.books.BookUrl;
import com.vst.bridge.rest.response.vo.user.BookLicenseInfoVO;
import com.vst.bridge.util.constant.ApplicationAction;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;

@Service("bookPrintService")
public class BookPrintServiceImpl implements IBookPrintService {
	@Autowired
	private IBridgeDAO bridgeDAO;

	@Autowired
	private IBridgeBookCacheDAO bridgeBookCacheDAO;

	@Autowired
	private IBridgeUserDAO bridgeUserDAO;

	@Autowired
	private BookServiceUtil bookServiceUtil;

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public BookLicenseInfoVO checkPrintFunctinalityForVbid(String vbid, BridgeUser user, Bridge bridge)
			throws BridgeException {
		BookLicenseInfoVO licensesInfoVO = new BookLicenseInfoVO();
		if (null != bridge) {
			if (StringUtils.isNotEmpty(bridge.getPrintBookURL())) {
				licensesInfoVO.setUrl(
						com.vst.bridge.StringUtils.getFormatedString(ApplicationConstants.BOOK_LICENSE_PRINT, vbid));
				licensesInfoVO.setState(ApplicationConstants.BOOK_LICENSE_STATE_PURCHASE);
			}
		}
		return licensesInfoVO;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse printBook(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		RestResponse response = bookServiceUtil.getDefaultRestResponse();
		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		BridgeUser user = bridgeUserDAO.get(sessionStatusVO.getAdminId());
		BookLicenseInfoVO licenseInfoVO = this.checkPrintFunctinalityForVbid(vbid, user, bridge);
		if (null != licenseInfoVO && null != licenseInfoVO.getState()
				&& StringUtils.equals(licenseInfoVO.getState(), ApplicationConstants.BOOK_LICENSE_STATE_PURCHASE)) {
			BridgeBookCache bookCache = bridgeBookCacheDAO.getBookForVbid(bridge.getId(), vbid);
			BookUrl bookUrl = null;
			String printURL = bridge.getPrintBookURL();
			if (StringUtils.isNotBlank(printURL) && printURL.contains(ApplicationConstants.PISBN10)) {
				bookUrl = new BookUrl();
				String textBookISBN = bookCache.getTextbookIsbn();
				if (StringUtils.isNotBlank(textBookISBN) && textBookISBN.length() == 13) {
					textBookISBN = com.vst.bridge.StringUtils.ISBN1310(textBookISBN);
				}
				String url = com.vst.bridge.StringUtils.getFormatedStringForPISBN10(printURL, textBookISBN, vbid);
				bookUrl.setUrl(url);
			} else if (StringUtils.isNotBlank(printURL) && printURL.contains(ApplicationConstants.PISBN13)) {
				bookUrl = new BookUrl();
				String textBookISBN = bookCache.getTextbookIsbn();
				if (StringUtils.isNotBlank(textBookISBN) && textBookISBN.length() == 10) {
					textBookISBN = com.vst.bridge.StringUtils.ISBN1013(textBookISBN);
				}
				String url = com.vst.bridge.StringUtils.getFormatedStringForPISBN10(printURL, textBookISBN, vbid);
				bookUrl.setUrl(url);
			}

			response.setData(bookUrl);
			bookServiceUtil.createBridgeLog(user.getId(), bridge, ApplicationAction.PRINT_BOOK, vbid);
		}
		return response;
	}
}
