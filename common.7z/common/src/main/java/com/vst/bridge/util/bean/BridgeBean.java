package com.vst.bridge.util.bean;

public class BridgeBean {

}
