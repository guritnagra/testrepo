package com.vst.bridge.rest.response.vo.user;

import com.vst.bridge.rest.response.vo.ContextVO;

public class IntegratedBridgeUserResponseVO {
	private Integer id;
	private String firstName;
	private String lastName;
	private String email;
	private String tenantUserId;
	private Integer bridgeId;
	private String accessToken;
	private String guid;
	private ContextVO contextVO;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTenantUserId() {
		return tenantUserId;
	}
	public void setTenantUserId(String tenantUserId) {
		this.tenantUserId = tenantUserId;
	}
	public Integer getBridgeId() {
		return bridgeId;
	}
	public void setBridgeId(Integer bridgeId) {
		this.bridgeId = bridgeId;
	}
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public String getGuid() {
		return guid;
	}
	public void setGuid(String guid) {
		this.guid = guid;
	}
	public ContextVO getContextVO() {
		return contextVO;
	}
	public void setContextVO(ContextVO contextVO) {
		this.contextVO = contextVO;
	}

}
