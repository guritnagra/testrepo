package com.vst.bridge.rest.response.vo;

import com.vst.bridge.rest.input.vo.PurchaseRequestVO;

public class BridgePurchaseResponseVO extends PurchaseRequestVO{
	private Integer bridgeId;
	private Boolean isPurchaseEnabled;
	public Integer getBridgeId() {
		return bridgeId;
	}
	public void setBridgeId(Integer bridgeId) {
		this.bridgeId = bridgeId;
	}
	public Boolean getIsPurchaseEnabled() {
		return isPurchaseEnabled;
	}
	public void setIsPurchaseEnabled(Boolean isPurchaseEnabled) {
		this.isPurchaseEnabled = isPurchaseEnabled;
	}
	
	
	
	

}
