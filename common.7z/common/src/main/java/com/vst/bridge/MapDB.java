package com.vst.bridge;

import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

import org.mapdb.*;

public class MapDB {
	private static MapDB instance;
	private DB db;

	private MapDB() {
	}

	public static MapDB getInstance() {
		if (null == instance) {
			instance = new MapDB();
		}
		return instance;
	}

	{
		makeDB();
	}

	public ConcurrentMap<String, String> getStore() {
		if (null == db || db.isClosed()) {
			makeDB();
		}


		return 	db.createHashMap("contextStore").expireAfterAccess(5, TimeUnit.MINUTES)
				.expireAfterWrite(10, TimeUnit.MINUTES).makeOrGet();
	}

	private void makeDB() {
		db = DBMaker.newMemoryDB().transactionDisable().make();
	}

	public void closeDB() {
		if (null != db && !db.isClosed())
			db.close();
	}

}
