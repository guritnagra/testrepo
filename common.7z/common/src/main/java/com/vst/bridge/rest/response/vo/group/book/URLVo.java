package com.vst.bridge.rest.response.vo.group.book;

public class URLVo {
	private String url;
	private String price;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
	
}
