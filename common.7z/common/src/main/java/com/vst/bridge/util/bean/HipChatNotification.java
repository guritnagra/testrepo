package com.vst.bridge.util.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class HipChatNotification {
	private String color;
	private String message;
	private String notify;
	private String message_format;
	private HipChatCard hipChatCard;

	public HipChatNotification() {
		this.hipChatCard = new HipChatCard();
	}

	@JsonProperty(value = "color", required = true)
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@JsonProperty(value = "message", required = true)
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@JsonProperty(value = "notify", required = true)
	public String getNotify() {
		return notify;
	}

	public void setNotify(String notify) {
		this.notify = notify;
	}

	@JsonProperty(value = "message_format", required = true)
	public String getMessage_format() {
		return message_format;
	}

	public void setMessage_format(String message_format) {
		this.message_format = message_format;
	}

	@JsonProperty(value = "card", required = true)
	public HipChatCard getHipChatCard() {
		return hipChatCard;
	}

	public void setHipChatCard(HipChatCard hipChatCard) {
		this.hipChatCard = hipChatCard;
	}

}
