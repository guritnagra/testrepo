package com.vst.bridge.dao.log;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.log.BridgeRosterLog;
import com.vst.bridge.util.exception.BridgeException;	

@Repository("bridgeRosterLogDAO")
public class BridgeRosterLogDAOImpl extends GenericDAO<BridgeRosterLog, Integer> implements IBridgeRosterLogDAO {

	public BridgeRosterLogDAOImpl() {
		super(BridgeRosterLog.class);
	}

	@Override
	public BridgeRosterLog getRosterLogByURL(String fileURL) throws BridgeException{
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("fileURL",fileURL));
		List<BridgeRosterLog> result = executeCriteira(criteria);
		return null!=result && result.size() > 0? result.get(0) : null;
	}

	@Override
	public List<BridgeRosterLog> getAllBridgeRosterLog(Integer bridgeId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id",bridgeId));
		criteria.addOrder(Order.desc("createdDate"));
		return executeCriteira(criteria);
		 
	}

}
