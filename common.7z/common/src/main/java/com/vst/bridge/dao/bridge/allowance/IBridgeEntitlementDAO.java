package com.vst.bridge.dao.bridge.allowance;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.allowance.BridgeEntitlement;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeEntitlementDAO extends IGenericDAO<BridgeEntitlement, Integer>{
	
	List<BridgeEntitlement> getBridgeEntitlements(final Integer bridgeId)throws BridgeException;

}
