package com.vst.bridge.util.bean;

import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class HipChatCard {
	private String style;
	private String url;
	private String id;
	private String title;
	private String description;
	private HipChatIcon icon;
	private HipChatThumbnail thumbnail;
	private List<HipChatAttribute> attributes;

	public HipChatCard() {
		this.icon = new HipChatIcon();
		this.thumbnail = new HipChatThumbnail();
		id = UUID.randomUUID().toString();
	}
	@JsonProperty(value = "style", required = true)
	public String getStyle() {
		return style;
	}

	public void setStyle(String style) {
		this.style = style;
	}

	@JsonProperty(value = "url", required = true)
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@JsonProperty(value = "id", required = true)
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@JsonProperty(value = "title", required = true)
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@JsonProperty(value = "description", required = true)
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@JsonProperty(value = "icon", required = true)
	public HipChatIcon getIcon() {
		return icon;
	}

	public void setIcon(HipChatIcon icon) {
		this.icon = icon;
	}

	@JsonProperty(value = "thumbnail", required = true)
	public HipChatThumbnail getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(HipChatThumbnail thumbnail) {
		this.thumbnail = thumbnail;
	}

	@JsonProperty(value = "attributes", required = true)
	public List<HipChatAttribute> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<HipChatAttribute> attributes) {
		this.attributes = attributes;
	}

}
