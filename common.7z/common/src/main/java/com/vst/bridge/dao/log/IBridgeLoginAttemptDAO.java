package com.vst.bridge.dao.log;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.log.BridgeLoginAttempt;

public interface IBridgeLoginAttemptDAO extends IGenericDAO<BridgeLoginAttempt, Integer> {

	BridgeLoginAttempt getAttemptsByUserName(String username);

	BridgeLoginAttempt getAttemptsByUserNameAndIPAddress(String username, String ipAddress);
}
