package com.vst.bridge.service.bc;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.UriInfo;

import org.jdom2.JDOMException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.job.JobTask;
import com.vst.bridge.rest.response.vo.BCUserVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.exception.BusinessCenterException;
import com.vst.bridge.util.exception.IntegrationException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;

public interface IBusinessCenterServices {
	RestResponse createOrUpdateCoursesForTenantId(SessionStatusVO sessionStatusVO, Integer bridgeId, Integer tenantId,
			HttpServletRequest httpRequest, UriInfo uriInfo,JobTask jobTask,Boolean isJobScheduler) throws IOException, BridgeException, BusinessCenterException, ConnectApiException, JDOMException, ParseException;

	RestResponse getTenant(Integer tenantId, String apiKey) throws BusinessCenterException, JsonParseException, JsonMappingException, IOException;

	RestResponse createOrUpdateBridgeUserFromContextToken(HttpServletRequest httpRequest, HttpServletResponse httpResponse,
			String code, String contextToken, UriInfo uriInfo)throws BusinessCenterException, JsonParseException, JsonMappingException, IOException, IntegrationException;

	RestResponse getUsersForTenantId(SessionStatusVO sessionStatusVO, Integer bridgeId, Integer tenantId,
			HttpServletRequest httpRequest, UriInfo uriInfo,JobTask jobTask, Boolean isJobScheduler) throws BridgeException,BusinessCenterException, JsonParseException, JsonMappingException, IOException, ConnectApiException;

	RestResponse getCourseForGroupId(SessionStatusVO sessionStatusVO, Integer bridgeId, Integer courseId,
			HttpServletRequest httpRequest, UriInfo uriInfo,Boolean isJobScheduler) throws BridgeException,BusinessCenterException, JsonParseException, JsonMappingException, IOException, ConnectApiException;

	List<BCUserVO> refreshUsersForTenantId(AdminUser adminUser, Bridge bridge, Integer tenantId)
			throws JsonParseException, JsonMappingException, IOException;
  
	/*RestResponse getUsersForCourses(SessionStatusVO sessionStatusVO, Integer bridgeId, Integer tenantId, String course,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws IOException, BridgeExcepation,
			BusinessCenterException, ConnectApiException, JDOMException, ParseException;*/


}
