package com.vst.bridge.rest.input.vo;


/*
 * "purchaseName": "Print book",																
				"displayPricing": "Digital",
				"purchaseUrl": "www.google.com/purchase/1234"
 */
public class PurchaseVO {
	
	private Integer id;
	private String purchaseName;
	private String displayPricing;
	private String purchaseUrl;
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPurchaseName() {
		return purchaseName;
	}
	public void setPurchaseName(String purchaseName) {
		this.purchaseName = purchaseName;
	}
	public String getDisplayPricing() {
		return displayPricing;
	}
	public void setDisplayPricing(String displayPricing) {
		this.displayPricing = displayPricing;
	}
	public String getPurchaseUrl() {
		return purchaseUrl;
	}
	public void setPurchaseUrl(String purchaseUrl) {
		this.purchaseUrl = purchaseUrl;
	}
	
}
