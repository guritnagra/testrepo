package com.vst.bridge.dao.user;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.rest.response.vo.BCUserVO;
import com.vst.bridge.rest.response.vo.bridge.user.BridgeUserResponseVO;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.util.exception.BridgeException;


public interface IBridgeUserDAO extends IGenericDAO<BridgeUser,Integer>{

	BridgeUser checkUserAllreadyExist(Integer id, String guid) throws BridgeException;
	
	BridgeUser checkUserAllreadyExist(Integer id, String guid, Integer role_id) throws BridgeException;
	
	BridgeUser getForEmail(final String email) throws BridgeException;
	
	BridgeUser getForEmail(final Integer bridgeId,final String email) throws BridgeException;
	
	BridgeUser getForUser(final Integer bridgeId,final Integer userId) throws BridgeException;

	List<BridgeUserResponseVO> getUsersForBridge(Integer bridgeId, Integer startIndex, PaginationVO paginationVo)throws BridgeException;
	
	List<Integer> getUserIdsForBridge(Integer bridgeId)throws BridgeException;
	

	Integer getUsersCountForBridge(Integer bridgeId, PaginationVO paginationVo) throws BridgeException;
	
	List<BridgeUser> getAllUsersForBridge(Integer bridgeId )throws BridgeException;

	List<BridgeUserResponseVO> getUsersForBridge(Integer bridgeId, PaginationVO paginationVo) throws BridgeException;

	BridgeUser getBridgeUserByTenantUserId(String tenantUserId, Integer bridgeId)throws BridgeException;

	List<BridgeUser> getIntegratedBridgeUserByBridgeId(Integer bridgeId)throws BridgeException;

	BridgeUser getBridgeUserByGUID(Integer bridgeId, String guid, Integer role_id) throws BridgeException;

	Integer deleteAllUsers(Integer adminId, Bridge bridge);

	BridgeUser getBridgeUserBySourceId(Integer bridgeId, String userSourceId) throws BridgeException;

	BridgeUser getBridgeUserByTenantUser(BCUserVO bcUserV, Integer bridgeId) throws BridgeException;
	
}
