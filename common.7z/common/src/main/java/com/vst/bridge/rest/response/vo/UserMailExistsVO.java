package com.vst.bridge.rest.response.vo;

public class UserMailExistsVO {
	
	private String mail;
	
	private boolean exists;
	
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public boolean isExists() {
		return exists;
	}
	public void setExists(boolean exists) {
		this.exists = exists;
	}

}
