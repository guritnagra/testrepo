package com.vst.bridge.rest.response.vo.user;

public class BookLicensesVO {
	private BookLicenseInfoVO trial;
	private BookLicenseInfoVO rental;
	private BookLicenseInfoVO full;
	private BookLicenseInfoVO print;
	private BookLicenseInfoVO text;
	public BookLicenseInfoVO getTrial() {
		return trial;
	}
	public void setTrial(BookLicenseInfoVO trial) {
		this.trial = trial;
	}
	public BookLicenseInfoVO getRental() {
		return rental;
	}
	public void setRental(BookLicenseInfoVO rental) {
		this.rental = rental;
	}
	public BookLicenseInfoVO getFull() {
		return full;
	}
	public void setFull(BookLicenseInfoVO full) {
		this.full = full;
	}
	public BookLicenseInfoVO getPrint() {
		return print;
	}
	public void setPrint(BookLicenseInfoVO print) {
		this.print = print;
	}
	public BookLicenseInfoVO getText() {
		return text;
	}
	public void setText(BookLicenseInfoVO text) {
		this.text = text;
	}
	
}
