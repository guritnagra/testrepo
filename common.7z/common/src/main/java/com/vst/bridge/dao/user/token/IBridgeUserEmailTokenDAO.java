package com.vst.bridge.dao.user.token;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.user.token.BridgeUserEmailToken;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeUserEmailTokenDAO extends IGenericDAO<BridgeUserEmailToken, Integer>{

	List<BridgeUserEmailToken> getList(Integer bridgeId,String email,Boolean used)throws BridgeException;
	
	BridgeUserEmailToken getForToken(final String email)throws BridgeException;
	
}
