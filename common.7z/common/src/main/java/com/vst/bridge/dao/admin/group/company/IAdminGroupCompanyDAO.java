package com.vst.bridge.dao.admin.group.company;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.group.company.AdminGroupCompany;
import com.vst.bridge.entity.company.Company;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminGroupCompanyDAO extends IGenericDAO<AdminGroupCompany, Integer>{

	List<Company> getListOfCompaniesForGroupId(final Integer groupId)throws BridgeException;
	
	List<AdminGroupCompany> getListOfGroupCompanies()throws BridgeException;

	List<Company> getListOfCompaniesForGroupIds(List<Integer> groupIds)throws BridgeException;
}
