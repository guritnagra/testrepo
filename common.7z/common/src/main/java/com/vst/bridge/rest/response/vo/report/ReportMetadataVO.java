package com.vst.bridge.rest.response.vo.report;

public class ReportMetadataVO {
	private Integer totalRecords;
	private Integer totalPages;
	private Integer currentPage;
	public ReportMetadataVO() {}
	
	public ReportMetadataVO(Integer totalRecords,Integer totalPages,Integer currentPage) {
		this.totalPages = totalPages;
		this.totalRecords = totalRecords;
		this.currentPage = currentPage;
	}
	
	public Integer getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}
	public Integer getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(Integer totalPages) {
		this.totalPages = totalPages;
	}

	public Integer getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}
	
}
