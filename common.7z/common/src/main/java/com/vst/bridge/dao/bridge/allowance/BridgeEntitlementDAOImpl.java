package com.vst.bridge.dao.bridge.allowance;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.allowance.BridgeEntitlement;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeEntitlementDAO")
public class BridgeEntitlementDAOImpl extends GenericDAO<BridgeEntitlement, Integer> implements IBridgeEntitlementDAO {
	
	public BridgeEntitlementDAOImpl() {
		super(BridgeEntitlement.class);
	}

	@Override
	public List<BridgeEntitlement> getBridgeEntitlements(Integer bridgeId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		List<BridgeEntitlement> result =  executeCriteira(criteria);
		return result;
	}

}
