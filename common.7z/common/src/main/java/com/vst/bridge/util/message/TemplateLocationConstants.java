package com.vst.bridge.util.message;

public class TemplateLocationConstants {
	public static final String TEMPLATE_FOLDER = "templates/";
	public static final String RESET_PASSWORD_TEMPLATE=TEMPLATE_FOLDER+"resetPassword.vm";
	public static final String BATCH_FILE_TEMPLATE=TEMPLATE_FOLDER+"downloadBatches.vm";
	public static final String NEW_BRIDGE_NOTIFICATION_TEMPLATE=TEMPLATE_FOLDER+"newBridgeNotification.vm";
	public static final String USER_ACCTIVATION_NOTIFICATION_TEMPLATE=TEMPLATE_FOLDER+"activateAccountEmail.vm";
	public static final String BRIDGE_ACCTIVATION_NOTIFICATION_TEMPLATE=TEMPLATE_FOLDER+"activateBridgeEmail.vm";
	public static final String KPI_DATA_REPORT_TEMPLATE=TEMPLATE_FOLDER+"kpiReportEmail.vm";
	public static final String BRIDGE_ALLOWANCE_NOTIFICATION_TEMPLATE=TEMPLATE_FOLDER+"bridgeAllowanceNotificationEmail.vm";
	public static final String HIPCHAT_NOTIFICATION=TEMPLATE_FOLDER+"hipChatNotification.vm";
}
