package com.vst.bridge.dao.admin.ancillary;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.ancillary.AncillaryUploadToken;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.Bridge;

@Repository("ancillaryUploadTokenDAO")
public class AncillaryUploadTokenDAOImpl extends GenericDAO<AncillaryUploadToken, Integer> implements IAncillaryUploadTokenDAO {

	public AncillaryUploadTokenDAOImpl() {
		super(AncillaryUploadToken.class);
	}

	@Override
	public AncillaryUploadToken getAncillaryTokenByTokenString(String token, Bridge bridge) {
		if(null == bridge || null == token){
			return null;
		}
		Criteria criteria = getCriteria(AncillaryUploadToken.class);
		criteria.add(Restrictions.eq("token", token));
		criteria.add(Restrictions.eqOrIsNull("bridge.id", bridge.getId()));
		List<AncillaryUploadToken> uploadTokens = executeCriteira(criteria);
		return null != uploadTokens && uploadTokens.size() > 0 ? uploadTokens.get(0) : null;
	}

	@Override
	public List<AncillaryUploadToken> getAncillaryTokensForAdmin(AdminUser admin, Bridge bridge) {
		if (null == admin || null == bridge){
			return null; 
		}
		Criteria criteria = getCriteria(AncillaryUploadToken.class);
		criteria.add(Restrictions.eq("admin_id", admin.getId()));
		criteria.add(Restrictions.eq("bridge_id",bridge.getId()));
		return executeCriteira(criteria);
	}

}
