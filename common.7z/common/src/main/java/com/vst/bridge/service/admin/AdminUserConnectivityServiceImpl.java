package com.vst.bridge.service.admin;

import java.math.BigInteger;
import java.util.List;

import javax.ws.rs.core.Response;

import org.hibernate.SQLQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.dao.bridge.type.IBridgeTypeDAO;
import com.vst.bridge.rest.response.vo.ConnectivityMonitorResponseVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;

@Service("adminUserConnectivityService")
public class AdminUserConnectivityServiceImpl implements IAdminUserConnectivityService{
	@Autowired
	private LocaleMessageUtility localeMessageUtility;
	
	@Autowired
	private IBridgeTypeDAO bridgeTypeDAO;
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse connectivityMonitorCheck() throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		ConnectivityMonitorResponseVO connectivityMonitorResponseVO = new ConnectivityMonitorResponseVO();
		connectivityMonitorResponseVO.setSuccess(Boolean.TRUE);
		BigInteger expectedVal= new BigInteger("1");
		try{
			SQLQuery sql = bridgeTypeDAO.getSQLQueryObj("select 1");
			List<BigInteger> val=bridgeTypeDAO.executeHQLSelectQuery(sql);		
			if(expectedVal.equals(val.get(0)));
			{
				connectivityMonitorResponseVO.setDbStatus(Boolean.TRUE);
			}
		}
		catch(Exception e){
			connectivityMonitorResponseVO.setDbStatus(Boolean.FALSE);
		}
		
		
		response.setData(connectivityMonitorResponseVO);
		
		return response;
	}
}
