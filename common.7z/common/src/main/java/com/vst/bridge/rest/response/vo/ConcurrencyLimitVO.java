package com.vst.bridge.rest.response.vo;

public class ConcurrencyLimitVO {
	
	private Integer concurrencyLimit;
	private Boolean isConcurrencyEnabled;
	
	public Integer getConcurrencyLimit() {
		return concurrencyLimit;
	}
	public void setConcurrencyLimit(Integer concurrencyLimit) {
		this.concurrencyLimit = concurrencyLimit;
	}
	public Boolean getIsConcurrencyEnabled() {
		return isConcurrencyEnabled;
	}
	public void setIsConcurrencyEnabled(Boolean isConcurrencyEnabled) {
		this.isConcurrencyEnabled = isConcurrencyEnabled;
	}

}
