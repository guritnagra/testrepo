package com.vst.bridge.rest.response.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class TenantVO {
	
	private String id;
	private String key;
	private String name;
	private String company_name;
	private String company_id;
	private String api_key;
	private String slug;
	private String api_opt_out_url;
	private String api_opt_out_tenant_identifier;
	private String comment;
	private String geography_id;
	private String parent_id;
	private String created_at;
	private String updated_at;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getCompany_id() {
		return company_id;
	}
	public void setCompany_id(String company_id) {
		this.company_id = company_id;
	}
	public String getApi_key() {
		return api_key;
	}
	public void setApi_key(String api_key) {
		this.api_key = api_key;
	}
	public String getSlug() {
		return slug;
	}
	public void setSlug(String slug) {
		this.slug = slug;
	}
	public String getApi_opt_out_url() {
		return api_opt_out_url;
	}
	public void setApi_opt_out_url(String api_opt_out_url) {
		this.api_opt_out_url = api_opt_out_url;
	}
	/*public String getApi_opt_out_tenant_indentifier() {
		return api_opt_out_tenant_indentifier;
	}
	public void setApi_opt_out_tenant_indentifier(String api_opt_out_tenant_indentifier) {
		this.api_opt_out_tenant_indentifier = api_opt_out_tenant_indentifier;
	}*/
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getGeography_id() {
		return geography_id;
	}
	public void setGeography_id(String geography_id) {
		this.geography_id = geography_id;
	}
	public String getParent_id() {
		return parent_id;
	}
	public void setParent_id(String parent_id) {
		this.parent_id = parent_id;
	}
	public String getCreated_at() {
		return created_at;
	}
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	public String getUpdated_at() {
		return updated_at;
	}
	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}
	public String getApi_opt_out_tenant_identifier() {
		return api_opt_out_tenant_identifier;
	}
	public void setApi_opt_out_tenant_identifier(String api_opt_out_tenant_identifier) {
		this.api_opt_out_tenant_identifier = api_opt_out_tenant_identifier;
	}
}

