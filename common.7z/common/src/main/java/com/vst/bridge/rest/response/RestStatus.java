package com.vst.bridge.rest.response;

import javax.ws.rs.core.Response;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class RestStatus {
	protected Response.Status code;
	protected String text;
	
	public RestStatus(Response.Status code, String text) {
		this.code= code;
		this.text= text;
	}
	
	public RestStatus setStatus(RestStatus status) {
		this.code= status.getCode();
		this.text= status.getText();
		
		return this;
	}
	
	public RestStatus() {
		code= Response.Status.OK;
		text= "OK";
	};
	
	public Response.Status getCode()
	{
		return code;
	}
	public void setCode(Response.Status code)
	{
		this.code= code;
	}
	
	public String getText()
	{
		return text;
	}
	public void setText(String txt) {
		this.text= txt;
		
	}
}
