package com.vst.bridge.util.bean;

public class BridgeUserBean extends BridgeBean {
//sourcedId,status,dateLastModified,orgSourcedIds,role,username,userId,givenName,familyName,identifier,email,sms,phone,agents
	
	private String sourcedId;
	private String status;
	private String dateLastModified;
	private String orgSourcedIds;
	private String role;
	private String username;
	private String userId;
	private String givenName;
	private String familyName;
	private String identifier;
	private String email;
	private String sms;
	private String phone;
	private String agents;
	
	public String getSourcedId() {
		return sourcedId;
	}
	public void setSourcedId(String sourcedId) {
		this.sourcedId = sourcedId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDateLastModified() {
		return dateLastModified;
	}
	public void setDateLastModified(String dateLastModified) {
		this.dateLastModified = dateLastModified;
	}
	public String getOrgSourcedIds() {
		return orgSourcedIds;
	}
	public void setOrgSourcedIds(String orgSourcedIds) {
		this.orgSourcedIds = orgSourcedIds;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getGivenName() {
		return givenName;
	}
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}
	public String getFamilyName() {
		return familyName;
	}
	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSms() {
		return sms;
	}
	public void setSms(String sms) {
		this.sms = sms;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAgents() {
		return agents;
	}
	public void setAgents(String agents) {
		this.agents = agents;
	}
	
	
	

}
