package com.vst.bridge.rest.input.vo;

public class ReCaptchaLoginVO extends LoginInfoVO {
	
	private String captchaResponse;

	public String getCaptchaResponse() {
		return captchaResponse;
	}

	public void setCaptchaResponse(String captchaResponse) {
		this.captchaResponse = captchaResponse;
	}
}
