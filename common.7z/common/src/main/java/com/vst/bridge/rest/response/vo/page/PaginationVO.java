package com.vst.bridge.rest.response.vo.page;

import java.io.Serializable;

/**
 * This VO is used to set all paging related values
 * 
 * @author Irfan.Tamboli
 * 
 */
@SuppressWarnings("serial")
public class PaginationVO implements Serializable {

	/**
	 * Current page of the query
	 */
	private Integer page;

	/**
	 * Total numbers of rows to be fetched.
	 */
	private Integer limit;

	/**
	 * Total no of pages for the grid.
	 */
	private Integer totalPages;


	/**
	 * Currently selected sort column name.
	 */
	private String orderBy;

	/**
	 * Sort order.
	 */
	private String order = "ASC";

	/**
	 * Search Field
	 */
	private String search;
	
	private Integer count;
	
	private Integer offset;
	
	private String metadataName;
	
	public PaginationVO(Integer page,Integer limit,Integer totalPages,String orderBy,String order,String serach,Integer count,Integer offset) {
		this.page = page;
		this.limit=limit;
		this.totalPages=totalPages;
		this.orderBy=orderBy;
		this.order=order;
		this.search=serach;
		this.count = count;
		this.offset=offset;
	}
	
	public PaginationVO() {}
	
	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}

	public Integer getLimit() {
		return limit;
	}

	public void setLimit(Integer limit) {
		this.limit = limit;
	}

	public Integer getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(Integer totalPages) {
		this.totalPages = totalPages;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

	public String getSearch() {
		return search;
	}

	public void setSearch(String serach) {
		this.search = serach;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Integer getOffset() {
		return offset;
	}

	public void setOffset(Integer offset) {
		this.offset = offset;
	}

	public String getMetadataName() {
		return metadataName;
	}

	public void setMetadataName(String metadataName) {
		this.metadataName = metadataName;
	}
}
