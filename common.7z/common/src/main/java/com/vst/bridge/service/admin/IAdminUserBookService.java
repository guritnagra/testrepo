package com.vst.bridge.service.admin;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.user.CreateKeysVO;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;

public interface IAdminUserBookService {
	RestResponse refreshBookCache(CreateKeysVO createKeysVO, HttpServletRequest httpRequest, UriInfo uriInfo)throws BridgeException, ConnectApiException, ConnectApiXmlException, ParseException, IOException;
}
