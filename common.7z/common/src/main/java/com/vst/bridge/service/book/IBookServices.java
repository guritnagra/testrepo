package com.vst.bridge.service.book;

public interface IBookServices extends IBookBridgeService, IBookAncillaryService, IBookConcurrencyService, IBookEntitlementService, IBookLicenseService, IBookPrintService, IBookActionService {
	
}
