package com.vst.bridge.dao.bridge.group;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.group.BridgeGroup;
import com.vst.bridge.entity.group.GroupUser;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.rest.response.vo.bridge.user.BridgeUserResponseVO;
import com.vst.bridge.rest.response.vo.group.user.BridgeGroupUserResponseVO;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeGroupUserDAO")
public class BridgeGroupUserDAOImpl extends GenericDAO<GroupUser, Integer> implements IBridgeGroupUserDAO{

	public BridgeGroupUserDAOImpl() {
		super(GroupUser.class);
	}
	
	@Override
	public List<BridgeUserResponseVO> getUsersForGroup(Integer groupId, final Integer startIndex, PaginationVO paginationVo)
			throws BridgeException {
		
		Criteria criteria= getCriteria();
		criteria.createAlias("user", "userAlias");
		if(null!=paginationVo){
			
			Integer totalRecordToFetch = paginationVo.getLimit();
			if(null != startIndex && null != totalRecordToFetch  && totalRecordToFetch > 0){
				criteria.setFirstResult(startIndex);
				criteria.setMaxResults(totalRecordToFetch);
			}
			
			String searchParam =  paginationVo.getSearch();
			if(StringUtils.isNotBlank(searchParam)){
				
				
				Criterion criterion1 = Restrictions.ilike("userAlias.firstName", "%"+searchParam+"%");
				Criterion criterion2 = Restrictions.ilike("userAlias.lastName", "%"+searchParam+"%");
				Criterion criterion3 = Restrictions.ilike("userAlias.email", "%"+searchParam+"%");
				
				Criterion completeCriterion = Restrictions.disjunction()
						.add(criterion1)
						.add(criterion2)
						.add(criterion3);
				criteria.add(completeCriterion);
			}
			
			if(StringUtils.equals(paginationVo.getOrder(), ApplicationConstants.SORTING_ORDER_ASC)){
				criteria.addOrder(Order.asc(paginationVo.getOrderBy()));
			}else{
				criteria.addOrder(Order.desc(paginationVo.getOrderBy()));
			}
		}
		
	
		
		criteria.add(Restrictions.eq("group.id", groupId));
		criteria.add(Restrictions.eq("selected", Boolean.TRUE));
		
		criteria.setProjection(Projections.projectionList()
				.add( Projections.property("userAlias.id").as("id"))
				.add( Projections.property("userAlias.firstName").as("firstName"))
				.add( Projections.property("userAlias.email").as("email"))
				.add( Projections.property("userAlias.lastName").as("lastName"))
				.add(Projections.property("userAlias.createdDate").as("activationDate"))
				.add(Projections.property("userAlias.tenantUserId").as("tenantUserId")))
				.setResultTransformer(new AliasToBeanResultTransformer(BridgeUserResponseVO.class));
				
		return executeCriteira(criteria);
	}
	
	@Override
	public Integer getUsersCountForGroup(Integer groupId, PaginationVO paginationVo)
			throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.createAlias("user", "userAlias");
		if(null!=paginationVo){
			
			String searchParam =  paginationVo.getSearch();
			if(StringUtils.isNotBlank(searchParam)){
				
				
				Criterion criterion1 = Restrictions.ilike("userAlias.firstName", "%"+searchParam+"%");
				Criterion criterion2 = Restrictions.ilike("userAlias.lastName", "%"+searchParam+"%");
				Criterion criterion3 = Restrictions.ilike("userAlias.email", "%"+searchParam+"%");
				
				Criterion completeCriterion = Restrictions.disjunction()
						.add(criterion1)
						.add(criterion2)
						.add(criterion3);
				criteria.add(completeCriterion);
			}
		}
		criteria.add(Restrictions.eq("group.id", groupId));
		criteria.add(Restrictions.eq("selected", Boolean.TRUE));
		
		criteria.setProjection(Projections.projectionList()
				.add( Projections.property("userAlias.id").as("id"))
				.add( Projections.property("userAlias.firstName").as("firstName"))
				.add( Projections.property("userAlias.email").as("email"))
				.add( Projections.property("userAlias.lastName").as("lastName")))
				.setResultTransformer(new AliasToBeanResultTransformer(BridgeGroupUserResponseVO.class));
				
		List<BridgeGroupUserResponseVO> result = executeCriteira(criteria);
		if (null != result && result.size() > 0) {
			return result.size();
		}
			
		return 0;
	}
	
	@Override
	public List<GroupUser> getAllUsersForGroup(Integer groupId) throws BridgeException{
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("group.id", groupId));
		return executeCriteira(criteria);
	}


	@Override
	public List<GroupUser> getAllUsersForGroup(Integer groupId,Boolean isSelected) throws BridgeException{
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("group.id", groupId));
		criteria.add(Restrictions.eq("selected", isSelected));
		return executeCriteira(criteria);
	}
	
	@Override
	public GroupUser getGroupUser(Integer groupId, Integer userId, Boolean isDeleted, Boolean isExpired, Boolean removeFutureActiveGroups) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.createAlias("group", "groupAlias");
		criteria.add(Restrictions.eq("group.id", groupId));
		criteria.add(Restrictions.eq("user.id", userId));
		if(removeFutureActiveGroups){
			Criterion criteria1 = Restrictions.le("groupAlias.startDate", new Date());
			Criterion criteria2 = Restrictions.isNull("groupAlias.startDate");
			Criterion disjuctionCriteria = Restrictions.disjunction()
											.add(criteria1)
											.add(criteria2);
			criteria.add(disjuctionCriteria);			
		}
/*		criteria.add(Restrictions.eq("groupAlias.deleted", isDeleted));
		if(isExpired) {
			Criterion criteria1 = Restrictions.gt("groupAlias.expiredDate", new Date());
			Criterion criteria2 = Restrictions.isNull("groupAlias.expiredDate");
			Criterion disjuctionCriteria = Restrictions.disjunction()
											.add(criteria1)
											.add(criteria2);
			criteria.add(disjuctionCriteria);			
		}*/
		List<GroupUser> results = executeCriteira(criteria);
		return null != results && results.size() > 0 ? results.get(0) : null;
	}
	@Override
	public GroupUser getGroupUser(Integer groupId, Integer userId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.createAlias("group", "groupAlias");
		criteria.add(Restrictions.eq("group.id", groupId));
		criteria.add(Restrictions.eq("user.id", userId));
		List<GroupUser> results = executeCriteira(criteria);
		return null != results && results.size() > 0 ? results.get(0) : null;
	}
	@Override
	public List<Integer> getGroupUsersForBridge(List<Integer> groupIds) throws BridgeException {
		
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.in("group.id", groupIds));
		criteria.add(Restrictions.eq("selected", Boolean.TRUE));
		criteria.setProjection(Projections.property("user.id"));
		List<Integer> ids = executeCriteira(criteria);
		return ids;
	}
	

	@Override
	public List<BridgeGroup> getGroupsForUser(Integer userId, Boolean isDeleted, Boolean isExpired,Boolean removeFutureActiveGroups)  throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.createAlias("group", "groupAlias");
		criteria.add(Restrictions.eq("user.id", userId));
		criteria.add(Restrictions.eq("selected", Boolean.TRUE));
		criteria.add(Restrictions.eq("groupAlias.isHidden", Boolean.FALSE));
		criteria.add(Restrictions.eq("groupAlias.deleted", isDeleted));
		if(isExpired) {
			Criterion criteria1 = Restrictions.gt("groupAlias.expiredDate", new Date());
			Criterion criteria2 = Restrictions.isNull("groupAlias.expiredDate");
			Criterion disjuctionCriteria = Restrictions.disjunction()
											.add(criteria1)
											.add(criteria2);
			criteria.add(disjuctionCriteria);			
		}
		if(removeFutureActiveGroups){
			Criterion criteria1 = Restrictions.le("groupAlias.startDate", new Date());
			Criterion criteria2 = Restrictions.isNull("groupAlias.startDate");
			Criterion disjuctionCriteria1 = Restrictions.disjunction()
											.add(criteria1)
											.add(criteria2);
			criteria.add(disjuctionCriteria1);			
		}
		criteria.setProjection(Projections.property("group"));
		List<BridgeGroup> groups = executeCriteira(criteria);
		return groups;
	}

	@Override
	public List<Integer> getGroupIdsForUser(Integer bridgeId, Integer userId,Boolean isDeleted, Boolean isExpired,Boolean removeFutureActiveGroups) throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.createAlias("group", "groupAlias");		
		criteria.add(Restrictions.eq("user.id", userId));
		criteria.add(Restrictions.eq("groupAlias.bridge.id", bridgeId));
		criteria.add(Restrictions.eq("groupAlias.isHidden", Boolean.FALSE));
		criteria.add(Restrictions.eq("selected", Boolean.TRUE));
		criteria.setProjection(Projections.property("group.id"));
		
		criteria.add(Restrictions.eq("groupAlias.deleted", isDeleted));
		if(isExpired) {
			Criterion criteria1 = Restrictions.gt("groupAlias.expiredDate", new Date());
			Criterion criteria2 = Restrictions.isNull("groupAlias.expiredDate");
			Criterion disjuctionCriteria = Restrictions.disjunction()
											.add(criteria1)
											.add(criteria2);
			criteria.add(disjuctionCriteria);			
		}
		if(removeFutureActiveGroups){
			Criterion criteria1 = Restrictions.le("groupAlias.startDate", new Date());
			Criterion criteria2 = Restrictions.isNull("groupAlias.startDate");
			Criterion disjuctionCriteria1 = Restrictions.disjunction()
											.add(criteria1)
											.add(criteria2);
			criteria.add(disjuctionCriteria1);			
		}
		
		List<Integer> ids = executeCriteira(criteria);
		return ids;
	}

	@Override
	public List<IdValueVO> getGroupsForUserId(Integer bridgeId, Integer userId) throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.createAlias("group", "groupAlias");
		criteria.add(Restrictions.eq("groupAlias.bridge.id", bridgeId));
		criteria.add(Restrictions.eq("user.id", userId));
		criteria.add(Restrictions.eq("selected", Boolean.TRUE));
		criteria.addOrder(Order.asc("groupAlias.name"));
		criteria.setProjection(Projections.projectionList()
				.add( Projections.property("groupAlias.id").as("id"))
				.add( Projections.property("groupAlias.name").as("value")))
				.setResultTransformer(new AliasToBeanResultTransformer(IdValueVO.class));
		
		return executeCriteira(criteria);
	}

	@Override
	public List<GroupUser> getUsersForGroup(Integer groupId, List<Integer> userIds) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("group.id", groupId));
		criteria.add(Restrictions.in("user.id", userIds));
		
		return executeCriteira(criteria);
	}

	@Override
	public List<GroupUser> getBridgeGroupUsers(Integer bridgeId, List<Integer> userIds) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.createAlias("group", "groupAlias");
		criteria.add(Restrictions.eq("groupAlias.bridge.id", bridgeId));
		criteria.add(Restrictions.in("user.id", userIds));		
		return executeCriteira(criteria);
	}

	@Override
	public Integer deleteGroupUsersForGroup(Integer groupId) throws BridgeException {
		Session session = getCrntSession();
		String hqlUpdate = "update GroupUser gu set gu.selected = :selected where gu.group = :group";
		int updatedEntities = session.createQuery(hqlUpdate)
				.setBoolean("selected", Boolean.FALSE)
				.setInteger("group", groupId)
				.executeUpdate();
		return updatedEntities;
	}
	
	@Override
	public Integer deleteGroupUsersForUser(Integer userId) throws BridgeException {
		Session session = getCrntSession();
		String hqlUpdate = "update GroupUser gu set gu.selected = :selected  where gu.user = :user and gu.group.id in (select bg.id from BridgeGroup bg where bg.courseId IS NOT NULL)";
		int updatedEntities = session.createQuery(hqlUpdate)
				.setBoolean("selected", Boolean.FALSE)
				.setInteger("user", userId)
				.executeUpdate();
		return updatedEntities;
	}
	
	@Override
	public Integer deleteAllGroupUsersForBridge(Bridge bridge) throws BridgeException {
		Session session = getCrntSession();
		String hqlUpdate = "update GroupUser gu set gu.selected = :selected where gu.group.id in (select bg.id from BridgeGroup bg where bg.bridge.id = :bridge and bg.courseId IS NOT NULL) ";
		int updatedEntities = session.createQuery(hqlUpdate)
				.setBoolean("selected", Boolean.FALSE)
				.setInteger("bridge", bridge.getId())
				.executeUpdate();
		return updatedEntities;
	}
}
