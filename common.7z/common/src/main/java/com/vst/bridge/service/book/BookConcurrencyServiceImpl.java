package com.vst.bridge.service.book;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.jdom2.JDOMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.bridge.VstException;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookCacheDAO;
import com.vst.bridge.dao.key.IKeyBatchDAO;
import com.vst.bridge.dao.key.IKeyDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.dao.user.book.IBridgeUserBookAssignDAO;
import com.vst.bridge.dao.user.key.IBridgeUserKeyDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.entity.bridge.books.BridgeUserBookAssign;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.BridgeUserKey;
import com.vst.bridge.entity.keys.KeyBatch;
import com.vst.bridge.entity.keys.Keys;
import com.vst.bridge.rest.input.vo.BookConcurrencyLimitVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.user.AccessCodeResponseVO;
import com.vst.bridge.rest.response.vo.user.ConcurrentBookLicenseInfoVO;
import com.vst.bridge.rest.response.vo.user.UserCreditsInfoVO;
import com.vst.bridge.rest.response.vo.user.UserEntitlementVO;
import com.vst.bridge.util.constant.ApplicationAction;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.constant.ApplicationConstants.CodeType;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.StoriaUtils;

@Service("bookConcurrencyService")
public class BookConcurrencyServiceImpl implements IBookConcurrencyService {

	@Autowired
	private IBridgeDAO bridgeDAO;

	@Autowired
	private IBridgeUserBookAssignDAO bridgeUserBookAssignDAO;

	@Autowired
	private IBridgeBookCacheDAO bridgeBookCacheDAO;

	@Autowired
	private IBridgeUserDAO bridgeUserDAO;

	@Autowired
	private IBridgeUserKeyDAO bridgeUserKeyDAO;

	@Autowired
	private IKeyDAO keyDAO;
	
	@Autowired
	private IKeyBatchDAO keyBatchDAO;
	
	@Autowired
	private BookServiceUtil bookServiceUtil;
	
	@Autowired
	private IBookEntitlementService bookEntitlementService;
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse updateConcurrencyForBooks(SessionStatusVO sessionStatusVO, Integer bridgeId,
			BookConcurrencyLimitVO bookConcurrencyLimitVO, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException {
		RestResponse response = bookServiceUtil.getDefaultRestResponse();
		Bridge bridge = bridgeDAO.get(bridgeId);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		if (bridge.getConcurrencyEnabled()) {
			String category = null;
			List<BridgeBookCache> bookCaches = bridgeBookCacheDAO.getCacheBooks(bridgeId, null,
					bookConcurrencyLimitVO.getVbids(), Boolean.FALSE, category);
			if (bookCaches != null) {
				for (BridgeBookCache bookCache : bookCaches) {
					bookCache.setConcurrencyLimit(bookConcurrencyLimitVO.getConcurrencyLimit());
				}
			} else {
				throw new BridgeException(ApplicationCode.BOOK_NOT_FOUND);
			}
			bridgeBookCacheDAO.saveOrUpdateAll(bookCaches);
		}

		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse concurrentBook(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException {
		RestResponse response = bookServiceUtil.getDefaultRestResponse();

		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		if (!bridge.getConcurrencyEnabled()) {
			throw new BridgeException(ApplicationCode.CONCURRENCY_NOT_ENABLED);
		}
		BridgeUser user = bridgeUserDAO.get(sessionStatusVO.getAdminId());
		String apiKey = bridge.getApiKey();
		ConcurrentBookLicenseInfoVO concurrentLicenseInfoVO = this.checkConcurrentFunctinalityForVbid(vbid, user,
				bridge);

		if (null != concurrentLicenseInfoVO && null != concurrentLicenseInfoVO.getState() && StringUtils
				.equals(concurrentLicenseInfoVO.getState(), ApplicationConstants.BOOK_LICENSE_STATE_CREDIT)) {
			if (!concurrentLicenseInfoVO.getIsAvailable()) {
				throw new BridgeException(ApplicationCode.CONCURRENCY_LIMIT_REACHED);
			}
			List<BridgeUserKey> userKeys = bridgeUserKeyDAO.getListOfKeysAssigedForUser(user.getId());
			if (null != userKeys && userKeys.size() > 0) {
				BridgeUserKey key = userKeys.get(0);

				AccessCodeResponseVO accessCodeResponseVO = StoriaUtils.giveAccess(apiKey, user.getAccessToken(), vbid,
						CodeType.CONCURRENCY, bridge, key);
				BridgeUserBookAssign userBook = new BridgeUserBookAssign();
				userBook.setKeyAssigned(key);
				userBook.setLastAccess(new Date());
				userBook.setBookshelfRedeemCode(accessCodeResponseVO.getRedeemCode());
				userBook.setExpires(accessCodeResponseVO.getExpires());
				userBook.setVbid(vbid);
				userBook.setUsedType(ApplicationConstants.BOOK_KEY_USED_TYPE_CONCURRENT);
				bridgeUserBookAssignDAO.saveOrUpdate(userBook);
			}
			bookServiceUtil.createBridgeLog(user.getId(), bridge, ApplicationAction.CONCURRENT_BOOK, vbid);
		}

		return response;
	}

	@Override
	public ConcurrentBookLicenseInfoVO checkConcurrentFunctinalityForVbid(String vbid, BridgeUser user, Bridge bridge) {
		ConcurrentBookLicenseInfoVO concurrentLicensesInfoVO = new ConcurrentBookLicenseInfoVO();
		if (bridge.getConcurrencyEnabled()) {
			UserCreditsInfoVO userCreditsInfoVO = bookServiceUtil.getUserCredits(user);
			Integer concurrenyLimitForVbid = this.getconcurrencyLimitForVbid(vbid, bridge);
			List<Integer> keyIds = keyDAO.getKeyIdsForBridge(bridge.getId());
			Integer booksInUseCount = bridgeUserBookAssignDAO.getInUseBookCountForConcurrency(keyIds, vbid,null);					
			Integer concurrentCredits = userCreditsInfoVO.getConcurrencyCredits();
			Integer concurrentCreditsUsed = userCreditsInfoVO.getConcurrencyUsed();

			if ((concurrentCredits != null && (concurrentCredits == -1 || concurrentCreditsUsed < concurrentCredits))) {
				concurrentLicensesInfoVO.setUrl(com.vst.bridge.StringUtils
						.getFormatedString(ApplicationConstants.BOOK_LICENSE_CONCURRENT, vbid));
				concurrentLicensesInfoVO.setState(ApplicationConstants.BOOK_LICENSE_STATE_CREDIT);
				if (concurrenyLimitForVbid != null && booksInUseCount >= concurrenyLimitForVbid) {
					concurrentLicensesInfoVO.setIsAvailable(Boolean.FALSE);
				}
			}
		}
		return concurrentLicensesInfoVO;
	}

	@Override
	public Integer getconcurrencyLimitForVbid(String vbid, Bridge bridge) {
		Integer bookLimit = null;
		if (bridge.getConcurrencyEnabled()) {
			BridgeBookCache bookCache = bridgeBookCacheDAO.getBookForVbid(bridge.getId(), vbid);
			if (bookCache != null) {
				Integer bookCacheLimit = bookCache.getConcurrencyLimit();
				Integer bridgeConcurrencyLimit = bridge.getConcurrencyLimit();
				if (bookCacheLimit != null && bookCacheLimit != 0) {
					return bookCacheLimit;
				} else if (bookCacheLimit == null && bridgeConcurrencyLimit != null && bridgeConcurrencyLimit != 0) {
					return bridgeConcurrencyLimit;
				}
			}
		}
		return bookLimit;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse returnBook(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, VstException, ConnectApiException, ParseException {
		RestResponse response = bookServiceUtil.getDefaultRestResponse();
		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		if (!bridge.getConcurrencyEnabled()) {
			throw new BridgeException(ApplicationCode.CONCURRENCY_NOT_ENABLED);
		}
		BridgeUser user = bridgeUserDAO.get(sessionStatusVO.getAdminId());
		BridgeUserBookAssign bookUser = bridgeUserBookAssignDAO.getAssignedBookToUser(user.getId(), vbid,
				ApplicationConstants.BOOK_KEY_USED_TYPE_CONCURRENT);
		if (bookUser != null) {
			if(bookUser.getKeyBatch()!=null){
				KeyBatch keyBatch= bookUser.getKeyBatch();
				if(keyBatch.getIsReturn()!=null && !keyBatch.getIsReturn()){
					throw new BridgeException(ApplicationCode.RETURN_BOOK_FAILED);
				}
			}
			String refundCode = bookUser.getBookshelfRedeemCode();
			Boolean isRefundSuccess = StoriaUtils.refundCode(refundCode, bridge.getApiKey());
			if (isRefundSuccess) {
				SimpleDateFormat dateFormatGmt = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
				dateFormatGmt.setTimeZone(TimeZone.getTimeZone("GMT"));
				// Local time zone
				SimpleDateFormat dateFormatLocal = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
				// Time in GMT
				bookUser.setReturnDate(dateFormatLocal.parse(dateFormatGmt.format(new Date())));
				// bookUser.setDeleted(Boolean.TRUE);
				bridgeUserBookAssignDAO.saveOrUpdate(bookUser);
			} else {
				throw new BridgeException(ApplicationCode.RETURN_BOOK_FAILED);
			}
		} else {
			throw new BridgeException(ApplicationCode.BOOK_NOT_FOUND);
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse redeemConcurrencyVbid(SessionStatusVO sessionStatusVO, String vbid, Integer entitlementId, String code)
			throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException {
		RestResponse response = bookServiceUtil.getDefaultRestResponse();
		
		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		BridgeUser user = bridgeUserDAO.get(sessionStatusVO.getAdminId());
		String apiKey = bridge.getApiKey();
		ConcurrentBookLicenseInfoVO licenseInfoVO = checkConcurrentEntitlementFunctionalityForVbidById(vbid, user, bridge,entitlementId, null);		
		if (null != licenseInfoVO && null != licenseInfoVO.getState()
				&& StringUtils.equals(licenseInfoVO.getState(), ApplicationConstants.BOOK_LICENSE_STATE_CREDIT)) {
			if (!licenseInfoVO.getIsAvailable()) {
				throw new BridgeException(ApplicationCode.CONCURRENCY_LIMIT_REACHED);
			}
			List<BridgeUserKey> userKeys = bridgeUserKeyDAO.getListOfKeysAssigedForUser(user.getId());
			BridgeUserKey userKey= checkForConcurrentEntitlementIdKey(userKeys,entitlementId);
			if(userKey==null){
				throw new BridgeException(ApplicationCode.KEY_CODE_NOT_FOUND);
			}
			KeyBatch keyBatch = keyBatchDAO.get(entitlementId);
			if(keyBatch==null){
				throw new BridgeException(ApplicationCode.KEY_BATCH_NOT_FOUND);
			}
			
			AccessCodeResponseVO accessCodeResponseVO = StoriaUtils.giveAccess(apiKey, user.getAccessToken(), 
					vbid, bookEntitlementService.populateRedeemBookVOFromKeyBatchEntitlement(keyBatch),bridge);
		
			BridgeUserBookAssign userBook = new BridgeUserBookAssign();
			userBook.setKeyAssigned(userKey);
			userBook.setLastAccess(new Date());
			userBook.setBookshelfRedeemCode(accessCodeResponseVO.getRedeemCode());
			userBook.setExpires(accessCodeResponseVO.getExpires());
			userBook.setVbid(vbid);
			userBook.setUsedType(ApplicationConstants.BOOK_KEY_USED_TYPE_CONCURRENT);
			userBook.setKeyBatch(keyBatch);
			bridgeUserBookAssignDAO.saveOrUpdate(userBook);
			ApplicationAction action= bookServiceUtil.getActionType(licenseInfoVO.getType());
			bookServiceUtil.createBridgeLog(user.getId(), bridge,action , vbid);
		}
		return response;
	}
	
	private ConcurrentBookLicenseInfoVO checkConcurrentEntitlementFunctionalityForVbidById(String vbid, BridgeUser user, Bridge bridge,Integer concEntitlementId,String state){
		UserCreditsInfoVO userCreditsInfoVO = bookServiceUtil.getUserCredits(user);
		ConcurrentBookLicenseInfoVO licensesInfoVO=null;
		List<UserEntitlementVO> userEntitlementVOList=userCreditsInfoVO.getConcurrencyEntitlements();
		for(UserEntitlementVO userEntitlementVO:userEntitlementVOList){
			if(state!=null && state.equals(ApplicationConstants.BOOK_LICENSE_STATE_EXPIRED) && ApplicationConstants.REDEEM_TYPE_COMP.equalsIgnoreCase(userEntitlementVO.getType()))
				continue;
			if(concEntitlementId!=null && concEntitlementId.equals(userEntitlementVO.getId())){
				licensesInfoVO = new ConcurrentBookLicenseInfoVO();			
				licensesInfoVO.setId(userEntitlementVO.getId());
				licensesInfoVO.setName(userEntitlementVO.getEntitlementName());
				licensesInfoVO.setType(userEntitlementVO.getType());
				Integer concurrenyLimitForVbid = getconcurrencyLimitForVbid(vbid, bridge);
				List<Integer> keyIds = keyDAO.getKeyIdsForBridge(bridge.getId());
				Integer booksInUseCount = bridgeUserBookAssignDAO.getInUseBookCountForConcurrency(keyIds, vbid,null);
				Integer credits = userEntitlementVO.getCredits();
				Integer usedCredits = userEntitlementVO.getUsed();
				if ((credits != null && (credits == -1 || usedCredits < credits))) {
					licensesInfoVO.setUrl(com.vst.bridge.StringUtils.getFormatedString(ApplicationConstants.BOOK_LICENSE_ENTITLEMENT, vbid,userEntitlementVO.getId().toString()));
					licensesInfoVO.setState(ApplicationConstants.BOOK_LICENSE_STATE_CREDIT);
					if (concurrenyLimitForVbid != null && booksInUseCount >= concurrenyLimitForVbid) {
						licensesInfoVO.setIsAvailable(Boolean.FALSE);
					}
				}
			}			
		}

		return licensesInfoVO;
		
	}
	private BridgeUserKey checkForConcurrentEntitlementIdKey(List<BridgeUserKey> userKeys, Integer concEntitlementId) {
		for(BridgeUserKey buk:userKeys){
			Keys key=buk.getKey();
			KeyBatch keyBatch=key.getKeyBatch();
			//List<KeyBatchEntitlement> keyBatchEntitlementList=keyBatchEntitlementDAO.getAllEntitlementsForKeyBatch(keyBatch.getId());
			//for(KeyBatchEntitlement kbe :keyBatchEntitlementList){
				if(keyBatch.getId().equals(concEntitlementId))
					return buk;
			}
		//}
		return null;
	}

}
