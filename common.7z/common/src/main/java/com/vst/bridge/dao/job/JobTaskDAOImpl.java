package com.vst.bridge.dao.job;

import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.job.JobTask;

@Repository("jobTaskDAO")
public class JobTaskDAOImpl extends GenericDAO<JobTask, Integer> implements IJobTaskDAO{
	
	public JobTaskDAOImpl() {
		super(JobTask.class);
	}

}
