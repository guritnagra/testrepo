package com.vst.bridge.rest.response;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

public class PdfResponse extends RestResponse
{
	private byte[]  pdf;
	
	public static PdfResponse instance(Response.Status code, byte[] pdf)
	{
		return new PdfResponse(code,pdf);
	}
	public static PdfResponse instance(Response.Status code, byte[] pdf, String filename)
	{
		return new PdfResponse(code,pdf, filename);
	}
	
	
	private PdfResponse(Response.Status code, byte[] pdf)
	{
		this.code = code;
		this.pdf = pdf;
	}
	private PdfResponse(Response.Status code, byte[] pdf, String filename)
	{
		this.code = code;
		this.pdf = pdf;
		this.filename = filename;
	}

	public Response build(HttpServletRequest hsr) 
	{
		ResponseBuilder rb = Response.status(this.getCode()).entity(pdf);//this.getText());
		
		for(NewCookie cookie: this.cookies) {
			rb.cookie(cookie);
		}
		
		rb.header("Content-Type", "application/pdf");
		
	    if(filename!=null)
	    {
	    	
			rb.header("Content-Disposition","inline; filename=\"" + filename + "\"");
	    }
		
		return rb.build();
	}

}
