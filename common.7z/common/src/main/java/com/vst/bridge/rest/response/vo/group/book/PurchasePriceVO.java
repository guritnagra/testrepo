package com.vst.bridge.rest.response.vo.group.book;

public class PurchasePriceVO {

	private String purchaseName;
	private String price;
	public String getPurchaseName() {
		return purchaseName;
	}
	public void setPurchaseName(String purchaseName) {
		this.purchaseName = purchaseName;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
}
