package com.vst.bridge.dao.bridge.book;

import java.util.Collection;
import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeBookCacheDAO extends IGenericDAO<BridgeBookCache, Integer>{
	Integer getCacheBookCount(Integer bridgeId, BridgePaginationVo paginationVo, List<String> vbids, Boolean isUser,
			String category) throws BridgeException;
	List<BridgeBookCache> getCacheBooks(Integer bridgeId, Integer startIndex, BridgePaginationVo paginationVo,
			List<String> vbids, Boolean isUser, String category) throws BridgeException;
	List<BridgeBookCache> getCacheBooks(final Integer bridgeId)throws BridgeException;
	List<String> getCacheBookVbids(final Integer bridgeId)throws BridgeException;
	BridgeBookCache getBookForVbid(Integer bridgeId, String vbid)throws BridgeException;
	BridgeBookCache getCacheBooksForVbid(String vbidId)throws BridgeException;
	List<BridgeBookCache> getCacheBooks(Integer bridgeId, BridgePaginationVo paginationVo, List<String> vbids, Boolean isUser, String category) throws BridgeException;
	List<BridgeBookCache> getCacheBooksWithConcurrencyLimit(Integer bridgeId);
	BridgeBookCache getCacheBooksForEbookIsbn(Integer bridgeId, String vbid) throws BridgeException;
	int deleteAllCacheBooksForBridge(final Integer bridgeId);
	List<Integer> getCacheBookIds(final Integer bridgeId)throws BridgeException;
	BridgeBookCache checkForExistingBookAndReturn(Integer bridgeId, String vbid)
			throws BridgeException;
	List<BridgeBookCache> getCacheBooksForVbidList(Integer bridgeId, Collection<String> vbids);
	List<BridgeBookCache> getAllCacheBooks(Integer bridgeId, boolean deleted);
	List<BridgeBookCache> getCacheBooksNotInVbidList(Integer bridgeId, Collection<String> vbidCollection);
	List<BridgeBookCache> getAncillaryCacheBooksForVbidList(Integer bridgeId, Collection<String> vbids);
}
