package com.vst.bridge.dao.bridge.allowance;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.allowance.BridgeAllowanceNotification;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeAllowanceNotificationDAO extends IGenericDAO<BridgeAllowanceNotification, Integer>{

	List<BridgeAllowanceNotification> getLastBridgeAllowanceNotifications(final Integer bridgeId)throws BridgeException;
}
