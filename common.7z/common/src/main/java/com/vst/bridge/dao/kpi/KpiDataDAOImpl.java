package com.vst.bridge.dao.kpi;

import java.util.List;

import org.hibernate.CacheMode;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.kpi.KpiData;
import com.vst.bridge.util.exception.BridgeException;

@Repository("kpiDataDAO")
public class KpiDataDAOImpl extends GenericDAO<KpiData, Integer> implements IKpiDAO {

	public KpiDataDAOImpl() {
		super(KpiData.class);
	}

	@Override
	public KpiData getKpiData() throws BridgeException {
		List<?> kpiList = getCriteria().setCacheable(Boolean.FALSE).setCacheMode(CacheMode.IGNORE).setMaxResults(1).list();
		return (KpiData) kpiList.get(0);
	}

}
