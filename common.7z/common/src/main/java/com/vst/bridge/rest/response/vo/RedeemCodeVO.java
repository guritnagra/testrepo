package com.vst.bridge.rest.response.vo;

import java.util.Date;

public class RedeemCodeVO {
	
	private String code;
	private Date expireDate;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Date getExpireDate() {
		return expireDate;
	}
	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}

}
