package com.vst.bridge.dao.admin.session;

import java.util.Date;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.session.AdminSession;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminSessionDAO extends IGenericDAO<AdminSession, Integer>{
	AdminSession getForSessionId(final String sessionId,Boolean updateLastAcess,Date lastAcessdate)throws BridgeException;
}
