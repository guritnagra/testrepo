package com.vst.bridge.service.admin;

import java.io.IOException;
import java.net.MalformedURLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.UriInfo;

import org.springframework.web.multipart.MultipartFile;
import org.supercsv.io.ICsvBeanReader;

import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.roster.CSVResponseWrapperVO;
import com.vst.bridge.rest.response.vo.roster.UploadRosterVO;
import com.vst.bridge.util.csv.CSVFileType;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.exception.InvalidActionException;

public interface IAdminUserRosteringService {
	CSVResponseWrapperVO uploadCSVRoster(SessionStatusVO sessionStatusVO, HttpServletRequest httpRequest, UriInfo uriInfo, Integer bridgeId, MultipartFile uploadFile) throws BridgeException,MalformedURLException, IOException, InvalidActionException;
	void processRosteringCSV(SessionStatusVO sessionStatusVO, UploadRosterVO uploadRosterVO, ICsvBeanReader beanReader, String[] header)
			throws BridgeException, MalformedURLException, IOException, InvalidActionException, Exception;
	RestResponse getRosterHistoryForBridgeId(SessionStatusVO sessionStatusVO, Integer id,
			HttpServletRequest httpRequest, UriInfo uriInfo)throws BridgeException;
	void getRosterFile(SessionStatusVO sessionStatusVO, Object param, HttpServletRequest httpRequest,
			HttpServletResponse httpServletResponse, UriInfo uriInfo) throws BridgeException, MalformedURLException, IOException;
	RestResponse uploadCSVRosterTemplate(HttpServletRequest httpRequest, UriInfo uriInfo, MultipartFile uploadFile, CSVFileType fileType) throws IOException, BridgeException;
	void downloadCSVRosterTemplate(CSVFileType fileType, HttpServletResponse httpServletResponse) throws IOException, BridgeException;
	
	RestResponse processCSVForGroupAssetsMapping(SessionStatusVO sessionStatusVO, HttpServletRequest httpRequest,
			UriInfo uriInfo, Integer bridgeId, MultipartFile uploadFile) throws IOException, BridgeException;
}
