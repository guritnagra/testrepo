package com.vst.bridge.rest.response.vo;

import java.util.List;

public class GroupCompaniesVO {
	private Integer groupId;
	private String groupName;
	private List<AdminCompanyVO> companies;
	public Integer getGroupId() {
		return groupId;
	}
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public List<AdminCompanyVO> getCompanies() {
		return companies;
	}
	public void setCompanies(List<AdminCompanyVO> companies) {
		this.companies = companies;
	}
}
