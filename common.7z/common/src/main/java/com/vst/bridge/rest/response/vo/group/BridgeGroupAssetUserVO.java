package com.vst.bridge.rest.response.vo.group;

import java.util.List;

import com.vst.bridge.annotation.custom.InputRequired;

public class BridgeGroupAssetUserVO {


	private Boolean allUsers;
	
	private Boolean allAssets;
	
	private Boolean allGroups;
	
	private List<Integer> groups;
	
	private SearchParamVO searchParam;
	
	@InputRequired(required=false)
	private List<Integer> users;
	
	@InputRequired(required=false)
	private List<String> books;

	public List<Integer> getGroups() {
		return groups;
	}

	public void setGroups(List<Integer> groups) {
		this.groups = groups;
	}

	public List<Integer> getUsers() {
		return users;
	}

	public void setUsers(List<Integer> users) {
		this.users = users;
	}

	public List<String> getBooks() {
		return books;
	}

	public void setBooks(List<String> books) {
		this.books = books;
	}

	public Boolean getAllUsers() {
		return allUsers;
	}

	public void setAllUsers(Boolean allUsers) {
		this.allUsers = allUsers;
	}

	public Boolean getAllAssets() {
		return allAssets;
	}

	public void setAllAssets(Boolean allAssets) {
		this.allAssets = allAssets;
	}

	public SearchParamVO getSearchParam() {
		return searchParam;
	}

	public void setSearchParam(SearchParamVO searchParam) {
		this.searchParam = searchParam;
	}
}
