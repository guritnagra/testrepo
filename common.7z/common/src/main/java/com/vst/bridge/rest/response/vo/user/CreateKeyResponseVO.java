package com.vst.bridge.rest.response.vo.user;

public class CreateKeyResponseVO {
	private long expire;
	private Boolean expired;
	private TotalUsedDetailsVO fullCredits;
	private TotalUsedDetailsVO trialCredits;
	private TotalUsedDetailsVO retalCredits;
	public long getExpire() {
		return expire;
	}
	public void setExpire(long expire) {
		this.expire = expire;
	}
	public Boolean getExpired() {
		return expired;
	}
	public void setExpired(Boolean expired) {
		this.expired = expired;
	}
	public TotalUsedDetailsVO getFullCredits() {
		return fullCredits;
	}
	public void setFullCredits(TotalUsedDetailsVO fullCredits) {
		this.fullCredits = fullCredits;
	}
	public TotalUsedDetailsVO getTrialCredits() {
		return trialCredits;
	}
	public void setTrialCredits(TotalUsedDetailsVO trialCredits) {
		this.trialCredits = trialCredits;
	}
	public TotalUsedDetailsVO getRetalCredits() {
		return retalCredits;
	}
	public void setRetalCredits(TotalUsedDetailsVO retalCredits) {
		this.retalCredits = retalCredits;
	}
}
