package com.vst.bridge.dao.bridge.group;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.group.BridgeGroup;
import com.vst.bridge.entity.group.GroupUser;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.rest.response.vo.bridge.user.BridgeUserResponseVO;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeGroupUserDAO extends IGenericDAO<GroupUser, Integer>{	
	List<GroupUser> getAllUsersForGroup(Integer groupId);

	List<BridgeUserResponseVO> getUsersForGroup(Integer groupId, Integer startIndex, PaginationVO paginationVo)
			throws BridgeException;

	List<GroupUser> getAllUsersForGroup(Integer groupId, Boolean isSelected)  throws BridgeException;

	Integer getUsersCountForGroup(Integer groupId, PaginationVO paginationVo) throws BridgeException;

    GroupUser getGroupUser(Integer groupId,Integer userId, Boolean isDeleted, Boolean isExpired, Boolean removeFutureActiveGroups) throws BridgeException;

	List<Integer> getGroupUsersForBridge(List<Integer> groupIds)throws BridgeException;

	List<BridgeGroup> getGroupsForUser(Integer userId, Boolean isDeleted, Boolean isExpired, Boolean removeFutureActiveGroups) throws BridgeException;

	List<Integer> getGroupIdsForUser(Integer bridgeId,Integer userId,Boolean isDeleted, Boolean isExpired, Boolean removeFutureActiveGroups)throws BridgeException;

	List<IdValueVO> getGroupsForUserId(Integer bridgeId, Integer userId) throws BridgeException;
	
	List<GroupUser> getUsersForGroup(Integer groupId,List<Integer> userIds)throws BridgeException;
	
	List<GroupUser> getBridgeGroupUsers(Integer bridgeId,List<Integer> userIds) throws BridgeException;

	Integer deleteGroupUsersForGroup(Integer groupId) throws BridgeException;

	GroupUser getGroupUser(Integer groupId, Integer userId) throws BridgeException;

	Integer deleteGroupUsersForUser(Integer userId) throws BridgeException;

	Integer deleteAllGroupUsersForBridge(Bridge bridge) throws BridgeException;

}
