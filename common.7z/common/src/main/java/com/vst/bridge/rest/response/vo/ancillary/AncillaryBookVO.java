package com.vst.bridge.rest.response.vo.ancillary;

import java.util.Date;

import com.vst.bridge.entity.admin.ancillary.Ancillary;
import com.vst.bridge.entity.admin.user.AdminUser;

public class AncillaryBookVO {
	private Integer ancillaryId;
	private Integer fileSize;
	private Date dateUploaded;
	private String uploader;
	
	public AncillaryBookVO(){
		
	}
	
	public AncillaryBookVO(Ancillary ancillary){
		if(null !=ancillary){
			this.ancillaryId=ancillary.getId();
			this.fileSize=ancillary.getFileSize();
			this.dateUploaded=ancillary.getCreatedAt();
			this.uploader=getUploaderName(ancillary);
		}	
	}

	private String getUploaderName(Ancillary ancillary) {
		AdminUser adminUser = ancillary.getUpdatedBy();	
		return null != adminUser ? new StringBuilder().append(adminUser.getFirstName()).append(" ").append(adminUser.getLastName()).toString() : "";
	}

	public Integer getAncillaryId() {
		return ancillaryId;
	}

	public void setAncillaryId(Integer ancillaryId) {
		this.ancillaryId = ancillaryId;
	}

	public Integer getFileSize() {
		return fileSize;
	}

	public void setFileSize(Integer fileSize) {
		this.fileSize = fileSize;
	}

	public Date getDateUploaded() {
		return dateUploaded;
	}

	public void setDateUploaded(Date dateUploaded) {
		this.dateUploaded = dateUploaded;
	}

	public String getUploader() {
		return uploader;
	}

	public void setUploader(String uploader) {
		this.uploader = uploader;
	}
	
	
}
