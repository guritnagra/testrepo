package com.vst.bridge.rest.response.vo.user;

import java.util.List;

public class UserCreditsInfoVO {
	private Integer trialCredits;
	private Integer trailUsed;
	
	private Integer fullCredits;
	private Integer fullUsed;
	
	private Integer rentalCredits;
	private Integer rentalUsed;
	
	private Integer concurrencyCredits;
	private Integer concurrencyUsed;
	
	private List<UserEntitlementVO> entitlements;
	
	private List<UserEntitlementVO> concurrencyEntitlements;
	
	public Integer getTrialCredits() {
		return trialCredits;
	}
	public void setTrialCredits(Integer trialCredits) {
		this.trialCredits = trialCredits;
	}

	public Integer getTrailUsed() {
		return trailUsed;
	}
	public void setTrailUsed(Integer trailUsed) {
		this.trailUsed = trailUsed;
	}

	public Integer getRentalCredits() {
		return rentalCredits;
	}
	public void setRentalCredits(Integer rentalCredits) {
		this.rentalCredits = rentalCredits;
	}
	public Integer getRentalUsed() {
		return rentalUsed;
	}
	public void setRentalUsed(Integer rentalUsed) {
		this.rentalUsed = rentalUsed;
	}
	public Integer getFullCredits() {
		return fullCredits;
	}
	public void setFullCredits(Integer fullCredits) {
		this.fullCredits = fullCredits;
	}
	public Integer getFullUsed() {
		return fullUsed;
	}
	public void setFullUsed(Integer fullUsed) {
		this.fullUsed = fullUsed;
	}
	public Integer getConcurrencyCredits() {
		return concurrencyCredits;
	}
	public void setConcurrencyCredits(Integer concurrencyCredits) {
		this.concurrencyCredits = concurrencyCredits;
	}
	public Integer getConcurrencyUsed() {
		return concurrencyUsed;
	}
	public void setConcurrencyUsed(Integer concurrencyUsed) {
		this.concurrencyUsed = concurrencyUsed;
	}
	public List<UserEntitlementVO> getEntitlements() {
		return entitlements;
	}
	public void setEntitlements(List<UserEntitlementVO> entitlements) {
		this.entitlements = entitlements;
	}
	public List<UserEntitlementVO> getConcurrencyEntitlements() {
		return concurrencyEntitlements;
	}
	public void setConcurrencyEntitlements(List<UserEntitlementVO> concurrencyEntitlements) {
		this.concurrencyEntitlements = concurrencyEntitlements;
	}
	
	
}
