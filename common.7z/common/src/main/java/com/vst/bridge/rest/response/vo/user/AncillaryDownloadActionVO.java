package com.vst.bridge.rest.response.vo.user;

public class AncillaryDownloadActionVO extends BaseLicenseInfoVO{
}
