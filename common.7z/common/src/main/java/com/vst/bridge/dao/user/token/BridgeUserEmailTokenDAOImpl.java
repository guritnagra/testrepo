package com.vst.bridge.dao.user.token;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.user.token.BridgeUserEmailToken;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeUserEmailTokenDAO")
public class BridgeUserEmailTokenDAOImpl extends GenericDAO<BridgeUserEmailToken, Integer> implements IBridgeUserEmailTokenDAO{

	public BridgeUserEmailTokenDAOImpl() {
		super(BridgeUserEmailToken.class);
	}

	@Override
	public List<BridgeUserEmailToken> getList(Integer bridgeId, String email,Boolean used) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.eq("used", used));
		criteria.add(Restrictions.eq("email", email));
		return executeCriteira(criteria);
	}

	@Override
	public BridgeUserEmailToken getForToken(String token) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.like("token", token));		
		List<BridgeUserEmailToken> result = executeCriteira(criteria);
		return null!= result && result.size() > 0? result.get(0) : null;
	}
	
	
	
	
}
