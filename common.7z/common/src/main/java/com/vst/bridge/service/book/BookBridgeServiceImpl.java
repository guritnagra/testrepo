package com.vst.bridge.service.book;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookCacheDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookPricingDAO;
import com.vst.bridge.dao.bridge.purchase.IBridgePurchaseDAO;
import com.vst.bridge.entity.admin.ancillary.Ancillary;
import com.vst.bridge.entity.admin.purchase.BridgePurchase;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.entity.bridge.books.BridgeBookPricing;
import com.vst.bridge.entity.bridge.books.BridgeBooks;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.books.BridgeBookVO;
import com.vst.bridge.rest.response.vo.books.SelectAllBooksMetadataVO;
import com.vst.bridge.rest.response.vo.bridge.BridgeBooksVO;
import com.vst.bridge.rest.response.vo.group.book.PurchasePriceVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.service.admin.AdminUserServiceUtil;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.constant.PermissionAction;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ApiKeys;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;

@Service("bookBridgeService")
public class BookBridgeServiceImpl implements IBookBridgeService {
	@Autowired
	private IBridgeDAO bridgeDAO;

	@Autowired
	private IBridgeBookCacheDAO bridgeBookCacheDAO;

	@Autowired
	private IBridgeBookPricingDAO bridgeBookPricingDAO;

	@Autowired
	private IBridgePurchaseDAO bridgePurchaseDAO;

	@Autowired
	private BookServiceUtil bookServiceUtil;

	@Autowired
	private IBridgeBookDAO bridgeBooksDAO;

	@Autowired
	private BookRefreshWorker bookRefreshWorker;

	@Autowired
	private IAdminUserDAO adminUserDAO;

	private ExecutorService jobQueue = Executors.newFixedThreadPool(2);
	
	@Autowired
	private AdminUserServiceUtil adminUserServiceUtil;

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse updateBridgesBooks(Integer bridgeId, Boolean selectAllBooks, List<BridgeBookVO> bridgeBooksVO,
			HttpServletRequest httpRequest) throws BridgeException, ParseException, IOException {
		RestResponse response = bookServiceUtil.getDefaultRestResponse();

		Bridge bridge = bridgeDAO.get(bridgeId);
		if (bridge == null || bridge.getDeleted()) {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		if (null != selectAllBooks && selectAllBooks) {
			bridge.setShowAllBooks(Boolean.TRUE);
			bridgeDAO.saveOrUpdate(bridge);
		} else {
			if (null != bridgeBooksVO && bridgeBooksVO.size() > 0) {
				List<BridgeBooks> bridgeBooks = bridgeBooksDAO.getAllBooksForBridge(bridgeId);
				Iterator<BridgeBookVO> bookVOIterator = bridgeBooksVO.iterator();
				while (bookVOIterator.hasNext()) {
					BridgeBookVO bookVo = bookVOIterator.next();
					if (null != bridgeBooks && bridgeBooks.size() > 0) {
						Iterator<BridgeBooks> bookIterator = bridgeBooks.iterator();
						while (bookIterator.hasNext()) {
							BridgeBooks book = bookIterator.next();
							if (StringUtils.equals(bookVo.getVbid(), book.getBookVbid())) {
								book.setSeleted(bookVo.getSelected());
								book.setLastModifiedDate(new Date());
								bookVOIterator.remove();
							}
						}
					}
				}
				bridgeBooksDAO.saveOrUpdateAll(bridgeBooks);
				if (bridgeBooksVO.size() > 0) {
					List<BridgeBooks> newEntries = new ArrayList<BridgeBooks>();
					for (BridgeBookVO newBridgeBooks : bridgeBooksVO) {
						BridgeBooks newBook = new BridgeBooks();
						newBook.setBridge(bridgeDAO.load(bridgeId));
						newBook.setBookVbid(newBridgeBooks.getVbid());
						newBook.setLastModifiedDate(new Date());
						newBook.setSeleted(newBridgeBooks.getSelected());
						newEntries.add(newBook);
					}
					bridgeBooksDAO.saveOrUpdateAll(newEntries);
				}
			}

			bridge.setShowAllBooks(Boolean.FALSE);
			bridgeDAO.saveOrUpdate(bridge);
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false)
	public void refreshBookCache(final Integer bridgeId, final String bridgeAPIKey)
			throws BridgeException, ConnectApiException, ConnectApiXmlException, ConnectApiHttpException {

		if (null != bridgeId && bridgeId > 0) {
			final Bridge bridge = checkAndReturnBridge(bridgeId);
			String apiKey = bridge.getApiKey();
			apiKey = apiKey != null ? apiKey : bridgeAPIKey;
			if (apiKey == null) {
				throw new BridgeException(ApplicationCode.INVALID_BRIDGE_KEY);
			}
			final ApiKeys key = new ApiKeys(ApplicationConstants.getApiMode(), apiKey, "unused:lti_key",
					"unused:lti_secret");
			jobQueue.execute(new Runnable() {
				@Override
				public void run() {
					bookRefreshWorker.refreshBridges(bridge, key);
				}
			});

		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse getBooksForBridge(SessionStatusVO sessionStatusVO, BridgePaginationVo bridgePaginationVo,
			String category, Boolean isGrouped, HttpServletRequest request, UriInfo uriInfo) throws BridgeException,
			ParseException, IOException, ConnectApiException, ConnectApiXmlException, ConnectApiHttpException {

		RestResponse response = bookServiceUtil.getDefaultRestResponse();
		AdminUser adminUser = adminUserDAO.get(sessionStatusVO.getAdminId());

		Integer bridgeId = bridgePaginationVo.getBridgeId();
		if (null != bridgeId && bridgeId > 0) {
			Bridge bridge = bridgeDAO.get(bridgeId);
			if (bridge == null) {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}

			this.validateAndRearangePaginationVO(bridgePaginationVo);

			List<BridgeBooksVO> books = null;
			if (bridgePaginationVo.getRefreshCatche()) {
				adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_MANAGE, adminUser);
				books = this.getBooksFromConnectAPIAndUpdateCache(bridgeId, bridgePaginationVo, isGrouped, category);
			} else {
				books = this.getBooksFromBridgeCache(bridgeId, bridgePaginationVo, isGrouped, category);
			}

			Integer totalRecords = bridgePaginationVo.getCount();
			Integer totalPages = this.calculateTotalPageCount(totalRecords, bridgePaginationVo.getLimit());
			Integer offset = this.calculateOffsetValue(bridgePaginationVo.getPage(), bridgePaginationVo.getLimit());
			SelectAllBooksMetadataVO metadata = new SelectAllBooksMetadataVO(bridge.getShowAllBooks(),
					bridgePaginationVo.getPage(), bridgePaginationVo.getLimit(), totalPages,
					bridgePaginationVo.getOrderBy(), bridgePaginationVo.getOrder(), bridgePaginationVo.getSearch(),
					totalRecords, offset);
			response.setMetadata(metadata);
			response.setData(books);
		}
		return response;
	}

	private Integer calculateOffsetValue(Integer page, Integer limit) {
		if (page != null) {
			return (page - 1) * limit;
		}
		return 0;
	}

	@SuppressWarnings("deprecation")
	private void validateAndRearangePaginationVO(BridgePaginationVo bridgePaginationVo) {

		Integer page = bridgePaginationVo.getPage();
		if (null == page || page == 0) {
			bridgePaginationVo.setPage(ApplicationConstants.DEFAULT_GET_BOOK_PAGE_VALUE);
		}

		Integer limit = bridgePaginationVo.getLimit();
		if (null == limit || limit == 0) {
			bridgePaginationVo.setLimit(ApplicationConstants.DEFAULT_GET_BOOK_LIMIT_VALUE);
		}

		String orderby = bridgePaginationVo.getOrderBy();
		if (!StringUtils.isEmpty(orderby) && !ApplicationConstants.validBookOrderByValues.contains(orderby)) {
			throw new BridgeException(ApplicationCode.INVALID_ORDERBY_FIELD);
		}
		if (null == orderby || StringUtils.isEmpty(orderby)) {
			bridgePaginationVo.setOrderBy(ApplicationConstants.DEFAULT_GET_BOOK_ORDER_BY_VALUE);
		}

		String order = bridgePaginationVo.getOrder();
		if (null == order || StringUtils.isEmpty(order)) {
			bridgePaginationVo.setOrder(ApplicationConstants.DEFAULT_GET_BOOK_ORDER_VALUE);
		}
	}

	private List<BridgeBooksVO> getBooksFromBridgeCache(Integer bridgeId, BridgePaginationVo bridgePaginationVo,
			Boolean isGrouped, String category) {
		List<BridgeBookCache> cacheBooks = bridgeBookCacheDAO.getCacheBooks(bridgeId, bridgePaginationVo, null,
				Boolean.FALSE, category);
		List<BridgeBooksVO> books = bookServiceUtil.populateBridgeBooksVOFromConnectBook(cacheBooks,
				bridgeDAO.get(bridgeId), bridgePaginationVo, isGrouped);
		return books;
	}

	private List<BridgeBooksVO> getBooksFromConnectAPIAndUpdateCache(Integer bridgeId,
			BridgePaginationVo bridgePaginationVo, Boolean isGrouped, String category)
			throws ConnectApiException, ConnectApiXmlException, BridgeException, ConnectApiHttpException {
		this.refreshBookCache(bridgeId, null);
		List<BridgeBookCache> cacheBooks = bridgeBookCacheDAO.getCacheBooks(bridgeId, bridgePaginationVo, null,
				Boolean.FALSE, category);
		List<BridgeBooksVO> books = bookServiceUtil.populateBridgeBooksVOFromConnectBook(cacheBooks,
				bridgeDAO.get(bridgeId), bridgePaginationVo, isGrouped);
		return books;
	}

	/**
	 * This method is used to calculate total page count for report
	 * 
	 * @param totalCount
	 * @param totalRowsToFetch
	 * @return {@link String}
	 */
	private Integer calculateTotalPageCount(final int totalCount, final int totalRowsToFetch) {
		final Integer pageCount = (int) Math.ceil((double) totalCount / totalRowsToFetch);
		return pageCount;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getBookForVbid(Integer bridgeId, String vbid) throws BridgeException {
		RestResponse response = bookServiceUtil.getDefaultRestResponse();

		if (null != bridgeId && bridgeId > 0) {
			Bridge bridge = bridgeDAO.get(bridgeId);
			if (bridge == null) {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			BridgeBookCache bookCache = bridgeBookCacheDAO.getBookForVbid(bridgeId, vbid);
			if (bookCache == null) {
				throw new BridgeException(ApplicationCode.BOOK_NOT_FOUND);
			}
			List<BridgeBookCache> caches = new ArrayList<BridgeBookCache>();
			caches.add(bookCache);
			List<BridgeBooksVO> books = bookServiceUtil.populateBridgeBooksVOFromConnectBook(caches, bridge, null);
			response.setData(books);
		}
		return response;
	}

	@SuppressWarnings("unused")
	@Deprecated
	private void populatePricingforBook(BridgeBooksVO bridgeBooksVO, BridgeBookCache cacheBook, Bridge bridge) {
		List<BridgePurchase> bridgePurchaseList = bridgePurchaseDAO.getBridgePurchases(bridge.getId());
		List<PurchasePriceVO> PurchasePriceVOList = new ArrayList<>();
		BridgeBookPricing baseVbidPricing = bridgeBookPricingDAO.getBookPricingByRentalType(cacheBook.getId(), null);
		if (!bridgePurchaseList.isEmpty()) {
			for (BridgePurchase bridgePurchase : bridgePurchaseList) {
				PurchasePriceVO purchasePriceVO = new PurchasePriceVO();
				purchasePriceVO.setPurchaseName(bridgePurchase.getPurchaseName());
				if (bridgePurchase.getDisplayPricing() != null) {
					if (baseVbidPricing != null) {
						if (StringUtils.equals(ApplicationConstants.PUBLISHER_PRICE_TYPE,
								bridgePurchase.getDisplayPricing())) {
							purchasePriceVO.setPrice(baseVbidPricing.getPublisherPrice());
						} else if (StringUtils.equals(ApplicationConstants.DIGITAL_PRICE_TYPE,
								bridgePurchase.getDisplayPricing())) {
							purchasePriceVO.setPrice(baseVbidPricing.getDigitalPrice());
						} else {
							BridgeBookPricing rentalVbidPricing = bridgeBookPricingDAO
									.getBookPricingByRentalType(cacheBook.getId(), bridgePurchase.getDisplayPricing());
							if (rentalVbidPricing != null) {
								purchasePriceVO.setPrice(rentalVbidPricing.getDigitalPrice());
							}
						}
					}
				}
				PurchasePriceVOList.add(purchasePriceVO);
			}
			bridgeBooksVO.setPurchasePriceVO(PurchasePriceVOList);
		}
	}

	@Override
	public RestResponse updateBridgesBooks(Integer bridgeId, Boolean selectAllBooks, HttpServletRequest httpRequest)
			throws BridgeException, ParseException, IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@Transactional(isolation=Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse deleteAncillaryBookCache(Integer bridgeId, List<String> vbidList, String vbid,
			HttpServletRequest httpRequest, SessionStatusVO sessionStatusVO) {
		RestResponse response = bookServiceUtil.getDefaultRestResponse();
		checkAndReturnBridge(bridgeId);
		Integer adminId = sessionStatusVO.getAdminId();
		AdminUser admin = checkAndReturnAdmin(adminId);
		List<BridgeBookCache> bookCacheList = bridgeBookCacheDAO.getAncillaryCacheBooksForVbidList(bridgeId, vbidList);
		Ancillary ancillary = null;
		
		for (BridgeBookCache bookCache : bookCacheList) {
			if (null != (ancillary = bookCache.getAncillary())) {
				bookCache.setDeleted(Boolean.TRUE);
				bookCache.setLastModifiedDate(new Date());
				ancillary.setDeleted(Boolean.TRUE);
				ancillary.setDeletedAt(new Date());
				ancillary.setUpdatedAt(new Date());
				ancillary.setUpdatedBy(admin);
			}
		}
		bridgeBookCacheDAO.saveOrUpdateAll(bookCacheList);
		return response;
	}

	private AdminUser checkAndReturnAdmin(Integer adminId) {
		if(null == adminId){
			throw new BridgeException("Admin not found",ApplicationCode.INVALID_USER_REQUEST);
		}
		AdminUser admin = adminUserDAO.get(adminId);
		if(null == admin){
			throw new BridgeException("Admin not found",ApplicationCode.INVALID_USER_REQUEST);
		}
		return admin;
	}

	private Bridge checkAndReturnBridge(final Integer bridgeId) {
		Bridge bridge = null;

		if (null == bridgeId || null == (bridge = bridgeDAO.get(bridgeId))) {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		return bridge;
	}

}
