package com.vst.bridge.service.admin;

import java.io.IOException;
import java.net.MalformedURLException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.UriInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.supercsv.io.ICsvBeanReader;

import com.vst.bridge.VstException;
import com.vst.bridge.rest.input.vo.AdminUserProfileVO;
import com.vst.bridge.rest.input.vo.AllowanceRequestVO;
import com.vst.bridge.rest.input.vo.KeyBatchesVO;
import com.vst.bridge.rest.input.vo.KeyGenerateRequestVO;
import com.vst.bridge.rest.input.vo.LoginInfoVO;
import com.vst.bridge.rest.input.vo.PurchaseRequestVO;
import com.vst.bridge.rest.response.vo.AdminResetPasswordVO;
import com.vst.bridge.rest.response.vo.CompanyVO;
import com.vst.bridge.rest.response.vo.GroupVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.bridge.BridgeInfoWithFavoriteVO;
import com.vst.bridge.rest.response.vo.bridge.IntigrationVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.rest.response.vo.roster.CSVResponseWrapperVO;
import com.vst.bridge.rest.response.vo.roster.UploadRosterVO;
import com.vst.bridge.rest.response.vo.user.CreateKeysVO;
import com.vst.bridge.util.csv.CSVFileType;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.exception.InvalidActionException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;

@Service("adminUserService")
public class AdminUserServicesImpl implements IAdminUserServices{
	@Autowired
	IAdminUserPasswordService adminUserPasswordService;
	
	@Autowired
	IAdminUserGroupService adminUserGroupService;
	
	@Autowired
	IAdminUserAccessService adminUserAccessService;
	
	@Autowired
	IAdminUserEntityService adminUserEntityService;
	
	@Autowired
	IAdminUserBridgeService adminUserBridgeService;
	
	@Autowired
	IAdminUserBookService adminUserBookService;
	
	@Autowired
	IAdminUserCompaniesService adminUserCompaniesSerivce;
	
	@Autowired
	IAdminUserKeyService adminUserKeyService;
	
	@Autowired
	IAdminUserConnectivityService adminUserConnectivityService;
	
	@Autowired
	IAdminUserRosteringService adminUserRosteringService;
	
	@Autowired
	IAdminUserEntitlementService adminUserEntitlementService;

	@Override
	public RestResponse resetPassword(AdminResetPasswordVO adminResetPasswordVO, HttpServletRequest httpRequest,
			UriInfo uriInfo) throws BridgeException, ParseException, IOException {
		return adminUserPasswordService.resetPassword(adminResetPasswordVO, httpRequest, uriInfo);		
	}

	@Override
	public RestResponse updateResetPassword(LoginInfoVO loginInfoVO, String token, HttpServletRequest httpRequest,
			UriInfo uriInfo) throws BridgeException, ParseException, IOException {
		return adminUserPasswordService.updateResetPassword(loginInfoVO, token, httpRequest, uriInfo);		
	}

	@Override
	public RestResponse getGroups(SessionStatusVO sessionStatusVO, UriInfo uriInfo) throws BridgeException {
		return adminUserGroupService.getGroups(sessionStatusVO, uriInfo);
	}

	@Override
	public RestResponse createOrUpdateGroups(SessionStatusVO sessionStatusVO, GroupVO groupVO, Integer groupId,
			UriInfo uriInfo, HttpServletRequest httpRequest) throws BridgeException, ParseException, IOException {
		return adminUserGroupService.createOrUpdateGroups(sessionStatusVO, groupVO, groupId, uriInfo, httpRequest);
	}

	@Override
	public RestResponse getAllGroupsWithCompanies(SessionStatusVO sessionStatusVO) throws BridgeException {
		return adminUserGroupService.getAllGroupsWithCompanies(sessionStatusVO);
	}

	@Override
	public RestResponse login(LoginInfoVO loginInfoVO, HttpServletRequest request,
			HttpServletResponse httpServletResponse, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException, VstException {
		return adminUserAccessService.login(loginInfoVO, request, httpServletResponse, uriInfo);
	}

	@Override
	public RestResponse logout(String sessionId, HttpServletRequest request, UriInfo uriInfo) throws BridgeException {
		return adminUserAccessService.logout(sessionId, request, uriInfo);
	}

	@Override
	public RestResponse getAdminUserInfo(SessionStatusVO sessionStatusVO, Integer adminId,
			BridgePaginationVo bridgePaginationVo, Boolean getAllUsers, UriInfo uriInfo) throws BridgeException {
		return adminUserEntityService.getAdminUserInfo(sessionStatusVO, adminId, bridgePaginationVo, getAllUsers, uriInfo);
	}

	@Override
	public RestResponse createOrUpdateAdminUser(SessionStatusVO sessionStatusVO, AdminUserProfileVO adminUserProfileVO,
			Integer adminId, HttpServletRequest request, Boolean isNew, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException, VstException {
		return adminUserEntityService.createOrUpdateAdminUser(sessionStatusVO, adminUserProfileVO, adminId, request, isNew, uriInfo);
	}

	@Override
	public RestResponse getAdminUserInfoForId(Integer adminId, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException {
		return adminUserEntityService.getAdminUserInfoForId(adminId, uriInfo);
	}

	@Override
	public RestResponse deleteUser(SessionStatusVO sessionStatusVO, Integer id, HttpServletRequest httpRequest,
			UriInfo uriInfo) throws BridgeException {
		return adminUserEntityService.deleteUser(sessionStatusVO, id, httpRequest, uriInfo);
	}

	@Override
	public RestResponse uploadLogo(SessionStatusVO sessionStatusVO, Object param, HttpServletRequest httpRequest,
			UriInfo uriInfo) throws BridgeException, MalformedURLException, IOException {
		return adminUserBridgeService.uploadLogo(sessionStatusVO, param, httpRequest, uriInfo);
	}

	@Override
	public RestResponse getBridgesList(SessionStatusVO sessionStatusVO, BridgePaginationVo bridgePaginationVo,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		return adminUserBridgeService.getBridgesList(sessionStatusVO, bridgePaginationVo, httpRequest, uriInfo);
	}

	@Override
	public RestResponse getBridgeForId(SessionStatusVO sessionStatusVO, Integer bridgeid,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		return adminUserBridgeService.getBridgeForId(sessionStatusVO, bridgeid, httpRequest, uriInfo);
	}

	@Override
	public RestResponse getBridgeConfigForId(SessionStatusVO sessionStatusVO, Integer id,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		return adminUserBridgeService.getBridgeConfigForId(sessionStatusVO, id, httpRequest, uriInfo);
	}

	@Override
	public RestResponse getBridgeIntigrationForBridgeId(SessionStatusVO sessionStatusVO, Integer id,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		return adminUserBridgeService.getBridgeIntigrationForBridgeId(sessionStatusVO, id, httpRequest, uriInfo);
	}

	@Override
	public RestResponse updateBridgeIntigrationForBridgeId(SessionStatusVO sessionStatusVO, IntigrationVO intigrationVO,
			Integer id, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException {
		return adminUserBridgeService.updateBridgeIntigrationForBridgeId(sessionStatusVO, intigrationVO, id, httpRequest, uriInfo);
	}

	@Override
	public RestResponse deleteBridge(SessionStatusVO sessionStatusVO, Integer id, HttpServletRequest httpRequest,
			UriInfo uriInfo) throws BridgeException {
		return adminUserBridgeService.deleteBridge(sessionStatusVO, id, httpRequest, uriInfo);
	}

	@Override
	public RestResponse getBridgeTypes() throws BridgeException {
		return adminUserBridgeService.getBridgeTypes();
	}

	@Override
	public RestResponse createOrUpdateBridges(BridgeInfoWithFavoriteVO bridgeInfoWithFavoriteVO,
			SessionStatusVO sessionStatusVO, Integer id, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException, ConnectApiException, ConnectApiXmlException,
			ConnectApiHttpException, VstException {
		return adminUserBridgeService.createOrUpdateBridges(bridgeInfoWithFavoriteVO, sessionStatusVO, id, httpRequest, uriInfo);
	}

	@Override
	public RestResponse updateBridgeConfigForId(SessionStatusVO sessionStatusVO, Integer id,
			Map<String, String> requestMap, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException {
		return adminUserBridgeService.updateBridgeConfigForId(sessionStatusVO, id, requestMap, httpRequest, uriInfo);
	}

	@Override
	public RestResponse deleteBridgeUsers(SessionStatusVO sessionStatusVO, Integer bridgeId,
			List<Integer> usersToRemove, Boolean deleteAll,String search, Boolean isUngrouped) throws BridgeException, ParseException {
		return adminUserBridgeService.deleteBridgeUsers(sessionStatusVO, bridgeId, usersToRemove, deleteAll,search,isUngrouped);
	}

	@Override
	public RestResponse refreshBookCache(CreateKeysVO createKeysVO, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ConnectApiException, ConnectApiXmlException, ParseException, IOException {
		return adminUserBookService.refreshBookCache(createKeysVO, httpRequest, uriInfo);
	}

	@Override
	public RestResponse getCompanies(SessionStatusVO sessionStatusVO, Integer companyId,PaginationVO paginationVO, UriInfo uriInfo)
			throws BridgeException {
		return adminUserCompaniesSerivce.getCompanies(sessionStatusVO, companyId,paginationVO, uriInfo);
	}

	@Override
	public RestResponse createOrUpdateCompanies(SessionStatusVO sessionStatusVO, CompanyVO companyVO, Integer companyId,
			UriInfo uriInfo, HttpServletRequest httpRequest) throws BridgeException, ParseException, IOException {
		return adminUserCompaniesSerivce.createOrUpdateCompanies(sessionStatusVO, companyVO, companyId, uriInfo, httpRequest);
	}

	@Override
	public RestResponse getCompaniesForGroupId(SessionStatusVO sessionStatusVO, Integer id, String code,
			BridgePaginationVo bridgePaginationVo) throws BridgeException {
		return adminUserCompaniesSerivce.getCompaniesForGroupId(sessionStatusVO, id, code, bridgePaginationVo);
	}

	@Override
	public RestResponse getKeyBatchesForBridgeId(SessionStatusVO sessionStatusVO, Integer id,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		return adminUserKeyService.getKeyBatchesForBridgeId(sessionStatusVO, id, httpRequest, uriInfo);
	}

	@Override
	public void getKeyBatchFile(SessionStatusVO sessionStatusVO, Object param, HttpServletRequest httpRequest,
			HttpServletResponse httpServletResponse, UriInfo uriInfo) {
		adminUserKeyService.getKeyBatchFile(sessionStatusVO, param, httpRequest, httpServletResponse, uriInfo);
		
	}

	@Override
	public RestResponse deleteUserKeyCode(SessionStatusVO sessionStatusVO, Object param, HttpServletRequest httpRequest,
			UriInfo uriInfo) throws BridgeException {
		return adminUserKeyService.deleteUserKeyCode(sessionStatusVO, param, httpRequest, uriInfo);
	}

	@Override
	public RestResponse createOrUpdateKeyBatchesForBridgeId(SessionStatusVO sessionStatusVO, KeyBatchesVO keyBatchesVO,
			Integer bridgeId, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException {
		return adminUserKeyService.createOrUpdateKeyBatchesForBridgeId(sessionStatusVO, keyBatchesVO, bridgeId, httpRequest, uriInfo);
	}

	@Override
	public RestResponse generateKeysForBridgeId(SessionStatusVO sessionStatusVO, KeyGenerateRequestVO keyGenerateRequestVO,
			Integer bridgeId, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException {
		return adminUserKeyService.generateKeysForBridgeId(sessionStatusVO, keyGenerateRequestVO, bridgeId, httpRequest, uriInfo);
	}
	
	@Override
	public RestResponse connectivityMonitorCheck() throws BridgeException {

		return adminUserConnectivityService.connectivityMonitorCheck();
	}

	@Override
	public CSVResponseWrapperVO uploadCSVRoster(SessionStatusVO sessionStatusVO, HttpServletRequest httpRequest,
			UriInfo uriInfo, Integer bridgeId, MultipartFile uploadFile)
			throws BridgeException, MalformedURLException, IOException, InvalidActionException {
		return adminUserRosteringService.uploadCSVRoster(sessionStatusVO, httpRequest, uriInfo, bridgeId, uploadFile);
	}

	@Override
	public void processRosteringCSV(SessionStatusVO sessionStatusVO, UploadRosterVO uploadRosterVO,
			ICsvBeanReader beanReader, String[] header)
			throws BridgeException, MalformedURLException, IOException, InvalidActionException, Exception {
		adminUserRosteringService.processRosteringCSV(sessionStatusVO, uploadRosterVO, beanReader, header);
	}

	@Override
	public RestResponse getRosterHistoryForBridgeId(SessionStatusVO sessionStatusVO, Integer id,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		return adminUserRosteringService.getRosterHistoryForBridgeId(sessionStatusVO, id, httpRequest, uriInfo);
	}

	@Override
	public void getRosterFile(SessionStatusVO sessionStatusVO, Object param, HttpServletRequest httpRequest,
			HttpServletResponse httpServletResponse, UriInfo uriInfo)
			throws BridgeException, MalformedURLException, IOException {
		adminUserRosteringService.getRosterFile(sessionStatusVO, param, httpRequest, httpServletResponse, uriInfo);
	}

	@Override
	public RestResponse uploadCSVRosterTemplate(HttpServletRequest httpRequest, UriInfo uriInfo,
			MultipartFile uploadFile, CSVFileType fileType) throws IOException, BridgeException {
		return adminUserRosteringService.uploadCSVRosterTemplate(httpRequest, uriInfo, uploadFile, fileType);
	}

	@Override
	public void downloadCSVRosterTemplate(CSVFileType fileType, HttpServletResponse httpServletResponse)
			throws IOException, BridgeException {
		adminUserRosteringService.downloadCSVRosterTemplate(fileType, httpServletResponse);
		
	}

	@Override
	public RestResponse updateBridgeAllowanceForBridgeId(SessionStatusVO sessionStatusVO,
			AllowanceRequestVO allowanceRequestVO, Integer bridgeId, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException {
		return adminUserEntitlementService.updateBridgeAllowanceForBridgeId(sessionStatusVO,allowanceRequestVO,bridgeId,httpRequest,uriInfo);
		
	}

	@Override
	public RestResponse getBridgeAllowanceForBridgeId(SessionStatusVO sessionStatusVO,
			Integer bridgeId, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		return adminUserEntitlementService.getBridgeAllowanceForBridgeId(sessionStatusVO, bridgeId, httpRequest, uriInfo);		
	}

	@Override
	public RestResponse getAccessTypeForBridgeId(SessionStatusVO sessionStatusVO, Integer bridgeId,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		return adminUserEntitlementService.getAccessTypeForBridgeId(sessionStatusVO, bridgeId, httpRequest, uriInfo);
	}

	@Override
	public void getCsvErrorFile(SessionStatusVO sessionStatusVO, Object params, HttpServletRequest httpRequest,
			HttpServletResponse httpServletResponse, UriInfo uriInfo) {
		adminUserEntitlementService.getCsvErrorFile(sessionStatusVO, params, httpRequest, httpServletResponse, uriInfo);
		
	}

	@Override
	public RestResponse updateBridgePurchaseForBridgeId(SessionStatusVO sessionStatusVO,
			PurchaseRequestVO purchaseRequestVO, Integer bridgeId, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException {
		return adminUserEntitlementService.updateBridgePurchaseForBridgeId(sessionStatusVO, purchaseRequestVO, bridgeId, httpRequest, uriInfo);
	}

	@Override
	public RestResponse getBridgePurchaseForBridgeId(SessionStatusVO sessionStatusVO, Integer bridgeId,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		return adminUserEntitlementService.getBridgePurchaseForBridgeId(sessionStatusVO, bridgeId, httpRequest, uriInfo);
	}

	@Override
	public RestResponse updateGeneratedKeysForBridgeId(SessionStatusVO sessionStatusVO,
			KeyGenerateRequestVO keyGenerateRequestVO, Object params, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException {
		// TODO Auto-generated method stub
		return adminUserKeyService.updateGeneratedKeysForBridgeId(sessionStatusVO, keyGenerateRequestVO, params, httpRequest, uriInfo);
	}

	@Override
	public RestResponse getEntitlementForKeybatch(SessionStatusVO sessionStatusVO, Integer bridgeId, Integer keyBatchId,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException, IOException {
		return adminUserKeyService.getEntitlementForKeybatch(sessionStatusVO, bridgeId, keyBatchId, httpRequest, uriInfo);
	}

	@Override
	public RestResponse processCSVForGroupAssetsMapping(SessionStatusVO sessionStatusVO, HttpServletRequest httpRequest,
			UriInfo uriInfo, Integer bridgeId, MultipartFile uploadFile) throws IOException, BridgeException {
		// TODO Auto-generated method stub
		return adminUserRosteringService.processCSVForGroupAssetsMapping(sessionStatusVO, httpRequest, uriInfo, bridgeId, uploadFile);
	}

	@Override
	public RestResponse checkCompany(SessionStatusVO sessionStatusVO, String apiKey, UriInfo uriInfo,
			HttpServletRequest httpRequest) throws BridgeException, VstException {
		// TODO Auto-generated method stub
		return adminUserCompaniesSerivce.checkCompany(sessionStatusVO, apiKey, uriInfo, httpRequest);
	}

	@Override
	public RestResponse getAdminLabels(HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		// TODO Auto-generated method stub
		return adminUserBridgeService.getAdminLabels(httpRequest, uriInfo);
	}

}
