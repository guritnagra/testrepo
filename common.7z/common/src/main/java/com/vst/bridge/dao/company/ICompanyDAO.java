package com.vst.bridge.dao.company;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.company.Company;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.util.exception.BridgeException;

public interface ICompanyDAO extends IGenericDAO<Company, Integer>{

	List<Company> getAllCompanies(Integer startIndex,PaginationVO paginationVO)throws BridgeException;
	Company getForName(final String name)throws BridgeException;
	void checkCompanyNameExist(String name)throws BridgeException;
	Company getCompanyByApiKey(String apiKey)throws BridgeException;
	List<Company> getCompaniesByIds(List<Integer> companyList)throws BridgeException;
	Integer getAllCompaniesCount(PaginationVO paginationVo) throws BridgeException;
}
