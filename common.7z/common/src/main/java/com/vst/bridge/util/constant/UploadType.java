package com.vst.bridge.util.constant;

public enum UploadType {
MULTIPART,RESUMABLE
}
