package com.vst.bridge.rest.response.vo.report;

import java.util.List;

public class ReportBridgeBookVO {
	private Integer id;
	private String name;
	private String company;
	
	private List<ReportBooksVOIntigrationVO> books;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public List<ReportBooksVOIntigrationVO> getBooks() {
		return books;
	}

	public void setBooks(List<ReportBooksVOIntigrationVO> books) {
		this.books = books;
	}
}
