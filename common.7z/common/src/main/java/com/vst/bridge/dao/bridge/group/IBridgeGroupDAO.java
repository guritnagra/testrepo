package com.vst.bridge.dao.bridge.group;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.group.BridgeGroup;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeGroupDAO extends IGenericDAO<BridgeGroup, Integer>{
	List<BridgeGroup> getAllGroups(Integer bridgeId, Boolean getDeletedGroups, Boolean getDefaultGroup) throws BridgeException;

	BridgeGroup getDefaultGroup(Integer bridgeId) throws BridgeException;
	
	List<Integer> getGroupIdsForBridgeId(Integer bridgeId,Boolean withDefaultGroup)throws BridgeException;
	
	List<Integer> getCourseIdsForBridgeId(Integer bridgeId, Boolean withDefaultGroup) throws BridgeException;

	BridgeGroup getGroupByCourseId(Integer bridgeId, String courseId) throws BridgeException;
	
	List<BridgeGroup> getBCGroupsForBridgeId(Integer bridgeId)throws BridgeException;

	List<Integer> getCourseIds(Integer bridgeId, List<String> courseIds, Boolean withDefaultGroup) throws BridgeException;

	Integer deleteAllGroupsForBridge(Bridge bridge, AdminUser adminUser) throws BridgeException;

	BridgeGroup getDefaultGroup(Integer bridgeId, Boolean deleted) throws BridgeException;

	BridgeGroup getBridgeGroupBySourceId(Integer bridgeId,String classSourcedId) throws BridgeException;
	
	List<BridgeGroup> getAllAutoAssignGroups(Integer bridgeId, Boolean getDeletedGroups, Boolean getDefaultGroup) throws BridgeException;

	List<BridgeGroup> getAllAutoAssignAssetGroup(Integer bridgeId, List<Integer> userGroups, Boolean getDeletedGroups) throws BridgeException;
	
	BridgeGroup getBridgeGroupByName(Integer bridgeId, String groupName) throws BridgeException;
}
