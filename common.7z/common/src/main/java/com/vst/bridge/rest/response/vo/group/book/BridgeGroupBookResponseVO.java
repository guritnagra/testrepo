package com.vst.bridge.rest.response.vo.group.book;

import com.vst.bridge.rest.response.vo.ancillary.AncillaryBookVO;

public class BridgeGroupBookResponseVO {
	
	private String vbid;
	private String eBookIsbn;
	private String textbookIsbn;
	private String coverImageUrl;
	private String title;
	private String description;
	private String author;
	private String edition;
	private String eTextPrice;
	private String rentalPrice;
	private String textBookPrice;
	private Integer concurrencyLimit;
	private String fileType;
	private AncillaryBookVO ancillaryMetaData;
	
	public String getVbid() {
		return vbid;
	}
	public void setVbid(String vbid) {
		this.vbid = vbid;
	}
	public String geteBookIsbn() {
		return eBookIsbn;
	}
	public void seteBookIsbn(String eBookIsbn) {
		this.eBookIsbn = eBookIsbn;
	}
	public String getTextbookIsbn() {
		return textbookIsbn;
	}
	public void setTextbookIsbn(String textbookIsbn) {
		this.textbookIsbn = textbookIsbn;
	}
	public String getCoverImageUrl() {
		return coverImageUrl;
	}
	public void setCoverImageUrl(String coverImageUrl) {
		this.coverImageUrl = coverImageUrl;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getEdition() {
		return edition;
	}
	public void setEdition(String edition) {
		this.edition = edition;
	}
	public String geteTextPrice() {
		return eTextPrice;
	}
	public void seteTextPrice(String eTextPrice) {
		this.eTextPrice = eTextPrice;
	}
	public String getRentalPrice() {
		return rentalPrice;
	}
	public void setRentalPrice(String rentalPrice) {
		this.rentalPrice = rentalPrice;
	}
	public String getTextBookPrice() {
		return textBookPrice;
	}
	public void setTextBookPrice(String textBookPrice) {
		this.textBookPrice = textBookPrice;
	}
	public Integer getConcurrencyLimit() {
		return concurrencyLimit;
	}
	public void setConcurrencyLimit(Integer concurrencyLimit) {
		this.concurrencyLimit = concurrencyLimit;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public AncillaryBookVO getAncillaryMetaData() {
		return ancillaryMetaData;
	}
	public void setAncillaryMetaData(AncillaryBookVO ancillaryMetaData) {
		this.ancillaryMetaData = ancillaryMetaData;
	}
	
}
