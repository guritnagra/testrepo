package com.vst.bridge.dao.user.book;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.books.BridgeUserBookAssign;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.date.DateUtility;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeUserBookAssignDAO")
public class BridgeUserBookAssignDAOImpl extends GenericDAO<BridgeUserBookAssign, Integer> implements IBridgeUserBookAssignDAO{
	public BridgeUserBookAssignDAOImpl() {
		super(BridgeUserBookAssign.class);
	}

	@Override
	public Integer getCountForUsedType(List<Integer> ids,final String type) throws BridgeException {
		Integer count = 0;
		if(null != ids && ids.size() > 0){
			Criteria criteria = getCriteria();
			criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
			criteria.add(Restrictions.like("usedType", type));
			if(ApplicationConstants.BOOK_KEY_USED_TYPE_CONCURRENT.equals(type)){
				criteria.add(Restrictions.isNull("returnDate"));
				criteria.add(Restrictions.gt("expires", new Date()));
			}
				
			criteria.add(Restrictions.in("keyAssigned.id", ids));
			List<BridgeUserBookAssign> result = executeCriteira(criteria);
			return null != result && result.size() > 0 ? result.size() : count;
		}
		return count;
	}
	
	@Override
	public Integer getCountForUsedEntitlementType(List<Integer> ids,final Integer entitlementId,Boolean isReusableCredit) throws BridgeException {
		Integer count = 0;
		if(null != ids && ids.size() > 0){
			Criteria criteria = getCriteria();
			criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
			criteria.add(Restrictions.like("usedType", entitlementId.toString()));			
			if(isReusableCredit!=null && isReusableCredit)
				criteria.add(Restrictions.gt("expires", DateUtility.getDateStartOfDay(new Date())));
			criteria.add(Restrictions.in("keyAssigned.id", ids));
			List<BridgeUserBookAssign> result = executeCriteira(criteria);
			return null != result && result.size() > 0 ? result.size() : count;
		}
		return count;
	}
	
	@Override
	public Integer getConcurrencyCountForUsedEntitlementType(List<Integer> ids,final Integer entitlementId) throws BridgeException {
		Integer count = 0;
		if(null != ids && ids.size() > 0){
			Criteria criteria = getCriteria();
			criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
			criteria.add(Restrictions.like("usedType", ApplicationConstants.BOOK_KEY_USED_TYPE_CONCURRENT));
			criteria.add(Restrictions.eq("keyBatch.id", entitlementId));
			criteria.add(Restrictions.isNull("returnDate"));
			criteria.add(Restrictions.gt("expires", new Date()));	
			criteria.add(Restrictions.in("keyAssigned.id", ids));
			List<BridgeUserBookAssign> result = executeCriteira(criteria);
			return null != result && result.size() > 0 ? result.size() : count;
		}
		return count;
	}

	@Override
	public Boolean checkUsedTypeForAssignedIds(List<Integer> ids, String vbid, String type) throws BridgeException {
		if(null != ids && ids.size() > 0){
			Criteria criteria = getCriteria();
			criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
			criteria.add(Restrictions.like("usedType", type));
			criteria.add(Restrictions.like("vbid", vbid));
			criteria.add(Restrictions.in("keyAssigned.id", ids));
			List<BridgeUserBookAssign> bookAssigns = executeCriteira(criteria);
			return null != bookAssigns && bookAssigns.size() > 0 ?Boolean.TRUE : Boolean.FALSE;
		}
		return Boolean.FALSE;
	}

	@Override
	public Integer getUsedCountForUsedType(Integer keyAssignedId, String type) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.like("usedType", type));
		criteria.add(Restrictions.eq("keyAssigned.id", keyAssignedId));
		List<BridgeUserBookAssign> bookAssigns = executeCriteira(criteria);
		return null != bookAssigns && bookAssigns.size() > 0 ? bookAssigns.size() : 0;
	}

	@Override
	public BridgeUserBookAssign getLastActionForBook(List<Integer> keyIds, String vbid) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.in("keyAssigned.id", keyIds));
		criteria.add(Restrictions.like("vbid", vbid));
		criteria.addOrder(Order.desc("createdDate"));
		List<BridgeUserBookAssign> bookAssigns = executeCriteira(criteria);
		return null != bookAssigns && bookAssigns.size() > 0 ? bookAssigns.get(0) : null;
	}
	
	@Override
	public Integer getInUseBookCountForConcurrency(List<Integer> keyIds, String vbid,Integer keyBatchId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.createAlias("keyAssigned", "keyAssignedAlias");
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.in("keyAssignedAlias.key.id", keyIds));
		criteria.add(Restrictions.eq("usedType", ApplicationConstants.BOOK_KEY_USED_TYPE_CONCURRENT));
		if(keyBatchId!=null)
			criteria.add(Restrictions.eq("keyBatch.id",keyBatchId));
		criteria.add(Restrictions.like("vbid", vbid));
		criteria.add(Restrictions.isNull("returnDate"));
		criteria.add(Restrictions.gt("expires", DateUtility.getDateStartOfDay(new Date())));
		List<BridgeUserBookAssign> bookAssigns = executeCriteira(criteria);
		return null != bookAssigns && bookAssigns.size() > 0 ? bookAssigns.size() : 0;
	}

	@Override
	public BridgeUserBookAssign getAssignedBookToUser(Integer userId, String vbid,String usedType) throws BridgeException {
		// TODO Auto-generated method stub
		Criteria criteria = getCriteria();
		if(null != userId && userId >0){
			criteria.createAlias("keyAssigned", "keyAssignedAlias");
			criteria.add(Restrictions.eq("keyAssignedAlias.user.id", userId));
		}
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));		
		criteria.add(Restrictions.like("usedType", usedType));
		criteria.add(Restrictions.like("vbid", vbid));
		criteria.add(Restrictions.isNull("returnDate"));
		criteria.add(Restrictions.gt("expires", DateUtility.getDateStartOfDay(new Date())));
		List<BridgeUserBookAssign> bookAssigns = executeCriteira(criteria);
		return null != bookAssigns && bookAssigns.size() > 0 ? bookAssigns.get(0) : null;
		 
	}
}
