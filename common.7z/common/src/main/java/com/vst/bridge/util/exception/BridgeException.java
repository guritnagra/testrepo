package com.vst.bridge.util.exception;


public class BridgeException extends RuntimeException {
	

	private static final long serialVersionUID = 4265758284484258031L;

	public static final String UNHANDLED_EXCEPTION_TXT = "Unhandled Exception !!! ";
	
	private String message;
	private boolean logged;
	private  ApplicationCode errorCode;
	
	public BridgeException(final ApplicationCode code) {
		this.errorCode = code;
	}
	
	public BridgeException(final String message, final ApplicationCode code) {
		this.setMessage(message);
		this.errorCode = code;
	}

	public BridgeException(final String message, final ApplicationCode code, final Throwable throwable) {
		super(throwable);
		this.errorCode = code;
		this.setMessage(message);
	}
	
	public ApplicationCode getErrorCode() {
		return errorCode;
	}

	public boolean isLogged() {
		return this.logged;
	}
	
	public void setLogged(boolean logged) {
		this.logged = logged;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}	
}
