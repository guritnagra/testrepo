package com.vst.bridge.service.user;

public interface IUserServices extends IUserAccessService, IUserEntityService, IUserBridgeService, IUserBookService, IUserPasswordService, IUserKeyService, IUserValidationService{
	
}
