package com.vst.bridge.service.ancillary;

public enum AncillaryApiKey {

	LOCAL(){
		@Override
		void init() {
			apiKey = "MNL9CcV3Ym2pytvJfFzYXrEH";
		}
	},
	DEV() {

		@Override
		void init() {
			apiKey = "MNL9CcV3Ym2pytvJfFzYXrEH";
		}

	},
	STAGE() {

		@Override
		void init() {
			apiKey = "cGhVaKA2eur4kok7pV1vXcoJ";
		}

	},
	TEST(){
		@Override
		void init() {
			apiKey = "TEST-API-KEY";
		}
	},
	PROD() {

		@Override
		void init() {
			apiKey = "bc7ad6d1259d227ede208958";
		}

	},
	NONE(){
		@Override
		void init() {
			apiKey = "No API Key available";
		}
	};

	private AncillaryApiKey() {
		init();
	}

	abstract void init();

	protected String apiKey;

	public String getApiKey() {
		return this.apiKey;
	}

}
