package com.vst.bridge.dao.admin;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.user.AdminGroup;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.BridgeException;

@Repository("adminGroupDAO")
public class AdminGroupDAOImpl extends GenericDAO<AdminGroup, Integer> implements IAdminGroupDAO{

	public AdminGroupDAOImpl() {
		super(AdminGroup.class);
	}

	@Override
	public List<Integer> getGropIdsForAdminUser(AdminUser adminUser)
			throws BridgeException {
		List<Integer> ids = new ArrayList<Integer>(0);
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("admin.id", adminUser.getId()));
		List<AdminGroup> adminGroupsList = executeCriteira(criteria);
		if(null != adminGroupsList && adminGroupsList.size()>0){
			for(AdminGroup adminGroup : adminGroupsList){
				ids.add(adminGroup.getGroup().getId());
			}
		}
		return ids;
	}

	@Override
	public List<AdminUser> getUsersForGroupIds(List<Integer> groupIds, Integer startIndex, BridgePaginationVo paginationVo)
			throws BridgeException {
		List<AdminUser> adminUsers = new ArrayList<AdminUser>();
		Criteria criteria = getCriteria();
		criteria.createAlias("admin", "adminAlias");
		if(null!=paginationVo){
			Integer totalRecordToFetch = paginationVo.getLimit();
			if(null != startIndex && null != totalRecordToFetch  && totalRecordToFetch > 0){
				criteria.setFirstResult(startIndex);
				criteria.setMaxResults(totalRecordToFetch);
			}
			
			String search = paginationVo.getSearch();
			if(null!=search && !StringUtils.isEmpty(search)){
				Criterion criterion1 = Restrictions.ilike("adminAlias.firstName", "%"+search+"%");
				Criterion criterion2 = Restrictions.ilike("adminAlias.lastName", "%"+search+"%");
				Criterion criterion3 = Restrictions.ilike("adminAlias.email", "%"+search+"%");
				Criterion completeCriterion = Restrictions.disjunction()
																	.add(criterion1)
																	.add(criterion2)
																	.add(criterion3);
				
				criteria.add(completeCriterion);
			}
			String orderBy = paginationVo.getOrderBy();
			if(null != orderBy && !StringUtils.isEmpty(orderBy)){
				String order = paginationVo.getOrder();
				if(order.equals(ApplicationConstants.SORTING_ORDER_ASC)){
					criteria.addOrder(Order.asc("adminAlias."+orderBy));
				}else{
					criteria.addOrder(Order.desc("adminAlias."+orderBy));
				}
			}
		}
		criteria.add((Restrictions.in("group.id", groupIds)));
		List<AdminGroup> adminGroupsList = executeCriteira(criteria);
		if(null != adminGroupsList && adminGroupsList.size()>0){
			for(AdminGroup adminGroup : adminGroupsList){
				adminUsers.add(adminGroup.getAdmin());
			}
		}
		return adminUsers;
	}

	@Override
	public Integer getUserCount(List<Integer> groupIds,BridgePaginationVo paginationVo) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.createAlias("admin", "adminAlias");
		String search = paginationVo.getSearch();
		if(null!=search && !StringUtils.isEmpty(search)){
			Criterion criterion1 = Restrictions.ilike("adminAlias.firstName", "%"+search+"%");
			Criterion criterion2 = Restrictions.ilike("adminAlias.lastName", "%"+search+"%");
			Criterion criterion3 = Restrictions.ilike("adminAlias.email", "%"+search+"%");
			Criterion completeCriterion = Restrictions.disjunction()
																.add(criterion1)
																.add(criterion2)
																.add(criterion3);
			criteria.add(completeCriterion);
		}
		criteria.add((Restrictions.in("group.id", groupIds)));
		criteria.setProjection(Projections.distinct(Projections.property("admin.id")));
		List<AdminGroup> adminGroupsList = executeCriteira(criteria);
		return null!=adminGroupsList && adminGroupsList.size() > 0 ? adminGroupsList.size() : 0;
	}

	@Override
	public List<AdminGroup> getGroupsForAdminId(Integer adminId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.eq("admin.id", adminId));
		return executeCriteira(criteria);
	}
}
