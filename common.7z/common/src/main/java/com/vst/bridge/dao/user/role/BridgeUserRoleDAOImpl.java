package com.vst.bridge.dao.user.role;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.user.Role;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeUserRoleDAO")
public class BridgeUserRoleDAOImpl extends GenericDAO<Role,Integer> implements IBridgeUserRoleDAO{

	public BridgeUserRoleDAOImpl() {
		super(Role.class);
	}

	@Override
	public Role getForName(String name) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.like("name", name));
		List<Role> result = executeCriteira(criteria);
		return null!=result  && result.size() > 0 ? result.get(0) : null;
	}
}
