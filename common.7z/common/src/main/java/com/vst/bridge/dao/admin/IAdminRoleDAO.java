package com.vst.bridge.dao.admin;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.role.AdminRole;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminRoleDAO extends IGenericDAO<AdminRole, Integer>{
	public AdminRole getUserForRoleName(final String name)throws BridgeException;	
}
