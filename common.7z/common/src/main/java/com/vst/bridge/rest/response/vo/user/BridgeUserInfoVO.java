package com.vst.bridge.rest.response.vo.user;

import java.util.Date;
import java.util.List;

import com.owlike.genson.annotation.JsonIgnore;


public class BridgeUserInfoVO {

	private Integer id;
	private String firstName;
	private String lastName;
	private String email;
	private Long created;
	private Date createdDate;
	
	private TotalUsedDetailsVO fullCredits;
	private TotalUsedDetailsVO trialCredits;
	private TotalUsedDetailsVO rentalCredits;
	private ConcurrencyCreditUsedDetailsVO concurrencyCredits;
	private List<UserEntitlementVO> entitlements;
	private List<UserEntitlementVO> concurrencyEntitlements;
	
	private Boolean promotionSubscription;
	private Boolean surveySubscription;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getCreated() {
		return created;
	}
	public void setCreated(Long created) {
		this.created = created;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public TotalUsedDetailsVO getFullCredits() {
		return fullCredits;
	}
	public void setFullCredits(TotalUsedDetailsVO fullCredits) {
		this.fullCredits = fullCredits;
	}
	public TotalUsedDetailsVO getTrialCredits() {
		return trialCredits;
	}
	public void setTrialCredits(TotalUsedDetailsVO trialCredits) {
		this.trialCredits = trialCredits;
	}
	public Boolean getPromotionSubscription() {
		return promotionSubscription;
	}
	public void setPromotionSubscription(Boolean promotionSubscription) {
		this.promotionSubscription = promotionSubscription;
	}
	public Boolean getSurveySubscription() {
		return surveySubscription;
	}
	public void setSurveySubscription(Boolean surveySubscription) {
		this.surveySubscription = surveySubscription;
	}
	public TotalUsedDetailsVO getRentalCredits() {
		return rentalCredits;
	}
	public void setRentalCredits(TotalUsedDetailsVO rentalCredits) {
		this.rentalCredits = rentalCredits;
	}

	@JsonIgnore
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public ConcurrencyCreditUsedDetailsVO getConcurrencyCredits() {
		return concurrencyCredits;
	}
	public void setConcurrencyCredits(ConcurrencyCreditUsedDetailsVO concurrencyCredits) {
		this.concurrencyCredits = concurrencyCredits;
	}
	public List<UserEntitlementVO> getEntitlements() {
		return entitlements;
	}
	public void setEntitlements(List<UserEntitlementVO> entitlements) {
		this.entitlements = entitlements;
	}
	public List<UserEntitlementVO> getConcurrencyEntitlements() {
		return concurrencyEntitlements;
	}
	public void setConcurrencyEntitlements(List<UserEntitlementVO> concurrencyEntitlements) {
		this.concurrencyEntitlements = concurrencyEntitlements;
	}
	
}
