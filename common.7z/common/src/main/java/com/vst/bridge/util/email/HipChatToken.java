package com.vst.bridge.util.email;

public enum HipChatToken {
	LOCAL(){
		@Override
		void init() {
			token = "N9ssONvxvckX8pbWN6rcVIUJ2oqUiHOLhPFBjXN2";
		}
	},
	DEV() {

		@Override
		void init() {
			token = "N9ssONvxvckX8pbWN6rcVIUJ2oqUiHOLhPFBjXN2";
		}

	},
	STAGE() {

		@Override
		void init() {
			token = "N9ssONvxvckX8pbWN6rcVIUJ2oqUiHOLhPFBjXN2";
		}

	},
	TEST(){
		@Override
		void init() {
			token = "N9ssONvxvckX8pbWN6rcVIUJ2oqUiHOLhPFBjXN2";
		}
	},
	PROD() {

		@Override
		void init() {
			token = "RLTEFzglF8j92DNiwUEaiU95jAUlW9MZK0Y5aMQO";
		}

	},
	NONE(){
		@Override
		void init() {
			token = "No API Key available";
		}
	};

	private HipChatToken() {
		init();
	}

	abstract void init();

	protected String token;

	public String getToken() {
		return this.token;
	}
}
