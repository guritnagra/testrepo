package com.vst.bridge.dao.bc;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bc.ContextToken;
import com.vst.bridge.util.exception.BridgeException;

@Repository("contextTokenDAO")
public class ContextTokenDAOImpl extends GenericDAO<ContextToken, Integer> implements IContextTokenDAO{
	
	public ContextTokenDAOImpl() {
		super(ContextToken.class);
	}

	@Override
	public ContextToken getByContextToken(String contextToken) throws BridgeException {
		Criteria criteria = getCriteria();
		if(null != contextToken){
			criteria.add(Restrictions.like("contextToken", contextToken));
		}
		List<ContextToken> result =  executeCriteira(criteria);
		return result != null && result.size() > 0 ? result.get(0) : null ;
	}

}
