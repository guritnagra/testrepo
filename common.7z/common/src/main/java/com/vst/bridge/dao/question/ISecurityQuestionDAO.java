package com.vst.bridge.dao.question;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.question.SecurityQuestion;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.util.exception.BridgeException;

public interface ISecurityQuestionDAO extends IGenericDAO<SecurityQuestion, Integer>{
	List<IdValueVO> getListOfQuestions()throws BridgeException;
}
