package com.vst.bridge.service.admin;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.routines.EmailValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvBeanReader;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.prefs.CsvPreference;

import com.vst.bridge.TomcatUtils;
import com.vst.bridge.VstUtils;
import com.vst.bridge.actions.Aws;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookCacheDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupAssetDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupUserDAO;
import com.vst.bridge.dao.log.IBridgeRosterLogDAO;
import com.vst.bridge.dao.role.IRoleDAO;
import com.vst.bridge.dao.roster.IBridgeRosterTemplateDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.log.BridgeRosterLog;
import com.vst.bridge.entity.bridge.roster.BridgeRosterTemplate;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.Role;
import com.vst.bridge.entity.group.BridgeGroup;
import com.vst.bridge.entity.group.GroupAsset;
import com.vst.bridge.entity.group.GroupUser;
import com.vst.bridge.rest.response.vo.Metadata;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.roster.CSVResponseWrapperVO;
import com.vst.bridge.rest.response.vo.roster.RosterHistoryResponseVO;
import com.vst.bridge.rest.response.vo.roster.UploadRosterVO;
import com.vst.bridge.util.bean.BridgeGroupAssetMappingBean;
import com.vst.bridge.util.bean.BridgeGroupBean;
import com.vst.bridge.util.bean.BridgeGroupUserBean;
import com.vst.bridge.util.bean.BridgeUserBean;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.csv.CSVFileType;
import com.vst.bridge.util.csv.CsvHandlerService;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.exception.InvalidActionException;
import com.vst.bridge.util.exception.RosterException;
import com.vst.bridge.util.message.LocaleMessageUtility;

@Service("adminUserRosteringService")
public class AdminUserRosteringServiceImpl implements IAdminUserRosteringService {
	@Autowired
	private IAdminUserDAO adminUserDAO;
	
	@Autowired
	private LocaleMessageUtility localeMessageUtility;
	
	@Autowired
	private IBridgeDAO bridgeDAO;

	@Autowired
	private IBridgeUserDAO bridgeUserDAO;

	@Autowired
	private IBridgeGroupDAO bridgeGroupDAO;
	
	@Autowired
	private IBridgeRosterLogDAO bridgeRosterLogDAO;
	
	@Autowired
	private IBridgeRosterTemplateDAO bridgeRosterTemplateDAO;
	
	@Autowired
	private CsvHandlerService csvHandlerService;
	
	@Autowired
	private IBridgeGroupUserDAO bridgeGroupUserDAO;
	
	@Autowired
	private IRoleDAO roleDAO;
	
	@Autowired
	private IBridgeBookCacheDAO bridgeBookCacheDAO;
	
	@Autowired
	private IBridgeGroupAssetDAO bridgeGroupAssetDAO;
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public CSVResponseWrapperVO uploadCSVRoster(SessionStatusVO sessionStatusVO, HttpServletRequest httpRequest,
			UriInfo uriInfo, Integer bridgeId, MultipartFile uploadFile)
			throws BridgeException, MalformedURLException, IOException, InvalidActionException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
 				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		
		CSVResponseWrapperVO cWrapperVO = new CSVResponseWrapperVO();
		
		final String fileName=uploadFile.getOriginalFilename();
		final String ext   = fileName.substring(fileName.lastIndexOf(".")+1).toLowerCase();
		final long fileSize=uploadFile.getSize();
		Bridge bridge = bridgeDAO.get(bridgeId);
		if(bridge == null || bridge.getDeleted()){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		if(!bridge.getIsRostered()){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_ROSTERED);
		}
		AdminUser adminUser = adminUserDAO.get(sessionStatusVO.getAdminId());
		if(!ext.equals("csv")&& fileSize==0){
			response= new RestResponse(Response.Status.UNSUPPORTED_MEDIA_TYPE.getStatusCode(),ApplicationCode.UNSUPPORTED_MEDIA_TYPE.getCodeId(),
					localeMessageUtility.getMessage(ApplicationCode.UNSUPPORTED_MEDIA_TYPE.getCodeId()));
		}
		else if(fileSize> Long.parseLong(TomcatUtils.getParam("csv_filesize_limit"))){ //300KB limit increase to 25MB
			response= new RestResponse(Response.Status.REQUEST_ENTITY_TOO_LARGE.getStatusCode(),ApplicationCode.FILE_SIZE_LIMIT_EXCEEDED.getCodeId(),
					localeMessageUtility.getMessage(ApplicationCode.FILE_SIZE_LIMIT_EXCEEDED.getCodeId()));
		}
		else{	
			Map<String, String> rosterMap= new HashMap<>();			
			InputStream uploadedInputStream = uploadFile.getInputStream();
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int len;
			while ((len = uploadedInputStream.read(buffer)) > -1 ) {
			    baos.write(buffer, 0, len);
			}
			baos.flush();

			InputStream is1 = new ByteArrayInputStream(baos.toByteArray()); 
			InputStream is2 = new ByteArrayInputStream(baos.toByteArray());
			Reader in = new InputStreamReader(is1); 
			ICsvBeanReader beanReader = new CsvBeanReader(in, CsvPreference.STANDARD_PREFERENCE);
			
			
            // the header elements are used to map the values to the bean (names must match)
            String[] headers = beanReader.getHeader(true);
            StringBuffer sb= new StringBuffer();
            ArrayList<String> trimedList= new ArrayList<String>();
            String trimHead=null;
            for(String header: headers){
            	if(StringUtils.isNotEmpty(header))
            		trimHead = header.trim();
            		trimedList.add(trimHead);
            		sb.append(trimHead).append(",");
            }
            sb.deleteCharAt(sb.length()-1);
            headers=trimedList.toArray(headers);
            rosterMap.put(ApplicationConstants.TYPE,sb.toString());
			//rosterMap.put(ApplicationConstants.TYPE,"sourcedId,status,dateLastModified,orgSourcedIds,role,username,userId,givenName,familyName,identifier,email,sms,phone,agents");
			final String fileUrl=Aws.uploadRosterFile(VstUtils.getDomain(uriInfo, httpRequest), is2, ext, uploadFile.getSize());
			rosterMap.put(ApplicationConstants.ROSTER_URL, fileUrl);
			UploadRosterVO uploadRosterVO = this.populateRosterResponse(rosterMap,bridge);
			BridgeRosterLog bridgeRosterLog=this.populateBridgeRosterLog(uploadRosterVO);
			bridgeRosterLog.setBridge(bridge);
			bridgeRosterLog.setFileName(fileName);
			bridgeRosterLog.setCreator(adminUser);
			bridgeRosterLogDAO.saveOrUpdate(bridgeRosterLog);
			BridgeRosterLog bridgeRosterLog1 =bridgeRosterLogDAO.getRosterLogByURL(uploadRosterVO.getFileURL());
			uploadRosterVO.setRosterId(bridgeRosterLog1.getId());
			response.setData(uploadRosterVO);
			//this.processRosteringCSV(uploadRosterVO,beanReader,headers,bridgeDAO,bridgeUserDAO);
			cWrapperVO.setBeanReader(beanReader);
			cWrapperVO.setHeader(headers);
			//cWrapperVO.setResponse(response);
			cWrapperVO.setUploadRosterVO(uploadRosterVO);
		}
		cWrapperVO.setResponse(response);
		return cWrapperVO;
	}

	private BridgeRosterLog populateBridgeRosterLog(UploadRosterVO uploadRosterVO) {
		BridgeRosterLog bridgeRosterLog = new BridgeRosterLog();
		bridgeRosterLog.setFileType(uploadRosterVO.getFileType().name());
		bridgeRosterLog.setFileURL(uploadRosterVO.getFileURL());
		bridgeRosterLog.setStatus(ApplicationConstants.FileStatus.LOADED.name());
		bridgeRosterLog.setCreatedDate(new Date());
		return bridgeRosterLog;
	}

	private UploadRosterVO populateRosterResponse(Map<String, String> rosterMap,Bridge bridge) throws InvalidActionException {
		UploadRosterVO uploadRosterVO = new UploadRosterVO();
		uploadRosterVO.setBridgeId(bridge.getId());
		String fileType=rosterMap.get(ApplicationConstants.TYPE);
		System.out.println(CSVFileType.fromString(fileType));
		
		switch(CSVFileType.fromString(fileType)){
		
		case BRIDGEUSER:
			uploadRosterVO.setFileType(CSVFileType.BRIDGEUSER);
			break;
		
		case BRIDGEGROUP:
			uploadRosterVO.setFileType(CSVFileType.BRIDGEGROUP);
			break;
		
		case BRIDGEGROUPUSER:
			uploadRosterVO.setFileType(CSVFileType.BRIDGEGROUPUSER);
			break;
			
		case INVALIDHEADER:
			//System.out.println("Invalid Roster Header.");
			throw new BridgeException(ApplicationCode.INVALID_ROSTER_HEADER);
			
		default :
			throw new InvalidActionException();
			
		}
		
		uploadRosterVO.setFileURL(rosterMap.get(ApplicationConstants.ROSTER_URL));
		
		return uploadRosterVO;
		
	}
	
	/**** CSV processing *******/
	@Override
	@Transactional(readOnly=false)
	public void processRosteringCSV(SessionStatusVO sessionStatusVO, final UploadRosterVO uploadRosterVO,final ICsvBeanReader beanReader,final String[] header) throws BridgeException,MalformedURLException, IOException, InvalidActionException{		

			List<Object> bridgeBeans=csvHandlerService.getRosterBean(uploadRosterVO,beanReader,header);
			BridgeRosterLog bridgeRosterLog=bridgeRosterLogDAO.getRosterLogByURL(uploadRosterVO.getFileURL());
			Bridge bridge=bridgeDAO.get(uploadRosterVO.getBridgeId());
			StringBuilder errorRowLogging= new StringBuilder();
			List<String> duplicateMailList= new ArrayList<String>();
			List<String> duplicateSrcIdList= new ArrayList<String>();
			if(null!=bridgeBeans && bridgeBeans.get(0) instanceof BridgeUserBean){
				
				List<BridgeUser> bridgeUserList= new ArrayList<BridgeUser>();
				
				List<BridgeUser> existingBridgeUsers=bridgeUserDAO.getAllUsersForBridge(bridge.getId());
				
				for(int row=0;row<bridgeBeans.size();row++){
					BridgeUserBean bridgeUserBean1=(BridgeUserBean)bridgeBeans.get(row);
					try{
					BridgeUser bridgeUser=new BridgeUser();
					String email=bridgeUserBean1.getEmail();
					if(null!=email){
						email = email.trim();
						if(duplicateMailList.contains(email.toLowerCase())){
							throw new RosterException("Mail "+email+" is duplicate in csv");
						}
						BridgeUser bridgeUserWithMail=bridgeUserDAO.getForEmail(bridge.getId(),email);
						if(null!=bridgeUserWithMail && bridgeUserWithMail.getDeleted()==null){
							String checkSourceId=bridgeUserBean1.getSourcedId();
							if(checkSourceId!=null && bridgeUserWithMail.getSourceId()!=null && StringUtils.equals(checkSourceId, bridgeUserWithMail.getSourceId())){
								bridgeUserWithMail.setFirstName(bridgeUserBean1.getGivenName());
								bridgeUserWithMail.setLastName(bridgeUserBean1.getFamilyName());
								bridgeUserList.add(bridgeUserWithMail);
								continue;
							}
							else{
								throw new RosterException(email +" already exist");
							}							
						}else if(null!=bridgeUserWithMail && bridgeUserWithMail.getDeleted()!=null){
							bridgeUserWithMail.setDeleted(null);
							bridgeUserWithMail.setDeletedBy(null);
							bridgeUserWithMail.setGuid(null);
							bridgeUserWithMail.setAccessToken(null);
							//bridgeUserDAO.saveOrUpdate(bridgeUserWithMail);
							bridgeUserList.add(bridgeUserWithMail);
							continue;
						}
						if(!EmailValidator.getInstance(true).isValid(email)){						
							throw new RosterException("Invalid mail format :"+email);
						}
						bridgeUser.setEmail(email);
						duplicateMailList.add(email.toLowerCase());
					}
					String sourceId=bridgeUserBean1.getSourcedId();
					if(null!=sourceId){
						for(BridgeUser bu:existingBridgeUsers){
							if(sourceId.equals(bu.getSourceId())){
								throw new RosterException("SourceID "+sourceId +" already assigned to other user(ID="+bu.getId()+")");
							}
							if(duplicateSrcIdList.contains(sourceId.toLowerCase())){
								throw new RosterException("SourceID "+sourceId+" is duplicate in csv");
							}
						}
						bridgeUser.setSourceId(sourceId);
						duplicateSrcIdList.add(sourceId.toLowerCase());
					}
					else{
						throw new RosterException("SourceId is missing");
					}
					String firstName=bridgeUserBean1.getGivenName();
					if(StringUtils.isNotEmpty(firstName)){
						bridgeUser.setFirstName(firstName);
					}
					else{
						throw new RosterException("FirstName is missing");
					}
					String familyName=bridgeUserBean1.getFamilyName();
					if(StringUtils.isNotEmpty(familyName)){
						bridgeUser.setLastName(familyName);
					}
					else{
						throw new RosterException("FamilyName is missing");
					}
					String role =bridgeUserBean1.getRole();
					role = role!=null ? role : "Student";
					if(null!=role){
						Role roleDB=roleDAO.getRoleByName(role);
						if(null!=roleDB)
							bridgeUser.setRole(roleDB);
						else
							throw new RosterException("Invalid role");
					}					
					bridgeUser.setBridge(bridge);				
					bridgeUser.setCreatedDate(new Date());
					bridgeUserList.add(bridgeUser);
				}
				catch(RosterException e){
					errorRowLogging.append("Row No :").append(row+1)
					.append("  Error :").append(e.getMessage()).append(System.lineSeparator());
					continue;
					}
				}
				
				bridgeUserDAO.saveOrUpdateAll(bridgeUserList);
				
			}
			else if(null!=bridgeBeans && bridgeBeans.get(0) instanceof BridgeGroupBean){
				List<BridgeGroup> bridgeGroupList= new ArrayList<BridgeGroup>();
				List<BridgeGroup> bridgeGroupFromDB=bridgeGroupDAO.getAllGroups(bridge.getId(), Boolean.FALSE,Boolean.TRUE);
				for(int row=0;row<bridgeBeans.size();row++){
					BridgeGroupBean bridgeGroupBean1=(BridgeGroupBean)bridgeBeans.get(row);
					try{
					BridgeGroup bridgeGroup= new BridgeGroup();
					String sourceId=bridgeGroupBean1.getSourcedId();
					if(null!=sourceId){
						for(BridgeGroup bg:bridgeGroupFromDB){
							if(sourceId.equals(bg.getSourceId())){
								throw new RosterException("SourceID "+sourceId +" already assigned to other Group(ID="+bg.getId()+")");
							}
						}
						bridgeGroup.setSourceId(sourceId);
					}
					else{
						throw new RosterException("SourceId is missing");
					}
					String bridgeName=bridgeGroupBean1.getTitle();
					if(null!=bridgeName){
						bridgeGroup.setName(bridgeName);
					}
					else{
						throw new RosterException("Title is missing");
					}
					bridgeGroup.setBridge(bridgeDAO.get(uploadRosterVO.getBridgeId()));
					bridgeGroup.setCreatedBy(adminUserDAO.get(sessionStatusVO.getAdminId()));
					bridgeGroup.setModifiedBy(adminUserDAO.get(sessionStatusVO.getAdminId()));
					bridgeGroup.setModifiedDate(new Date());
					bridgeGroup.setCreatedDate(new Date());
					if(StringUtils.isNotEmpty(bridgeGroupBean1.getStatus())){
						if(StringUtils.equals(bridgeGroupBean1.getStatus(), ApplicationConstants.STATUS_INACTIVE)||
								StringUtils.equals(bridgeGroupBean1.getStatus(), ApplicationConstants.STATUS_TOBEDELETED)){
							bridgeGroup.setDeleted(Boolean.TRUE);
						}
					}
					
					bridgeGroupList.add(bridgeGroup);
					}
					catch(RosterException e){
						errorRowLogging.append("Row No :").append(row+1)
						.append("  Error :").append(e.getMessage()).append(System.lineSeparator());
						continue;
						}
				}
				
				bridgeGroupDAO.saveOrUpdateAll(bridgeGroupList);
			}
			else if(null!=bridgeBeans && bridgeBeans.get(0) instanceof BridgeGroupUserBean){
				List<GroupUser> bridgeGroupUserList= new ArrayList<GroupUser>();
				for(int row=0;row<bridgeBeans.size();row++){
					BridgeGroupUserBean bridgeGroupUserBean1=(BridgeGroupUserBean)bridgeBeans.get(row);
					try{
						GroupUser groupUser= new GroupUser();
						String sourceId=bridgeGroupUserBean1.getSourcedId();
						if(null!=sourceId){
							groupUser.setSourceId(sourceId);
						}
						else{
							throw new RosterException("SourceId is missing");
						}
						String classSourceid=bridgeGroupUserBean1.getClassSourcedId();
						if(null!=classSourceid){
							BridgeGroup bridgeGroup=bridgeGroupDAO.getBridgeGroupBySourceId(bridge.getId(),bridgeGroupUserBean1.getClassSourcedId());
							if(null!=bridgeGroup)
								groupUser.setGroup(bridgeGroup);
							else
								throw new RosterException("Invalid Bridge group classSourcedId");
						}
						else{
							throw new RosterException("ClassSourceId is missing");
						}
						String userSourceId=bridgeGroupUserBean1.getUserSourcedId();
						if(null!=userSourceId){
							BridgeUser bridgeUser=bridgeUserDAO.getBridgeUserBySourceId(bridge.getId(),userSourceId);
							if(null!=bridgeUser)
								groupUser.setUser(bridgeUser);
							else
								throw new RosterException("Invalid Bridge user sourcedId");
						}
						else{
							throw new RosterException("SourcedId is missing");
						}
						
						String role=bridgeGroupUserBean1.getRole();
						if(null!=role){
							Role roleDB=roleDAO.getRoleByName(role);
							if(null!=roleDB)
								groupUser.setRole(roleDB);
							else
								throw new RosterException("Invalid role");
						}
						else{
							throw new RosterException("Role is missing");
						}	
											
						if(StringUtils.isNotEmpty(bridgeGroupUserBean1.getStatus())){
							if(StringUtils.equals(bridgeGroupUserBean1.getStatus(), ApplicationConstants.STATUS_INACTIVE)||
									StringUtils.equals(bridgeGroupUserBean1.getStatus(), ApplicationConstants.STATUS_TOBEDELETED)){
								groupUser.setSelected(Boolean.FALSE);
							}
						}					
						bridgeGroupUserList.add(groupUser);
					}
					catch(RosterException e){
						errorRowLogging.append("Row No :").append(row+1)
						.append("  Error :").append(e.getMessage()).append(System.lineSeparator());
						continue;
					}
				}
				
				
				bridgeGroupUserDAO.saveOrUpdateAll(bridgeGroupUserList);
			}
			String errorLog=errorRowLogging.toString();
			if(StringUtils.isNotEmpty(errorLog)){
				bridgeRosterLog.setErrorDescription(errorLog);
				bridgeRosterLog.setStatus(ApplicationConstants.FileStatus.WARNING.name());
				
			}
			else{
				bridgeRosterLog.setStatus(ApplicationConstants.FileStatus.COMPLETED.name());
			}
			bridgeRosterLogDAO.saveOrUpdate(bridgeRosterLog);
			
	}
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getRosterHistoryForBridgeId(SessionStatusVO sessionStatusVO, Integer bridgeId,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Bridge bridge = bridgeDAO.get(bridgeId);
		if(bridge==null){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		List<BridgeRosterLog> bridgeRosterLogList = bridgeRosterLogDAO.getAllBridgeRosterLog(bridgeId);
		if(null != bridgeRosterLogList && bridgeRosterLogList.size() > 0){
			List<RosterHistoryResponseVO> data = new ArrayList<RosterHistoryResponseVO>();
			for(BridgeRosterLog bridgeRosterLog : bridgeRosterLogList){
				data.add(populateRosterHistoryResponseVOFrombridgeRosterLog(bridgeRosterLog));
			}
			response.setData(data);
			Metadata metadata = new Metadata();
			metadata.setCount(data.size());
			response.setMetadata(metadata);
		}
		return response;
	}

	private RosterHistoryResponseVO populateRosterHistoryResponseVOFrombridgeRosterLog(
			BridgeRosterLog bridgeRosterLog) {
		RosterHistoryResponseVO response = new RosterHistoryResponseVO();
		response.setRosterId(bridgeRosterLog.getId());
		response.setFileName(bridgeRosterLog.getFileName());
		//response.setDownloadURL(bridgeRosterLog.getFileURL());
		response.setUploadedDate(bridgeRosterLog.getCreatedDate());
		response.setUploadedTime(bridgeRosterLog.getCreatedDate().getTime());
		response.setStatus(bridgeRosterLog.getStatus());
		AdminUser adminUser = bridgeRosterLog.getCreator();
		response.setUploadedBy(com.vst.bridge.StringUtils.getFullName(adminUser.getFirstName(), adminUser.getLastName()));
		return response;
	}
	

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public void getRosterFile(SessionStatusVO sessionStatusVO, Object params, HttpServletRequest httpRequest,
			HttpServletResponse httpServletResponse, UriInfo uriInfo) throws BridgeException, IOException {
		
		if(params instanceof HashMap){
			Map<String, Integer> param = (Map<String, Integer>) params;
			Integer bridgeId = param.get(ApplicationConstants.BRIDGE_ID);
			Integer rosterId = param.get(ApplicationConstants.REST_PARAM_ID);
			Bridge bridge = bridgeDAO.get(bridgeId);
			if(bridge==null || bridge.getDeleted()){
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			BridgeRosterLog bridgeRosterLog = bridgeRosterLogDAO.get(rosterId);
			if(bridgeRosterLog==null){
				throw new BridgeException(ApplicationCode.INVALID_INPUT);
			}
			
			URL fileURL = new URL(bridgeRosterLog.getFileURL());
	        URLConnection urlConn = fileURL.openConnection();
	        BufferedReader in = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
	        StringBuilder msgBuilder=new StringBuilder();
	        String msg;
	        while ((msg = in.readLine()) != null) 
	        	msgBuilder.append(msg).append(System.lineSeparator());
	        in.close();	    
	        msg=msgBuilder.toString();
	        httpServletResponse.setHeader("Content-Disposition", "attachment; filename=" + bridgeRosterLog.getFileName());
			httpServletResponse.setContentType("application/plain");
			httpServletResponse.setContentLength(msg.length());
			try{
					PrintWriter writer = httpServletResponse.getWriter();
					writer.write(msg);
					httpServletResponse.flushBuffer();
			} 
			catch (IOException e1) {
					e1.printStackTrace();
			}
			 
		}	
		
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public RestResponse uploadCSVRosterTemplate(HttpServletRequest httpRequest, UriInfo uriInfo, MultipartFile uploadFile, CSVFileType fileType) throws IOException, BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
 				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		
		if(null != uploadFile && null != fileType) {
			
			final String fileName=uploadFile.getOriginalFilename();
			final String ext   = fileName.substring(fileName.lastIndexOf(".")+1).toLowerCase();
			final long fileSize=uploadFile.getSize();
			
			if(!ext.equals("csv") || fileSize==0){
				response= new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(),ApplicationCode.UNSUPPORTED_FILE_TYPE.getCodeId(),
						localeMessageUtility.getMessage(ApplicationCode.UNSUPPORTED_FILE_TYPE.getCodeId()));
			} else if(fileSize > Long.parseLong(TomcatUtils.getParam("csv_filesize_limit"))){ 
				response= new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(),ApplicationCode.UNSUPPORTED_FILE_TYPE.getCodeId(),
						localeMessageUtility.getMessage(ApplicationCode.UNSUPPORTED_FILE_TYPE.getCodeId()));
			} else{	
				InputStream uploadedInputStream = uploadFile.getInputStream();
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				byte[] buffer = new byte[1024];
				int len;
				while ((len = uploadedInputStream.read(buffer)) > -1 ) {
				    baos.write(buffer, 0, len);
				}
				baos.flush();
				InputStream is = new ByteArrayInputStream(baos.toByteArray());
				final String fileUrl=Aws.uploadRosterFile(VstUtils.getDomain(uriInfo, httpRequest), is, ext, uploadFile.getSize());
				
				BridgeRosterTemplate rosterTemplate = bridgeRosterTemplateDAO.getByFileType(fileType.name());
				
				if(null != rosterTemplate) {
					rosterTemplate.setUrl(fileUrl);
					bridgeRosterTemplateDAO.update(rosterTemplate);
				} else {
					rosterTemplate = new BridgeRosterTemplate();
					rosterTemplate.setUrl(fileUrl);
					rosterTemplate.setName(fileType.name());
					bridgeRosterTemplateDAO.saveOrUpdate(rosterTemplate);
				}				
			}
		} else {
			throw new BridgeException(ApplicationCode.INVALID_INPUT);
		}
		return response;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public void downloadCSVRosterTemplate(CSVFileType fileType, HttpServletResponse httpServletResponse) throws IOException, BridgeException {
		if(null != fileType) {
			BridgeRosterTemplate rosterTemplate = bridgeRosterTemplateDAO.getByFileType(fileType.name());
			if(null!=rosterTemplate) {
				URL fileURL = new URL(rosterTemplate.getUrl());
				URLConnection urlConn = fileURL.openConnection();
				BufferedReader in = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
				StringBuilder msgBuilder=new StringBuilder();
		        String msg;
		        while ((msg = in.readLine()) != null) 
		        	msgBuilder.append(msg).append(System.lineSeparator());
		        in.close();	    
		        msg=msgBuilder.toString();
		        httpServletResponse.setHeader("Content-Disposition", "attachment; filename=" +  fileType.name().toLowerCase() + "_template.csv");
		        httpServletResponse.setContentType("application/plain");
				httpServletResponse.setContentLength(msg.length());
				try{
					PrintWriter writer = httpServletResponse.getWriter();
					writer.write(msg);
					httpServletResponse.flushBuffer();
					writer.close();
				} 
				catch (IOException e1) {						
						e1.printStackTrace();
				}
		        
			} else {
				throw new BridgeException(ApplicationCode.TEMPLATE_NOT_FOUND);
			}
		}

	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public RestResponse processCSVForGroupAssetsMapping(SessionStatusVO sessionStatusVO, HttpServletRequest httpRequest,
			UriInfo uriInfo, Integer bridgeId, MultipartFile uploadFile) throws IOException, BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
 				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		AdminUser adminUser = adminUserDAO.get(sessionStatusVO.getAdminId());
		String role = sessionStatusVO.getRoleName();
		if (!StringUtils.equals(role, ApplicationConstants.USER_ROLE_SUPER_ADMIN)) {
			throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE);
		}
		InputStream uploadedInputStream = uploadFile.getInputStream();
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		byte[] buffer = new byte[1024];
		int len;
		while ((len = uploadedInputStream.read(buffer)) > -1 ) {
		    baos.write(buffer, 0, len);
		}
		baos.flush();

		InputStream is1 = new ByteArrayInputStream(baos.toByteArray()); 		
		Reader in = new InputStreamReader(is1); 
		ICsvBeanReader beanReader = new CsvBeanReader(in, CsvPreference.STANDARD_PREFERENCE);
		String[] headers = beanReader.getHeader(true);
        StringBuffer sb= new StringBuffer();
        ArrayList<String> trimedList= new ArrayList<String>();
        String trimHead=null;
        for(String header: headers){
        	if(StringUtils.isNotEmpty(header))
        		trimHead = header.trim();
        		trimedList.add(trimHead);
        		sb.append(trimHead).append(",");
        }
        sb.deleteCharAt(sb.length()-1);
        headers=trimedList.toArray(headers);
        
        List<Object> beanList = new ArrayList<>();
        
        try{
        	BridgeGroupAssetMappingBean bridgeGroupAssetMappingBean=null;
        	final CellProcessor[] processors=getBridgeGroupBooksMappingProcessor(); 
        	while ((bridgeGroupAssetMappingBean = beanReader.read(BridgeGroupAssetMappingBean.class, headers, processors)) != null) {
				beanList.add(bridgeGroupAssetMappingBean);
			}
        	List<String> bookCacheList = bridgeBookCacheDAO.getCacheBookVbids(bridgeId);       	
        	
        	if(bookCacheList!=null && bookCacheList.size()>0){
        		List<GroupAsset> groupAssets = new ArrayList<GroupAsset>();
	        	for(int row=0;row<beanList.size();row++){
	        		bridgeGroupAssetMappingBean=(BridgeGroupAssetMappingBean)beanList.get(row);
	        		String vbid=bridgeGroupAssetMappingBean.getVbid();
	        		if(!bookCacheList.contains(vbid)){
	        			throw new BridgeException("vbid not found in connect :"+vbid,ApplicationCode.BOOK_NOT_FOUND);
	        		}
	        		String group = bridgeGroupAssetMappingBean.getGroup();
	        		BridgeGroup bridgeGroup = bridgeGroupDAO.getBridgeGroupByName(bridgeId, group);
	        		if(bridgeGroup==null){
	        			bridgeGroup = new BridgeGroup();
	        			bridgeGroup.setBridge(bridgeDAO.load(bridgeId));
	        			bridgeGroup.setName(group);	        			
	    				bridgeGroup.setCreatedBy(adminUser);
	    				bridgeGroup.setCreatedDate(new Date());
	    				bridgeGroup.setModifiedBy(adminUser);
	    				bridgeGroup.setModifiedDate(new Date());
	        			bridgeGroupDAO.saveOrUpdate(bridgeGroup);
	        		}
	        		
	        		GroupAsset groupAsset = bridgeGroupAssetDAO.getGroupAsset(bridgeGroup.getId(),vbid);
					groupAsset = null !=groupAsset ? groupAsset : new GroupAsset();
					groupAsset.setGroup(bridgeGroup);
					groupAsset.setVbid(vbid);
					groupAsset.setSelected(Boolean.TRUE);
					groupAsset.setLastUpdated(new Date());
					groupAssets.add(groupAsset);
					
	        	}
	        	bridgeGroupAssetDAO.saveOrUpdateAll(groupAssets);
        	}
        }
        finally{
        	beanReader.close();
        }
		return response;
	}
	
	private CellProcessor[] getBridgeGroupBooksMappingProcessor() {
		// sourcedId,status,dateLastModified,title,grade,courseSourcedId,classCode,classType,location,schoolSourcedId,termSourcedId,subjects
		final CellProcessor[] getBridgeGroupBooksMappingProcessor = new CellProcessor[] {
				new Optional(), // vbid
				new Optional(), // Group Name
		};

		return getBridgeGroupBooksMappingProcessor;
	}


}
