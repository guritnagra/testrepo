package com.vst.bridge.service.admin;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.VstException;
import com.vst.bridge.rest.input.vo.AdminUserProfileVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminUserEntityService {
	RestResponse getAdminUserInfo(SessionStatusVO sessionStatusVO,final Integer adminId,BridgePaginationVo bridgePaginationVo,final Boolean getAllUsers,UriInfo uriInfo)throws BridgeException;
	RestResponse createOrUpdateAdminUser(SessionStatusVO sessionStatusVO,AdminUserProfileVO adminUserProfileVO, Integer adminId, HttpServletRequest request, Boolean isNew,UriInfo uriInfo)throws BridgeException, ParseException, IOException, VstException;
	RestResponse getAdminUserInfoForId(Integer adminId,UriInfo uriInfo)throws BridgeException, ParseException, IOException;
	RestResponse deleteUser(SessionStatusVO sessionStatusVO, Integer id, HttpServletRequest httpRequest,UriInfo uriInfo) throws BridgeException;
}
