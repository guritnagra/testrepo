package com.vst.bridge.rest.response;

import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;

//@XmlRootElement
public abstract class RestResponse extends RestStatus
{
	protected String filename;
	protected Vector<NewCookie> cookies = new Vector<NewCookie>();
	
	public String getFilename() {
		return filename;
	}
	public Vector<NewCookie> getCookies() {
		return cookies;
	}
	public void cookie(NewCookie newCookie) 
	{
		this.cookies.add(newCookie);
		
	}
	
	public abstract Response build(HttpServletRequest hsr);
}
