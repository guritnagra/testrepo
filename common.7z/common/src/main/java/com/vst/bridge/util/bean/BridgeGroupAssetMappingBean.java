package com.vst.bridge.util.bean;

public class BridgeGroupAssetMappingBean {
	
	private String vbid;
	private String group;
	public String getVbid() {
		return vbid;
	}
	public void setVbid(String vbid) {
		this.vbid = vbid;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	
	
	

}
