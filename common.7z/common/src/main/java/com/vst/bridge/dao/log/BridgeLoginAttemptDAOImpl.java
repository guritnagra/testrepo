package com.vst.bridge.dao.log;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.log.BridgeLoginAttempt;

@Repository("bridgeLoginAttemptDAO")
public class BridgeLoginAttemptDAOImpl extends GenericDAO<BridgeLoginAttempt, Integer>
		implements IBridgeLoginAttemptDAO {

	public BridgeLoginAttemptDAOImpl() {
		super(BridgeLoginAttempt.class);
	}

	@Override
	public BridgeLoginAttempt getAttemptsByUserNameAndIPAddress(String username, String ipAddress){
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("username",username));
		criteria.add(Restrictions.eq("ipAddress",ipAddress));
		List<BridgeLoginAttempt> result = executeCriteira(criteria);
		return result != null && result.size()>0 ? result.get(0) : null;
	}

	@Override
	public BridgeLoginAttempt getAttemptsByUserName(String username) {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("username",username));
		List<BridgeLoginAttempt> result = executeCriteira(criteria);
		return result != null && result.size()>0 ? result.get(0) : null;
	}

}
