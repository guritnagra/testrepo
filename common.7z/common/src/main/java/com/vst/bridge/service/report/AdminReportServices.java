package com.vst.bridge.service.report;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookCacheDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookDAO;
import com.vst.bridge.dao.key.IKeyBatchDAO;
import com.vst.bridge.dao.key.IKeyDAO;
import com.vst.bridge.dao.log.IBridgeLogDAO;
import com.vst.bridge.dao.user.key.IBridgeUserKeyDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.BridgeUserKey;
import com.vst.bridge.entity.keys.KeyBatch;
import com.vst.bridge.entity.keys.Keys;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.rest.response.vo.report.BookLaunchCountVO;
import com.vst.bridge.rest.response.vo.report.KeyDetailsVO;
import com.vst.bridge.rest.response.vo.report.ReportBookActionCountVO;
import com.vst.bridge.rest.response.vo.report.ReportBookLaunchVO;
import com.vst.bridge.rest.response.vo.report.ReportBooksVOIntigrationVO;
import com.vst.bridge.rest.response.vo.report.ReportBridgeBookVO;
import com.vst.bridge.rest.response.vo.report.ReportCountDetails;
import com.vst.bridge.rest.response.vo.report.ReportCountWithTrialVO;
import com.vst.bridge.rest.response.vo.report.ReportKeyDetailVO;
import com.vst.bridge.rest.response.vo.report.ReportKeyUserVO;
import com.vst.bridge.rest.response.vo.report.ReportKeysDetailsVO;
import com.vst.bridge.rest.response.vo.report.ReportMetadataVO;
import com.vst.bridge.rest.response.vo.report.ReportSummaryVO;
import com.vst.bridge.rest.response.vo.report.ReportUserVO;
import com.vst.bridge.util.constant.ApplicationAction;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;


@Service("reportServices")
public class AdminReportServices implements IAdminReportServices{

	@Autowired
	private LocaleMessageUtility localeMessageUtility;
	
	@Autowired
	private IBridgeDAO bridgeDAO;
	
	@Autowired
	private IBridgeBookCacheDAO bridgeBookCacheDAO;
	
	@Autowired
	private IBridgeLogDAO bridgeLogDAO;
	
	@Autowired
	private IKeyBatchDAO keyBatchDAO;
		
	@Autowired
	private  IKeyDAO keyDAO;
	
	@Autowired
	private IBridgeUserKeyDAO bridgeUserKeyDAO;
	
	@Autowired
	private IBridgeBookDAO bridgeBooksDAO;
	
	private static Logger logger = LogManager.getLogger(AdminReportServices.class);
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getBooksForBridgeId(BridgePaginationVo bridgePaginationVo, String category) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		
		Integer bridgeId = bridgePaginationVo.getBridgeId();
		
		Bridge bridge = bridgeDAO.get(bridgeId);

		if(bridge==null || bridge.getDeleted()){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		this.validateAndRearangePaginationVO(bridgePaginationVo);
		
		ReportBridgeBookVO bridgeBookVo = this.getBridgeBooks(bridge,bridgePaginationVo, category);
		List<ReportBooksVOIntigrationVO> books = bridgeBookVo.getBooks();
		Integer currentPage = bridgePaginationVo.getPage();
		if(null != books && books.size() > 0){
			Integer totalRecords = books.size();
			Integer totalPages = this.calculateTotalPageCount(totalRecords, bridgePaginationVo.getLimit());
			Integer recordToFetch = bridgePaginationVo.getLimit();		
			if(currentPage <= totalPages){
				ReportMetadataVO reportMetadataVO = new ReportMetadataVO(totalRecords,totalPages,currentPage);
				response.setMetadata(reportMetadataVO);
				Integer startIndex = this.calculateStartIndexForReport(currentPage, recordToFetch);
				Integer lastIndex = startIndex+recordToFetch;
				lastIndex = lastIndex > totalRecords ? totalRecords : lastIndex; 
				List<ReportBooksVOIntigrationVO> bookList = books.subList(startIndex, lastIndex);
				bridgeBookVo.setBooks(bookList);
			}
			else{
				throw new BridgeException(ApplicationCode.INVALID_REPORT_PAGE);
			}
		} else {
			ReportMetadataVO reportMetadataVO = new ReportMetadataVO(0,currentPage,currentPage);
			response.setMetadata(reportMetadataVO);
		}
		
		response.setData(bridgeBookVo);
		
		return response;
	}

	private void validateAndRearangePaginationVO(BridgePaginationVo bridgePaginationVo) {
		Integer page = bridgePaginationVo.getPage();
		if(null==page || page==0){
			bridgePaginationVo.setPage(ApplicationConstants.DEFAULT_GET_BOOK_PAGE_VALUE);
		}
		
		Integer limit = bridgePaginationVo.getLimit();
		if(null==limit || limit==0){
			bridgePaginationVo.setLimit(ApplicationConstants.DEFAULT_GET_BOOK_LIMIT_VALUE);
		}
		
		String order = bridgePaginationVo.getOrderBy();
		if(StringUtils.isNotEmpty(order)){
			bridgePaginationVo.setOrder(ApplicationConstants.DEFAULT_GET_BOOK_ORDER_BY_VALUE);
			bridgePaginationVo.setOrderBy(ApplicationConstants.DEFAULT_GET_BOOK_ORDER_BY_VALUE);
		}
		
	}

	private ReportBridgeBookVO getBridgeBooks(Bridge bridge, BridgePaginationVo bridgePaginationVo, String category) {
		ReportBridgeBookVO bridgeBookVo = null;
		if(null != bridge){
			bridgeBookVo = new ReportBridgeBookVO();
			bridgeBookVo.setId(bridge.getId());
			bridgeBookVo.setName(bridge.getName());
			bridgeBookVo.setCompany(bridge.getCompany().getName());
			bridgeBookVo.setBooks(this.getBooks(bridge.getId(),bridgePaginationVo, category));
		}
		return bridgeBookVo;
	}

	private List<ReportBooksVOIntigrationVO> getBooks(Integer bridgeId, BridgePaginationVo bridgePaginationVo, String category) {
		List<ReportBooksVOIntigrationVO> books = null;
		
		List<String> vbids = bridgeBooksDAO.getBookIdsForBridge(bridgeId, false, false);
		
		//List<BridgeBookCache> cacheBooks = bridgeBookCacheDAO.getCacheBooks(bridgeId);
		List<BridgeBookCache> cacheBooks = bridgeBookCacheDAO.getCacheBooks(bridgeId, null,bridgePaginationVo, vbids, Boolean.FALSE, category);
		if(null != cacheBooks && cacheBooks.size() > 0){
			books = new ArrayList<ReportBooksVOIntigrationVO>();
			for(BridgeBookCache bookCache : cacheBooks){
				ReportBooksVOIntigrationVO reportBooksVO = new ReportBooksVOIntigrationVO();
			
				reportBooksVO.setAuthor(bookCache.getAuthor());
				reportBooksVO.setEdition(bookCache.getEdition());
				reportBooksVO.setIsbn(bookCache.getEbookIsbn());
				reportBooksVO.setTitle(bookCache.getTitle());
				String vbid = bookCache.getVbid();
				reportBooksVO.setVbid(vbid);
				reportBooksVO.setActivations(bridgeLogDAO.getTotalActivationsForBook(bridgeId, vbid));
				reportBooksVO.setIntegrations(bridgeLogDAO.getTotalIntigrationForBook(bridgeId, vbid));
				
				books.add(reportBooksVO);
			}
		}
		if(null != books){
			Collections.sort(books, new Comparator<ReportBooksVOIntigrationVO>() {
				@Override
		        public int compare(ReportBooksVOIntigrationVO o1, ReportBooksVOIntigrationVO o2) {
					return o1.getTitle().compareTo(o2.getTitle());
		           // return o2.getActivations().compareTo(o1.getActivations());
		        }
		    });
		}
		
		return books;
	}

	
	/**
	 * This method is used to calculate total page count for report
	 * 
	 * @param totalCount
	 * @param totalRowsToFetch
	 * @return {@link String}
	 */
	private Integer calculateTotalPageCount(final int totalCount, final int totalRowsToFetch) {
		final Integer pageCount = (int) Math.ceil((double) totalCount / totalRowsToFetch);
		return pageCount;
	}

	/**
	 * This method is used to calculate start index for report
	 * 
	 * @param currentPage
	 * @param totalRowsToFetch
	 * @return {@link Integer} value
	 */
	private Integer calculateStartIndexForReport(final int currentPage, final int totalRowsToFetch) {
		final Integer startIndex = (currentPage * totalRowsToFetch) - totalRowsToFetch;
		return startIndex;
	}
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getBookForVbid(Integer bridgeId, String vbid) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		
		Bridge bridge = bridgeDAO.get(bridgeId);
		if(bridge==null || bridge.getDeleted()){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
	
		BridgeBookCache bookCache = bridgeBookCacheDAO.getBookForVbid(bridgeId, vbid);
		if(bookCache != null){
			ReportBookActionCountVO bookActionCountVO = new ReportBookActionCountVO();
			bookActionCountVO.setId(bridge.getId());
			bookActionCountVO.setName(bridge.getName());
			bookActionCountVO.setCompany(bridge.getCompany().getName());
			
			bookActionCountVO.setTitle(bookCache.getTitle());
			bookActionCountVO.setAuthor(bookCache.getAuthor());
			bookActionCountVO.setEdition(bookCache.getEdition());
			bookActionCountVO.setIsbn(bookCache.getEbookIsbn());
			bookActionCountVO.setVbid(bookCache.getVbid());
			
			bookActionCountVO.setActivations(this.getActivations(vbid,bridgeId));
			bookActionCountVO.setIntegrations(this.getIntigrations(vbid,bridgeId));
			response.setData(bookActionCountVO);
		}else{
			throw new BridgeException(localeMessageUtility.getMessage(ApplicationCode.BOOK_NOT_FOUND.getCodeId()), ApplicationCode.BOOK_NOT_FOUND);
		}
		return response;
	}

	private ReportCountWithTrialVO getActivations(String vbid,Integer bridgeId) {
		ReportCountWithTrialVO reportCountWithTrialVO = new ReportCountWithTrialVO();
		Integer total = 0;
		Integer full = bridgeLogDAO.getGetCountForAction(bridgeId,ApplicationAction.FULL_BOOK.getCodeId(),vbid,null,null);
		Integer trial = bridgeLogDAO.getGetCountForAction(bridgeId,ApplicationAction.TRY_BOOK.getCodeId(),vbid,null,null);
		Integer rental = bridgeLogDAO.getGetCountForAction(bridgeId,ApplicationAction.RENT_BOOK.getCodeId(),vbid,null,null);
	//	Integer launch = bridgeLogDAO.getGetCountForAction(bridgeId,ApplicationAction.LAUNCH_BOOK.getCodeId(),vbid,null,null);
	//	Integer print = bridgeLogDAO.getGetCountForAction(bridgeId,ApplicationAction.PRINT_BOOK.getCodeId(),vbid);
	//	reportCountWithTrialVO.setLaunch(launch);
		reportCountWithTrialVO.setFull(full);
		reportCountWithTrialVO.setTrial(trial);
		reportCountWithTrialVO.setRental(rental);
		// TODO Change this when we have print credits from UI
		reportCountWithTrialVO.setPrint(0);
//		total = full+trial+rental+print;
		total = full+trial+rental;
		reportCountWithTrialVO.setTotal(total);
		return reportCountWithTrialVO;
	}

	private ReportCountDetails getIntigrations(String vbid,Integer bridgeId) {
		ReportCountDetails reportCountVO = new ReportCountWithTrialVO();
		
		Integer total = 0;
		Integer full = bridgeLogDAO.getGetCountForAction(bridgeId,ApplicationAction.CART_FULL.getCodeId(),vbid,null,null);
		Integer rental = bridgeLogDAO.getGetCountForAction(bridgeId,ApplicationAction.CART_RENT.getCodeId(),vbid,null,null);
		Integer print = bridgeLogDAO.getGetCountForAction(bridgeId,ApplicationAction.PRINT_BOOK.getCodeId(),vbid,null,null);
		reportCountVO.setFull(full);
		reportCountVO.setRental(rental);
		reportCountVO.setPrint(print);
		total = full+rental+print;
		reportCountVO.setTotal(total);
		
		return reportCountVO;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getKeysForBridgeId(BridgePaginationVo bridgePaginationVo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Integer bridgeId = bridgePaginationVo.getBridgeId();
		Bridge bridge = bridgeDAO.get(bridgeId);
		if(bridge==null || bridge.getDeleted()){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		
		this.validateAndRearangePaginationVO(bridgePaginationVo);
		
		List<Integer> keyBatchIds = keyBatchDAO.getAllKeyBatchesIds(bridgeId);
	//	if(null != keyBatchIds && keyBatchIds.size() > 0){
			ReportKeysDetailsVO reportKeysDetailsVO = new ReportKeysDetailsVO();
			reportKeysDetailsVO.setId(bridge.getId());
			reportKeysDetailsVO.setName(bridge.getName());
			reportKeysDetailsVO.setCompany(bridge.getCompany().getName());
			
			Integer recordToFetch = bridgePaginationVo.getLimit();
			Integer currentPage = bridgePaginationVo.getPage();
			Integer startIndex = this.calculateStartIndexForReport(currentPage, recordToFetch);
			
			String search = bridgePaginationVo.getSearch();
			Integer totalRecords = keyDAO.getTotalRecordsCount(keyBatchIds,search);
			List<Keys> keys = keyDAO.getKeysForKeyBatches(keyBatchIds,startIndex,recordToFetch,search);
			if(null != keys && keys.size() > 0){
				List<KeyDetailsVO> totalKeys = this.getKeysDetails(keys);
				Integer totalPages = this.calculateTotalPageCount(totalRecords, recordToFetch);
				ReportMetadataVO reportMetadataVO = new ReportMetadataVO(totalRecords,totalPages,currentPage);
				response.setMetadata(reportMetadataVO);
				reportKeysDetailsVO.setKeys(totalKeys);
			} else {
				ReportMetadataVO reportMetadataVO = new ReportMetadataVO(0,currentPage,currentPage);
				response.setMetadata(reportMetadataVO);
			}
			response.setData(reportKeysDetailsVO);
	//	}else
		return response;
	}

	private List<KeyDetailsVO> getKeysDetails(List<Keys> keys) {
		List<KeyDetailsVO> keyDetailsVOs = null;
		if(null != keys && keys.size() > 0){
			keyDetailsVOs = new ArrayList<KeyDetailsVO>();
			for(Keys key : keys){
				KeyBatch keyBatch = key.getKeyBatch();
				KeyDetailsVO keyDetailsVO = new KeyDetailsVO();
				keyDetailsVO.setCode(key.getKeyCode());
				keyDetailsVO.setNumUsersPerKey(key.getNoOfUsers());
				keyDetailsVO.setTotalUsed(bridgeUserKeyDAO.getKeyCodeUsedCount(key.getId()));
				keyDetailsVO.setRole(keyBatch.getRole().getName());
				keyDetailsVO.setCreated(keyBatch.getCreatedDate().getTime());
				keyDetailsVO.setCreatedDate(keyBatch.getCreatedDate());
				if(null!=key.getExpireDate())
					keyDetailsVO.setExpires(key.getExpireDate().getTime());
				keyDetailsVO.setExpiresDate(key.getExpireDate());
				keyDetailsVOs.add(keyDetailsVO);
			}
		}
		if(null != keyDetailsVOs){
			Collections.sort(keyDetailsVOs, new Comparator<KeyDetailsVO>() {
				@Override
		        public int compare(KeyDetailsVO o1, KeyDetailsVO o2) {
		            return o2.getTotalUsed().compareTo(o1.getTotalUsed());
		        }
		    });
		}
		return keyDetailsVOs;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getKeyDetailsForCode(Integer bridgeId, String keyCode) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		
		Bridge bridge = bridgeDAO.get(bridgeId);
		if(bridge==null || bridge.getDeleted()){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		
		Keys key = keyDAO.getKeyForCode(keyCode);
		if(null != key){
			KeyBatch keyBatch = key.getKeyBatch();
			if(keyBatch.getBridge().getId() != bridge.getId()){
				throw new BridgeException(ApplicationCode.INVALID_BRIDGE_KEY_CODE);
			}
			ReportKeyDetailVO keyDetailVO = new ReportKeyDetailVO();
			keyDetailVO.setId(bridge.getId());
			keyDetailVO.setName(bridge.getName());
			keyDetailVO.setCompany(bridge.getCompany().getName());
			keyDetailVO.setCode(keyCode);
			Date expiredDate = key.getExpireDate();
			keyDetailVO.setExpiredDate(expiredDate);
			if(null!=expiredDate)
				keyDetailVO.setExpires(expiredDate.getTime());
			keyDetailVO.setRole(keyBatch.getRole().getName());
			keyDetailVO.setUsers(this.getUsersForKeyCode(bridgeId,key));
			response.setData(keyDetailVO);
		}else{
			throw new BridgeException(ApplicationCode.KEY_NOT_FOUND);
		}
		return response;
	}

	private List<ReportUserVO> getUsersForKeyCode(Integer bridgeId, Keys key) {
		List<ReportUserVO> users = null;
		
		List<BridgeUserKey> userKeys = bridgeUserKeyDAO.getListOfUsersAssigedForKey(key.getId());
		if(null != userKeys && userKeys.size() > 0){
			users = new ArrayList<ReportUserVO>();
			for(BridgeUserKey userKey : userKeys){
				ReportUserVO reportUserVO = new ReportUserVO();
				BridgeUser user = userKey.getUser();
				reportUserVO.setEmail(user.getEmail());
				reportUserVO.setFirstName(user.getFirstName());
				reportUserVO.setLastName(user.getLastName());
				reportUserVO.setActivation(userKey.getActivationDate().getTime());
				reportUserVO.setActivationDate(userKey.getActivationDate());
				users.add(reportUserVO);
			}
		}
		
		return users;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getBridgeLoginSummary(Integer bridgeId, Date startDate, Date endDate) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		
		Bridge bridge = bridgeDAO.get(bridgeId);
		if(bridge==null || bridge.getDeleted()){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		startDate = this.checkAndRearrageDate(startDate,null);
		endDate = this.checkAndRearrageDate(endDate, new Date());
		List<Integer> loginUserIds = bridgeLogDAO.getBridgeLogsForAction(bridgeId, ApplicationAction.LOGIN.getCodeId(), Boolean.TRUE,startDate,endDate);
		
		ReportSummaryVO summaryVO = this.getReportSummaryForUsersIds(bridgeId,loginUserIds,Boolean.TRUE,startDate,endDate);
		
		response.setData(summaryVO);
		
		return response;
	}

	@SuppressWarnings("deprecation")
	private Date checkAndRearrageDate(Date date, Date defaultDate) {
		logger.debug("checkAndRearrageDate : received date = "+date);
	//	return null != date ? date : defaultDate;
		if(date != null && null != defaultDate){
			date.setHours(23);
			date.setMinutes(59);
			date.setSeconds(59);
		}
		
		logger.debug("checkAndRearrageDate : converted date = "+date);
		
		return date;
	}

	private ReportSummaryVO getReportSummaryForUsersIds(Integer bridgeId,List<Integer> userIds,Boolean uniqueUsers, Date startDate, Date endDate) {
		ReportSummaryVO summaryVO = null;
		if(null != userIds && userIds.size() > 0){
		//	List<Integer> keysAssignedToUsers = bridgeUserKeyDAO.getKeysAssigedToUsers(userIds);
			List<ReportKeyUserVO> keysAssignedToUsers = bridgeUserKeyDAO.getKeysAssigedToUsers(userIds, startDate, endDate);
			
			List<Integer> teacherKeys = keyDAO.getKeysForType(bridgeId,ApplicationConstants.BRIDGE_USER_ROLE_TEACHER,null);
			Integer totalTeachers = this.getTotalCounts(keysAssignedToUsers,teacherKeys);
			if(uniqueUsers){
				Set<ReportKeyUserVO> uniqueUsersSet = new HashSet<ReportKeyUserVO>(keysAssignedToUsers);
				keysAssignedToUsers = new ArrayList<ReportKeyUserVO>(uniqueUsersSet);
			}
			List<Integer> studentKeys = keyDAO.getKeysForType(bridgeId,ApplicationConstants.BRIDGE_USER_ROLE_STUDENT,null);
			Integer totalStudents = this.getTotalCounts(keysAssignedToUsers,studentKeys);
			summaryVO = new ReportSummaryVO();
			summaryVO.setTeachers(totalTeachers);
			summaryVO.setStudents(totalStudents);
			summaryVO.setTotal(totalStudents+totalTeachers);
		}
		return summaryVO;
	}

	private Integer getTotalCounts(List<ReportKeyUserVO> keysAssignedToUsers, List<Integer> keyIds) {
		Integer total = 0;
		if(null != keysAssignedToUsers && keysAssignedToUsers.size() > 0){
			if(null != keyIds && keyIds.size()  >0){
				for(Integer keyId : keyIds){
					for(ReportKeyUserVO keyUserVO : keysAssignedToUsers){
						if(keyId.intValue()==keyUserVO.getKeyId().intValue()){
							total++;
						}
					}
				}
			}
		}
		return total;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getBridgeKeyRedeemedSummary(Integer bridgeId, Date startDate, Date endDate) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		
		Bridge bridge = bridgeDAO.get(bridgeId);
		if(bridge==null || bridge.getDeleted()){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		startDate = this.checkAndRearrageDate(startDate,null);
		endDate = this.checkAndRearrageDate(endDate, new Date());
		
		List<Integer> keyReedemdedUsers = bridgeLogDAO.getBridgeLogsForAction(bridgeId, ApplicationAction.REGISTER_KEY.getCodeId(), Boolean.FALSE,startDate,endDate);
		
		ReportSummaryVO summaryVO = this.getReportSummaryForUsersIds(bridgeId,keyReedemdedUsers,Boolean.FALSE,startDate,endDate);
		
		response.setData(summaryVO);
		
		return response;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getBridgeCreditsSummary(Integer bridgeId, Date startDate, Date endDate) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		Bridge bridge = bridgeDAO.get(bridgeId);
		if(bridge==null || bridge.getDeleted()){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		
		startDate = this.checkAndRearrageDate(startDate,null);
		endDate = this.checkAndRearrageDate(endDate, new Date());
		
		Integer full = bridgeLogDAO.getGetCountForAction(bridgeId,ApplicationAction.FULL_BOOK.getCodeId(),null,startDate,endDate);
		Integer trial = bridgeLogDAO.getGetCountForAction(bridgeId,ApplicationAction.TRY_BOOK.getCodeId(),null,startDate,endDate);
		Integer rental = bridgeLogDAO.getGetCountForAction(bridgeId,ApplicationAction.RENT_BOOK.getCodeId(),null,startDate,endDate);
		Integer print = 0; //TODO get value from db when print credits added to UI
//		Integer launch =0;
		ReportCountWithTrialVO countVo = new ReportCountWithTrialVO();
		Integer total = full+trial+rental+print;
		countVo.setTotal(total);
		countVo.setFull(full);
		countVo.setTrial(trial);
		countVo.setRental(rental);
		countVo.setPrint(print);
	//	countVo.setLaunch(launch);
		response.setData(countVo);
		return response;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getBridgeBookLaunchSummary(Integer bridgeId, Integer limit,Date startDate, Date endDate)
			throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		Bridge bridge = bridgeDAO.get(bridgeId);
		if(bridge==null || bridge.getDeleted()){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		
		startDate = this.checkAndRearrageDate(startDate,null);
		endDate = this.checkAndRearrageDate(endDate, new Date());
		
		List<BookLaunchCountVO> launchedBooks = bridgeLogDAO.getBookLaunched(bridgeId, startDate, endDate);
		
		limit = null != limit && limit > 0 ? limit : 5;
		
		if(null != launchedBooks && launchedBooks.size() > 0){
			Collections.sort(launchedBooks, new Comparator<BookLaunchCountVO>() {
				@Override
		        public int compare(BookLaunchCountVO o1, BookLaunchCountVO o2) {
		            return o2.getCount().compareTo(o1.getCount());
		        }
		    });
		}
		
		limit = limit > launchedBooks.size() ? launchedBooks.size() : limit;
		
		launchedBooks = launchedBooks.subList(0, limit);
		
		response.setData(getBookLaunched(bridgeId,launchedBooks));
		
		return response;
	}
	
	
	private List<ReportBookLaunchVO> getBookLaunched(Integer bridgeId,List<BookLaunchCountVO> launchedBooks){
		List<ReportBookLaunchVO>books = null;
		if(null != launchedBooks && launchedBooks.size() > 0){
			books = new ArrayList<ReportBookLaunchVO>();
			for(BookLaunchCountVO bookLaunched : launchedBooks){
				BridgeBookCache bookCache = bridgeBookCacheDAO.getBookForVbid(bridgeId, bookLaunched.getVbid());
				if(null != bookCache){
					ReportBookLaunchVO book = new ReportBookLaunchVO();
					book.setAuthor(bookCache.getAuthor());
					book.setEdition(bookCache.getEdition());
					book.setIsbn(bookCache.getEbookIsbn());
					book.setTitle(bookCache.getTitle());
					book.setVbid(bookCache.getVbid());
					book.setTotalCount(bookLaunched.getCount().intValue());
					book.setFileType(bookCache.getFileType());
					books.add(book);
				}
			}
		}
		return books;
	}
	
/*	private List<String> getVbids(List<BookLaunchCountVO> launchedBooks){
		List<String> vbids = null;
		if(null != launchedBooks && launchedBooks.size() > 0){
			vbids = new ArrayList<String>();
			for(){
				
			}
		}
		return vbids;
	}*/
	
}
