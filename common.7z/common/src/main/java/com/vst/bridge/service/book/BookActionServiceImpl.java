package com.vst.bridge.service.book;

import java.io.IOException;

import java.net.MalformedURLException;
import java.nio.charset.Charset;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.JDOMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vst.bridge.MapDB;
import com.vst.bridge.VstException;
import com.vst.bridge.VstUtils;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookCacheDAO;
import com.vst.bridge.dao.bridge.purchase.IBridgePurchaseDAO;
import com.vst.bridge.dao.key.IKeyBatchEntitlementDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.dao.user.book.IBridgeUserBookAssignDAO;
import com.vst.bridge.dao.user.key.IBridgeUserKeyDAO;
import com.vst.bridge.entity.admin.purchase.BridgePurchase;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.entity.bridge.books.BridgeUserBookAssign;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.BridgeUserKey;
import com.vst.bridge.entity.keys.KeyBatch;
import com.vst.bridge.entity.keys.KeyBatchEntitlement;
import com.vst.bridge.entity.keys.Keys;
import com.vst.bridge.rest.response.vo.ContextVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.books.BookUrl;
import com.vst.bridge.rest.response.vo.user.AccessCodeResponseVO;
import com.vst.bridge.rest.response.vo.user.BookLicenseInfoVO;
import com.vst.bridge.util.constant.ApplicationAction;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.constant.ApplicationConstants.CodeType;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ApiKeys;
import com.vst.connectapi.ApiKeys.API_MODE;
import com.vst.connectapi.ConnectApiWrapper;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectLicense;
import com.vst.connectapi.StoriaUtils;

@Service("bookActionService")
public class BookActionServiceImpl implements IBookActionService {

	@Autowired
	private IBridgeDAO bridgeDAO;

	@Autowired
	private IBridgeUserBookAssignDAO bridgeUserBookAssignDAO;

	@Autowired
	private IBridgeBookCacheDAO bridgeBookCacheDAO;

	@Autowired
	private IBridgeUserDAO bridgeUserDAO;

	@Autowired
	private IBridgeUserKeyDAO bridgeUserKeyDAO;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private IKeyBatchEntitlementDAO keyBatchEntitlementDAO;

	@Autowired
	private IBridgePurchaseDAO bridgePurchaseDAO;

	@Autowired
	private BookServiceUtil bookServiceUtil;

	@Autowired
	private IBookLicenseService bookLicenseService;
	@Autowired
	private IBookEntitlementService bookEntitlementService;

	private Logger log = LogManager.getLogger(BookActionServiceImpl.class);

	public boolean isEncoded(String text) {
		Charset charset = Charset.forName("US-ASCII");
		String checked = new String(text.getBytes(charset), charset);
		return !checked.equals(text);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse launchBook(SessionStatusVO sessionStatusVO, String vbid, String linkLocation, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, VstException, ConnectApiException {
		RestResponse response = bookServiceUtil.getDefaultRestResponse();
		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		BridgeUser user = bridgeUserDAO.get(sessionStatusVO.getAdminId());
		String apiKey = bridge.getApiKey();
		String domain=null;
		try {
			domain = VstUtils.getUrlWithProtocol(httpRequest, VstUtils.getDomain(uriInfo, httpRequest));
		} catch (MalformedURLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ApiKeys.API_MODE mode = ApplicationConstants.getApiMode();
		String bookshelfUrl = bridge.getBookshelfUrl();
		Boolean isEmbeddedReader=bridge.getIsEmbeddedEnabled();
		ApiKeys key = new ApiKeys(mode, apiKey, "unused:lti_key", "unused:lti_secret");
		Map<String, List<ConnectLicense>> licenses = ConnectApiWrapper.getLicenses(key, user.getAccessToken(), vbid);
		Boolean hasValidLicense = null;
		if (null != licenses && licenses.size() > 0) {
			Map<String, Object> result = bookLicenseService.checkVbidHasLaunchFunctionality(licenses.get(vbid), vbid,
					null);
			hasValidLicense = (Boolean) result.get(ApplicationConstants.BOOK_HAS_VALID_LICENSE);
			if (hasValidLicense) {
				if (null != user) {

					String token;
					BookUrl bookUrl = new BookUrl();
					if (StringUtils.isNotEmpty(linkLocation)) {
						String url = createBookUrl(vbid, mode, bridge,domain);
						url = url + linkLocation;
						createRedirectURL(bridge, user, bookUrl, url);
						log.info("Deeplink with path param and location created: " + url);
					} else if (null != (token = MapDB.getInstance().getStore().get(user.getTenantUserId()))) {
						ContextVO context = null;
						if (bridge.getIsIntegrated() && null != user.getTenantUserId()) {
							try {
								context = objectMapper.readValue(token, ContextVO.class);
								log.info("Toke retrieved from server side persistence for user with bridge id: "
										+ user.getId());
							} catch (IOException e) {
								log.error("User token was not found", e);
							}
						}
						String contextVbid = null == context.getBookmetaVbid() ? context.getVbid()
								: context.getBookmetaVbid();
						String url = vbid.equals(contextVbid) ? createBookUrl(contextVbid, mode, bridge,domain)
								: createBookUrl(vbid, mode, bridge,domain);
						
						if (vbid.equals(contextVbid)) {
							String location = StringUtils.isEmpty(context.getLocation()) ? context.getCustomLocation()
									: context.getLocation();
							url = url + location;
							createRedirectURL(bridge, user, bookUrl, url);
							log.info("Deeplink with location from context created: " + url + " with context "
									+ context.getLtiSequenceIdent());
						} else {
							createRedirectURL(bridge, user, bookUrl, url);
							log.info("Deeplink created: " + url + " with context " + context.getLtiSequenceIdent());
						}
					} else {
						String url = createBookUrl(vbid, mode, bridge,domain);
						createRedirectURL(bridge, user, bookUrl, url);
						log.info("Book link created: " + url);
					}
					response.setData(bookUrl);
					bookServiceUtil.createBridgeLog(user.getId(), bridge, ApplicationAction.LAUNCH_BOOK, vbid);
				}
			}
		} else {
			response.setCode(HttpStatus.UNPROCESSABLE_ENTITY.value());
		}
		if (null != hasValidLicense && !hasValidLicense) {
			throw new BridgeException(ApplicationCode.LICENSE_NOT_FOUND);
		}
		return response;
	}

	private void createRedirectURL(Bridge bridge, BridgeUser user, BookUrl bookUrl, String url) throws VstException {
		String redirectUrl = StoriaUtils.createRedirectUrl(url, user.getAccessToken(), bridge.getApiKey());
		log.info("redirectUrl url : " + redirectUrl);
		bookUrl.setUrl(redirectUrl);
	}

	private String createBookUrl(String vbid, API_MODE mode, Bridge bridge,String domain) // bookId,
																					// String
																					// sectionId)
	{
		String bookshelfUrl=bridge.getBookshelfUrl();
		Boolean isEmbeddedReader=bridge.getIsEmbeddedEnabled();
		StringBuilder sb = new StringBuilder();
		if(!isEmbeddedReader){
			if (StringUtils.isNotBlank(bookshelfUrl)) {
				bookshelfUrl = bookshelfUrl.endsWith(ApplicationConstants.BOOK_URL) ? bookshelfUrl
						: bookshelfUrl.concat(ApplicationConstants.BOOK_URL);
				sb.append(bookshelfUrl).append(vbid);
			} else {
				switch (mode) {
				case dev:
					sb.append(ApplicationConstants.BOOKSHELF_URL_DEV).append(vbid);
					break;
				case stage:
					sb.append(ApplicationConstants.BOOKSHELF_URL_STAGE).append(vbid);
					break;
				case prod:
					sb.append(ApplicationConstants.BOOKSHELF_URL_PROD).append(vbid);
					break;
				default:
					throw new BridgeException(ApplicationCode.INVALID_BRIDGE_ACTION);
				}
			}
		}
		else{
			sb.append(domain + ApplicationConstants.USER_READER_PAGE + vbid);
		}

		return sb.toString();
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse tryBook(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException {
		RestResponse response = bookServiceUtil.getDefaultRestResponse();
		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		BridgeUser user = bridgeUserDAO.get(sessionStatusVO.getAdminId());
		String apiKey = bridge.getApiKey();
		BookLicenseInfoVO licenseInfoVO = bookLicenseService.checkTrialFunctinalityForVbid(vbid, user, null);
		if (null != licenseInfoVO && null != licenseInfoVO.getState()
				&& StringUtils.equals(licenseInfoVO.getState(), ApplicationConstants.BOOK_LICENSE_STATE_CREDIT)) {

			/*
			 * if(null!= bridge.getBridgeType() &&
			 * ApplicationConstants.BRIDGE_TYPE_SAMPLER.equals(bridge.
			 * getBridgeType().getType())){ //StoriaUtils.giveAccess(token,
			 * user.getAccessToken(), vbid, 1, Boolean.TRUE, null);
			 * StoriaUtils.giveAccess(token, user.getAccessToken(),
			 * vbid,CodeType.TRIAL, 1, null, bridge); } else{ // Method to
			 * create code and redeem code for vbid.
			 * //StoriaUtils.giveAccess(token, user.getAccessToken(), vbid, 30,
			 * Boolean.TRUE, null); StoriaUtils.giveAccess(token,
			 * user.getAccessToken(), vbid,CodeType.TRIAL, 30, null, bridge); }
			 */

			// TODO PAU-899
			AccessCodeResponseVO accessCodeResponseVO = StoriaUtils.giveAccess(apiKey, user.getAccessToken(), vbid,
					CodeType.TRIAL, bridge, null);

			List<BridgeUserKey> userKeys = bridgeUserKeyDAO.getListOfKeysAssigedForUser(user.getId());
			if (null != userKeys && userKeys.size() > 0) {
				BridgeUserKey key = userKeys.get(0);
				BridgeUserBookAssign userBook = new BridgeUserBookAssign();
				userBook.setKeyAssigned(key);
				userBook.setLastAccess(new Date());
				userBook.setBookshelfRedeemCode(accessCodeResponseVO.getRedeemCode());
				userBook.setExpires(accessCodeResponseVO.getExpires());
				userBook.setVbid(vbid);
				userBook.setUsedType(ApplicationConstants.BOOK_KEY_USED_TYPE_TRIAL);
				bridgeUserBookAssignDAO.saveOrUpdate(userBook);
			}
			/*
			 * ApiKeys.API_MODE mode= ApplicationConstants.getApiMode(); String
			 * bookshelfUrl=bridge.getBookshelfUrl(); String url =
			 * ApplicationConstants.createBookUrl(vbid,mode,bookshelfUrl);
			 * String redirectUrl = StoriaUtils.createRedirectUrl(url,
			 * user.getAccessToken(), token); BookUrl bookUrl = new BookUrl();
			 * bookUrl.setUrl(redirectUrl); response.setData(bookUrl);
			 */
			bookServiceUtil.createBridgeLog(user.getId(), bridge, ApplicationAction.TRY_BOOK, vbid);
		} else {
			throw new BridgeException(ApplicationCode.LICENSE_NOT_FOUND);
		}
		return response;
	}

	/*
	 * private String getUsedConcurrencyEntitlementName(String entitlementId) {
	 * KeyBatch keyBatch = keyBatchDAO.get(Integer.valueOf(entitlementId));
	 * if(keyBatch!=null && keyBatch.getConcurrencyEntitlementName()!=null)
	 * return keyBatch.getConcurrencyEntitlementName(); else return
	 * ApplicationConstants.BOOK_KEY_USED_TYPE_CONCURRENT; }
	 */

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse fullBook(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException {
		RestResponse response = bookServiceUtil.getDefaultRestResponse();

		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		BridgeUser user = bridgeUserDAO.get(sessionStatusVO.getAdminId());
		String apiKey = bridge.getApiKey();
		BookLicenseInfoVO licenseInfoVO = bookLicenseService.checkFullFunctinalityForVbid(vbid, user, bridge);

		if (null != licenseInfoVO && null != licenseInfoVO.getState()
				&& StringUtils.equals(licenseInfoVO.getState(), ApplicationConstants.BOOK_LICENSE_STATE_CREDIT)) {
			List<BridgeUserKey> userKeys = bridgeUserKeyDAO.getListOfKeysAssigedForUser(user.getId());
			if (null != userKeys && userKeys.size() > 0) {
				BridgeUserKey key = userKeys.get(0);

				// StoriaUtils.giveAccess(token, user.getAccessToken(), vbid,
				// null, Boolean.FALSE, null);
				AccessCodeResponseVO accessCodeResponseVO = StoriaUtils.giveAccess(apiKey, user.getAccessToken(), vbid,
						CodeType.FULL, bridge, null);
				BridgeUserBookAssign userBook = new BridgeUserBookAssign();
				userBook.setKeyAssigned(key);
				userBook.setLastAccess(new Date());
				userBook.setBookshelfRedeemCode(accessCodeResponseVO.getRedeemCode());
				userBook.getExpires();
				userBook.setVbid(vbid);
				userBook.setUsedType(ApplicationConstants.BOOK_KEY_USED_TYPE_FULL);
				bridgeUserBookAssignDAO.saveOrUpdate(userBook);

				/*
				 * ApiKeys.API_MODE mode= ApplicationConstants.getApiMode();
				 * String bookshelfUrl = bridge.getBookshelfUrl(); String url =
				 * ApplicationConstants.createBookUrl(vbid,mode,bookshelfUrl);
				 * String redirectUrl = StoriaUtils.createRedirectUrl(url,
				 * user.getAccessToken(), token); BookUrl bookUrl = new
				 * BookUrl(); bookUrl.setUrl(redirectUrl);
				 * response.setData(bookUrl);
				 */
				bookServiceUtil.createBridgeLog(user.getId(), bridge, ApplicationAction.FULL_BOOK, vbid);
			}
		}
		/*
		 * }else if(null != licenseInfoVO && null != licenseInfoVO.getState() &&
		 * StringUtils.equals(licenseInfoVO.getState(),
		 * ApplicationConstants.BOOK_LICENSE_STATE_PURCHASE)){ BridgeBookCache
		 * bookCache = bridgeBookCacheDAO.getBookForVbid(bridge.getId(), vbid);
		 * BookUrl bookUrl = null; // String url =
		 * com.vst.bridge.StringUtils.getFormatedString(bridge.getFullURL(),
		 * bookCache.getEbookIsbn(), vbid); // bookUrl.setUrl(url);
		 * 
		 * String fullURL = bridge.getFullURL();
		 * if(StringUtils.isNotBlank(fullURL) &&
		 * fullURL.contains(ApplicationConstants.ISBN10)){ bookUrl = new
		 * BookUrl(); String ebbokISBN = bookCache.getEbookIsbn();
		 * if(StringUtils.isNotBlank(ebbokISBN) && ebbokISBN.length() == 13){
		 * ebbokISBN = com.vst.bridge.StringUtils.ISBN1310(ebbokISBN); } String
		 * url = com.vst.bridge.StringUtils.getFormatedStringForISBN10(fullURL,
		 * ebbokISBN, vbid); bookUrl.setUrl(url); }else
		 * if(StringUtils.isNotBlank(fullURL) &&
		 * fullURL.contains(ApplicationConstants.ISBN13)){ bookUrl = new
		 * BookUrl(); String ebbokISBN = bookCache.getEbookIsbn();
		 * if(StringUtils.isNotBlank(ebbokISBN) && ebbokISBN.length() == 10){
		 * ebbokISBN = com.vst.bridge.StringUtils.ISBN1013(ebbokISBN); } String
		 * url = com.vst.bridge.StringUtils.getFormatedStringForISBN10(fullURL,
		 * ebbokISBN, vbid); bookUrl.setUrl(url); }
		 * 
		 * response.setData(bookUrl);
		 * bookServiceUtil.createBridgeLog(user.getId(),
		 * bridge,ApplicationAction.CART_FULL, vbid); }
		 */
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse purchaseBook(SessionStatusVO sessionStatusVO, String vbid, Integer purchaseId, String code)
			throws BridgeException, ParseException, IOException {
		RestResponse response = bookServiceUtil.getDefaultRestResponse();

		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (null != bridge) {
			if (bridge.getIsPurchasesEnabled() != null && !bridge.getIsPurchasesEnabled()) {
				throw new BridgeException(ApplicationCode.PURCHASE_NOT_ENABLED);
			}
			Integer userId = sessionStatusVO.getAdminId();
			String bridgeUrl = null;
			BridgeBookCache bookCache = bridgeBookCacheDAO.getBookForVbid(bridge.getId(), vbid);
			String textBookISBN = null;
			/*
			 * switch (action) {
			 * 
			 * case ApplicationConstants.PURCHASE_RENT: bridgeUrl =
			 * bridge.getRentalURL(); textBookISBN = bookCache.getEbookIsbn();
			 * bookServiceUtil.createBridgeLog(userId, bridge,
			 * ApplicationAction.PURCHASE_RENT_BOOK, vbid); break; case
			 * ApplicationConstants.PURCHASE_PRINT: bridgeUrl =
			 * bridge.getPrintBookURL(); textBookISBN =
			 * bookCache.getTextbookIsbn();
			 * bookServiceUtil.createBridgeLog(userId, bridge,
			 * ApplicationAction.PURCHASE_PRINT_BOOK, vbid); break; case
			 * ApplicationConstants.PURCHASE_FULL: bridgeUrl =
			 * bridge.getFullURL(); textBookISBN = bookCache.getEbookIsbn();
			 * bookServiceUtil.createBridgeLog(userId, bridge,
			 * ApplicationAction.PURCHASE_FULL_BOOK, vbid); break;
			 * 
			 * default: new
			 * BridgeExcepation(ApplicationCode.INVALID_BRIDGE_ACTION);
			 * 
			 * }
			 */
			BridgePurchase bridgePurchase = bridgePurchaseDAO.get(purchaseId);
			if (bridgePurchase != null) {
				bridgeUrl = bridgePurchase.getPurchaseUrl();
			}
			if (StringUtils.isNotBlank(bridgeUrl)) {

				BookUrl bookUrl = null;
				if (bridgeUrl.toUpperCase().contains("PISBN")) {
					textBookISBN = bookCache.getTextbookIsbn();
				} else {
					textBookISBN = bookCache.getEbookIsbn();
				}

				if (StringUtils.isNotBlank(bridgeUrl) && (bridgeUrl.contains(ApplicationConstants.PISBN10)
						|| bridgeUrl.contains(ApplicationConstants.EISBN10))) {
					bookUrl = new BookUrl();
					String url = null;
					if (StringUtils.isNotBlank(textBookISBN) && textBookISBN.length() == 13) {
						textBookISBN = com.vst.bridge.StringUtils.ISBN1310(textBookISBN);
					}
					if (bridgeUrl.contains(ApplicationConstants.PISBN10)) {
						url = com.vst.bridge.StringUtils.getFormatedStringForPISBN10(bridgeUrl, textBookISBN, vbid);
					} else {
						url = com.vst.bridge.StringUtils.getFormatedStringForEISBN10(bridgeUrl, textBookISBN, vbid);
					}
					bookUrl.setUrl(url);
				} else if (StringUtils.isNotBlank(bridgeUrl) && (bridgeUrl.contains(ApplicationConstants.PISBN13)
						|| bridgeUrl.contains(ApplicationConstants.EISBN13))) {
					bookUrl = new BookUrl();
					String url = null;
					if (StringUtils.isNotBlank(textBookISBN) && textBookISBN.length() == 10) {
						textBookISBN = com.vst.bridge.StringUtils.ISBN1013(textBookISBN);
					}
					if (bridgeUrl.contains(ApplicationConstants.PISBN13)) {
						url = com.vst.bridge.StringUtils.getFormatedStringForPISBN13(bridgeUrl, textBookISBN, vbid);
					} else {
						url = com.vst.bridge.StringUtils.getFormatedStringForEISBN13(bridgeUrl, textBookISBN, vbid);
					}
					bookUrl.setUrl(url);
				}
				response.setData(bookUrl);

			}

		} else {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse redeemVbid(SessionStatusVO sessionStatusVO, String vbid, Integer entitlementId, String code)
			throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException {
		RestResponse response = bookServiceUtil.getDefaultRestResponse();

		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		BridgeUser user = bridgeUserDAO.get(sessionStatusVO.getAdminId());
		String apiKey = bridge.getApiKey();
		BookLicenseInfoVO licenseInfoVO = bookEntitlementService.checkEntitlementFunctionalityForVbidById(vbid, user,
				bridge, entitlementId, null);
		if (null != licenseInfoVO && null != licenseInfoVO.getState()
				&& StringUtils.equals(licenseInfoVO.getState(), ApplicationConstants.BOOK_LICENSE_STATE_CREDIT)) {
			List<BridgeUserKey> userKeys = bridgeUserKeyDAO.getListOfKeysAssigedForUser(user.getId());
			BridgeUserKey userKey = this.checkForEntitlementIdKey(userKeys, entitlementId);
			KeyBatchEntitlement keyBatchEntitlement = keyBatchEntitlementDAO.get(entitlementId);
			if (keyBatchEntitlement == null) {
				throw new BridgeException(ApplicationCode.KEY_CODE_NOT_FOUND);
			}

			AccessCodeResponseVO accessCodeResponseVO = StoriaUtils.giveAccess(apiKey, user.getAccessToken(), vbid,
					bookEntitlementService.populateRedeemBookVOFromKeyBatchEntitlement(keyBatchEntitlement), bridge);

			BridgeUserBookAssign userBook = new BridgeUserBookAssign();
			userBook.setKeyAssigned(userKey);
			userBook.setLastAccess(new Date());
			userBook.setBookshelfRedeemCode(accessCodeResponseVO.getRedeemCode());
			userBook.setExpires(accessCodeResponseVO.getExpires());
			userBook.setVbid(vbid);
			userBook.setUsedType(entitlementId.toString());
			userBook.setKeyBatch(keyBatchEntitlement.getKeyBatch());
			bridgeUserBookAssignDAO.saveOrUpdate(userBook);
			ApplicationAction action = bookServiceUtil.getActionType(licenseInfoVO.getType());
			bookServiceUtil.createBridgeLog(user.getId(), bridge, action, vbid);
		}
		return response;
	}

	private BridgeUserKey checkForEntitlementIdKey(List<BridgeUserKey> userKeys, Integer entitlementId) {
		for (BridgeUserKey buk : userKeys) {
			Keys key = buk.getKey();
			KeyBatch keyBatch = key.getKeyBatch();
			List<KeyBatchEntitlement> keyBatchEntitlementList = keyBatchEntitlementDAO
					.getAllEntitlementsForKeyBatch(keyBatch.getId());
			for (KeyBatchEntitlement kbe : keyBatchEntitlementList) {
				if (kbe.getId().equals(entitlementId))
					return buk;
			}
		}
		return null;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse rentBook(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException {
		RestResponse response = bookServiceUtil.getDefaultRestResponse();

		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		BridgeUser user = bridgeUserDAO.get(sessionStatusVO.getAdminId());
		String apiKey = bridge.getApiKey();
		BookLicenseInfoVO licenseInfoVO = bookLicenseService.checkRentalFunctinalityForVbid(vbid, user, bridge);

		if (null != licenseInfoVO && null != licenseInfoVO.getState()
				&& StringUtils.equals(licenseInfoVO.getState(), ApplicationConstants.BOOK_LICENSE_STATE_CREDIT)) {

			List<BridgeUserKey> userKeys = bridgeUserKeyDAO.getListOfKeysAssigedForUser(user.getId());
			if (null != userKeys && userKeys.size() > 0) {
				BridgeUserKey key = userKeys.get(0);
				AccessCodeResponseVO accessCodeResponseVO = StoriaUtils.giveAccess(apiKey, user.getAccessToken(), vbid,
						CodeType.RENTAL, bridge, key);
				BridgeUserBookAssign userBook = new BridgeUserBookAssign();
				userBook.setKeyAssigned(key);
				userBook.setLastAccess(new Date());
				userBook.setBookshelfRedeemCode(accessCodeResponseVO.getRedeemCode());
				userBook.setExpires(accessCodeResponseVO.getExpires());
				userBook.setVbid(vbid);
				userBook.setUsedType(ApplicationConstants.BOOK_KEY_USED_TYPE_RENTAL);
				bridgeUserBookAssignDAO.saveOrUpdate(userBook);
			}
			bookServiceUtil.createBridgeLog(user.getId(), bridge, ApplicationAction.RENT_BOOK, vbid);
		}

		return response;
	}

}
