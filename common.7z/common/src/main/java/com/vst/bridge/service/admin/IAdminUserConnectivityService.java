package com.vst.bridge.service.admin;

import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminUserConnectivityService {
	RestResponse connectivityMonitorCheck() throws BridgeException;
}
