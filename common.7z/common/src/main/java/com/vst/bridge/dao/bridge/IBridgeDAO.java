package com.vst.bridge.dao.bridge;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.rest.response.vo.BridgeTenantVO;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeDAO extends IGenericDAO<Bridge,Integer>{
	List<Bridge> getBrigesList(final List<Integer> companyIds,final Boolean deleted,final Integer startIndex,BridgePaginationVo paginationVo,Boolean isSuperAdmin)throws BridgeException;
	List<IdValueVO> getListOfApiKeys()throws BridgeException;
	Bridge getBridgeForCode(final String code)throws BridgeException;
	Bridge getBridgeForAlias(final String alias)throws BridgeException;
	void checkBridgeNameExist(String name, Integer bridgeId)throws BridgeException;
	Integer getBridgesCount(final List<Integer> companyIds,final Boolean deleted,BridgePaginationVo paginationVo,final Boolean isSuperAdmin)throws BridgeException;
	void checkBridgeCodeUnique(String code)throws BridgeException;
	List<Bridge> getAllBridges()throws BridgeException;
	void checkBridgeAliasUnique(final String alias) throws BridgeException;
	List<BridgeTenantVO> getIntegratedBridgesTenant()throws BridgeException;
}
