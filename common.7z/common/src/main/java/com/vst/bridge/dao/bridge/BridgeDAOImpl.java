package com.vst.bridge.dao.bridge;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.rest.response.vo.BridgeTenantVO;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeDAO")
public class BridgeDAOImpl extends GenericDAO<Bridge, Integer> implements IBridgeDAO{

	public BridgeDAOImpl() {
		super(Bridge.class);
	}

	@Override
	public Integer getBridgesCount(List<Integer> companyIds, final Boolean deleted,BridgePaginationVo paginationVo,final Boolean isSuperAdmin)
			throws BridgeException {
		Criteria criteria = getCriteria();
		if(null != companyIds && companyIds.size() > 0){
			criteria.add(Restrictions.in("company.id", companyIds));
		}else if(!isSuperAdmin){
			return 0;
		}
		String search = paginationVo.getSearch();
		if(null!=search && !StringUtils.isEmpty(search)){
			
			Criterion criterion1 = Restrictions.ilike("name", "%"+search+"%");
			Criterion criterion2 = Restrictions.ilike("contactName", "%"+search+"%");
			Criterion criterion3 = Restrictions.ilike("email", "%"+search+"%");
			Criterion criterion4 = Restrictions.ilike("code", "%"+search+"%");
			Criterion criterion5 = Restrictions.ilike("language", "%"+search+"%");

			Criterion completeCriterion = Restrictions.disjunction()
																.add(criterion1)
																.add(criterion2)
																.add(criterion3)
																.add(criterion4)
																.add(criterion5);
			
			criteria.add(completeCriterion);
		}
		criteria.add(Restrictions.eq("deleted", deleted));
		List<Bridge> result = executeCriteira(criteria);
		if(null != result && result.size()>0){
			return result.size();
		}
 		return 0;
	}
	
	@Override
	public List<Bridge> getBrigesList(List<Integer> companyIds,final Boolean deleted,final Integer startIndex,BridgePaginationVo paginationVo,Boolean isSuperAdmin)throws BridgeException {
		Criteria criteria = getCriteria();
		if(isSuperAdmin!=null && !isSuperAdmin){
			if(null != companyIds && companyIds.size() > 0){
				criteria.add(Restrictions.in("company.id", companyIds));
			}
			else{
				return null;
			}
		}
		if(null!=paginationVo){
			Integer totalRecordToFetch = paginationVo.getLimit();
			if(null != startIndex && null != totalRecordToFetch  && totalRecordToFetch > 0){
				criteria.setFirstResult(startIndex);
				criteria.setMaxResults(totalRecordToFetch);
			}
			
			String search = paginationVo.getSearch();
			if(null!=search && !StringUtils.isEmpty(search)){
				
				Criterion criterion1 = Restrictions.ilike("name", "%"+search+"%");
				Criterion criterion2 = Restrictions.ilike("contactName", "%"+search+"%");
				Criterion criterion3 = Restrictions.ilike("email", "%"+search+"%");
				Criterion criterion4 = Restrictions.ilike("code", "%"+search+"%");
				Criterion criterion5 = Restrictions.ilike("language", "%"+search+"%");

				Criterion completeCriterion = Restrictions.disjunction()
																	.add(criterion1)
																	.add(criterion2)
																	.add(criterion3)
																	.add(criterion4)
																	.add(criterion5);
				
				criteria.add(completeCriterion);
			}
			
			String orderBy = paginationVo.getOrderBy();
			if(null != orderBy && !StringUtils.isEmpty(orderBy)){
				String order = paginationVo.getOrder();
				if(order.equals(ApplicationConstants.SORTING_ORDER_ASC)){
					criteria.addOrder(Order.asc(orderBy));
				}else{
					criteria.addOrder(Order.desc(orderBy));
				}
			}
		}
		criteria.add(Restrictions.eq("deleted", deleted));
		return executeCriteira(criteria);
	}

	@Override
	public List<IdValueVO> getListOfApiKeys()
			throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("pendingApproved", Boolean.FALSE));
		criteria.setProjection(Projections.projectionList()
				.add( Projections.property("id").as("id"))
				.add( Projections.property("apiKey").as("value")))
				.setResultTransformer(new AliasToBeanResultTransformer(IdValueVO.class));
		return executeCriteira(criteria);
	}

	@Override
	public Bridge getBridgeForCode(String code) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.like("code", code));
		List<Bridge> result = executeCriteira(criteria);
		return null != result && result.size() > 0 ? result.get(0) : null;
	}

	@Override
	public void checkBridgeNameExist(String name,Integer bridgeId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.ilike("name", name.trim()));
		if(bridgeId!=null)
			criteria.add(Restrictions.ne("id", bridgeId));
		List<Bridge> result = executeCriteira(criteria);
		 if(null != result && result.size() > 0){
			 throw new BridgeException(ApplicationCode.DUPLICATE_BRIDGE_NAME);
		 }
	}

	@Override
	public void checkBridgeCodeUnique(String code) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.ilike("code", code.trim()));
		List<Bridge> result = executeCriteira(criteria);
		 if(null != result && result.size() > 0){
			 throw new BridgeException(ApplicationCode.DUPLICATE_BRIDGE_CODE);
		 }
	}

	@Override
	public List<Bridge> getAllBridges() throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		return executeCriteira(criteria);
	}
	
	
	@Override
	public void checkBridgeAliasUnique(String alias) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.ilike("domainAlias", alias.trim()));
		List<Bridge> result = executeCriteira(criteria);
		 if(null != result && result.size() > 0){
			 throw new BridgeException(ApplicationCode.DUPLICATE_BRIDGE_ALIAS);
		 }
	}

	@Override
	public Bridge getBridgeForAlias(String alias) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.ilike("domainAlias", alias));
		List<Bridge> result = executeCriteira(criteria);
		return null != result && result.size() > 0 ? result.get(0) : null;
	}

	@Override
	public List<BridgeTenantVO> getIntegratedBridgesTenant() throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.eq("isIntegrated", Boolean.TRUE));
		criteria.add(Restrictions.isNotNull("bcTenantId"));
		criteria.setProjection(Projections.projectionList()
				.add( Projections.property("id").as("bridgeId"))
				.add( Projections.property("bcTenantId").as("bcTenantId")))
				.setResultTransformer(new AliasToBeanResultTransformer(BridgeTenantVO.class));
		return executeCriteira(criteria);
	}
}
