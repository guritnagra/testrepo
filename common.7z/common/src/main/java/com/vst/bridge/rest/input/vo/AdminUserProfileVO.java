package com.vst.bridge.rest.input.vo;

import java.util.List;

import com.vst.bridge.annotation.custom.InputRequired;

public class AdminUserProfileVO {
	
	private List<SystemUserInfoVO> systemUserInfo;
	private String type;
		
	@InputRequired(required=false)
	private List<Integer> companies;
	
	@InputRequired(required=false)
	private PermissionLevelVO permission;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}	
	public List<Integer> getCompanies() {
		return companies;
	}
	public void setCompanies(List<Integer> companies) {
		this.companies = companies;
	}
	public PermissionLevelVO getPermission() {
		return permission;
	}
	public void setPermission(PermissionLevelVO permission) {
		this.permission = permission;
	}
	public List<SystemUserInfoVO> getSystemUserInfo() {
		return systemUserInfo;
	}
	public void setSystemUserInfo(List<SystemUserInfoVO> systemUserInfo) {
		this.systemUserInfo = systemUserInfo;
	}
}
