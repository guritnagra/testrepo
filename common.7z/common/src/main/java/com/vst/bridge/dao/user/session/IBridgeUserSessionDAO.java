package com.vst.bridge.dao.user.session;

import java.util.Date;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.session.BridgeUserSession;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeUserSessionDAO extends IGenericDAO<BridgeUserSession, Integer>{
	BridgeUserSession getForSessionId(final String sessionId,Boolean updateLastAcess,Date lastAcessdate)throws BridgeException;
	BridgeUser getBridgeUserForSessionId(final String sessionId)throws BridgeException;
}
