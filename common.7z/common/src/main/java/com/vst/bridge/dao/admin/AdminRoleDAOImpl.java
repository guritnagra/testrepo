package com.vst.bridge.dao.admin;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.role.AdminRole;
import com.vst.bridge.util.exception.BridgeException;

@Repository("adminRoleDAO")
public class AdminRoleDAOImpl extends GenericDAO<AdminRole, Integer> implements IAdminRoleDAO{

	public AdminRoleDAOImpl() {
		super(AdminRole.class);
	}

	@Override
	public AdminRole getUserForRoleName(String name) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.like("name", name));
		List<AdminRole> result = executeCriteira(criteria);
		return null != result && result.size() >0 ? result.get(0) : null;
	}
}
