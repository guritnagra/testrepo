package com.vst.bridge.util.constant;

public enum ServicePath {
	BOOKHOLDER("/bookholder"),
	BOOKS("/books/book"),
	BOOK_SELECTOR("/books"),
	MOBILE_SSO("/auth/redirect"),
	ENGAGEMENT_DASHBOARD("/engagement_dashboard"),
	OPT_OUT_TOOL("/tenants/hayesbarton/opt_out_tool"),;

	private final String path;

	private ServicePath(final String path) {
		this.path = path;
	}

	public String getPath() {
		return this.path;
	}
	
	public static ServicePath getPathFromString(final String path){
		for(ServicePath servicePath:values()){
			if(servicePath.path.equals(path)){
				return servicePath;
			}
		}
		
		return null;
	}
	
	@Override
	public String toString() {
		return path;
	}

}
