package com.vst.bridge.rest.response.vo.report;

import java.util.Date;
import java.util.List;

public class ReportKeyDetailVO {
	private Integer id;
	private String name;
	private String company;
	private String role;
	private String code;
	private Date expiredDate;
	private Long expires;
	private List<ReportUserVO> users;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public List<ReportUserVO> getUsers() {
		return users;
	}
	public void setUsers(List<ReportUserVO> users) {
		this.users = users;
	}
	public Date getExpiredDate() {
		return expiredDate;
	}
	public void setExpiredDate(Date expiredDate) {
		this.expiredDate = expiredDate;
	}
	public Long getExpires() {
		return expires;
	}
	public void setExpires(Long expires) {
		this.expires = expires;
	}
}
