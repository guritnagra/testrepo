package com.vst.bridge.service.user;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.JsonUtils;
import com.vst.bridge.VstUtils;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupUserDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.dao.user.token.IBridgeUserEmailTokenDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.token.BridgeUserEmailToken;
import com.vst.bridge.entity.group.BridgeGroup;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.user.BridgeUserInfoVO;
import com.vst.bridge.rest.response.vo.user.UserDetailsVO;
import com.vst.bridge.util.constant.ApplicationAction;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.error.ErrorHandlerUtil;
import com.vst.bridge.util.error.ResponseError;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.connectapi.ApiKeys;
import com.vst.connectapi.ConnectApiWrapper;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiFieldException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;
import com.vst.connectapi.ConnectCredentials;
import com.vst.connectapi.ConnectUser;

@Service("userEntityService")
public class UserEntityServiceImpl implements IUserEntityService{

	@Autowired
	private IBridgeUserDAO bridgeUserDAO;
	
	@Autowired
	private LocaleMessageUtility localeMessageUtility;
	
	@Autowired
	private ErrorHandlerUtil errorHandlerUtility;
		
	@Autowired
	private IBridgeDAO bridgeDAO;
	
	@Autowired
	private IBridgeUserEmailTokenDAO bridgeUserEmailTokenDAO;
	
	@Autowired
	private IBridgeGroupUserDAO bridgeGroupUserDAO;
	
	@Autowired
	private IBridgeGroupDAO bridgeGroupDAO;
	
	@Autowired
	private UserServiceUtil userServiceUtil;

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public RestResponse createOrUpdateUser(SessionStatusVO sessionStatusVO,HttpServletRequest httpRequest,UserDetailsVO newUserRequest, UriInfo uriInfo,String code,Boolean isNew,UserDetailsVO newDummyUser,Boolean isReferenceUser) throws BridgeException, ParseException, IOException, ConnectApiException, ConnectApiXmlException, ConnectApiFieldException, ConnectApiHttpException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		final Integer userId = null != sessionStatusVO ? sessionStatusVO.getAdminId() : null;
		BridgeUser bridgeUser = new BridgeUser();
		
		ResponseError responseError = isNew && null != newUserRequest ? errorHandlerUtility.validateCreateUserInputParameters(JsonUtils.getJsonString(newUserRequest)) : null;
		ConnectUser connectUser = null; 
		if(responseError==null){
			Bridge bridge = bridgeDAO.getBridgeForCode(code);
			ConnectCredentials credentials = null;
			if(null != bridge){
				UserDetailsVO userDetails = null != newUserRequest ? newUserRequest : newDummyUser;
				ApiKeys apikeys = new ApiKeys(ApplicationConstants.getApiMode(), bridge.getApiKey(), "unused:lti_key", "unused:lti_secret");
				if(isNew){
					if(bridge.getIsRostered() && StringUtils.isBlank(bridgeUser.getAccessToken()) && StringUtils.isBlank(bridgeUser.getGuid())){
						bridgeUser=bridgeUserDAO.getForEmail(bridge.getId(),newUserRequest.getEmail());
					}
					else{
						bridgeUser = new BridgeUser();
					}
					if(userDetails.getPassword()!=null && !VstUtils.isValidPassword(userDetails.getPassword())){
						throw new BridgeException(ApplicationCode.PASSWORD_NOT_VALID);
					}
					connectUser = ConnectApiWrapper.addUser(apikeys, userDetails,isReferenceUser);
					if(null != isReferenceUser && !isReferenceUser){
						credentials = ConnectApiWrapper.verifyCredentials(apikeys, connectUser.getEmail(), userDetails.getPassword());
					}
					
				}else{
					bridgeUser = bridgeUserDAO.get(userId);
					if(bridgeUser==null){
						throw new BridgeException(ApplicationCode.USER_NOT_FOUND);
					}
					connectUser = ConnectApiWrapper.updateUser(apikeys,bridgeUser,userDetails);
					credentials = new ConnectCredentials(connectUser.getGuid(), connectUser.getAccessToken());
				}
				if(bridge.getIsRostered() && StringUtils.isBlank(bridgeUser.getAccessToken()) && StringUtils.isBlank(bridgeUser.getGuid())){
					List<BridgeUserEmailToken> bridgeUserTokenList=bridgeUserEmailTokenDAO.getList(bridge.getId(), bridgeUser.getEmail(), Boolean.FALSE);
					
					if(bridgeUserTokenList!=null && bridgeUserTokenList.size()>0){
						BridgeUserEmailToken bridgeUserEmailToken= bridgeUserTokenList.get(0);
						bridgeUserEmailToken.setUsed(Boolean.TRUE);
						bridgeUserEmailToken.setActivationDate(new Date());
						bridgeUserEmailTokenDAO.saveOrUpdate(bridgeUserEmailToken);
					}
					else{
						throw new BridgeException(ApplicationCode.EXPIRED_TOKEN);
					}
				}
				userServiceUtil.populateBridgeUserDetailsFromConnectUser(bridgeUser, bridge, connectUser, credentials);
				bridgeUserDAO.saveOrUpdate(bridgeUser);
							
				BridgeUserInfoVO userInfoVO = userServiceUtil.populateBridgeUserInfoFromBridgeUser(bridgeUser);
				if(isNew){
					userServiceUtil.createBridgeLog(bridgeUser.getId(), bridge, ApplicationAction.USER_CREATED, bridgeUser.getEmail());
				}else{
					userServiceUtil.createBridgeLog(bridgeUser.getId(), bridge, ApplicationAction.USER_INFO_UPDATED, bridgeUser.getEmail());
				}
				response.setData(userInfoVO);
		}
		else{
				throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
			}
		}else{
			response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
			response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
			response.setError(responseError);
		}
		return response;
	}
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getGroups(SessionStatusVO sessionStatusVO,String code) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(), 
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if(null != bridge){
			BridgeUser bridgeUser = bridgeUserDAO.get(sessionStatusVO.getAdminId());
			List<BridgeGroup> groups = bridgeGroupUserDAO.getGroupsForUser(bridgeUser.getId(), Boolean.FALSE, Boolean.TRUE, Boolean.TRUE);
			Set<IdValueVO> groupsVO = new TreeSet<IdValueVO>();
			List<BridgeGroup> autoAssignGroups = bridgeGroupDAO.getAllAutoAssignGroups(bridge.getId(), Boolean.FALSE, Boolean.FALSE);
			if(autoAssignGroups!=null && autoAssignGroups.size()>0){
				groups.addAll(autoAssignGroups);
			}
			if(null != groups && groups.size() > 0) {
				for(BridgeGroup group : groups) {
					groupsVO.add(this.populateBridgeGroupInfoFromGroupUser(group));
				}
			}
			response.setData(groupsVO);
		}
		else{
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		return response;
	}
	
	private IdValueVO populateBridgeGroupInfoFromGroupUser(BridgeGroup group) {
		IdValueVO idValueVO = new IdValueVO();
		idValueVO.setId(group.getId());
		idValueVO.setValue(group.getName());
		return idValueVO;
	}


}
