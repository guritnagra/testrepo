package com.vst.bridge.service.admin;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.rest.response.vo.GroupVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminUserGroupService {
	RestResponse getGroups(SessionStatusVO sessionStatusVO,UriInfo uriInfo)throws BridgeException;
	RestResponse createOrUpdateGroups(SessionStatusVO sessionStatusVO,GroupVO groupVO, Integer groupId,UriInfo uriInfo, HttpServletRequest httpRequest)throws BridgeException, ParseException, IOException;
	RestResponse getAllGroupsWithCompanies(SessionStatusVO sessionStatusVO)throws BridgeException;
}
