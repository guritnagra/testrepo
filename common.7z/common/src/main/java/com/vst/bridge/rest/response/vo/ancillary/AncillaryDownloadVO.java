package com.vst.bridge.rest.response.vo.ancillary;

import com.vst.bridge.entity.admin.ancillary.Ancillary;

public class AncillaryDownloadVO {

	private Integer id;
	private String title;
	private String fileName;
	private String link;
	private String vbid;
	private Integer fileSize;
	private Integer bridgeId;
	public Integer getId() {
		return id;
	}
	
	public AncillaryDownloadVO(){
		
	}
	public AncillaryDownloadVO(Ancillary ancillary){
		if(null!=ancillary){
			this.id=ancillary.getId();
			this.title=ancillary.getTitle();
			this.fileName=ancillary.getFileName();
			this.vbid=ancillary.getVbid();
			this.fileSize=ancillary.getFileSize();
			this.bridgeId=ancillary.getBridge().getId();
		}
		
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getVbid() {
		return vbid;
	}
	public void setVbid(String vbid) {
		this.vbid = vbid;
	}
	public Integer getFileSize() {
		return fileSize;
	}
	public void setFileSize(Integer fileSize) {
		this.fileSize = fileSize;
	}
	public Integer getBridgeId() {
		return bridgeId;
	}
	public void setBridgeId(Integer bridgeId) {
		this.bridgeId = bridgeId;
	}
	
	
}
