package com.vst.bridge.util.error;

public interface  IResponseError {
	public  void setType(final String type);
	public  String getType();
	public  void setData(final Object data);
	public  Object getData();
}
