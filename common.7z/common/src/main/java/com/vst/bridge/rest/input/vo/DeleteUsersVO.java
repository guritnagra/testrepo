package com.vst.bridge.rest.input.vo;

import java.util.List;

public class DeleteUsersVO {
	private List<Integer> users;

	public List<Integer> getUsers() {
		return users;
	}

	public void setUsers(List<Integer> users) {
		this.users = users;
	}
	
}
