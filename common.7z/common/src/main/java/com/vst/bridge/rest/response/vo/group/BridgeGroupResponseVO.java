package com.vst.bridge.rest.response.vo.group;

import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.vst.bridge.annotation.custom.CustomDateSerializer;

public class BridgeGroupResponseVO {
	
	private Integer id;
	private Integer bridgeId;
    private String groupName;
    private Date activationDate;
    private long activationTime;
    private Date expirationDate;
    private long expirationTime;
    private Boolean isExpired=Boolean.FALSE;
    private String courseId;
    private Boolean isGroupAlive=Boolean.FALSE;
    private Boolean isAutoAssignUser;
    private Boolean isHidden;
    private Boolean isAutoAssignAsset;
    /*private Date created;
    private long createdTime;*/
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getBridgeId() {
		return bridgeId;
	}
	public void setBridgeId(Integer bridgeId) {
		this.bridgeId = bridgeId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getActivationDate() {
		return activationDate;
	}
	public void setActivationDate(Date activationDate) {
		this.activationDate = activationDate;
	}
	public long getActivationTime() {
		return activationTime;
	}
	public void setActivationTime(long activationTime) {
		this.activationTime = activationTime;
	}
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}
	public long getExpirationTime() {
		return expirationTime;
	}
	public void setExpirationTime(long expirationTime) {
		this.expirationTime = expirationTime;
	}
	/*@JsonSerialize(using = CustomDateSerializer.class)
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public long getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(long createdTime) {
		this.createdTime = createdTime;
	}*/
	public Boolean getIsExpired() {
		return isExpired;
	}
	public void setIsExpired(Boolean isExpired) {
		this.isExpired = isExpired;
	}
	public String getCourseId() {
		return courseId;
	}
	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}
	public Boolean getIsGroupAlive() {
		return isGroupAlive;
	}
	public void setIsGroupAlive(Boolean isGroupAlive) {
		this.isGroupAlive = isGroupAlive;
	}
	public Boolean getIsAutoAssignUser() {
		return isAutoAssignUser;
	}
	public void setIsAutoAssignUser(Boolean isAutoAssignUser) {
		this.isAutoAssignUser = isAutoAssignUser;
	}
	public Boolean getIsHidden() {
		return isHidden;
	}
	public void setIsHidden(Boolean isHidden) {
		this.isHidden = isHidden;
	}
	public Boolean getIsAutoAssignAsset() {
		return isAutoAssignAsset;
	}
	public void setIsAutoAssignAsset(Boolean isAutoAssignAsset) {
		this.isAutoAssignAsset = isAutoAssignAsset;
	}
	
	
    
    

}
