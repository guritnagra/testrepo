package com.vst.bridge.util.recaptcha;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLEncoder;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.vst.bridge.rest.input.vo.LoginInfoVO;
import com.vst.bridge.rest.input.vo.ReCaptchaLoginVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;

@PropertySource("classpath:application.properties")
@Service("reCaptchaUtil")
public class ReCaptchaUtil {

	private static final String NULL = "null";
	private Logger logger = LogManager.getLogger(ReCaptchaUtil.class);

	@Autowired
	private Environment env;

	@Autowired
	IReCaptchaAttemptService reCaptchaAttemptService;

	public LoginInfoVO verifyCaptcha(ReCaptchaLoginVO loginInfoVO, HttpServletRequest request) {
		String ipAddress = getClientIP(request);
		String username = loginInfoVO.getEmail();
		checkFailureReset(username, ipAddress);
		int currentAttempt = reCaptchaAttemptService.getUnsuccessfulAttempts(username, ipAddress) + 1;

		if (currentAttempt >= IReCaptchaAttemptService.MAX_ATTEMPTS_PW) {

			if (maxPasswordAttempts(currentAttempt)) {
				reCaptchaAttemptService.reCaptchaFailure(username, ipAddress);
				logger.warn("User : " + username + " has been reached max unsuccssful password attempts "
						+ IReCaptchaAttemptService.MAX_ATTEMPTS_PW);
				throw new BridgeException("User with username: " + username + " and IP: " + ipAddress
						+ "  has failed password vaildation " + IReCaptchaAttemptService.MAX_ATTEMPTS_PW + " times",
						ApplicationCode.PASSWORD_MAX_EXCEEDED);
			}

			if (reCaptchaAttemptService.isBlocked(username, ipAddress)) {
				logger.warn("User is blocked: " + username);
				throw new BridgeException(
						"User with username: " + username + " and IP: " + ipAddress + "  has exceeded "
								+ IReCaptchaAttemptService.MAX_ATTEMPTS_CAPTCHA + " attempts",
						ApplicationCode.CAPTCHA_MAX_EXCEEDED);
			}

			String captchaResponse = null == loginInfoVO.getCaptchaResponse() ? NULL : loginInfoVO.getCaptchaResponse();
			try {
				captchaResponse = URLEncoder.encode(captchaResponse, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				logger.error("There was an error encoding the recaptcha url ", e);
			}
			String url = String.format(ApplicationConstants.RE_CAPTCHA_VERIFY_URL, getReCaptchaSecret(),
					captchaResponse, getClientIP(request));

			URI verifyUri = URI.create(url);
			RestTemplate restTemplate = new RestTemplate();
			ReCaptchaResponseVO reCaptcharesponse = restTemplate.getForObject(verifyUri, ReCaptchaResponseVO.class);
			if (!reCaptcharesponse.isSuccess()) {
				reCaptchaAttemptService.reCaptchaFailure(username, ipAddress);
				logger.warn("Captcha unsuccessful for user with username: " + username);
				throw new BridgeException(
						"User with username: " + username + " and IP: " + ipAddress + "  has failed reCaptcha",
						ApplicationCode.CAPTCHA_FAILED);
			}
			return loginInfoVO;
		}else{
			return populateLoginInfoVO(loginInfoVO);
		}

	}

	public void setPasswordFailure(LoginInfoVO loginInfoVO, HttpServletRequest request) {
		reCaptchaAttemptService.reCaptchaFailure(loginInfoVO.getEmail(), getClientIP(request));
	}

	public void resetPasswordFailure(LoginInfoVO loginInfoVO, HttpServletRequest request) {
		reCaptchaAttemptService.reCaptchaSuccessful(loginInfoVO.getEmail(), getClientIP(request));
	}

	private void checkFailureReset(String username, String ipAddress) {
		Date lastFailure = reCaptchaAttemptService.getLastUnsuccessfulTime(username, ipAddress);
		if (null != lastFailure) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(lastFailure);
			cal.add(Calendar.MINUTE, 30);

			if (new Date().after(cal.getTime())) {
				logger.info("User : " + username + " has been reset for unsuccessful password attempts ");
				reCaptchaAttemptService.resetLastUnsuccessful(username, ipAddress);
			}
		}
	}
	
	private LoginInfoVO populateLoginInfoVO(ReCaptchaLoginVO loginInfoVO){
		logger.info("Login info populated for non-captcha login for user : "+loginInfoVO.getEmail());
		LoginInfoVO newLoginInfoVO = new LoginInfoVO();
		newLoginInfoVO.setEmail(loginInfoVO.getEmail());
		newLoginInfoVO.setPassword(loginInfoVO.getPassword());
		return newLoginInfoVO;
	}

	private String getClientIP(HttpServletRequest request) {
		final String xfHeader = request.getHeader("X-Forwarded-For");
		if (xfHeader == null) {
			return request.getRemoteAddr();
		}
		return xfHeader.split(",")[0];
	}

	private String getReCaptchaSite() {
		return env.getProperty("recaptcha.site.key");
	}

	private String getReCaptchaSecret() {
		return env.getProperty("recaptcha.secret.key");
	}

	private boolean maxPasswordAttempts(int attempts) {
		return attempts == IReCaptchaAttemptService.MAX_ATTEMPTS_PW;
	}

}
