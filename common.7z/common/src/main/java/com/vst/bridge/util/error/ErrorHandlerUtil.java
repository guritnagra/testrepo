package com.vst.bridge.util.error;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.owlike.genson.Genson;
import com.vst.bridge.rest.input.vo.AdminUserProfileVO;
import com.vst.bridge.rest.input.vo.BridgeGroupBookVO;
import com.vst.bridge.rest.input.vo.BridgeGroupUserVO;
import com.vst.bridge.rest.input.vo.BridgeGroupVO;
import com.vst.bridge.rest.input.vo.KeyBatchesVO;
import com.vst.bridge.rest.input.vo.KeyGenerateRequestVO;
import com.vst.bridge.rest.input.vo.LoginInfoVO;
import com.vst.bridge.rest.input.vo.ReCaptchaLoginVO;
import com.vst.bridge.rest.response.vo.CompanyVO;
import com.vst.bridge.rest.response.vo.GroupVO;
import com.vst.bridge.rest.response.vo.bridge.BridgeInfoVO;
import com.vst.bridge.rest.response.vo.user.CreateKeysVO;
import com.vst.bridge.rest.response.vo.user.UserDetailsVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;

@Component("errorHandlerUtility")
public class ErrorHandlerUtil {

	@Autowired
	private LocaleMessageUtility localeMessageUtility;
	
	public ResponseError validateAdminLoginInputParameters(final String inputJson)throws BridgeException, ParseException{
		ResponseError error  = validateInputJson(inputJson, LoginInfoVO.class);
		return error;
	}
	
	public ResponseError validateCaptchaLoginInputParameters(final String inputJson)throws BridgeException, ParseException{
		ResponseError error  = validateInputJson(inputJson, ReCaptchaLoginVO.class);
		return error;
	} 
	public ResponseError validateAdminProfileVOParameters(final String inputJson)throws BridgeException, ParseException{
		ResponseError error  = validateInputJson(inputJson, AdminUserProfileVO.class);
		return error;
	}
	
	public ResponseError validateBridgeVOParameters(final String inputJson)throws BridgeException, ParseException{
		ResponseError error  = validateInputJson(inputJson, BridgeInfoVO.class);
		return error;
	}
	
	public ResponseError validateGroupsVOParameters(final String inputJson)throws BridgeException, ParseException{
		ResponseError error  = validateInputJson(inputJson, GroupVO.class);
		return error;
	}
	
	public ResponseError validateCompanyVOParameters(final String inputJson)throws BridgeException, ParseException{
		ResponseError error  = validateInputJson(inputJson, CompanyVO.class);
		return error;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private ResponseError validateInputJson(final String inputJson,Class _class)throws BridgeException, ParseException{
		ResponseError error = null;
		Boolean errorOccured = Boolean.FALSE;
		List<Error> fieldErrors = new ArrayList<Error>(0);
		if(null != inputJson && !inputJson.equals("")){
			Object tmpObject = (new Genson()).deserialize(inputJson, _class);		
			for(Field field : tmpObject.getClass().getDeclaredFields()){
				if(!field.isAnnotationPresent(com.vst.bridge.annotation.custom.InputRequired.class)){
					PropertyDescriptor pd = BeanUtils.getPropertyDescriptor(_class, field.getName());
					Method method = pd.getReadMethod();
					method.setAccessible(Boolean.TRUE);
					try {
							Object result = 	method.invoke(tmpObject, null);
							String value = null != result ? result.toString() : "";
						if(value.equals("")){
							errorOccured = Boolean.TRUE;
							Error fieldError = new Error();
							fieldError.setName(field.getName());
							fieldError.setMessage(localeMessageUtility.getErrorMessage(ApplicationCode.MISSING_INPUT_FIELD.getCodeId()));
							fieldErrors.add(fieldError);
						}
					} catch (Exception e) {
						e.printStackTrace();
						throw new BridgeException(localeMessageUtility.getErrorMessage(ApplicationCode.ERROR_VALIDATION_INPUT_FIELD.getCodeId()),ApplicationCode.ERROR_VALIDATION_INPUT_FIELD);
					}
				}
			}
			
		}else{
			throw new ParseException(localeMessageUtility.getErrorMessage(ApplicationCode.DATA_VALIDATION_ERROR.getCodeId()),new Integer(0));
		}
		if(errorOccured){
			error = new ResponseError();
			error.setType(ApplicationConstants.FIELD_VALIDATION_ERROR);
			error.setData(fieldErrors);
		}
		return error;
	}


	public ResponseError validateKeyBatchesVOParameters(String inputJson) throws BridgeException, ParseException {
		ResponseError error  = validateInputJson(inputJson, KeyBatchesVO.class);
		return error;
	}

	public ResponseError validateKeyGenerateRequestVOParameters(String inputJson) throws BridgeException, ParseException {
		ResponseError error  = validateInputJson(inputJson, KeyGenerateRequestVO.class);
		return error;
	}

	public ResponseError validateCreateUserInputParameters(String inputJson) throws BridgeException, ParseException {
		ResponseError error  = validateInputJson(inputJson, UserDetailsVO.class);
		return error;
	}


	public ResponseError validatePostKeysParameters(String inputJson)throws BridgeException, ParseException  {
		ResponseError error  = validateInputJson(inputJson, CreateKeysVO.class);
		return error;
	}


	public ResponseError validateBridgeGroupVOParameters(String inputJson) throws BridgeException, ParseException {
		ResponseError error  = validateInputJson(inputJson, BridgeGroupVO.class);
		return error;
	}


	public ResponseError validateBridgeGroupUsersVOParameters(String inputJson) throws BridgeException, ParseException {
		ResponseError error  = validateInputJson(inputJson, BridgeGroupUserVO.class);
		return error;
	}
	
	public ResponseError validateBridgeGroupBooksVOParameters(String inputJson) throws BridgeException, ParseException {
		ResponseError error  = validateInputJson(inputJson, BridgeGroupBookVO.class);
		return error;
	}
}
