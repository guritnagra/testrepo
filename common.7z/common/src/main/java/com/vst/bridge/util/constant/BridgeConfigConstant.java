package com.vst.bridge.util.constant;

public class BridgeConfigConstant {
	public static final String PURCHASING_RENTAL_PROMO_CODE = "purchasing.rental.promoCode";
	public static final String PURCHASING_RENTAL_URL = "purchasing.rental.url";
	public static final String PURCHASING_TEXT_BOOK_URL = "purchasing.textBook.url";
	public static final String PURCHASING_E_TEXT_URL = "purchasing.eText.url";
}
