package com.vst.bridge;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.connectapi.ApiKeys;

public class VstUtils {
	private static Logger log = LogManager.getLogger(VstUtils.class);
	
	/**
	 * Creates Session id string.
	 * @param prefix prefix to session id string
	 * @return univerally unique Session id string
	 **/
	public static String createSessionid(String prefix) {
		return ((null == prefix) ? "" : prefix) + UUID.randomUUID().toString();
	}
		
	/**
	 * Gets full URL prefix.
	 * @param uriInfo URI Info
	 * @param request Https Request Info
	 * @return URL prefix string or null if undetermined
	 * @throws MalformedURLException 
	 **/
	public static URI getBaseUrl(UriInfo uriInfo, HttpServletRequest request) throws MalformedURLException {
		final URI uri= uriInfo.getRequestUri();
		final String protocol= uri.toString().contains("https") ? "https" : "http";
		
		try {
			return new URI(String.format("%s://%s", protocol, getDomain(uriInfo, request)));
		} catch (URISyntaxException e) {
			return null;
		}
	}
	
	/**
	 * Gets domain string from request info.
	 * @param uriInfo URI Info
	 * @param request Https Request Info
	 * @return domain string or null if undetermined
	 * @throws MalformedURLException 
	 **/
	public static String getDomain(UriInfo uriInfo, HttpServletRequest request) throws MalformedURLException {
	//	final URI uri= uriInfo.getRequestUri();
		 URL uri = new URL(request.getRequestURL().toString());
		 
		String domain= uri.getHost();
		if(null == domain || domain.equals("127.0.0.1") || domain.equals("localhost")) {
			domain= request.getHeader("x-forwarded-host");
		}

		log.debug("uriInfo.getRequestUri.getHost() == {}", uri.getHost());				//works on local/Eclipse tomcat
		log.debug("x-forwarded-host == {}", request.getHeader("x-forwarded-host"));		//works on AWS tomcat
		log.debug("x-forwarded-server == {}", request.getHeader("x-forwarded-server"));	//works on AWS tomcat
		
		log.debug("domain: {}", domain);
		
		return domain;
	}


	public static List<String> getKeyCodeValues(final Integer count){
		List<String> codes =  new ArrayList<String>();
		Random random = new Random();
		for(int i=0;i<count;i++){
			codes.add(String.format("%010d", (long)(random.nextDouble()*10000000000L)));
		}
		return codes;
	}
	
	public static boolean isValidPassword(String pwd){
		boolean isValid = false;
		try{
			if(pwd.matches(ApplicationConstants.PASSWORD_REGEX)){
				isValid = true;
			}
		}catch(Exception e){}
		return isValid;
		
	}
	
	public static String getUrlWithProtocol(HttpServletRequest request,String domain){		
		//String scheme=request.getScheme();
		if(ApplicationConstants.getApiMode() == ApiKeys.API_MODE.prod){
			String protocol = "https";
			return String.format("%s://%s", protocol, domain);	
		};

		String protocol = request.isSecure() ? "https":"http";
		return String.format("%s://%s", protocol, domain);		
		
	}
}
