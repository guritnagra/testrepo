package com.vst.bridge.dao.bridge.type;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.BridgeType;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeTypeDAO extends IGenericDAO<BridgeType, Integer> {
	
	BridgeType getBridgeForType(final String type)throws BridgeException;
	List<BridgeType> getAllBridgeTypes()throws BridgeException;
	List<IdValueVO> getTypes()throws BridgeException;
}
