package com.vst.bridge.rest.response.vo.bridge;

public class BridgeConfigResponseVO {
	private String loginWelcome;
	private String primaryColor;
	private String primaryLogo;
	private String purchasingETextEnabled;
	private String purchasingETextPromoCode;
	private String purchasingETextUrl;
	private String purchasingRentalEnabled;
	private String purchasingRentalPromoCode;
	private String purchasingRentalUrl;
	private String purchasingTextBookEnabled;
	private String purchasingTextBookPromoCode;
	private String purchasingTextBookUrl;
	private String randomKey;
	private String secondaryColor;
	private String secondaryLogo;
	private String entitlementType;
	
	public String getLoginWelcome() {
		return loginWelcome;
	}
	public void setLoginWelcome(String loginWelcome) {
		this.loginWelcome = loginWelcome;
	}
	public String getPrimaryColor() {
		return primaryColor;
	}
	public void setPrimaryColor(String primaryColor) {
		this.primaryColor = primaryColor;
	}
	public String getPrimaryLogo() {
		return primaryLogo;
	}
	public void setPrimaryLogo(String primaryLogo) {
		this.primaryLogo = primaryLogo;
	}
	public String getPurchasingETextEnabled() {
		return purchasingETextEnabled;
	}
	public void setPurchasingETextEnabled(String purchasingETextEnabled) {
		this.purchasingETextEnabled = purchasingETextEnabled;
	}
	public String getPurchasingETextPromoCode() {
		return purchasingETextPromoCode;
	}
	public void setPurchasingETextPromoCode(String purchasingETextPromoCode) {
		this.purchasingETextPromoCode = purchasingETextPromoCode;
	}
	public String getPurchasingETextUrl() {
		return purchasingETextUrl;
	}
	public void setPurchasingETextUrl(String purchasingETextUrl) {
		this.purchasingETextUrl = purchasingETextUrl;
	}
	public String getPurchasingRentalEnabled() {
		return purchasingRentalEnabled;
	}
	public void setPurchasingRentalEnabled(String purchasingRentalEnabled) {
		this.purchasingRentalEnabled = purchasingRentalEnabled;
	}
	public String getPurchasingRentalPromoCode() {
		return purchasingRentalPromoCode;
	}
	public void setPurchasingRentalPromoCode(String purchasingRentalPromoCode) {
		this.purchasingRentalPromoCode = purchasingRentalPromoCode;
	}
	public String getPurchasingRentalUrl() {
		return purchasingRentalUrl;
	}
	public void setPurchasingRentalUrl(String purchasingRentalUrl) {
		this.purchasingRentalUrl = purchasingRentalUrl;
	}
	public String getPurchasingTextBookEnabled() {
		return purchasingTextBookEnabled;
	}
	public void setPurchasingTextBookEnabled(String purchasingTextBookEnabled) {
		this.purchasingTextBookEnabled = purchasingTextBookEnabled;
	}
	public String getPurchasingTextBookPromoCode() {
		return purchasingTextBookPromoCode;
	}
	public void setPurchasingTextBookPromoCode(String purchasingTextBookPromoCode) {
		this.purchasingTextBookPromoCode = purchasingTextBookPromoCode;
	}
	public String getPurchasingTextBookUrl() {
		return purchasingTextBookUrl;
	}
	public void setPurchasingTextBookUrl(String purchasingTextBookUrl) {
		this.purchasingTextBookUrl = purchasingTextBookUrl;
	}
	public String getRandomKey() {
		return randomKey;
	}
	public void setRandomKey(String randomKey) {
		this.randomKey = randomKey;
	}
	public String getSecondaryColor() {
		return secondaryColor;
	}
	public void setSecondaryColor(String secondaryColor) {
		this.secondaryColor = secondaryColor;
	}
	public String getSecondaryLogo() {
		return secondaryLogo;
	}
	public void setSecondaryLogo(String secondaryLogo) {
		this.secondaryLogo = secondaryLogo;
	}
	public String getEntitlementType() {
		return entitlementType;
	}
	public void setEntitlementType(String entitlementType) {
		this.entitlementType = entitlementType;
	}
}
