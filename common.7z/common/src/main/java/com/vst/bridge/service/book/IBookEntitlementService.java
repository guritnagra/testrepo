package com.vst.bridge.service.book;

import java.util.List;

import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.rest.response.vo.RedeemBookVO;
import com.vst.bridge.rest.response.vo.user.BookLicenseInfoVO;
import com.vst.bridge.rest.response.vo.user.ConcurrentBookLicenseInfoVO;
import com.vst.bridge.rest.response.vo.user.UserCreditsInfoVO;
import com.vst.bridge.util.exception.BridgeException;

public interface IBookEntitlementService {
	BookLicenseInfoVO checkEntitlementFunctionalityForVbidById(String vbid, BridgeUser user, Bridge bridge,
			Integer entitlementId, String state) throws BridgeException;

	List<ConcurrentBookLicenseInfoVO> checkConcurrentEntitlementFunctinalityForVbid(String vbid, BridgeUser user,
			Bridge bridge, String state,UserCreditsInfoVO userCreditsInfoVO)throws BridgeException;
	
	List<BookLicenseInfoVO> checkEntitlementFunctionalityForVbid(String vbid, BridgeUser user, Bridge bridge, String state,UserCreditsInfoVO userCreditsInfoVO)throws BridgeException;

	<T> RedeemBookVO populateRedeemBookVOFromKeyBatchEntitlement(T t);

}
