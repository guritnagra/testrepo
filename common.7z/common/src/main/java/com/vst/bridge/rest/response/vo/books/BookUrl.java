package com.vst.bridge.rest.response.vo.books;

public class BookUrl {
	private String url;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
}
