package com.vst.bridge.rest.response.vo.page;

public class BridgePaginationVo extends PaginationVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	private Integer bridgeId;

	private Boolean refreshCatche = false;
	
	private Boolean licensed;
	
	public Boolean getRefreshCatche() {
		return refreshCatche;
	}


	public void setRefreshCatche(Boolean refreshCatche) {
		this.refreshCatche = refreshCatche;
	}


	public Integer getBridgeId() {
		return bridgeId;
	}


	public void setBridgeId(Integer bridgeId) {
		this.bridgeId = bridgeId;
	}
	
	
	
	public Boolean getLicensed() {
		return licensed;
	}


	public void setLicensed(Boolean licensed) {
		this.licensed = licensed;
	}


	public BridgePaginationVo() {}
	
	public BridgePaginationVo(Integer bridgeId,Boolean refreshCatche,Integer page,Integer limit,Integer totalPages,String orderBy,String order,String search,Boolean licensed,Integer offset) {
		this.bridgeId = bridgeId;
		this.refreshCatche = refreshCatche;
		this.licensed = licensed;
		this.setPage(page);
		this.setLimit(limit);
		this.setTotalPages(totalPages);
		this.setOrderBy(orderBy);
		this.setOrder(order);
		this.setSearch(search);
		this.setOffset(offset);
	}
}
