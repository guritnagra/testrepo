package com.vst.bridge.rest.response.vo.bridge;

import com.vst.bridge.annotation.custom.InputRequired;

public class BridgeInfoVO {
	private Integer company;
	private String name;
	private String language;
	private String code;
	private String contactEmail;
	private String contactName;
	private String contactPhone;
	
	@InputRequired(required=false)
	private String alias;
	
	@InputRequired(required=false)
	private String apiKey;
	
	@InputRequired(required=false)
	private Boolean isPending;
	
	@InputRequired(required=false)
	private Boolean isRostored;
	
	@InputRequired(required=false)
	private Boolean isPasswordProtected;
	
	@InputRequired(required=false)
	private String password;
	
	@InputRequired(required=false)
	private String bridgeType;
	
	@InputRequired(required=false)
	private String bookshelfUrl;
	
	public Boolean getIsPending() {
		return isPending;
	}
	public void setIsPending(Boolean isPending) {
		this.isPending = isPending;
	}
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	public Integer getCompany() {
		return company;
	}
	public void setCompany(Integer company) {
		this.company = company;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getContactEmail() {
		return contactEmail;
	}
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public Boolean getIsPasswordProtected() {
		return isPasswordProtected;
	}
	public void setIsPasswordProtected(Boolean isPasswordProtected) {
		this.isPasswordProtected = isPasswordProtected;
	}
	public String getContactPhone() {
		return contactPhone;
	}
	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getBridgeType() {
		return bridgeType;
	}
	public void setBridgeType(String bridgeType) {
		this.bridgeType = bridgeType;
	}
	public String getBookshelfUrl() {
		return bookshelfUrl;
	}
	public void setBookshelfUrl(String bookshelfUrl) {
		if(bookshelfUrl==null){
			this.bookshelfUrl = "";
		}else{
			this.bookshelfUrl = bookshelfUrl;
		}
		
	}
	public Boolean getIsRostored() {
		return isRostored;
	}
	public void setIsRostored(Boolean isRostored) {
		this.isRostored = isRostored;
	}

}
