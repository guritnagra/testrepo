package com.vst.bridge.dao.key;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.keys.KeyBatch;
import com.vst.bridge.util.exception.BridgeException;

public interface IKeyBatchDAO extends IGenericDAO<KeyBatch, Integer>{

	List<KeyBatch> getAllKeyBatches(Integer bridgeId)throws BridgeException;
	
	List<Integer> getAllKeyBatchesIds(Integer bridgeId)throws BridgeException;
	
	KeyBatch getKeyBatchForAutoRedeem(Integer id) throws BridgeException;

}
