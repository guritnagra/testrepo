package com.vst.bridge;

import java.security.MessageDigest;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.validator.routines.EmailValidator;

import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;

public abstract class StringUtils {
	
	public static final DateFormat yyyyMMdd= new SimpleDateFormat("yyyy-MM-dd");
	public static final DateFormat MMddyyyy= new SimpleDateFormat("MM_dd_yyyy");
	
	/**
	 * converts date string to Date object.
	 * @param dateStr date as string
	 * @return populated Date object
	 * @throws ParseException exception parsing date string
	 **/
	public static Date parseDate(String dateStr) throws ParseException {
		return ((DateFormat)yyyyMMdd.clone()).parse(dateStr);
	}
	
	/**
	 * Checks that a string is a valid email address.
	 * @param email email string to check
	 * @return whether email string is a valid email address
	 */
	public static boolean checkEmail(String email) 
	{
		return (!org.apache.commons.lang3.StringUtils.isBlank(email) && EmailValidator.getInstance().isValid(email));
	}
	
	/**
	 * Checks an number against min and max values.
	 * @param num number to check as a string
	 * @param min min value num can be
	 * @param max max value num can be
	 * @return whether number is between min and max values
	 **/
	public static boolean checkInteger(String num, int min, int max)
	{
		return checkInteger(Integer.valueOf(num), min, max);
	}
	
	/**
	 * Checks an number against min and max values.
	 * @param num number to check
	 * @param min min value num can be
	 * @param max max value num can be
	 * @return whether number is between min and max values
	 **/
	public static boolean checkInteger(Number num, int min, int max)
	{
		try
		{
			Integer i = num.intValue();
			if(i >= min && i <= max)
			{
				return true;
			}
		}catch(Exception e){}
		return false;
	}
	
	/**
	 * use apache isBlank() instead
	 * returns whether string is null or empty.
	 * @param str string
	 * @return whether string is null or empty
	 
	public static boolean isEmpty(String str) {
		return null == str || str.trim().isEmpty();
	}*/
	
	/**
	 * converts boolean string to boolean.
	 * @param boolStr boolean as a string
	 * @return boolean value of string
	 **/
	public static boolean parseBoolean(String boolStr) {
		return null != boolStr && (Boolean.valueOf(boolStr) || boolStr.equalsIgnoreCase("1"));
	}
	
	/**
	 * Returns a 1 if boolean is true, otherwise 0.
	 * @param bool boolean value
	 * @return 0 or 1, depending on boolean value
	 **/
	public static String booleanToOneOrZero(Boolean bool) {
		return bool ? "1" : "0";
	}
		
	/**
	 * Convert ISBN-13 to ISBN-10.
	 * @param isbn13 isbn-13
	 * @return isbn-10
	 **/
	public static String ISBN1310(String isbn13) 
	{
		String s9;
		int i, n, v;
		boolean ErrorOccurred;
		ErrorOccurred = false;
		s9 = isbn13.substring(3, 12);
		n = 0;
		for (i=0; i<9; i++) 
		{
			if (!ErrorOccurred) 
			{
				v = Character.getNumericValue(s9.charAt(i));
				if (v==-1) ErrorOccurred = true;
				else n = n + (10 - i) * v; 
			}
		}
		if (ErrorOccurred) return "ERROR";
		else 
		{
			n = 11 - (n % 11);
			return s9 + ApplicationConstants.CheckDigits.substring(n, n+1); 
		}
	}
	
	/**
	 * Convert ISBN-10 to ISBN-13.
	 * @param isbn10 isbn-10
	 * @return isbn-13
	 **/	
	public static String ISBN1013(String isbn10) 
	{
		String s12;
		int i, n, v;
		boolean ErrorOccurred;
		ErrorOccurred = false;
		s12 = "978" + isbn10.substring(0, 9);
		n = 0;
		for (i=0; i<12; i++) 
		{
			if (!ErrorOccurred) 
			{
				v = Character.getNumericValue(s12.charAt(i));
				if (v==-1) ErrorOccurred = true;
				else 
				{
					if ((i % 2)==0) n = n + v;
					else n = n + 3*v;
				}
			}
		}
		if (ErrorOccurred) return "ERROR";
		else 
		{
			n = n % 10;
			if (n!=0) n = 10 - n;
			return s12 + ApplicationConstants.CheckDigits.substring(n, n+1);
		}
	}

	public static String hash(String string) throws BridgeException {
		StringBuffer sb = new StringBuffer();
		try{
			MessageDigest md = MessageDigest.getInstance("MD5");
	        md.update(string.getBytes());
	        byte byteData[] = md.digest();
	        
	        for (int i = 0; i < byteData.length; i++) {
	         sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
	        }
		}catch(Exception exception){
			throw new BridgeException("Failed to get md5 value of "+string, ApplicationCode.FAILED_TO_MD5_HASHING);
		}
        return sb.toString();
    }
	
	public static String getFullName(String firstName,String lastname){
		return firstName+" "+lastname;
	}
	
	public static String getFormatedString(String request,String values){
		return request.replace(ApplicationConstants.STRING_PLACEHOLDER, values);
	}
	
	public static String getFormatedString(String request,String value1,String value2){
		String val1=request.replace(ApplicationConstants.STRING_PLACEHOLDER, value1);
		return val1.replace(ApplicationConstants.STRING_PLACEHOLDER_1,value2);
		
	}
	
	public static String getStringForArrayList(List<String> values){
		StringBuilder string = new StringBuilder();
		if(null != values && values.size() > 0){
			for(int i=0;i<values.size() ;i++){
				string.append("\"");
				string.append(values.get(i));
				string.append("\"");
				if(i<values.size()-1){
					string.append(",");
				}
			}
		}
		return string.toString();
	}
	
	public static String getEmptyForNull(String string){
		return org.apache.commons.lang.StringUtils.isNotEmpty(string) ? string : "";
	}
	
	public static String getFormatedStringForPISBN10(final String url,final String isbn10,final String vbid){
		return url.replaceAll(ApplicationConstants.BRIDGE_URL_REGREX_PISBN10, getEmptyForNull(isbn10)).replaceAll(ApplicationConstants.BRIDGE_URL_REGREX_VBID, getEmptyForNull(vbid));
	}
	
	public static String getFormatedStringForPISBN13(final String url,final String isbn13,final String vbid){
		return url.replaceAll(ApplicationConstants.BRIDGE_URL_REGREX_PISBN13, getEmptyForNull(isbn13)).replaceAll(ApplicationConstants.BRIDGE_URL_REGREX_VBID, getEmptyForNull(vbid));
	}	
	
	public static String getFormatedStringForEISBN10(final String url,final String isbn10,final String vbid){
		return url.replaceAll(ApplicationConstants.BRIDGE_URL_REGREX_EISBN10, getEmptyForNull(isbn10)).replaceAll(ApplicationConstants.BRIDGE_URL_REGREX_VBID, getEmptyForNull(vbid));
	}
	
	public static String getFormatedStringForEISBN13(final String url,final String isbn13,final String vbid){
		return url.replaceAll(ApplicationConstants.BRIDGE_URL_REGREX_EISBN13, getEmptyForNull(isbn13)).replaceAll(ApplicationConstants.BRIDGE_URL_REGREX_VBID, getEmptyForNull(vbid));
	}
}
