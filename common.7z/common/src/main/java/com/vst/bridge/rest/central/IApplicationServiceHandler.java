package com.vst.bridge.rest.central;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.UriInfo;

import org.springframework.http.ResponseEntity;

import com.vst.bridge.rest.config.AuthenticatedRestAction;
import com.vst.bridge.rest.config.PortalPermissionType;
import com.vst.bridge.rest.config.UnAuthenticatedRestAction;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;

public interface IApplicationServiceHandler {

	public ResponseEntity<RestResponse>  process(AuthenticatedRestAction postPassword,PortalPermissionType type,final String sessionId,Object param,HttpServletRequest httpRequest,HttpServletResponse httpServletResponse,UriInfo uriInfo);
	
	public ResponseEntity<RestResponse>  process(UnAuthenticatedRestAction action,PortalPermissionType type,final String sessionId,HttpServletRequest httpRequest,HttpServletResponse httpServletResponse,UriInfo uriInfo,Object param);
	
	public SessionStatusVO checkSessionAndGetUserInfo(String sessionId, PortalPermissionType type);
}
