package com.vst.bridge.dao.bridge.purchase;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.purchase.BridgePurchase;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgePurchaseDAO extends IGenericDAO<BridgePurchase, Integer>{
	
	List<BridgePurchase> getBridgePurchases(final Integer bridgeId)throws BridgeException;

}
