package com.vst.bridge.rest.response.vo;

public class BridgeTenantVO {
	
	Integer bridgeId;
	Integer bcTenantId;
	public Integer getBridgeId() {
		return bridgeId;
	}
	public void setBridgeId(Integer bridgeId) {
		this.bridgeId = bridgeId;
	}
	public Integer getBcTenantId() {
		return bcTenantId;
	}
	public void setBcTenantId(Integer bcTenantId) {
		this.bcTenantId = bcTenantId;
	}
	
	

}
