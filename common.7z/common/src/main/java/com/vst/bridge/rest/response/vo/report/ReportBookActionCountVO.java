package com.vst.bridge.rest.response.vo.report;

public class ReportBookActionCountVO extends ReportBooksVO{
	private Integer id;
	private String name;
	private String company;
	private ReportCountWithTrialVO activations;
	private ReportCountDetails integrations;
	public ReportCountWithTrialVO getActivations() {
		return activations;
	}
	public void setActivations(ReportCountWithTrialVO activations) {
		this.activations = activations;
	}
	public ReportCountDetails getIntegrations() {
		return integrations;
	}
	public void setIntegrations(ReportCountDetails integrations) {
		this.integrations = integrations;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	
}
