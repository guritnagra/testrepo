package com.vst.bridge.dao.admin;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.company.AdminCompany;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.company.Company;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.BridgeException;

@Repository("adminCompanyDAO")
public class AdminCompanyDAOImpl extends GenericDAO<AdminCompany, Integer> implements IAdminCompanyDAO{

	public AdminCompanyDAOImpl() {
		super(AdminCompany.class);
	}

	@Override
	public List<Company> getCompaniesForAdminId(Integer adminId)
			throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("admin.id", adminId));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		List<AdminCompany> companies = executeCriteira(criteria);
		List<Company> companiesList =  new ArrayList<Company>();
		if(null != companies && companies.size() > 0){
			for(AdminCompany adminCompany : companies){
				companiesList.add(adminCompany.getCompany());
			}
		}
		return companiesList;
	}

	@Override
	public List<AdminCompany> getAdminCompaniesForAdminId(Integer adminId,Boolean isDeleted) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("admin.id", adminId));
		if(isDeleted)
			criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		List<AdminCompany> companies = executeCriteira(criteria);
		return companies;
	}
	
	@Override
	public AdminCompany getAdminCompanyByAdminAndCompanyId(Integer adminId,Integer companyId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("admin.id", adminId));
		criteria.add(Restrictions.eq("company.id", companyId));		
		List<AdminCompany> result = executeCriteira(criteria);
		return result != null && result.size()>0 ? result.get(0) : null;
	}
	
	@Override
	public Set<AdminUser> getUsersForCompanyIds(List<Integer> companyIds, Integer startIndex, BridgePaginationVo paginationVo)
			throws BridgeException {
		Set<AdminUser> adminUsers = new LinkedHashSet<AdminUser>();
		Criteria criteria = getCriteria();
		criteria.createAlias("admin", "adminAlias");
		criteria.createAlias("admin.role", "roleAlias");
		if(null!=paginationVo){
			Integer totalRecordToFetch = paginationVo.getLimit();
			if(null != startIndex && null != totalRecordToFetch  && totalRecordToFetch > 0){
				criteria.setFirstResult(startIndex);
				criteria.setMaxResults(totalRecordToFetch);
			}
			
			String search = paginationVo.getSearch();
			if(null!=search && !StringUtils.isEmpty(search)){
				Criterion criterion1 = Restrictions.ilike("adminAlias.firstName", "%"+search+"%");
				Criterion criterion2 = Restrictions.ilike("adminAlias.lastName", "%"+search+"%");
				Criterion criterion3 = Restrictions.ilike("adminAlias.email", "%"+search+"%");
				Criterion completeCriterion = Restrictions.disjunction()
																	.add(criterion1)
																	.add(criterion2)
																	.add(criterion3);
				
				criteria.add(completeCriterion);
			}
			String orderBy = paginationVo.getOrderBy();
			if(null != orderBy && !StringUtils.isEmpty(orderBy)){
				String order = paginationVo.getOrder();
				if(order.equals(ApplicationConstants.SORTING_ORDER_ASC)){
					criteria.addOrder(Order.asc("adminAlias."+orderBy));
				}else{
					criteria.addOrder(Order.desc("adminAlias."+orderBy));
				}
			}
		}
		criteria.add((Restrictions.in("company.id", companyIds)));	
		criteria.add((Restrictions.eq("roleAlias.name",ApplicationConstants.USER_ROLE_ADMIN)));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		List<AdminCompany> adminCompanyList = executeCriteira(criteria);
		if(null != adminCompanyList && adminCompanyList.size()>0){
			for(AdminCompany adminCompany : adminCompanyList){
				adminUsers.add(adminCompany.getAdmin());
				//System.out.println("print admin-->"+adminCompany.getAdmin().getId());
			}
		}
		return adminUsers;
	}
	
	@Override
	public Integer getUsersCount(List<Integer> companyIds, BridgePaginationVo paginationVo)
			throws BridgeException {
		Set<Integer> adminUsers = new HashSet<Integer>();
		Criteria criteria = getCriteria();
		criteria.createAlias("admin", "adminAlias");
		criteria.createAlias("admin.role","roleAlias");
		if(null!=paginationVo){
					
			String search = paginationVo.getSearch();
			if(null!=search && !StringUtils.isEmpty(search)){
				Criterion criterion1 = Restrictions.ilike("adminAlias.firstName", "%"+search+"%");
				Criterion criterion2 = Restrictions.ilike("adminAlias.lastName", "%"+search+"%");
				Criterion criterion3 = Restrictions.ilike("adminAlias.email", "%"+search+"%");
				Criterion completeCriterion = Restrictions.disjunction()
																	.add(criterion1)
																	.add(criterion2)
																	.add(criterion3);
				
				criteria.add(completeCriterion);
			}
			String orderBy = paginationVo.getOrderBy();
			if(null != orderBy && !StringUtils.isEmpty(orderBy)){
				String order = paginationVo.getOrder();
				if(order.equals(ApplicationConstants.SORTING_ORDER_ASC)){
					criteria.addOrder(Order.asc("adminAlias."+orderBy));
				}else{
					criteria.addOrder(Order.desc("adminAlias."+orderBy));
				}
			}
		}
		criteria.add((Restrictions.in("company.id", companyIds)));
		criteria.add((Restrictions.eq("roleAlias.name",ApplicationConstants.USER_ROLE_ADMIN)));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		//criteria.setProjection(Projections.distinct(Projections.property("admin.id")));
		List<AdminCompany> adminCompanyList = executeCriteira(criteria);
		if(null != adminCompanyList && adminCompanyList.size()>0){
			for(AdminCompany adminCompany : adminCompanyList){
				//System.out.println("print admin from count-->"+adminCompany.getAdmin().getId());
				adminUsers.add(adminCompany.getAdmin().getId());
			}
		}
		return null!=adminUsers && adminUsers.size() > 0 ? adminUsers.size() : 0;
	}
	
	
}
