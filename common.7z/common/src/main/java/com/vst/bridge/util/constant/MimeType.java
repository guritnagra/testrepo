package com.vst.bridge.util.constant;

import java.util.EnumSet;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public enum MimeType {
	DOCX("application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
	DOC("application/msword"),
	XLSX("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
	XLS("application/vnd.ms-excel"),
	PPTX("application/vnd.oasis.opendocument.presentation"),
	PPT("application/vnd.ms-powerpoint"),
	PDF("application/pdf"),
	EPUB("application/epub+zip"),
	HTML("text/html"),
	CSS(" text/css"),
	JAVASCRIPT("text/javascript"),
	GIF("image/gif"),
	PNG("image/png"),
	JPEG("image/jpeg"),
	BMP("image/bmp"),
	WEBP("image/webp"),
	MIDI("audio/midi"),
	MP3("audio/mpeg"),
	WEBM("audio/webm|video/webm"),
	OGG("audio/ogg"),
	WAV("audio/wav"),
	FLV("video/x-flv"),
	MP4("video/mp4"),
	MOV("video/quicktime"),
	AVI("video/x-msvideo"),
	WMV("video/x-ms-wmv"),
	OGV("video/ogg"),
	BIN("application/octet-stream"),
	ETEXT("application/vstbook"),
	ZIP("application/zip"),
	RAR("application/x-rar-compressed"),
	GZ("application/x-gzip"),
	TXT("text/plain"),
	RTF("text/richtext"),
	CSV("text/csv");
	
	
	
	private final String mimeType;
	private static final EnumSet<MimeType> textList;
	private static final EnumSet<MimeType> imageList;
	private static final EnumSet<MimeType> audioList;
	private static final EnumSet<MimeType> videoList;
	private static final Map<String, MimeType> mimeTypeMap = new ConcurrentHashMap<>();
	
	private MimeType(final String mimeType) {
		this.mimeType = mimeType;		
	}

	static{
		textList = EnumSet.noneOf(MimeType.class);
		imageList = EnumSet.noneOf(MimeType.class);
		audioList = EnumSet.noneOf(MimeType.class);
		videoList = EnumSet.noneOf(MimeType.class);
		//Text enum init
		textList.add(HTML);
		textList.add(CSS);
		textList.add(JAVASCRIPT);
		
		//Image enum init
		imageList.add(GIF);
		imageList.add(PNG);
		imageList.add(JPEG);
		imageList.add(BMP);
		imageList.add(WEBP);
		
		//Audio enum list
		audioList.add(MIDI);
		audioList.add(MP3);
		audioList.add(WEBM);
		audioList.add(OGG);
		audioList.add(WAV);
		
		//Video enum List
		videoList.add(WEBM);
		videoList.add(FLV);
		videoList.add(MP4);
		videoList.add(MOV);
		videoList.add(AVI);
		videoList.add(WMV);
		videoList.add(OGV);
		
		for(MimeType type:MimeType.values()){
			mimeTypeMap.put(type.getMimeType(), type);
		}
		
	}
	public enum Category{VIDEO,IMAGE,AUDIO,ETEXT,PDF,PPT,SCORM,EXCEL,WORD,ZIP,OTHER}

	public String getMimeType() {
		return this.mimeType;
	}
	
	public static MimeType findExtenstionByString(String extension){
		MimeType mimeType = BIN;
		if(null==extension){
			return mimeType;
		}
		try {
			mimeType = valueOf(extension);
		}catch (IllegalArgumentException e){
			return  mimeType;
		}
		return mimeType;
	}
	
	public static MimeType findExtensionByMimeType(String mime) {
		if(null==mime){
			return BIN;
		}
		return null == mimeTypeMap.get(mime) ? BIN : mimeTypeMap.get(mime);
	}
	
	public static boolean checkMimeExists(String mime){
		if(null==mime){
			return false;
		}
		return mimeTypeMap.containsKey(mime);
	}
	public static final Category getMimeTypeCategory(MimeType mimeTypeExtension){
		
		Category returnCategory = Category.OTHER;
		switch (mimeTypeExtension) {
		case PDF:
			return Category.PDF;
		case PPT:
		case PPTX:
			return Category.PPT;
		case DOC:
		case DOCX:
			return Category.WORD;
		case XLS:
		case XLSX:
			return Category.EXCEL;
		case ZIP:
		case RAR:
		case GZ:
			return Category.ZIP;
		default:
			returnCategory = checkGroupedCatgegories(mimeTypeExtension);
			break;
		}
		return returnCategory;
	}

	private static Category checkGroupedCatgegories(MimeType mimeTypeExtension) {
		Category returnCategory = Category.OTHER;
		
		returnCategory = checkAndReturnVideo(mimeTypeExtension);
		if(Category.OTHER.equals(returnCategory)){
			returnCategory = checkAndReturnImage(mimeTypeExtension);
		}else if (Category.OTHER.equals(returnCategory)){
			returnCategory = checkAndReturnAudio(mimeTypeExtension);
		}
		return returnCategory;
	}

	private static Category checkAndReturnImage(MimeType type) {
		if(imageList.contains(type)){
			return Category.IMAGE;
		}else{
			return Category.OTHER;
		}
		
	}

	private static Category checkAndReturnVideo(MimeType type) {
		if(videoList.contains(type)){
			return Category.VIDEO;
		}else{
			return Category.OTHER;
		}
		
	}
	private static Category checkAndReturnAudio(MimeType type) {
		if(videoList.contains(type)){
			return Category.AUDIO;
		}else{
			return Category.OTHER;
		}
		
	}
	
}
