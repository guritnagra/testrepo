package com.vst.bridge.service.admin;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.JsonUtils;
import com.vst.bridge.VstException;
import com.vst.bridge.VstUtils;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.admin.session.IAdminSessionDAO;
import com.vst.bridge.entity.admin.session.AdminSession;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.rest.input.vo.LoginInfoVO;
import com.vst.bridge.rest.response.vo.AdminUserVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SystemUserLoginResponseVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.error.Error;
import com.vst.bridge.util.error.ErrorHandlerUtil;
import com.vst.bridge.util.error.ResponseError;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.connectapi.ConnectApiWrapper;

@Service("adminUserAccessService")
public class AdminUserAccessServiceImpl implements IAdminUserAccessService {
	@Autowired
	private IAdminUserDAO adminUserDAO;

	@Autowired
	private IAdminSessionDAO adminSessionDAO;

	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private ErrorHandlerUtil errorHandlerUtility;
	
	@Autowired
	private AdminUserServiceUtil adminUserServiceUtil;

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse login(LoginInfoVO loginInfoVO, HttpServletRequest request,
			HttpServletResponse httpServletResponse, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException, VstException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		String sessionId = null;
		ResponseError responseError = errorHandlerUtility
				.validateAdminLoginInputParameters(JsonUtils.getJsonString(loginInfoVO));
		if (null == responseError) {
			final String email = loginInfoVO.getEmail();
			final String password = loginInfoVO.getPassword();
			if (!StringUtils.isBlank(email) && !StringUtils.isBlank(password)) {
				sessionId = VstUtils.createSessionid(null);
				//AdminUser adminUser = adminUserDAO.authonticateAdminUser(email, password);
				AdminUser adminUser = null;
				SystemUserLoginResponseVO systemUserLoginResponseVO=ConnectApiWrapper.checkAdminFromConnect(loginInfoVO);
				if(systemUserLoginResponseVO!=null){
					adminUser=adminUserDAO.getAdminForSystemUserId(systemUserLoginResponseVO.getSystemUserId());
				}
				if (null != adminUser) {					
					AdminSession session = new AdminSession();
					session.setAdmin(adminUser);
					session.setSessionId(sessionId);
					adminSessionDAO.create(session);
					AdminUserVO adminUserVO = adminUserServiceUtil.populateAdminVoFromAdmin(adminUser);
					response.setData(adminUserVO);	
					Cookie cookie = new Cookie(ApplicationConstants.BRIDGE_SESSIONID, sessionId);	
					cookie.setMaxAge(NewCookie.DEFAULT_MAX_AGE);
					cookie.setSecure(ApplicationConstants.COOKIE_SECURE);
					cookie.setPath("/");
					httpServletResponse.addCookie(cookie);	
				} else {
					response = new RestResponse(Response.Status.UNAUTHORIZED.getStatusCode(),
							ApplicationCode.USER_AUTHENTICATION_FAILED.getCodeId(), localeMessageUtility
									.getErrorMessage(ApplicationCode.USER_AUTHENTICATION_FAILED.getCodeId()));
					checkInputParametersInDb(email,response);
				}
			}
		} else {
			response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
			response.setMessage(localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_INPUT.getCodeId()));
			response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
			response.setError(responseError);
		}
		return response;
	}

	private void checkInputParametersInDb(String email, RestResponse response) {
		List<Error> fieldErrors = new ArrayList<Error>(0);
		if (!adminUserDAO.checkEmailExistInDb(email)) {
			Error error = new Error();
			error.setMessage(localeMessageUtility.getErrorMessage(ApplicationCode.MISSING_EMAIL.getCodeId()));
			error.setName("email");
			fieldErrors.add(error);
		}		
		ResponseError error = new ResponseError();
		error.setType(ApplicationConstants.FIELD_VALIDATION_ERROR);
		error.setData(fieldErrors);
		response.setError(error);
	}


	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse logout(String sessionId, HttpServletRequest request, UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if (null != sessionId && !StringUtils.isEmpty(sessionId)) {
			AdminSession session = adminSessionDAO.getForSessionId(sessionId, Boolean.FALSE, null);
			if (null != session) {
				session.setDeleted(Boolean.TRUE);
				adminSessionDAO.update(session);
			}
		}
		return response;
	}
}
