package com.vst.bridge.rest.central;

import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.hibernate4.HibernateOptimisticLockingFailureException;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.owlike.genson.JsonBindingException;
import com.vst.bridge.VstException;
import com.vst.bridge.VstUtils;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.entity.admin.session.AdminSession;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.session.BridgeUserSession;
import com.vst.bridge.rest.config.AuthenticatedRestAction;
import com.vst.bridge.rest.config.PortalPermissionType;
import com.vst.bridge.rest.config.UnAuthenticatedRestAction;
import com.vst.bridge.rest.input.vo.AdminUserProfileVO;
import com.vst.bridge.rest.input.vo.AllowanceRequestVO;
import com.vst.bridge.rest.input.vo.BookConcurrencyLimitVO;
import com.vst.bridge.rest.input.vo.BridgeGroupBookVO;
import com.vst.bridge.rest.input.vo.BridgeGroupUserVO;
import com.vst.bridge.rest.input.vo.BridgeGroupVO;
import com.vst.bridge.rest.input.vo.KeyGenerateRequestVO;
import com.vst.bridge.rest.input.vo.LoginInfoVO;
import com.vst.bridge.rest.input.vo.OldPolicyPasswordVO;
import com.vst.bridge.rest.input.vo.PurchaseRequestVO;
import com.vst.bridge.rest.input.vo.ReCaptchaLoginVO;
import com.vst.bridge.rest.input.vo.TokenRequestVO;
import com.vst.bridge.rest.response.vo.AdminResetPasswordVO;
import com.vst.bridge.rest.response.vo.CompanyVO;
import com.vst.bridge.rest.response.vo.GroupVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.ancillary.AncillaryAdminVO;
import com.vst.bridge.rest.response.vo.ancillary.AncillaryVO;
import com.vst.bridge.rest.response.vo.books.BridgeBookVO;
import com.vst.bridge.rest.response.vo.bridge.BridgeBooksVO;
import com.vst.bridge.rest.response.vo.bridge.BridgeInfoWithFavoriteVO;
import com.vst.bridge.rest.response.vo.bridge.IntigrationVO;
import com.vst.bridge.rest.response.vo.group.BridgeGroupAssetUserVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.rest.response.vo.roster.CSVResponseWrapperVO;
import com.vst.bridge.rest.response.vo.user.BridgeUserInfoVO;
import com.vst.bridge.rest.response.vo.user.CreateKeysVO;
import com.vst.bridge.rest.response.vo.user.IntegratedBridgeUserResponseVO;
import com.vst.bridge.rest.response.vo.user.UpdatePasswordVO;
import com.vst.bridge.rest.response.vo.user.UserDetailsVO;
import com.vst.bridge.rest.response.vo.user.UserEmailVO;
import com.vst.bridge.service.admin.AdminUserServiceUtil;
import com.vst.bridge.service.admin.IAdminUserServices;
import com.vst.bridge.service.ancillary.IAncillaryServices;
import com.vst.bridge.service.bc.IBusinessCenterServices;
import com.vst.bridge.service.book.IBookServices;
import com.vst.bridge.service.group.IBridgeGroupServices;
import com.vst.bridge.service.report.IAdminReportServices;
import com.vst.bridge.service.report.IKpiDataReportService;
import com.vst.bridge.service.user.IUserServices;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.constant.PermissionAction;
import com.vst.bridge.util.constant.UploadType;
import com.vst.bridge.util.csv.CSVFileType;
import com.vst.bridge.util.email.ExecutorUtility;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.exception.BusinessCenterException;
import com.vst.bridge.util.exception.IntegrationException;
import com.vst.bridge.util.exception.InvalidActionException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.bridge.util.recaptcha.ReCaptchaUtil;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiFieldException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;

@Component("applicationServiceHandler")
public class ApplicationServiceHandler implements IApplicationServiceHandler{

	private static Logger logger = LogManager.getLogger(ApplicationServiceHandler.class);
	
	@Autowired
	private IAdminUserServices adminUserService;

	@Autowired
	private LocaleMessageUtility localeMessageUtility;
	
	@Autowired
	private IBridgeAuthonticator bridgeAuthonticator;
	
	@Autowired
	private IUserServices userServices;
	
	@Autowired
	private IBookServices bookServices;
	
	@Autowired
	private IAdminReportServices reportServices;
	
	@Autowired
	private IBridgeGroupServices groupServices;
	
	private Executor executor = ExecutorUtility.getExecutorInstance();
	
	@Autowired
	private IBusinessCenterServices businessCenterServices;
	
	@Autowired
	private IKpiDataReportService kpiDataReportService;
    
    @Autowired
	private ReCaptchaUtil reCaptchaUtil;
    
    @Autowired
	private IAncillaryServices ancillaryServices;	
    
    @Autowired
	private IAdminUserDAO adminUserDAO;
    
    @Autowired
	private AdminUserServiceUtil adminUserServiceUtil;
    
	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<RestResponse> process(AuthenticatedRestAction action,PortalPermissionType type,final String sessionId,Object param,HttpServletRequest httpRequest,HttpServletResponse httpServletResponse,UriInfo uriInfo){
		logger.info("process : processing "+action+" for "+type);
		RestResponse response = null;
		HttpStatus status = HttpStatus.OK;
		try{
			if(httpRequest!=null){
				httpRequest.setCharacterEncoding("UTF-8");
			}
			final String domain= VstUtils.getDomain(uriInfo, httpRequest);
			String code = null;
			if(null != domain && StringUtils.isNotEmpty(domain)){
				code = domain.substring(0, domain.indexOf(ApplicationConstants.BRIDGE_DOMAIN_NAME_PERIOD));
			}
			BridgePaginationVo bridgePaginationVo = null;
			final SessionStatusVO sessionStatusVO = this.checkSessionAndGetUserInfo(sessionId,type);
			AdminUser adminUser = bridgeAuthonticator.getAdminUserForSession(sessionStatusVO);
			Integer id = null;
			String vbid = null;
			Map<String,String> paramMap = null;
			if(param instanceof Integer){
				id =  (Integer) param;
				if(type.equals(PortalPermissionType.admin))
					bridgeAuthonticator.checkAdminAccessForBridgeById(sessionStatusVO,id);
			}else if(param instanceof BridgePaginationVo){
				 bridgePaginationVo = (BridgePaginationVo) param;
			}else if(param instanceof String){
				vbid = (String) param;
			}else if (param instanceof Map){
				paramMap = (Map<String,String>) param;
			}else if(param instanceof PaginationVO){
				
			}
			
			switch(action){
				case GET_SESSION:
					if(type.equals(PortalPermissionType.user)){
						response = userServices.getBridgeUserInfo(sessionId,uriInfo,code);
					}
					break;
				case GET_USER:
					if(type.equals(PortalPermissionType.user)){
						response = userServices.getBridgeUserInfo(sessionId, uriInfo,code);
					}else if(type.equals(PortalPermissionType.admin)){
						Integer adminId=null;
						if(param instanceof HashMap){
							Map<String, Object> putMap =  (HashMap<String, Object>) param;
							adminId=(Integer)putMap.get(ApplicationConstants.PUT_REQUEST_ID);							
						}	
						response = adminUserService.getAdminUserInfo(sessionStatusVO,adminId,null,Boolean.FALSE,uriInfo);
					}
					break;
				case GET_USERS:
					response = adminUserService.getAdminUserInfo(sessionStatusVO,null,bridgePaginationVo,Boolean.TRUE,uriInfo);
					break;
				case UPDATE_USER:
					if(param instanceof HashMap){

						adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_SYSTEMUSER, adminUser);
						Map<String, Object> putMap =  (HashMap<String, Object>) param;
						id=(Integer)putMap.get(ApplicationConstants.PUT_REQUEST_ID);
						AdminUserProfileVO adminUserProfileVO =  (AdminUserProfileVO) putMap.get(ApplicationConstants.PUT_REQUEST_OBJECT);
					response = adminUserService.createOrUpdateAdminUser(sessionStatusVO,adminUserProfileVO,id,httpRequest, Boolean.FALSE,uriInfo);
					}
					break;
				case ADD_USER:
					if(param instanceof AdminUserProfileVO){
						adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_SYSTEMUSER, adminUser);
						AdminUserProfileVO adminUserProfileVO =  (AdminUserProfileVO) param;
					response = adminUserService.createOrUpdateAdminUser(sessionStatusVO,adminUserProfileVO, null,httpRequest, Boolean.TRUE,uriInfo);
					}
					break;
				
				case DELETE_USER:
					 if(type.equals(PortalPermissionType.admin)){
						adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_SYSTEMUSER, adminUser);
						Map<String, Object> putMap =  (HashMap<String, Object>) param;
						id=(Integer)putMap.get(ApplicationConstants.PUT_REQUEST_ID);
					 	response = adminUserService.deleteUser(sessionStatusVO,id,httpRequest,uriInfo);
					 }					
					 break;
					
				case GET_COMPANIES:
					if(param instanceof PaginationVO){
						PaginationVO paginationVO = (PaginationVO) param;
						response = adminUserService.getCompanies(sessionStatusVO, id,paginationVO,uriInfo);
					}
					break;
				case POST_COMPANIES :
					if(param instanceof CompanyVO){
						CompanyVO companyVO =  (CompanyVO) param;
						adminUserServiceUtil.validateAdminPermission(PermissionAction.SUPER_ADMIN, adminUser);
						response = adminUserService.createOrUpdateCompanies(sessionStatusVO,companyVO, id, uriInfo, httpRequest);
					}
					break;
					
				case PUT_COMPANIES :
					if(param instanceof HashMap){

					
						Map<String, Object> putMap =  (HashMap<String, Object>) param;
						id=(Integer)putMap.get(ApplicationConstants.PUT_REQUEST_ID);
						CompanyVO companyVO =  (CompanyVO) putMap.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.SUPER_ADMIN, adminUser);
						response = adminUserService.createOrUpdateCompanies(sessionStatusVO,companyVO, id, uriInfo, httpRequest);
					}
					break;
				case CHECK_COMPANY:
					if(param instanceof String){
						String apiKey=(String)param;
						response = adminUserService.checkCompany(sessionStatusVO, apiKey, uriInfo, httpRequest);
					}
					break;
					
				case GET_GROUPS :
					if(type.equals(PortalPermissionType.user)){
						response = userServices.getGroups(sessionStatusVO,code);
					} else if(type.equals(PortalPermissionType.admin)){
						//		response = adminUserService.getGroups(sessionStatusVO,uriInfo);
						response = adminUserService.getAllGroupsWithCompanies(sessionStatusVO);
					}
					break;
				case POST_GROUPS :
					if(param instanceof GroupVO){
						GroupVO groupVO =(GroupVO) param;
						response = adminUserService.createOrUpdateGroups(sessionStatusVO,groupVO,id,uriInfo,httpRequest);
					}
					break;
				case PUT_GROUPS :
					if(param instanceof HashMap){


						Map<String, Object> putMap =  (HashMap<String, Object>) param;
						id=(Integer)putMap.get(ApplicationConstants.PUT_REQUEST_ID);
						GroupVO groupVO =  (GroupVO) putMap.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						response = adminUserService.createOrUpdateGroups(sessionStatusVO,groupVO,id,uriInfo,httpRequest);
					}
					break;
				case PUT_USER:
					if(type.equals(PortalPermissionType.user)){
						if(param instanceof UserDetailsVO){
							UserDetailsVO newUserRequest =(UserDetailsVO)param;
							response = userServices.createOrUpdateUser(sessionStatusVO,httpRequest,newUserRequest, uriInfo, code,Boolean.FALSE,null,Boolean.FALSE);
						}						
					}else if(type.equals(PortalPermissionType.admin)){
						if(param instanceof GroupVO){
							AdminUserProfileVO adminUserProfileVO =(AdminUserProfileVO) param;
							response = adminUserService.createOrUpdateAdminUser(sessionStatusVO,adminUserProfileVO,null,httpRequest, Boolean.FALSE,uriInfo);
						}
					}
					break;
				case POST_LOGOS:
					response = adminUserService.uploadLogo(sessionStatusVO,param,httpRequest,uriInfo);
					break;
				case GET_BRIDGES_FOR_ID:
					response = adminUserService.getBridgeForId(sessionStatusVO,id,httpRequest,uriInfo);
					break;
				case PUT_BRIDGE:
					if(param instanceof HashMap){
						
						 HashMap<String, Object> putMap =  (HashMap<String, Object>) param;
						BridgeInfoWithFavoriteVO bridgeInfoWithFavoriteVO =  (BridgeInfoWithFavoriteVO) putMap.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						id= (Integer)putMap.get(ApplicationConstants.PUT_REQUEST_ID);
						response = adminUserService.createOrUpdateBridges(bridgeInfoWithFavoriteVO,sessionStatusVO,id,httpRequest,uriInfo);
						break;
					}
				case DELETE_BRIDGE:
					response = adminUserService.deleteBridge(sessionStatusVO,id,httpRequest,uriInfo);
					break;
				case POST_BRIDGE:
					if(param instanceof BridgeInfoWithFavoriteVO){
						BridgeInfoWithFavoriteVO bridgeInfoWithFavoriteVO =  (BridgeInfoWithFavoriteVO) param;
						response = adminUserService.createOrUpdateBridges(bridgeInfoWithFavoriteVO,sessionStatusVO,id,httpRequest,uriInfo);
						break;
					}
					
					
				case GET_BRIDGES_LIST :
					response = adminUserService.getBridgesList(sessionStatusVO,bridgePaginationVo,httpRequest,uriInfo);
					break;
				case GET_BOOKS_FOR_BRIDGE_ID:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgePaginationVo = (BridgePaginationVo) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						Boolean isGrouped = (Boolean) params.get(ApplicationConstants.IS_GROUPED);
						String category = (String) params.get(ApplicationConstants.CATEGORY_FILTER);
						response = bookServices.getBooksForBridge(sessionStatusVO, bridgePaginationVo, category, isGrouped, httpRequest, uriInfo);
					}
					break;
				case GET_BOOKS_FOR_VBID:
					if(param instanceof HashMap){
						Integer bridgeId = null;
						Integer groupId = null;


						HashMap<String,Object> parms = (HashMap<String, Object>) param;
						bridgeId = (Integer) parms.get(ApplicationConstants.BRIDGE_ID);
						vbid = (String) parms.get(ApplicationConstants.BRIDGE_BOOK_VBID_ID);	
						if(type.equals(PortalPermissionType.admin)){						
							response = bookServices.getBookForVbid(bridgeId, vbid);
						}else if(type.equals(PortalPermissionType.user)){
							response = userServices.getBooks(sessionStatusVO,groupId,vbid,code,bridgePaginationVo,null,false);
							if(response.getCode() != HttpStatus.OK.value()){
								throw new BridgeException(ApplicationCode.BOOK_NOT_FOUND);
							}
						}
					}
					break;
				case PUT_BOOKS_FOR_BRIDGE_ID :
					Integer bridgeId = null;
					Boolean selectAllBooks = Boolean.FALSE;
					List<BridgeBookVO> bridgeBookVO=null;
					if(param instanceof HashMap){

					
						HashMap<String,Object> parms = (HashMap<String, Object>) param;
						bridgeId = (Integer) parms.get(ApplicationConstants.BRIDGE_ID);
						selectAllBooks = (Boolean) parms.get(ApplicationConstants.SELECT_ALL_BOOKS);
						bridgeBookVO=(List<BridgeBookVO>)parms.get(ApplicationConstants.PUT_REQUEST_OBJECT);
					}
					
					adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_MANAGE, adminUser);
					response = bookServices.updateBridgesBooks(bridgeId, selectAllBooks,bridgeBookVO,httpRequest);
					break;
				case GET_BRIDGE_CONFIG :
					response = adminUserService.getBridgeConfigForId(sessionStatusVO,id, httpRequest, uriInfo);
					break;
				case PUT_BRIDGE_CONFIG:
					if(param instanceof HashMap){

					
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Map<String,String> requestMap=(Map<String,String>)params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
					response = adminUserService.updateBridgeConfigForId(sessionStatusVO,bridgeId,requestMap, httpRequest, uriInfo);
					break;
					}
				/*case POST_BRIDGE_KEY_BATCHES :
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						KeyBatchesVO keyBatchesVO=(KeyBatchesVO)params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
					response = adminUserService.createOrUpdateKeyBatchesForBridgeId(sessionStatusVO,keyBatchesVO,bridgeId, httpRequest, uriInfo);
					break;
					}*/
				case GET_BRIDGE_KEY_BATCHES:
					response = adminUserService.getKeyBatchesForBridgeId(sessionStatusVO,id, httpRequest, uriInfo);
					break;
				case GET_BRIDGE_INTIGRATION :
					response = adminUserService.getBridgeIntigrationForBridgeId(sessionStatusVO,id, httpRequest, uriInfo);
					break;
				case PUT_BRIDGE_INTIGRATION :
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						IntigrationVO intigrationVO=(IntigrationVO)params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
					response = adminUserService.updateBridgeIntigrationForBridgeId(sessionStatusVO,intigrationVO,bridgeId, httpRequest, uriInfo);
					break;
					}
				case GET_BATCHES_FILE :
					 adminUserService.getKeyBatchFile(sessionStatusVO,param, httpRequest, httpServletResponse,uriInfo);
					 break;
				case DELETE_USER_KEY :
					response =  adminUserService.deleteUserKeyCode(sessionStatusVO,param, httpRequest, uriInfo);
					break;
				
				case GET_BOOKS :
					
					response = userServices.getBooks(sessionStatusVO,null,null,code,bridgePaginationVo,null,false); 	
					break;
				case GET_COMPANIES_FOR_GROUP_ID:
					response = adminUserService.getCompaniesForGroupId(sessionStatusVO,id,code,bridgePaginationVo);
					break;
					
				case LAUNCH_BOOK_FOR_VBID :
					vbid = paramMap.get(ApplicationConstants.BRIDGE_BOOK_VBID_ID);
					String linkLocation = paramMap.get(ApplicationConstants.DEEPLINK_LOCATION);
					response = bookServices.launchBook(sessionStatusVO,vbid, linkLocation,code,httpRequest,uriInfo);
					break;
					
				case TRY_BOOK_FOR_VBID :
					response = bookServices.tryBook(sessionStatusVO,vbid,code,httpRequest,uriInfo);
					break;
				
				case RENT_BOOK_FOR_VBID :
					response = bookServices.rentBook(sessionStatusVO,vbid,code,httpRequest,uriInfo);
					break;
				
				case FULL_BOOK_FOR_VBID :
					response = bookServices.fullBook(sessionStatusVO,vbid,code,httpRequest,uriInfo);
					break; 
					
				case CONCURRENCY_BOOK_FOR_VBID :
					response = bookServices.concurrentBook(sessionStatusVO, vbid, code, httpRequest, uriInfo);
					break;
					
				case RETURN_BOOK_FOR_VBID:
					response=bookServices.returnBook(sessionStatusVO,vbid,code,httpRequest,uriInfo);
					break;
					
				case PRINT_BOOK_FOR_VBID :
					response = bookServices.printBook(sessionStatusVO,vbid,code,httpRequest,uriInfo);
					break;
					
				/*case RENT_PURCHASE_FOR_VBID:
					response = bookServices.purchaseBook(sessionStatusVO, vbid, ApplicationConstants.PURCHASE_RENT, code);
					break;
				case PRINT_PURCHASE_FOR_VBID:
					response = bookServices.purchaseBook(sessionStatusVO, vbid, ApplicationConstants.PURCHASE_PRINT, code);
					break;
				case FULL_PURCHASE_FOR_VBID:
					response = bookServices.purchaseBook(sessionStatusVO, vbid, ApplicationConstants.PURCHASE_FULL, code);
					break;*/
				case PURCHASE_FOR_VBID:
					if(param instanceof HashMap){
						HashMap<String,Object> parms = (HashMap<String, Object>) param;
						Integer purchaseId = Integer.parseInt((String) parms.get(ApplicationConstants.BRIDGE_PURCHASE_ID));
						vbid = (String) parms.get(ApplicationConstants.BRIDGE_BOOK_VBID_ID);
						response = bookServices.purchaseBook(sessionStatusVO,vbid,purchaseId,code);
					}
					
					break;
					
				case REDEEM_BOOK_FOR_VBID:
					if(param instanceof HashMap){
						HashMap<String,Object> parms = (HashMap<String, Object>) param;
						Integer entitlementId = Integer.parseInt((String) parms.get(ApplicationConstants.ENTITLEMENT_ID));
						vbid = (String) parms.get(ApplicationConstants.BRIDGE_BOOK_VBID_ID);
						response = bookServices.redeemVbid(sessionStatusVO,vbid,entitlementId,code);
					}
					break;
					
				case REDEEM_BOOK_FOR_CONCURRENCY_VBID:
					if(param instanceof HashMap){
						HashMap<String,Object> parms = (HashMap<String, Object>) param;
						Integer concEntitlementId = Integer.parseInt((String) parms.get(ApplicationConstants.CONCURRENCY_ENTITLEMENT_ID));
						vbid = (String) parms.get(ApplicationConstants.BRIDGE_BOOK_VBID_ID);
						response = bookServices.redeemConcurrencyVbid(sessionStatusVO,vbid,concEntitlementId,code);
					}
					break;
					
				case POST_KEY :
					if(param instanceof CreateKeysVO){
						CreateKeysVO createKeys = (CreateKeysVO)param;
						response =userServices.postKeysForUser(sessionStatusVO,createKeys,vbid,code,httpRequest,uriInfo);
					}					
					break;
				case GET_KEYS:
					response =userServices.getKeysForUser(sessionStatusVO,vbid,code,httpRequest,uriInfo);
					break;
				
				case REPORTS_GET_BOOK_FOR_BRIDGE_ID:
					if(param instanceof Map){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgePaginationVo = (BridgePaginationVo) params.get(ApplicationConstants.PAGINATION_VO);
						String category = (String) params.get(ApplicationConstants.CATEGORY_FILTER);
						response = reportServices.getBooksForBridgeId(bridgePaginationVo, category);
					}
					break;
					
				case REPORTS_GET_BOOK_FOR_VBID:
					if(param instanceof HashMap){
						HashMap<String,Object> parms = (HashMap<String, Object>) param;
						bridgeId = (Integer) parms.get(ApplicationConstants.BRIDGE_ID);
						vbid = (String) parms.get(ApplicationConstants.BRIDGE_BOOK_VBID_ID);
						response = reportServices.getBookForVbid(bridgeId,vbid);
					}
					break;
				case REPORTS_GET_KEYS_FOR_BRIDGE_ID:
					response = reportServices.getKeysForBridgeId(bridgePaginationVo);
					break;
				case REPORTS_GET_KEY_FOR_CODE:
					if(param instanceof HashMap){

					
						HashMap<String,Object> parms = (HashMap<String, Object>) param;
						bridgeId = (Integer) parms.get(ApplicationConstants.BRIDGE_ID);
						String keyCode = (String) parms.get(ApplicationConstants.KEYCODE);
						response = reportServices.getKeyDetailsForCode(bridgeId,keyCode);
					}
					break;
				case REPORTS_SUMMARY_LOGIN:
					if(param instanceof HashMap){

					
						HashMap<String,Object> parms = (HashMap<String, Object>) param;
						bridgeId = (Integer) parms.get(ApplicationConstants.BRIDGE_ID);
						Long startDateLong = (Long) parms.get(ApplicationConstants.REPORT_PARAM_START_DATE);
						Date startDate = this.getDate(startDateLong);
						Long endDateLong = (Long) parms.get(ApplicationConstants.REPORT_PARAM_END_DATE);
						Date endDate = this.getDate(endDateLong);
						response = reportServices.getBridgeLoginSummary(bridgeId,startDate,endDate);
					}
					break;
				case REPORTS_SUMMARY_KEYS:
					if(param instanceof HashMap){

					
						HashMap<String,Object> parms = (HashMap<String, Object>) param;
						bridgeId = (Integer) parms.get(ApplicationConstants.BRIDGE_ID);
						Long startDateLong = (Long) parms.get(ApplicationConstants.REPORT_PARAM_START_DATE);
						Date startDate = this.getDate(startDateLong);
						Long endDateLong = (Long) parms.get(ApplicationConstants.REPORT_PARAM_END_DATE);
						Date endDate = this.getDate(endDateLong);
						response = reportServices.getBridgeKeyRedeemedSummary(bridgeId,startDate,endDate);
					}
					
					break;
				case REPORTS_SUMMARY_CREDITS:
					if(param instanceof HashMap){

					
						HashMap<String,Object> parms = (HashMap<String, Object>) param;
						bridgeId = (Integer) parms.get(ApplicationConstants.BRIDGE_ID);
						Long startDateLong = (Long) parms.get(ApplicationConstants.REPORT_PARAM_START_DATE);
						Date startDate = this.getDate(startDateLong);
						Long endDateLong = (Long) parms.get(ApplicationConstants.REPORT_PARAM_END_DATE);
						Date endDate = this.getDate(endDateLong);
						response = reportServices.getBridgeCreditsSummary(bridgeId,startDate,endDate);
					}
					
					break;
					
				case REPORTS_SUMMARY_LAUNCH :
					if(param instanceof HashMap){

					
						HashMap<String,Object> parms = (HashMap<String, Object>) param;
						bridgeId = (Integer) parms.get(ApplicationConstants.BRIDGE_ID);
						Long startDateLong = (Long) parms.get(ApplicationConstants.REPORT_PARAM_START_DATE);
						Date startDate = this.getDate(startDateLong);
						Long endDateLong = (Long) parms.get(ApplicationConstants.REPORT_PARAM_END_DATE);
						Integer limit =  (Integer) parms.get(ApplicationConstants.PAGINATION_LIMIT);
						Date endDate = this.getDate(endDateLong);
						response = reportServices.getBridgeBookLaunchSummary(bridgeId,limit,startDate,endDate);
					}
					break;
				case POST_BRIDGE_GROUP:	
					if(param instanceof HashMap){

					
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						BridgeGroupVO bridgeGroupVO=(BridgeGroupVO)params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						response= groupServices.createOrUpdateBridgeGroup(sessionStatusVO,bridgeGroupVO,bridgeId,null,httpRequest, uriInfo);
						break;
					}
				case PUT_BRIDGE_GROUP:
					if(param instanceof HashMap){

					
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Integer groupdId=(Integer) params.get(ApplicationConstants.BRIDGE_GROUP_ID);
						BridgeGroupVO bridgeGroupVO=(BridgeGroupVO)params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						response= groupServices.createOrUpdateBridgeGroup(sessionStatusVO,bridgeGroupVO,bridgeId,groupdId,httpRequest, uriInfo);
						break;
					}
				case POST_DUPLICATE_GROUP:
					if(param instanceof HashMap){

						
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Integer groupdId=(Integer) params.get(ApplicationConstants.BRIDGE_GROUP_ID);
						String duplicateGroupName=(String)params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						response= groupServices.duplicateBridgeGroup(sessionStatusVO,duplicateGroupName,bridgeId,groupdId,httpRequest, uriInfo);
						break;
					}
				case PUT_BRIDGE_GROUP_USERS:
					if(param instanceof HashMap){

					
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Integer groupId=(Integer) params.get(ApplicationConstants.BRIDGE_GROUP_ID);
						BridgeGroupUserVO bridgeGroupUserVO=(BridgeGroupUserVO)params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						response= groupServices.updateBridgeGroupUsers(sessionStatusVO,bridgeGroupUserVO,bridgeId,groupId,httpRequest, uriInfo);
						break;
					}
				case PUT_BRIDGE_GROUP_BOOKS:
					if(param instanceof HashMap){

					
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Integer groupId=(Integer) params.get(ApplicationConstants.BRIDGE_GROUP_ID);
						BridgeGroupBookVO bridgeGroupBookVO=(BridgeGroupBookVO)params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						response= groupServices.updateBridgeGroupBooks(sessionStatusVO,bridgeGroupBookVO,bridgeId,groupId,httpRequest, uriInfo);
						break;
					}
				case GET_USERS_FOR_BRIDGE_ID:
					if(param instanceof HashMap) {

						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						PaginationVO paginationVO = (PaginationVO) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						Boolean isGrouped = (Boolean) params.get(ApplicationConstants.IS_GROUPED);
						Boolean bcRefresh = (Boolean) params.get(ApplicationConstants.PAGINATION_REFRESH);
						response = groupServices.getGroupUsersForBridgeId(sessionStatusVO,bridgeId,null,paginationVO,isGrouped,bcRefresh);	
						break;
					}
					
				case GET_GROUPS_FOR_BRIDGE_ID:
					if(param instanceof HashMap) {

						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Boolean refreshGroups = (Boolean) params.get(ApplicationConstants.PAGINATION_REFRESH);
						response = groupServices.getGroupsForBridgeId(sessionStatusVO,bridgeId,refreshGroups, false,httpRequest, uriInfo);
					}
					break;
				case GET_GROUP_UESRS_FOR_BRIDGE_ID:
					if(param instanceof HashMap) {

					
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Integer groupId=(Integer) params.get(ApplicationConstants.BRIDGE_GROUP_ID);
						PaginationVO paginationVO = (PaginationVO) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						response = groupServices.getGroupUsersForBridgeId(sessionStatusVO,bridgeId, groupId, paginationVO, null,null);						
					}
					break;
				case GET_GROUP_BOOKS_FOR_BRIDGE_ID:
					if(param instanceof HashMap) {

					
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Integer groupId=(Integer) params.get(ApplicationConstants.BRIDGE_GROUP_ID);
						BridgePaginationVo paginationVO = (BridgePaginationVo) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						String category = (String) params.get(ApplicationConstants.CATEGORY_FILTER);						
						response = groupServices.getGroupBooksForBridgeId(bridgeId, groupId, paginationVO, category);						
					}
					break;
				case BULK_INSERT_GROUP_ASSETS_USERS :
				
					if(param instanceof HashMap) {

					
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
			//			BridgePaginationVo paginationVO = (BridgePaginationVo) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						BridgeGroupAssetUserVO groupAssetUsersVO = (BridgeGroupAssetUserVO) params.get(ApplicationConstants.GROUP_ASSET_USERS);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_MANAGE, adminUser);
						response = groupServices.addBulkGroupAssetUsers(bridgeId,groupAssetUsersVO);				
					}
				
				break;
				case DELETE_BRIDGE_GROUP_USERS:
					if(param instanceof HashMap){

					
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Integer groupId=(Integer) params.get(ApplicationConstants.BRIDGE_GROUP_ID);		
						List<Integer> userIds  =(List<Integer>)params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						Boolean deleteAll = (Boolean) params.get(ApplicationConstants.DELETE_ALL);
						String search=(String) params.get(ApplicationConstants.PAGINATION_SEARCH);
						Boolean isGrouped =(Boolean) params.get(ApplicationConstants.IS_GROUPED);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_MANAGE, adminUser);
						response= groupServices.deleteBridgeGroupUsers(sessionStatusVO,userIds,bridgeId,groupId,deleteAll,search,isGrouped,httpRequest, uriInfo);						
					}
					break;
				case DELETE_BRIDGE_GROUP_BOOKS:
					if(param instanceof HashMap){

					
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Integer groupId=(Integer) params.get(ApplicationConstants.BRIDGE_GROUP_ID);
						List<String> vbids = (List<String>)params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						Boolean deleteAll = (Boolean) params.get(ApplicationConstants.DELETE_ALL);
						String search= (String) params.get(ApplicationConstants.PAGINATION_SEARCH);
						Boolean isGrouped=(Boolean) params.get(ApplicationConstants.IS_GROUPED);
						String category=(String) params.get(ApplicationConstants.CATEGORY_FILTER);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_MANAGE, adminUser);
						response= groupServices.deleteBridgeGroupBooks(sessionStatusVO,vbids,bridgeId,groupId,deleteAll,search,isGrouped, category,httpRequest, uriInfo);
					}
					break;
				case DELETE_BRIDGE_GROUP:
					if(param instanceof HashMap){

					
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Integer groupId=(Integer) params.get(ApplicationConstants.BRIDGE_GROUP_ID);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_MANAGE, adminUser);						
						response= groupServices.deleteBridgeGroup(sessionStatusVO,bridgeId, groupId, httpRequest,uriInfo);						
					}
					break;
				case DELETE_BRIDGE_USERS:
					if(param instanceof HashMap){					
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
					
						List<Integer> users  =(List<Integer>) params.get(ApplicationConstants.GROUP_ASSET_USERS);
						Boolean deleteAll = (Boolean) params.get(ApplicationConstants.DELETE_ALL);
						String search = (String)params.get(ApplicationConstants.PAGINATION_SEARCH);
						Boolean isUngrouped = (Boolean)params.get(ApplicationConstants.IS_UNGROUPED);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_USERS, adminUser);
						response= adminUserService.deleteBridgeUsers(sessionStatusVO,bridgeId,users,deleteAll,search,isUngrouped);					
					}
					break;
				case GET_GROUP_BY_ID:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						Integer groupId=(Integer) params.get(ApplicationConstants.BRIDGE_GROUP_ID);
						BridgePaginationVo paginationVO = (BridgePaginationVo) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						response = userServices.getBooks(sessionStatusVO, groupId, vbid, code, paginationVO,null, Boolean.FALSE);
					}
				break;
				
				case GET_BOOK_GROUPS_FOR_BRIDGE_ID:					
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						vbid = (String) params.get(ApplicationConstants.BRIDGE_BOOK_VBID_ID);	
						response = groupServices.getBridgeGroupForVbid(sessionStatusVO, bridgeId, vbid, httpRequest, uriInfo);
					}					
					break;
				case GET_USER_GROUPS_FOR_BRIDGE_ID:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Integer userId = (Integer) params.get(ApplicationConstants.USER_ID);						
						response = groupServices.getBridgeGroupForUserId(bridgeId, userId);
					}					
					break;
				case POST_CSV_ROSTER:
					if(param instanceof HashMap){
						@SuppressWarnings("unchecked")
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						MultipartFile uploadFile =  (MultipartFile) params.get(ApplicationConstants.UPLOAD_INPUT_STREAM);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_ACCESS, adminUser);
						final CSVResponseWrapperVO wrapperVO = adminUserService.uploadCSVRoster(sessionStatusVO,httpRequest,uriInfo, bridgeId,uploadFile);
						response = wrapperVO.getResponse();
						if(response.getCode()==200){					
						
						final Runnable runnable = new Runnable() {

							@Override
							public void run(){
								try {
									adminUserService.processRosteringCSV(sessionStatusVO,wrapperVO.getUploadRosterVO(),wrapperVO.getBeanReader(),wrapperVO.getHeader());
								} catch (BridgeException | IOException | InvalidActionException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						};
						this.executor.execute(runnable);						
						}
						break;
					}
				case GET_BRIDGE_ROSTER_HISTORY:
					response=adminUserService.getRosterHistoryForBridgeId(sessionStatusVO,id, httpRequest, uriInfo);
					break;	

				case GET_ROSTER_FILE:
					adminUserService.getRosterFile(sessionStatusVO,param, httpRequest, httpServletResponse,uriInfo);
					break;

				case POST_CSV_ROSTER_TEMPLATE:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						MultipartFile uploadFile = (MultipartFile) params.get(ApplicationConstants.UPLOAD_INPUT_STREAM);
						CSVFileType fileType = (CSVFileType) params.get(ApplicationConstants.TYPE);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.SUPER_ADMIN, adminUser);
						response = adminUserService.uploadCSVRosterTemplate(httpRequest,uriInfo,uploadFile,fileType);
					}
					break;

				case GET_CSV_ROSTER_TEMPLATE:
					CSVFileType fileType = (CSVFileType) param;
					adminUserService.downloadCSVRosterTemplate(fileType, httpServletResponse);
					break;
					
				case PUT_CONCURRENCY_LIMIT_FOR_BOOKS:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						BookConcurrencyLimitVO bookConcurrencyLimitVO = (BookConcurrencyLimitVO) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_USERCONCURRENCY, adminUser);
						response = bookServices.updateConcurrencyForBooks(sessionStatusVO, bridgeId,bookConcurrencyLimitVO, httpRequest, uriInfo);
					}
					break;	
					
				case GET_BRIDGE_FOR_GROUP_ID:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Integer groupId = (Integer) params.get(ApplicationConstants.BRIDGE_GROUP_ID);
						Boolean refresh = (Boolean) params.get(ApplicationConstants.PAGINATION_REFRESH);
						
						response = groupServices.getBridgeGroupById(sessionStatusVO, bridgeId,groupId,refresh, httpRequest, uriInfo);
					}
					break;
				
				case GET_COURSES_FOR_TENANT_ID:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Integer tenantId = (Integer) params.get(ApplicationConstants.TENANT_ID);
						response = businessCenterServices.createOrUpdateCoursesForTenantId(sessionStatusVO, bridgeId,tenantId, httpRequest, uriInfo,null,Boolean.FALSE);
					}
				break;
				
				case GET_USERS_FOR_TENANT_ID:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Integer tenantId = (Integer) params.get(ApplicationConstants.TENANT_ID);
						response = businessCenterServices.getUsersForTenantId(sessionStatusVO, bridgeId,tenantId, httpRequest, uriInfo,null,Boolean.FALSE);
					}
				break;
				
				case GET_COURSE_FOR_GROUP_ID:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Integer groupId = (Integer) params.get(ApplicationConstants.BRIDGE_GROUP_ID);
						response = businessCenterServices.getCourseForGroupId(sessionStatusVO, bridgeId,groupId, httpRequest, uriInfo,Boolean.FALSE);
					}
				break;
				
				case PUT_ALLOWANCE_FOR_BRIDGE_ID:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						AllowanceRequestVO allowanceRequestVO = (AllowanceRequestVO) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_ALLOWANCE, adminUser);
						response=adminUserService.updateBridgeAllowanceForBridgeId(sessionStatusVO, allowanceRequestVO, bridgeId, httpRequest, uriInfo);
					}					
				break;
				
				case GET_ALLOWANCE_FOR_BRIDGE_ID:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);						
						response=adminUserService.getBridgeAllowanceForBridgeId(sessionStatusVO, bridgeId, httpRequest, uriInfo);
					}
				break;
				
				case GET_UPLOAD_TOKEN:
					if(param instanceof Map){
						Map<?,?> params = (HashMap<String,Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						TokenRequestVO tokenRequestVO = (TokenRequestVO) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						
						if(null != tokenRequestVO && null != tokenRequestVO.getUploadType()){
							if(UploadType.MULTIPART == UploadType.valueOf(tokenRequestVO.getUploadType().toUpperCase())){
								response=ancillaryServices.getAncillaryUploadToken(sessionStatusVO, bridgeId, UploadType.MULTIPART, httpRequest, uriInfo);
							}else if(UploadType.RESUMABLE == UploadType.valueOf(tokenRequestVO.getUploadType().toUpperCase())){
								
							}
						}	
					}
				break;
				
				case GET_ACCESS_TYPE_FOR_BRIDGE_ID:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);						
						response=adminUserService.getAccessTypeForBridgeId(sessionStatusVO, bridgeId, httpRequest, uriInfo);
					}		
				break;	
					
				case GET_CSV_ERROR_FILE:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						adminUserService.getCsvErrorFile(sessionStatusVO, params, httpRequest, httpServletResponse, uriInfo);
					}
				break;	
				
				case PUT_PURCHASE_FOR_BRIDGE_ID:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						PurchaseRequestVO purchaseRequestVO = (PurchaseRequestVO) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_PURCHASE, adminUser);
						response=adminUserService.updateBridgePurchaseForBridgeId(sessionStatusVO, purchaseRequestVO, bridgeId, httpRequest, uriInfo);
					}					
				break;
				
				case GET_PURCHASE_FOR_BRIDGE_ID:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);						
						response=adminUserService.getBridgePurchaseForBridgeId(sessionStatusVO, bridgeId, httpRequest, uriInfo);
					}					
				break;
				
				
				case POST_BRIDGE_KEY_GENERATE:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						KeyGenerateRequestVO keyGenerateRequestVO=(KeyGenerateRequestVO)params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_KEY, adminUser);
					response = adminUserService.generateKeysForBridgeId(sessionStatusVO,keyGenerateRequestVO,bridgeId, httpRequest, uriInfo);
					if(response.getCode()!=null && response.getCode()!=200){
						status=HttpStatus.BAD_REQUEST;
						}
					}
				break;
				
				case PUT_BRIDGE_KEY_GENERATE:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						KeyGenerateRequestVO keyGenerateRequestVO=(KeyGenerateRequestVO)params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_KEY, adminUser);
					response = adminUserService.updateGeneratedKeysForBridgeId(sessionStatusVO,keyGenerateRequestVO,params, httpRequest, uriInfo);
					if(response.getCode()!=null && response.getCode()!=200){
						status=HttpStatus.BAD_REQUEST;
					}
				}
				break;	
					
				case GET_ENTITLEMENT_FOR_KEYBATCH:
					if(param instanceof HashMap){
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						Integer keyBatchId = (Integer) params.get(ApplicationConstants.KEY_BATCH_ID);
					response = adminUserService.getEntitlementForKeybatch(sessionStatusVO,bridgeId,keyBatchId, httpRequest, uriInfo);
					}
				break;	

				case GET_ANCILLARIES_FOR_BRIDGE:
					if(param instanceof Map){
						Map<?,?> params = (Map<?, ?>) param;
						bridgeId =(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						PaginationVO paginationVO = (PaginationVO) params.get(ApplicationConstants.PAGINATION_VO);
						response=ancillaryServices.getAllAncillaries(sessionStatusVO, bridgeId, paginationVO, httpRequest);
					}
				break;
				
				case GET_ANCILLARY_STATUS:
					if(param instanceof Map){
						Map<?,?> params = (Map<?,?>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						id=(Integer) params.get(ApplicationConstants.REST_PARAM_ID);
						response=ancillaryServices.getAncillaryStatus(sessionStatusVO, bridgeId, id, httpRequest);
					}
					break;
					
				case GET_ANCILLARY:
					if(param instanceof Map){
						Map<?,?> params = (Map<?,?>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						id=(Integer) params.get(ApplicationConstants.REST_PARAM_ID);
						response=ancillaryServices.getAncillary(sessionStatusVO, bridgeId, id, httpRequest);
					}
					break;
				case UPDATE_ANCILLARY:
					if(param instanceof Map){
						Map<?,?> params = (Map<?,?>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.ALLOW_CONTENTUPLOAD, adminUser);
						if(params.get(ApplicationConstants.PUT_REQUEST_OBJECT) instanceof List<?>){
							List<AncillaryAdminVO> ancillaryAdminVOList = (List<AncillaryAdminVO>) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
							response=ancillaryServices.updateAncillary(bridgeId, ancillaryAdminVOList,sessionStatusVO , httpRequest);
						}else if (params.get(ApplicationConstants.PUT_REQUEST_OBJECT) instanceof AncillaryAdminVO){
							Integer ancillaryId = (Integer) params.get(ApplicationConstants.REST_PARAM_ID);
							AncillaryAdminVO ancillaryVO = (AncillaryAdminVO) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
							response=ancillaryServices.updateAncillary(bridgeId, ancillaryVO, ancillaryId, sessionStatusVO,httpRequest);
						}

					}
					break;
				case DOWNLOAD_ANCILLARY:
					if(param instanceof Map){
						Map<?,?> params = (Map<?,?>) param;
						vbid= (String) params.get(ApplicationConstants.BRIDGE_BOOK_VBID_ID);
						response=ancillaryServices.dowloadAncillary(vbid, httpRequest, code, sessionStatusVO);
					}
					break;
				
				case POST_CSV_GROUP_TO_ASSET_MAPPING:
					if(param instanceof HashMap){
						@SuppressWarnings("unchecked")
						HashMap<String,Object> params = (HashMap<String, Object>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						MultipartFile uploadFile =  (MultipartFile) params.get(ApplicationConstants.UPLOAD_INPUT_STREAM);
						response = adminUserService.processCSVForGroupAssetsMapping(sessionStatusVO,httpRequest,uriInfo, bridgeId,uploadFile);	
					}
					break;
				
				case DELETE_ANCILLARY:
					if(param instanceof Map){
						Map<?,?> params = (Map<?,?>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.ALLOW_CONTENTUPLOAD, adminUser);
						if(params.get(ApplicationConstants.PUT_REQUEST_OBJECT) instanceof List<?>){
							List<AncillaryAdminVO> ancillaryAdminVOList = (List<AncillaryAdminVO>) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
							response=ancillaryServices.deleteAncillary(bridgeId, ancillaryAdminVOList, httpRequest);
						}else if (params.get(ApplicationConstants.PUT_REQUEST_OBJECT) instanceof AncillaryAdminVO){
							Integer ancillaryId = (Integer) params.get(ApplicationConstants.REST_PARAM_ID);
							AncillaryAdminVO ancillaryAdminVO = (AncillaryAdminVO) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
							response=ancillaryServices.deleteAncillary(bridgeId, ancillaryAdminVO, ancillaryId, httpRequest);
						}
					}
					break;
				case EDIT_BOOK_FOR_VBID:
					if(param instanceof Map){
						Map<?,?> params = (Map<?,?>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						BridgeBooksVO bridgeBooksVO = null;
						vbid = (String) params.get(ApplicationConstants.BRIDGE_BOOK_VBID_ID);
						adminUserServiceUtil.validateAdminPermission(PermissionAction.ALLOW_CONTENTUPLOAD, adminUser);
						if((bridgeBooksVO = (BridgeBooksVO) params.get(ApplicationConstants.PUT_REQUEST_OBJECT)) instanceof BridgeBooksVO){
							response=bookServices.updateBridgeBookAncillaryTitle(bridgeId, bridgeBooksVO, vbid, httpRequest);
						}
					}
					break;

				case GET_ADMINS_LABELS:
					response = adminUserService.getAdminLabels(httpRequest, uriInfo);
					break;

				case DELETE_ANCILLARY_BOOK_CACHE:
					if(param instanceof Map){
						Map<?,?> params = (Map<?,?>) param;
						bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						List<String> vbidList = (List<String>) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						response=bookServices.deleteAncillaryBookCache(bridgeId, vbidList, vbid, httpRequest, sessionStatusVO);
					}
					
					break;

				default :					
						throw new InvalidActionException();
				}			
			}
		catch(BridgeException bridgeExcepation){
			logger.error(localeMessageUtility.getErrorMessage(bridgeExcepation.getErrorCode().getCodeId()) + " " +sessionId, 
					bridgeExcepation.getErrorCode() == ApplicationCode.SESSION_EXPIRED ? "" : bridgeExcepation);
			switch(bridgeExcepation.getErrorCode()){
				case SESSION_EXPIRED:
					status = HttpStatus.UNAUTHORIZED;
					response = new RestResponse(Response.Status.UNAUTHORIZED.getStatusCode(), ApplicationCode.SESSION_EXPIRED.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.SESSION_EXPIRED.getCodeId()));
					break;
					
				case INVALID_SESSION :
					status = HttpStatus.FORBIDDEN;
					response = new RestResponse(Response.Status.FORBIDDEN.getStatusCode(), ApplicationCode.INVALID_SESSION.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_SESSION.getCodeId()));
					break;
					
				case BASE_DB_ERROR:
					status = HttpStatus.INTERNAL_SERVER_ERROR;
					response = new RestResponse(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), ApplicationCode.BASE_DB_ERROR.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.BASE_DB_ERROR.getCodeId()));
					break;
					
				case USER_ALREADY_EXIST:
					status = HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.USER_ALREADY_EXIST.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.USER_ALREADY_EXIST.getCodeId()));
					break;
					
				case BRIDGE_NOT_FOUND:
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.BRIDGE_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.BRIDGE_NOT_FOUND.getCodeId()));
					break;
					
				case COMPANY_NOT_FOUND:
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.COMPANY_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.COMPANY_NOT_FOUND.getCodeId()));
					break;
					
				case DUPLICATE_BRIDGE_NAME :
					status = HttpStatus.CONFLICT;
					response = new RestResponse(Response.Status.CONFLICT.getStatusCode(), ApplicationCode.DUPLICATE_BRIDGE_NAME.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.DUPLICATE_BRIDGE_NAME.getCodeId()));
					break;
					
				case DUPLICATE_BRIDGE_CODE :
					status = HttpStatus.CONFLICT;
					response = new RestResponse(Response.Status.CONFLICT.getStatusCode(), ApplicationCode.DUPLICATE_BRIDGE_CODE.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.DUPLICATE_BRIDGE_CODE.getCodeId()));
					break;
				
				case DUPLICATE_COMPANY_NAME :
					status = HttpStatus.CONFLICT;
					response = new RestResponse(Response.Status.CONFLICT.getStatusCode(), ApplicationCode.DUPLICATE_COMPANY_NAME.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.DUPLICATE_COMPANY_NAME.getCodeId()));
					break;
				case DUPLICATE_GROUP_NAME :
					status = HttpStatus.CONFLICT;
					response = new RestResponse(Response.Status.CONFLICT.getStatusCode(), ApplicationCode.DUPLICATE_GROUP_NAME.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.DUPLICATE_GROUP_NAME.getCodeId()));
					break;
					
				case KEY_CODE_NOT_FOUND :
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.KEY_CODE_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.KEY_CODE_NOT_FOUND.getCodeId()));
					break;
					
				case KEY_MAX_USER_REACH :
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.KEY_MAX_USER_REACH.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.KEY_MAX_USER_REACH.getCodeId()));
					break;
				case BRIDGE_USER_NOT_FOUND :
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.BRIDGE_USER_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.BRIDGE_USER_NOT_FOUND.getCodeId()));
					break;
				case USE_KEY_ASSOCIATION_NOT_FOUND :
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.USE_KEY_ASSOCIATION_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.USE_KEY_ASSOCIATION_NOT_FOUND.getCodeId()));
					break;
					
				case INVALID_ORDERBY_FIELD :
					status = HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.INVALID_ORDERBY_FIELD.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_ORDERBY_FIELD.getCodeId()));
					break;
				case LICENSE_NOT_FOUND:
					status = HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.LICENSE_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.LICENSE_NOT_FOUND.getCodeId()));
					break;
				case KEY_EXPIRED:
					status = HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.KEY_EXPIRED.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.KEY_EXPIRED.getCodeId()));
					break;
				case KEY_NOT_FOUND:
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.KEY_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.KEY_NOT_FOUND.getCodeId()));
					break;
				case DUPLICATE_KEY:
					status = HttpStatus.CONFLICT;
					response = new RestResponse(Response.Status.CONFLICT.getStatusCode(), ApplicationCode.DUPLICATE_KEY.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.DUPLICATE_KEY.getCodeId()));
					break;
				case GROUP_NOT_FOUND:
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.GROUP_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.GROUP_NOT_FOUND.getCodeId()));
					break;
				case NO_SUCH_WEBSITE :
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.NO_SUCH_WEBSITE.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.NO_SUCH_WEBSITE.getCodeId()));
					break;
					
				case INVALID_BRIDGE_KEY:
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.INVALID_BRIDGE_KEY.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_BRIDGE_KEY.getCodeId()));
					break;
				case DUPLICATE_BRIDGE_ALIAS:
					status = HttpStatus.CONFLICT;
					response = new RestResponse(Response.Status.CONFLICT.getStatusCode(), ApplicationCode.DUPLICATE_BRIDGE_ALIAS.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.DUPLICATE_BRIDGE_ALIAS.getCodeId()));
					break;
					
				case INVALID_BRIDGE_CODE :
					status = HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.INVALID_BRIDGE_CODE.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_BRIDGE_CODE.getCodeId()));
					break;
					
				case INVALID_FULL_CREDITS_VALUE:
					status = HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.INVALID_FULL_CREDITS_VALUE.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_FULL_CREDITS_VALUE.getCodeId()));
					break;
					
				case INVALID_BRIDGE_KEY_CODE :
					status = HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.INVALID_BRIDGE_KEY_CODE.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_BRIDGE_KEY_CODE.getCodeId()));
					break;
				case INVALID_REPORT_PAGE :
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.INVALID_REPORT_PAGE.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_REPORT_PAGE.getCodeId()));
					break;
				case BOOK_NOT_FOUND :
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.BOOK_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.BOOK_NOT_FOUND.getCodeId()));
					break;
				case USER_NOT_FOUND :
					 status = HttpStatus.NOT_FOUND;
					 response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.USER_NOT_FOUND.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.USER_NOT_FOUND.getCodeId()));
					 break;
					 				
				case INSUFFICIENT_PRIVILEGE :
					 status = HttpStatus.NOT_FOUND;
					 response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.INSUFFICIENT_PRIVILEGE.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.INSUFFICIENT_PRIVILEGE.getCodeId()));
					 break;
				
				case INVALID_DATE :
					 status = HttpStatus.BAD_REQUEST;
					 response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.INVALID_DATE.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_DATE.getCodeId()));
					 break;
					 
				case INVALID_INPUT:
					status=HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.INVALID_INPUT.getCodeId(),
				 			localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_INPUT.getCodeId()));					
					break;
				
			case USER_DELTED_BY_ADMIN:
				 status = HttpStatus.BAD_REQUEST;
				 response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.USER_DELTED_BY_ADMIN.getCodeId(),
				 		localeMessageUtility.getErrorMessage(ApplicationCode.USER_DELTED_BY_ADMIN.getCodeId()));
					break;

			case	NOT_FULL_USER:
				 status = HttpStatus.BAD_REQUEST;
				 response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.NOT_FULL_USER.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.NOT_FULL_USER.getCodeId()));
				break;
				
			case BOOKSHELF_FULL_USER :
				 status = HttpStatus.BAD_REQUEST;
				 response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.BOOKSHELF_FULL_USER.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.BOOKSHELF_FULL_USER.getCodeId()));
				break;	
			
			case ALREADY_USED_TOKEN :
				 status = HttpStatus.BAD_REQUEST;
				 response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.ALREADY_USED_TOKEN.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.ALREADY_USED_TOKEN.getCodeId()));
				break;
			
			case EXPIRED_TOKEN :
				 status = HttpStatus.BAD_REQUEST;
				 response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.EXPIRED_TOKEN.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.EXPIRED_TOKEN.getCodeId()));
				break;
			
			case INVALID_TOKEN:
				status = HttpStatus.NOT_FOUND;
				 response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.INVALID_TOKEN.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_TOKEN.getCodeId()));
				break;

			case BRIDGE_NOT_ROSTERED:
				status = HttpStatus.NOT_FOUND;
				 response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.BRIDGE_NOT_ROSTERED.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.BRIDGE_NOT_ROSTERED.getCodeId()));
				break;

			case TEMPLATE_NOT_FOUND:
					status=HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.TEMPLATE_NOT_FOUND.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.TEMPLATE_NOT_FOUND.getCodeId()));
					break;
			
			case CONCURRENCY_NOT_ENABLED:
					status=HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.CONCURRENCY_NOT_ENABLED.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.CONCURRENCY_NOT_ENABLED.getCodeId()));
					break;
					
			case CONCURRENCY_LIMIT_REACHED:
				status=HttpStatus.BAD_REQUEST;
				response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.CONCURRENCY_LIMIT_REACHED.getCodeId(),
				 		localeMessageUtility.getErrorMessage(ApplicationCode.CONCURRENCY_LIMIT_REACHED.getCodeId()));
				break;
			
			case RETURN_BOOK_FAILED:
				status=HttpStatus.BAD_REQUEST;
				response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.RETURN_BOOK_FAILED.getCodeId(),
				 		localeMessageUtility.getErrorMessage(ApplicationCode.RETURN_BOOK_FAILED.getCodeId()));
				break;
			case USER_NOT_ROSTERED:
				status=HttpStatus.NOT_FOUND;
				response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.USER_NOT_ROSTERED.getCodeId(),
				 		localeMessageUtility.getErrorMessage(ApplicationCode.USER_NOT_ROSTERED.getCodeId()));
				break;
			case TENANT_NOT_VALID:
				status=HttpStatus.NOT_FOUND;
				response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.TENANT_NOT_VALID.getCodeId(),
				 		localeMessageUtility.getErrorMessage(ApplicationCode.TENANT_NOT_VALID.getCodeId()));
				break;
			
			case INVALID_ROSTER_HEADER:
				status=HttpStatus.BAD_REQUEST;
				response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.INVALID_ROSTER_HEADER.getCodeId(),
				 		localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_ROSTER_HEADER.getCodeId()));
				break;
			
			case PURCHASE_NOT_ENABLED:
				status=HttpStatus.BAD_REQUEST;
				response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.PURCHASE_NOT_ENABLED.getCodeId(),
				 		localeMessageUtility.getErrorMessage(ApplicationCode.PURCHASE_NOT_ENABLED.getCodeId()));
				break;
				
			case INVALID_GROUP_NAME:
				status=HttpStatus.BAD_REQUEST;
				response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.INVALID_GROUP_NAME.getCodeId(),
				 		localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_GROUP_NAME.getCodeId()));
				break;
			case DATA_VALIDATION_ERROR:
				status=HttpStatus.BAD_REQUEST;
				response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.INVALID_GROUP_NAME.getCodeId(),
				 		localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_GROUP_NAME.getCodeId()));
				break;
			
			case COMPANY_ALREADY_EXIST:
				status=HttpStatus.CONFLICT;
				response = new RestResponse(Response.Status.CONFLICT.getStatusCode(), ApplicationCode.COMPANY_ALREADY_EXIST.getCodeId(),
						bridgeExcepation.getMessage());
				break;
			case MISSING_INPUT_FIELD:
				status=HttpStatus.BAD_REQUEST;
				response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.MISSING_INPUT_FIELD.getCodeId(),
						bridgeExcepation.getMessage());
				break;
			
			case INSUFFICIENT_PRIVILEGE_FOR_ADMIN:
				status=HttpStatus.UNAUTHORIZED;
				response = new RestResponse(Response.Status.UNAUTHORIZED.getStatusCode(), ApplicationCode.INSUFFICIENT_PRIVILEGE_FOR_ADMIN.getCodeId(),
						bridgeExcepation.getMessage());
				break;
				
			
			default:
					status = HttpStatus.INTERNAL_SERVER_ERROR;
					response = new RestResponse(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), ApplicationCode.UNEXPECTED_ERROR.getCodeId(),							localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()));
			}
		} catch (InvalidActionException e) {
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_BRIDGE_ACTION.getCodeId()),e);
			status = HttpStatus.NOT_FOUND;
			response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.INVALID_BRIDGE_ACTION.getCodeId(),
					localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_BRIDGE_ACTION.getCodeId()));
		} catch (ParseException e) {
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.PARSING_ERROR.getCodeId()),e);
			status = HttpStatus.INTERNAL_SERVER_ERROR;
			response = new RestResponse(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), ApplicationCode.PARSING_ERROR.getCodeId(),
					localeMessageUtility.getErrorMessage(ApplicationCode.PARSING_ERROR.getCodeId()));
		} catch (IOException e) {
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()),e);
			status = HttpStatus.INTERNAL_SERVER_ERROR;
			response = new RestResponse(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), ApplicationCode.UNEXPECTED_ERROR.getCodeId(),
					localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()));
		}  catch (ConnectApiException e) {
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()),e);
			status = HttpStatus.INTERNAL_SERVER_ERROR;
			response = new RestResponse(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), ApplicationCode.CONNECT_API_ERROR.getCodeId(),
					localeMessageUtility.getErrorMessage(ApplicationCode.CONNECT_API_ERROR.getCodeId()));
		} catch (ConnectApiXmlException e) {
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()),e);
			status = HttpStatus.INTERNAL_SERVER_ERROR;
			response = new RestResponse(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), ApplicationCode.CONNECT_API_ERROR.getCodeId(),
					localeMessageUtility.getErrorMessage(ApplicationCode.CONNECT_API_ERROR.getCodeId()));
		}catch (JsonBindingException e) {
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.PARSING_ERROR.getCodeId()),e);
			status = HttpStatus.BAD_REQUEST;
			response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.PARSING_ERROR.getCodeId(),
					localeMessageUtility.getErrorMessage(ApplicationCode.PARSING_ERROR.getCodeId()));
		}catch (HibernateOptimisticLockingFailureException e) {
			status = HttpStatus.BAD_REQUEST;
			e.printStackTrace();
			process(action, type, sessionId, param, httpRequest,httpServletResponse,uriInfo);
		} catch (ConnectApiFieldException e) {
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()),e);
			status = HttpStatus.INTERNAL_SERVER_ERROR;
			response = new RestResponse(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), ApplicationCode.CONNECT_API_ERROR.getCodeId(),
					localeMessageUtility.getErrorMessage(ApplicationCode.CONNECT_API_ERROR.getCodeId()));
		} catch (ConnectApiHttpException e) {
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()),e);
			status = HttpStatus.INTERNAL_SERVER_ERROR;
			response = new RestResponse(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), ApplicationCode.CONNECT_API_ERROR.getCodeId(),
					localeMessageUtility.getErrorMessage(ApplicationCode.CONNECT_API_ERROR.getCodeId()));
		}
		catch (VstException e) {
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.DATA_VALIDATION_ERROR.getCodeId()),e);
			status = HttpStatus.BAD_REQUEST;
			response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.DATA_VALIDATION_ERROR.getCodeId(),
					localeMessageUtility.getErrorMessage(ApplicationCode.DATA_VALIDATION_ERROR.getCodeId()));
		}
		catch(BusinessCenterException bcException){
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()),bcException);
			switch(bcException.getErrorCode()){
			
			case UNATHORISED_REQUEST:
				status = HttpStatus.UNAUTHORIZED;
				response = new RestResponse(Response.Status.UNAUTHORIZED.getStatusCode(), ApplicationCode.UNATHORISED_REQUEST.getCodeId(),
						localeMessageUtility.getErrorMessage(ApplicationCode.UNATHORISED_REQUEST.getCodeId()));
				break;
				
			case TOKEN_NOT_FOUND:
				status = HttpStatus.NOT_FOUND;
				response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.TOKEN_NOT_FOUND.getCodeId(),
						localeMessageUtility.getErrorMessage(ApplicationCode.TOKEN_NOT_FOUND.getCodeId()));
				break;				
			
			default:
				status = HttpStatus.BAD_REQUEST;
				response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.BC_API_ERROR.getCodeId(),
						localeMessageUtility.getErrorMessage(ApplicationCode.BC_API_ERROR.getCodeId()));
			
			}
			
		}
		catch(Exception exception){
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.DATA_VALIDATION_ERROR.getCodeId()),exception);
			status = HttpStatus.BAD_REQUEST;
			response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.DATA_VALIDATION_ERROR.getCodeId(),
					localeMessageUtility.getErrorMessage(ApplicationCode.DATA_VALIDATION_ERROR.getCodeId()));
		}
		return ResponseEntity.status(status).body(response);
	}
	
		

	@Override
	public ResponseEntity<RestResponse> process(UnAuthenticatedRestAction action,PortalPermissionType type,final String sessionId,HttpServletRequest httpRequest,HttpServletResponse httpResponse,UriInfo uriInfo,Object param){
		logger.info("UnAuthenticatedRestAction process : processing "+action+" for "+type+ " and SessionId "+sessionId);
		RestResponse response = null;
		HttpStatus status = HttpStatus.OK;
		try{
			if(httpRequest!=null){
				httpRequest.setCharacterEncoding("UTF-8");
			}
			final String domain= VstUtils.getDomain(uriInfo, httpRequest);
			String code = null;
			if(null != domain && StringUtils.isNotEmpty(domain)){
				code = domain.substring(0, domain.indexOf(ApplicationConstants.BRIDGE_DOMAIN_NAME_PERIOD));
				if(type.equals(PortalPermissionType.user)){
					response = userServices.checkBridgeCode(code, domain);
					if(null != response && response.getCode()==302){
				//		return response.buildResponse();
					}
				}
			}
			BridgePaginationVo bridgePaginationVo = null;
			Integer id = null;
			String vbid = null;
			if(param instanceof Integer){
				id =  (Integer) param;
			}else if(param instanceof BridgePaginationVo){
				 bridgePaginationVo = (BridgePaginationVo) param;
			}else if(param instanceof String){
				vbid = (String) param;
			}
			
			if(type.equals(PortalPermissionType.admin)){
				switch(action){
				case POST_SESSION :
					if(param instanceof LoginInfoVO){
						LoginInfoVO loginInfoVO =  (LoginInfoVO) param;
						response =  adminUserService.login(loginInfoVO, httpRequest, httpResponse, uriInfo);
						if(response.getCode()==401){
							status=HttpStatus.UNAUTHORIZED;
						}
					}
					break;
				case DELETE_SESSION :
					response = adminUserService.logout(sessionId, httpRequest,uriInfo);
					break;
				case POST_PASSWORD :
					if(param instanceof AdminResetPasswordVO){
						AdminResetPasswordVO adminResetPasswordVO =  (AdminResetPasswordVO) param;
					response = adminUserService.resetPassword(adminResetPasswordVO,httpRequest,uriInfo);
					}
					break;
				case PUT_PASSWORD:
					if(param instanceof LoginInfoVO){
						LoginInfoVO loginInfoVO =(LoginInfoVO)param;
						response = adminUserService.updateResetPassword(loginInfoVO,sessionId, httpRequest, uriInfo);
					}					
					break;
				case REFRESH_BOOK_CACHE :
					if(param instanceof CreateKeysVO){
						CreateKeysVO createKeysVO =  (CreateKeysVO) param;
						response = adminUserService.refreshBookCache(createKeysVO,httpRequest, uriInfo);
					}
					
					break;
				case GET_BRIDGE_TYPES:
					response = adminUserService.getBridgeTypes();
					break;
					
					
				case GET_MONITOR_CONNECTIVITY:
					
					response=adminUserService.connectivityMonitorCheck();					
					
				break;
				
				case GET_KPI_DATA_JSON:
					response=kpiDataReportService.getKpiDataReportJson();
					break;
				case CREATE_ANCILLARY:
					if(param instanceof Map){
						Map<?,?> params = (Map<?,?>) param;
						Integer bridgeId=(Integer) params.get(ApplicationConstants.BRIDGE_ID);
						AncillaryVO ancillaryVO =(AncillaryVO) params.get(ApplicationConstants.PUT_REQUEST_OBJECT);
						response=ancillaryServices.createAncillary(bridgeId, ancillaryVO, httpRequest);
					}
					break;
				default :
					throw new InvalidActionException();
				}
			}else if(type.equals(PortalPermissionType.user)){
				switch(action){
				case POST_SESSION:
					if (param instanceof ReCaptchaLoginVO) {
						ReCaptchaLoginVO reCaptchaloginInfoVO = (ReCaptchaLoginVO) param;
						LoginInfoVO loginInfoVO = reCaptchaUtil.verifyCaptcha(reCaptchaloginInfoVO, httpRequest);

						response = userServices.login(loginInfoVO, httpRequest, httpResponse, uriInfo, code, null);

						if (response.getCode() == HttpStatus.OK.value()) {
							reCaptchaUtil.resetPasswordFailure(loginInfoVO, httpRequest);
						}
					}
					
					break;
				case DELETE_SESSION :
					response = userServices.logout(sessionId,code ,httpRequest,uriInfo);
					break;
				case GET_QUESTIONS:
					response = userServices.getQuestions(httpRequest, uriInfo);
					break;
				case POST_USER :
					if(param instanceof UserDetailsVO){
						UserDetailsVO userDetailsVO =(UserDetailsVO)param;
						response = userServices.createOrUpdateUser(null,httpRequest,userDetailsVO, uriInfo,code,Boolean.TRUE,null,Boolean.FALSE);
						BridgeUserInfoVO userInfoVO = (BridgeUserInfoVO) response.getData();
						LoginInfoVO loginInfoVO=new LoginInfoVO();
						loginInfoVO.setEmail(userDetailsVO.getEmail());
						loginInfoVO.setPassword(userDetailsVO.getPassword());
						response= userServices.login(loginInfoVO,httpRequest,httpResponse, uriInfo, code,userInfoVO.getId());
					}
					break;
//					
				case GET_BRIDGE_CONFIG:
					response = userServices.getBridgeConfig(httpRequest, uriInfo,code,domain);
					break;
				case GET_BOOKS_FOR_DEFER:
					response = userServices.getBooksForDeferSignIn(httpRequest,uriInfo,code,domain,bridgePaginationVo);
					break;
					
				case POST_USER_EMAIL:
					if(param instanceof UserEmailVO){
						UserEmailVO userEmailVO=(UserEmailVO)param;
						response=userServices.checkUserEmail(domain,userEmailVO, code,httpRequest);
					}
					
					break;
				case VALIDATE_TOKEN:
					String token = (String) param;
					response = userServices.validateToken(code,token);
					break;
					
				case POST_CONTEXT_TOKEN:
					String contextToken=(String)param;
					response=businessCenterServices.createOrUpdateBridgeUserFromContextToken(httpRequest,httpResponse, code, contextToken, uriInfo);				  					
						
					if(response != null && response.getData()!=null){
						IntegratedBridgeUserResponseVO integratedBridgeUserResponseVO =(IntegratedBridgeUserResponseVO)response.getData();
						response=userServices.ssoLoginForIntegratedUser(integratedBridgeUserResponseVO,code,httpResponse,httpRequest,uriInfo);
					}
					else{
						String requestUrlString = VstUtils.getUrlWithProtocol(httpRequest, VstUtils.getDomain(uriInfo, httpRequest));
						URL requestUrl = new URL(requestUrlString);
						throw new IntegrationException(ApplicationCode.USER_AUTHENTICATION_FAILED,requestUrl);
					}
					
					break;
					
				case POST_RESET_PASSWORD_REQUEST:
					if(param instanceof UserEmailVO){
						UserEmailVO userEmailVO=(UserEmailVO)param;
						response=userServices.resetPasswordRequest(httpRequest, userEmailVO, domain, code);
					}
					break;
					
				case POST_UPDATE_PASSWORD:
					if(param instanceof UpdatePasswordVO){
						UpdatePasswordVO updatePasswordVO=(UpdatePasswordVO)param;
						response=userServices.updatePassword(updatePasswordVO, domain);
						
					}
					break;
				
				case POST_UPDATE_OLD_POLICY_PASSWORD:
					if(param instanceof OldPolicyPasswordVO){
						OldPolicyPasswordVO oldPolicyPasswordVO=(OldPolicyPasswordVO)param;
						response=userServices.updateOldPolicyPassword(oldPolicyPasswordVO, code);
						BridgeUserInfoVO userInfoVO = (BridgeUserInfoVO) response.getData();
						LoginInfoVO loginInfoVO=new LoginInfoVO();
						loginInfoVO.setEmail(oldPolicyPasswordVO.getEmail());
						String password = oldPolicyPasswordVO.getNewPassword()!=null ? oldPolicyPasswordVO.getNewPassword() :oldPolicyPasswordVO.getOldPassword();
						loginInfoVO.setPassword(password);
						response= userServices.login(loginInfoVO,httpRequest,httpResponse, uriInfo, code,null);
					}
					break;
				default :
					throw new InvalidActionException();
				}
			}
		}catch(BridgeException bridgeExcepation){
			logger.error(localeMessageUtility.getErrorMessage(bridgeExcepation.getErrorCode().getCodeId()), bridgeExcepation);
			switch(bridgeExcepation.getErrorCode()){
				case SESSION_EXPIRED:
					status = HttpStatus.UNAUTHORIZED;
					response = new RestResponse(Response.Status.UNAUTHORIZED.getStatusCode(), ApplicationCode.SESSION_EXPIRED.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.SESSION_EXPIRED.getCodeId()));
					break;
					
				case INVALID_SESSION :
					status = HttpStatus.FORBIDDEN;
					response = new RestResponse(Response.Status.FORBIDDEN.getStatusCode(), ApplicationCode.INVALID_SESSION.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_SESSION.getCodeId()));
					break;
					
				case NO_SUCH_WEBSITE :
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.NO_SUCH_WEBSITE.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.NO_SUCH_WEBSITE.getCodeId()));
					break;
					
				case BASE_DB_ERROR:
					status = HttpStatus.INTERNAL_SERVER_ERROR;
					response = new RestResponse(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), ApplicationCode.BASE_DB_ERROR.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.BASE_DB_ERROR.getCodeId()));
					break;
					
				case USER_ALREADY_EXIST:
					status = HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.USER_ALREADY_EXIST.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.USER_ALREADY_EXIST.getCodeId()));
					break;
					
				case BRIDGE_NOT_FOUND:
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.BRIDGE_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.BRIDGE_NOT_FOUND.getCodeId()));
					break;
					
				case COMPANY_NOT_FOUND:
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.COMPANY_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.COMPANY_NOT_FOUND.getCodeId()));
					break;
					
				case DUPLICATE_BRIDGE_NAME :
					status = HttpStatus.CONFLICT;
					response = new RestResponse(Response.Status.CONFLICT.getStatusCode(), ApplicationCode.DUPLICATE_BRIDGE_NAME.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.DUPLICATE_BRIDGE_NAME.getCodeId()));
					break;
					
				case DUPLICATE_BRIDGE_CODE :
					status = HttpStatus.CONFLICT;
					response = new RestResponse(Response.Status.CONFLICT.getStatusCode(), ApplicationCode.DUPLICATE_BRIDGE_CODE.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.DUPLICATE_BRIDGE_CODE.getCodeId()));
					break;
				
				case DUPLICATE_COMPANY_NAME :
					status = HttpStatus.CONFLICT;
					response = new RestResponse(Response.Status.CONFLICT.getStatusCode(), ApplicationCode.DUPLICATE_COMPANY_NAME.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.DUPLICATE_COMPANY_NAME.getCodeId()));
					break;
				case DUPLICATE_GROUP_NAME :
					status = HttpStatus.CONFLICT;
					response = new RestResponse(Response.Status.CONFLICT.getStatusCode(), ApplicationCode.DUPLICATE_GROUP_NAME.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.DUPLICATE_GROUP_NAME.getCodeId()));
					break;
					
				case KEY_CODE_NOT_FOUND :
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.KEY_CODE_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.KEY_CODE_NOT_FOUND.getCodeId()));
					break;
				case BRIDGE_USER_NOT_FOUND :
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.BRIDGE_USER_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.BRIDGE_USER_NOT_FOUND.getCodeId()));
					break;
				case USE_KEY_ASSOCIATION_NOT_FOUND :
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.USE_KEY_ASSOCIATION_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.USE_KEY_ASSOCIATION_NOT_FOUND.getCodeId()));
					break;
					
				case INVALID_ORDERBY_FIELD :
					status = HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.INVALID_ORDERBY_FIELD.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_ORDERBY_FIELD.getCodeId()));
					break;
				case LICENSE_NOT_FOUND:
					status = HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.LICENSE_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.LICENSE_NOT_FOUND.getCodeId()));
					break;
				case KEY_EXPIRED:
					status = HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.KEY_EXPIRED.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.KEY_EXPIRED.getCodeId()));
					break;
				case KEY_NOT_FOUND:
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.KEY_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.KEY_NOT_FOUND.getCodeId()));
					break;
				case DUPLICATE_KEY:
					status = HttpStatus.CONFLICT;
					response = new RestResponse(Response.Status.CONFLICT.getStatusCode(), ApplicationCode.DUPLICATE_KEY.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.DUPLICATE_KEY.getCodeId()));
					break;
				
				case INVALID_BRIDGE_KEY:
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.INVALID_BRIDGE_KEY.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_BRIDGE_KEY.getCodeId()));
					break;
				
				case DUPLICATE_BRIDGE_ALIAS:
					status = HttpStatus.CONFLICT;
					response = new RestResponse(Response.Status.CONFLICT.getStatusCode(), ApplicationCode.DUPLICATE_BRIDGE_ALIAS.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.DUPLICATE_BRIDGE_ALIAS.getCodeId()));
					break;
					
				case INVALID_BRIDGE_CODE :
					status = HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.INVALID_BRIDGE_CODE.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_BRIDGE_CODE.getCodeId()));
					break;
				
				case BOOK_NOT_FOUND :
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.BOOK_NOT_FOUND.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.BOOK_NOT_FOUND.getCodeId()));
					break;
				case USER_AUTHENTICATION_FAILED:
					status = HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.USER_AUTHENTICATION_FAILED.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.USER_AUTHENTICATION_FAILED.getCodeId()));
					break;
				case USER_NOT_FOUND :
					status = HttpStatus.NOT_FOUND;
					 response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.USER_NOT_FOUND.getCodeId(),
					 	localeMessageUtility.getErrorMessage(ApplicationCode.USER_NOT_FOUND.getCodeId()));
					 break;
					 				
				case INSUFFICIENT_PRIVILEGE :
					status = HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.INSUFFICIENT_PRIVILEGE.getCodeId(),
					 			localeMessageUtility.getErrorMessage(ApplicationCode.INSUFFICIENT_PRIVILEGE.getCodeId()));
					 break;
				case INVALID_INPUT:
					status=HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.INVALID_INPUT.getCodeId(),
				 			localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_INPUT.getCodeId()));					
					break;
				
				case USER_DELTED_BY_ADMIN:
					 status = HttpStatus.BAD_REQUEST;
					 response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.USER_DELTED_BY_ADMIN.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.USER_DELTED_BY_ADMIN.getCodeId()));
						break;	
				case	NOT_FULL_USER:
					 status = HttpStatus.BAD_REQUEST;
					 response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.NOT_FULL_USER.getCodeId(),
						 		localeMessageUtility.getErrorMessage(ApplicationCode.NOT_FULL_USER.getCodeId()));
					break;
			
				case BOOKSHELF_FULL_USER :
					 status = HttpStatus.BAD_REQUEST;
					 response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.BOOKSHELF_FULL_USER.getCodeId(),
						 		localeMessageUtility.getErrorMessage(ApplicationCode.BOOKSHELF_FULL_USER.getCodeId()));
					break;
					
				case ALREADY_USED_TOKEN :
					 status = HttpStatus.BAD_REQUEST;
					 response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.ALREADY_USED_TOKEN.getCodeId(),
						 		localeMessageUtility.getErrorMessage(ApplicationCode.ALREADY_USED_TOKEN.getCodeId()));
					break;
				
				case EXPIRED_TOKEN :
					 status = HttpStatus.BAD_REQUEST;
					 response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.EXPIRED_TOKEN.getCodeId(),
						 		localeMessageUtility.getErrorMessage(ApplicationCode.EXPIRED_TOKEN.getCodeId()));
					break;
				
				case INVALID_TOKEN:
					status = HttpStatus.NOT_FOUND;
					 response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.INVALID_TOKEN.getCodeId(),
						 		localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_TOKEN.getCodeId()));
					break;
					
				case USER_NOT_ROSTERED:
					status=HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.USER_NOT_ROSTERED.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.USER_NOT_ROSTERED.getCodeId()));
					break;
					
				case INVALID_CONTEXT_TOKEN:
					status=HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.INVALID_CONTEXT_TOKEN.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_CONTEXT_TOKEN.getCodeId()));
					break;
					
				case TENANT_NOT_VALID:
					status=HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.TENANT_NOT_VALID.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.TENANT_NOT_VALID.getCodeId()));					
					break;
					
				case BRIDGE_NOT_INTEGRATED:
					status=HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.BRIDGE_NOT_INTEGRATED.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.BRIDGE_NOT_INTEGRATED.getCodeId()));					
					break;
					
				case PASSWORD_NOT_VALID:
					status=HttpStatus.FORBIDDEN;
					response = new RestResponse(Response.Status.FORBIDDEN.getStatusCode(), ApplicationCode.PASSWORD_NOT_VALID.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.PASSWORD_NOT_VALID.getCodeId()));					
					break;
				
				case OLD_SECURITY_QUESTION:
					status=HttpStatus.UNAUTHORIZED;
					response = new RestResponse(Response.Status.UNAUTHORIZED.getStatusCode(), ApplicationCode.OLD_SECURITY_QUESTION.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.OLD_SECURITY_QUESTION.getCodeId()));					
					break;
					
				case INVALID_USER_REQUEST:
					status=HttpStatus.BAD_REQUEST;
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.INVALID_USER_REQUEST.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_USER_REQUEST.getCodeId()));					
					break;
					
				case PASSWORD_NOT_ACCEPTED:
					status=HttpStatus.FORBIDDEN;
					response = new RestResponse(Response.Status.FORBIDDEN.getStatusCode(), ApplicationCode.PASSWORD_NOT_ACCEPTED.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.PASSWORD_NOT_ACCEPTED.getCodeId()));					
					break;	
					
				case TOO_MANY_REQUESTS_ERROR:
					status=HttpStatus.TOO_MANY_REQUESTS;
					response = new RestResponse(Response.Status.FORBIDDEN.getStatusCode(), ApplicationCode.TOO_MANY_REQUESTS_ERROR.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.TOO_MANY_REQUESTS_ERROR.getCodeId()));					
					break;	
					
				case KEY_BATCH_NOT_FOUND:
					status=HttpStatus.NOT_FOUND;
					response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.KEY_BATCH_NOT_FOUND.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.KEY_BATCH_NOT_FOUND.getCodeId()));
					break;
				case CAPTCHA_FAILED:
					status=HttpStatus.UNAUTHORIZED;
					response = new RestResponse(Response.Status.UNAUTHORIZED.getStatusCode(), ApplicationCode.CAPTCHA_FAILED.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.CAPTCHA_FAILED.getCodeId()));
					break;
				case CAPTCHA_MAX_EXCEEDED:
					status=HttpStatus.UNAUTHORIZED;
					response = new RestResponse(Response.Status.UNAUTHORIZED.getStatusCode(), ApplicationCode.CAPTCHA_MAX_EXCEEDED.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.CAPTCHA_MAX_EXCEEDED.getCodeId()));
					break;
				case PASSWORD_MAX_EXCEEDED:
					status=HttpStatus.UNAUTHORIZED;
					response = new RestResponse(Response.Status.UNAUTHORIZED.getStatusCode(), ApplicationCode.PASSWORD_MAX_EXCEEDED.getCodeId(),
					 		localeMessageUtility.getErrorMessage(ApplicationCode.PASSWORD_MAX_EXCEEDED.getCodeId()));
					break;

				case UNAUTHORISED_CONNECT_USER:
					status = HttpStatus.UNAUTHORIZED;
					response = new RestResponse(Response.Status.UNAUTHORIZED.getStatusCode(), ApplicationCode.UNAUTHORISED_CONNECT_USER.getCodeId(),
						localeMessageUtility.getErrorMessage(ApplicationCode.UNAUTHORISED_CONNECT_USER.getCodeId()));
					break;

					
				default:
					status = HttpStatus.INTERNAL_SERVER_ERROR;
					response = new RestResponse(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), ApplicationCode.UNEXPECTED_ERROR.getCodeId(),
							localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()));
			}
		}
		catch(BusinessCenterException bcException){
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()),bcException);
			switch(bcException.getErrorCode()){
			
			case UNATHORISED_REQUEST:
				status = HttpStatus.UNAUTHORIZED;
				response = new RestResponse(Response.Status.UNAUTHORIZED.getStatusCode(), ApplicationCode.UNATHORISED_REQUEST.getCodeId(),
						localeMessageUtility.getErrorMessage(ApplicationCode.UNATHORISED_REQUEST.getCodeId()));
				break;
				
			case TOKEN_NOT_FOUND:
				status = HttpStatus.NOT_FOUND;
				response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.TOKEN_NOT_FOUND.getCodeId(),
						localeMessageUtility.getErrorMessage(ApplicationCode.TOKEN_NOT_FOUND.getCodeId()));
				break;				
			
			default:
				status = HttpStatus.BAD_REQUEST;
				response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.BC_API_ERROR.getCodeId(),
						localeMessageUtility.getErrorMessage(ApplicationCode.BC_API_ERROR.getCodeId()));
			
			}
			
		}
		catch (IntegrationException ie){
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()),ie);
			switch(ie.getErrorCode()){
			
			
			default:
				status = HttpStatus.BAD_REQUEST;
				response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.BC_API_ERROR.getCodeId(),
						localeMessageUtility.getErrorMessage(ApplicationCode.BC_API_ERROR.getCodeId()));
				break;
			}
		}
		catch (ParseException e) {
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.PARSING_ERROR.getCodeId()),e);
			status = HttpStatus.INTERNAL_SERVER_ERROR;
			response = new RestResponse(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), ApplicationCode.PARSING_ERROR.getCodeId(),
					localeMessageUtility.getErrorMessage(ApplicationCode.PARSING_ERROR.getCodeId()));
		} catch (IOException e) {
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()),e);
			status = HttpStatus.INTERNAL_SERVER_ERROR;
			response = new RestResponse(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), ApplicationCode.UNEXPECTED_ERROR.getCodeId(),
					localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()));
		} catch (InvalidActionException e) {
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.UNEXPECTED_ERROR.getCodeId()),e);
			status = HttpStatus.INTERNAL_SERVER_ERROR;
			response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(), ApplicationCode.INVALID_BRIDGE_ACTION.getCodeId(),
					localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_BRIDGE_ACTION.getCodeId()));
		}catch (ConnectApiException exception) {
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.USER_AUTHENTICATION_FAILED.getCodeId()),exception);
			status = HttpStatus.UNAUTHORIZED;
			response = new RestResponse(Response.Status.UNAUTHORIZED.getStatusCode(), ApplicationCode.USER_AUTHENTICATION_FAILED.getCodeId(),
					exception.getMessage());
		}
		catch (ConnectApiXmlException e) {
			logger.error(e.getMessage() ,e);
			status = HttpStatus.BAD_REQUEST;
			response = new RestResponse(Response.Status.EXPECTATION_FAILED.getStatusCode(), ApplicationCode.CONNECT_API_ERROR.getCodeId(),e.getMessage());
		}
		catch(Exception exception){
			logger.error(localeMessageUtility.getErrorMessage(ApplicationCode.DATA_VALIDATION_ERROR.getCodeId()),exception);
			status = HttpStatus.BAD_REQUEST;
			response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(), ApplicationCode.DATA_VALIDATION_ERROR.getCodeId(),
					localeMessageUtility.getErrorMessage(ApplicationCode.DATA_VALIDATION_ERROR.getCodeId()));
		}
		return ResponseEntity.status(status).body(response);
	}
	
	public SessionStatusVO checkSessionAndGetUserInfo(String sessionId, PortalPermissionType type) throws BridgeException{
		SessionStatusVO sessionStatusVO = null;
		logger.debug("SessionId : = "+sessionId);
		if(type.equals(PortalPermissionType.admin)){
			AdminSession adminSession = bridgeAuthonticator.getAdminSession(sessionId);
			if(adminSession == null){
				bridgeAuthonticator.updateLastAccess(adminSession, sessionId);
				throw new BridgeException(ApplicationCode.SESSION_EXPIRED);
			}
			sessionStatusVO = getAdminSessionVoFromAdminSession(adminSession);
			bridgeAuthonticator.updateLastAccess(adminSession, sessionId);
		}else if(type.equals(PortalPermissionType.user)){
			BridgeUserSession userSession = bridgeAuthonticator.getBridgeUserSession(sessionId);
			if(userSession == null){
				bridgeAuthonticator.updateLastAccess(userSession, sessionId);
				throw new BridgeException(ApplicationCode.SESSION_EXPIRED);
			}
			sessionStatusVO = getBridgeUserSessionVoFromUserSession(userSession);
			bridgeAuthonticator.updateLastAccess(userSession, sessionId);
		}
		return sessionStatusVO;
	}

	private SessionStatusVO getBridgeUserSessionVoFromUserSession(BridgeUserSession userSession) {
		SessionStatusVO sessionStatusVO = bridgeAuthonticator.getBridgeUserSessionVO(userSession);
		return sessionStatusVO;
	}

	private SessionStatusVO getAdminSessionVoFromAdminSession(AdminSession adminSession) {
		SessionStatusVO sessionStatusVO = bridgeAuthonticator.getAdminSessionVO(adminSession);
		return sessionStatusVO;
	}
	
	private Date getDate(final Long timeInMiliseconds){
		logger.debug("getDate : received miliseconds =  "+timeInMiliseconds);
		Date date =  null != timeInMiliseconds ? new Date(timeInMiliseconds) : null;
		logger.debug("getDate : date =  "+date);
		return date;
	}

}
