package com.vst.bridge.dao.admin.session;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.session.AdminSession;
import com.vst.bridge.util.exception.BridgeException;

@Repository("adminSessionDAO")
public class AdminSessionDAOImpl extends GenericDAO<AdminSession, Integer> implements IAdminSessionDAO{

	public AdminSessionDAOImpl() {
		super(AdminSession.class);
	}

	@Override
	public AdminSession getForSessionId(String sessionId,Boolean updateLastAcess,Date lastAcessdate)
			throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.like("sessionId", sessionId));
		if(updateLastAcess){
			criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
			Criterion criterion1 = Restrictions.or(Restrictions.isNull("lastAccessDate"), Restrictions.gt("lastAccessDate",lastAcessdate));
			criteria.add(criterion1);
		}
		List<AdminSession> sessions = executeCriteira(criteria);
		return null != sessions && sessions.size()>0 ? sessions.get(0) : null;
	}
}
