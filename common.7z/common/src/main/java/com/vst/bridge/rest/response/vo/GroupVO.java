package com.vst.bridge.rest.response.vo;

public class GroupVO {
	private String name;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
