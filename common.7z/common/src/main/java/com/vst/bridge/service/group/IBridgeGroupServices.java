package com.vst.bridge.service.group;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import org.jdom2.JDOMException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.vst.bridge.rest.input.vo.BridgeGroupBookVO;
import com.vst.bridge.rest.input.vo.BridgeGroupUserVO;
import com.vst.bridge.rest.input.vo.BridgeGroupVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.group.BridgeGroupAssetUserVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.exception.BusinessCenterException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;

public interface IBridgeGroupServices {

	RestResponse createOrUpdateBridgeGroup(SessionStatusVO sessionStatusVO, BridgeGroupVO bridgeGroupVO,
			Integer bridgeId, Integer groupId, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException;
	
	RestResponse duplicateBridgeGroup(SessionStatusVO sessionStatusVO, String duplicateGroupName,
			Integer bridgeId, Integer groupId, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException;

	RestResponse getGroupsForBridgeId(SessionStatusVO sessionStatusVO, Integer bridgeId, Boolean refreshGroups,
			Boolean getDeletedGroups, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, BusinessCenterException, IOException, ConnectApiException, JDOMException, ParseException;
	
	RestResponse getGroupUsersForBridgeId(SessionStatusVO sessionStatusVO,Integer bridgeId, Integer groupId, PaginationVO paginationVO, Boolean isGrouped,Boolean refreshBC) throws JsonParseException, JsonMappingException, BridgeException, BusinessCenterException, IOException, ConnectApiException;

	RestResponse updateBridgeGroupUsers(SessionStatusVO sessionStatusVO, BridgeGroupUserVO bridgeGroupUserVO,
			Integer bridgeId, Integer groupId, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException;

	RestResponse updateBridgeGroupBooks(SessionStatusVO sessionStatusVO, BridgeGroupBookVO bridgeGroupBookVO,
			Integer bridgeId, Integer groupId, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException;

	RestResponse getGroupBooksForBridgeId(Integer bridgeId, Integer groupId, BridgePaginationVo paginationVo, String category);

	RestResponse addBulkGroupAssetUsers(Integer bridgeId, BridgeGroupAssetUserVO groupAssetUsersVO)throws BridgeException, ParseException;
	
	RestResponse deleteBridgeGroupUsers(SessionStatusVO sessionStatusVO, List<Integer>userIds,
			Integer bridgeId, Integer groupId, Boolean deleteAll, String search, Boolean isGrouped, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException;

	RestResponse deleteBridgeGroupBooks(SessionStatusVO sessionStatusVO, List<String> vbids,
			Integer bridgeId, Integer groupId, Boolean deleteAll,String search, Boolean isGrouped, String category, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException;

	RestResponse deleteBridgeGroup(SessionStatusVO sessionStatusVO, Integer bridgeId, Integer groupId,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException;



	RestResponse getBridgeGroupForVbid(SessionStatusVO sessionStatusVO, Integer bridgeId,String vbid,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException;

	RestResponse getBridgeGroupForUserId(Integer bridgeId, Integer userId)  throws BridgeException;

	RestResponse getBridgeGroupById(SessionStatusVO sessionStatusVO, Integer bridgeId, Integer groupId,Boolean refresh,
			HttpServletRequest httpRequest, UriInfo uriInfo)throws BridgeException, JsonParseException, JsonMappingException, BusinessCenterException, IOException, ConnectApiException;

	



	
	
}
