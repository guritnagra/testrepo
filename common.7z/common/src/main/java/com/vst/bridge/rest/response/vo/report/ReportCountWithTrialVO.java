package com.vst.bridge.rest.response.vo.report;

public class ReportCountWithTrialVO extends ReportCountDetails{
	private Integer trial;

//	private Integer launch;
	
	public Integer getTrial() {
		return trial;
	}

	public void setTrial(Integer trial) {
		this.trial = trial;
	}

	/*public Integer getLaunch() {
		return launch;
	}

	public void setLaunch(Integer launch) {
		this.launch = launch;
	}*/
	
}
