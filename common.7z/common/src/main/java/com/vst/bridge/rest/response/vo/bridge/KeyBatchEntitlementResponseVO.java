package com.vst.bridge.rest.response.vo.bridge;

import java.util.List;

import com.vst.bridge.rest.input.vo.ConcurrencyEntitlementVO;
import com.vst.bridge.rest.input.vo.EntitlementVO;

public class KeyBatchEntitlementResponseVO {

	private Integer id;
	private Integer numUsersPerKey;
	private Integer count;
	private String notes;
	private String role;
	private Long expiresDate;
	private Long createdDate;
	private String contactEmail;
	
	private List<ConcurrencyEntitlementVO> concurrencyEntitlements;
	private List<EntitlementVO> entitlements;
	
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	public Long getExpiresDate() {
		return expiresDate;
	}
	public void setExpiresDate(Long expiresDate) {
		this.expiresDate = expiresDate;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getNumUsersPerKey() {
		return numUsersPerKey;
	}
	public void setNumUsersPerKey(Integer numUsersPerKey) {
		this.numUsersPerKey = numUsersPerKey;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public List<ConcurrencyEntitlementVO> getConcurrencyEntitlements() {
		return concurrencyEntitlements;
	}
	public void setConcurrencyEntitlements(List<ConcurrencyEntitlementVO> concurrencyEntitlements) {
		this.concurrencyEntitlements = concurrencyEntitlements;
	}
	public List<EntitlementVO> getEntitlements() {
		return entitlements;
	}
	public void setEntitlements(List<EntitlementVO> entitlements) {
		this.entitlements = entitlements;
	}
	public Long getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Long createdDate) {
		this.createdDate = createdDate;
	}
	public String getContactEmail() {
		return contactEmail;
	}
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
}
