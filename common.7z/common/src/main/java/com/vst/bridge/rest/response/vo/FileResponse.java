package com.vst.bridge.rest.response.vo;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

public class FileResponse extends RestResponse{
	private String fileName;

	public FileResponse() {}
	public FileResponse(String filename) {
		this.fileName = filename;
	}
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public Response buildResponse(String text){
		ResponseBuilder rb = Response.ok(text);
		 if(fileName!=null)
		    {
		    	rb.header("Content-Type", "application/plain");
				rb.header("Content-Disposition","attachment; filename=\"" + this.fileName + "\"");
		    }
		return rb.build();
	}
}
