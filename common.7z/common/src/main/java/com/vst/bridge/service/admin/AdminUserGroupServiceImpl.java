package com.vst.bridge.service.admin;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.JsonUtils;
import com.vst.bridge.dao.admin.group.company.IAdminGroupCompanyDAO;
import com.vst.bridge.dao.group.IGroupDAO;
import com.vst.bridge.entity.admin.group.Group;
import com.vst.bridge.entity.company.Company;
import com.vst.bridge.rest.response.vo.AdminCompanyVO;
import com.vst.bridge.rest.response.vo.AdminGroupVO;
import com.vst.bridge.rest.response.vo.GroupCompaniesVO;
import com.vst.bridge.rest.response.vo.GroupVO;
import com.vst.bridge.rest.response.vo.Metadata;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.util.error.ErrorHandlerUtil;
import com.vst.bridge.util.error.ResponseError;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;

@Service("adminUserGroupService")
public class AdminUserGroupServiceImpl implements IAdminUserGroupService {

	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private ErrorHandlerUtil errorHandlerUtility;

	@Autowired
	private IGroupDAO groupDAO;

	@Autowired
	private IAdminGroupCompanyDAO adminGroupCompanyDAO;

	@Autowired
	private AdminUserServiceUtil adminUserServiceUtil;

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getGroups(SessionStatusVO sessionStatusVO, UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		List<Group> groups = groupDAO.getAllGroups();
		List<AdminGroupVO> groupList = new ArrayList<AdminGroupVO>();
		if (null != groups && groups.size() > 0) {
			for (Group group : groups) {
				AdminGroupVO adminGroupVO = new AdminGroupVO();
				adminGroupVO.setId(group.getId());
				adminGroupVO.setName(group.getName());
				groupList.add(adminGroupVO);
			}
			Metadata metadata = new Metadata();
			metadata.setCount(groupList.size());
			response.setMetadata(metadata);
		}
		response.setData(groupList);
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse createOrUpdateGroups(SessionStatusVO sessionStatusVO, GroupVO adminGroupVO, Integer groupId,
			UriInfo uriInfo, HttpServletRequest httpRequest) throws BridgeException, ParseException, IOException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		// final String inputJson = JsonUtils.requestToString(httpRequest);
		if (null != adminGroupVO) {
			// GroupVO adminGroupVO= (new Genson()).deserialize(inputJson,
			// GroupVO.class);
			ResponseError responseError = groupId == null
					? errorHandlerUtility.validateGroupsVOParameters(JsonUtils.getJsonString(adminGroupVO)) : null;
			Group group = groupId == null ? new Group() : groupDAO.get(groupId);
			String name = null;
			if (null == group) {
				throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
			} else if (groupId == null) {
				response.setCode(Response.Status.CREATED.getStatusCode());
			}
			if (null == responseError) {
				name = adminGroupVO.getName();
				if (null != name && !StringUtils.isEmpty(name) && !StringUtils.equals(name, group.getName())) {

					groupDAO.checkGroupNameExist(name);
					group.setName(name);
				}
				groupDAO.saveOrUpdate(group);
				if (null == groupId) {
					group = groupDAO.getGroupForName(name);
				}
				if (null != group) {
					AdminGroupVO groupVO = new AdminGroupVO();
					groupVO.setId(group.getId());
					groupVO.setName(group.getName());
					response.setData(groupVO);
				}
			} else {
				response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
				response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
				response.setError(responseError);
			}
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getAllGroupsWithCompanies(SessionStatusVO sessionStatusVO) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		List<Group> groups = groupDAO.getAllGroups();
		List<GroupCompaniesVO> groupCompaniesVOs = new ArrayList<GroupCompaniesVO>();
		if (null != groups && groups.size() > 0) {
			for (Group group : groups) {
				GroupCompaniesVO groupCompaniesVO = new GroupCompaniesVO();
				List<Company> companies = adminGroupCompanyDAO.getListOfCompaniesForGroupId(group.getId());
				List<AdminCompanyVO> companyVOs = adminUserServiceUtil.populateListOfCompanyVOFromCompany(companies);
				groupCompaniesVO.setCompanies(companyVOs);
				groupCompaniesVO.setGroupId(group.getId());
				groupCompaniesVO.setGroupName(group.getName());
				groupCompaniesVOs.add(groupCompaniesVO);
			}
			response.setData(groupCompaniesVOs);
		}
		return response;
	}

}
