package com.vst.bridge.service.admin;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.dao.admin.IAdminCompanyDAO;
import com.vst.bridge.dao.admin.IAdminGroupDAO;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.log.IBridgeAdminLogDAO;
import com.vst.bridge.entity.admin.company.AdminCompany;
import com.vst.bridge.entity.admin.group.Group;
import com.vst.bridge.entity.admin.user.AdminGroup;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.log.BridgeAdminLog;
import com.vst.bridge.entity.company.Company;
import com.vst.bridge.rest.response.vo.AdminCompanyVO;
import com.vst.bridge.rest.response.vo.AdminGroupVO;
import com.vst.bridge.rest.response.vo.AdminUserVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.util.constant.ApplicationAction;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.constant.PermissionAction;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;

@Component("adminUserServiceUtil")
public class AdminUserServiceUtil {

	@Autowired
	private IAdminGroupDAO adminGroupDAO;

	@Autowired
	private IAdminCompanyDAO adminCompanyDAO;
	
	@Autowired
	private IBridgeDAO bridgeDAO;
	
	@Autowired
	private IAdminUserDAO adminUserDAO;
	
	@Autowired
	private IBridgeAdminLogDAO bridgeAdminLogDAO;

	protected AdminUserVO populateAdminVoFromAdmin(AdminUser adminUser) {
		AdminUserVO adminUserVO = new AdminUserVO(adminUser);
		adminUserVO.setId(adminUser.getId());
		adminUserVO.setFirstName(StringUtils.capitalize(adminUser.getFirstName().toLowerCase()));
		adminUserVO.setLastName(StringUtils.capitalize(adminUser.getLastName().toLowerCase()));
		adminUserVO.setEmail(adminUser.getEmail().toLowerCase());
		adminUserVO.setType(adminUser.getRole().getName());
		adminUserVO.setCreated(adminUser.getCreatedDate().getTime());
		adminUserVO.setCreatedDate(adminUser.getCreatedDate());
		adminUserVO.setSystemUserId(adminUser.getSystemUserId());
		AdminUser creator = adminUser.getCreatedBy();
		adminUserVO.setCreatedBy(com.vst.bridge.StringUtils.getFullName(creator.getFirstName(), creator.getLastName()));

		List<AdminGroupVO> groupList = new ArrayList<AdminGroupVO>();
		List<AdminGroupVO> companyList = new ArrayList<AdminGroupVO>();

		List<AdminGroup> groups = adminGroupDAO.getGroupsForAdminId(adminUser.getId());
		if (null != groups && groups.size() > 0) {
			for (AdminGroup adminGroup : groups) {
				AdminGroupVO groupVO = new AdminGroupVO();
				Group group = adminGroup.getGroup();
				groupVO.setId(group.getId());
				groupVO.setName(group.getName());
				groupList.add(groupVO);
			}
		}
		adminUserVO.setGroups(groupList);
		List<AdminCompany> companies = adminCompanyDAO.getAdminCompaniesForAdminId(adminUser.getId(),Boolean.TRUE);
		if (null != companies && companies.size() > 0) {
			for (AdminCompany adminCompany : companies) {
				AdminGroupVO companyVO = new AdminGroupVO();
				Company company = adminCompany.getCompany();
				companyVO.setId(company.getId());
				companyVO.setName(company.getName());
				companyList.add(companyVO);
			}
		}
		adminUserVO.setCompanies(companyList);
		if(adminUser.getLabel()!=null)
			adminUserVO.setLabel(adminUser.getLabel().getLabel());		
		
		return adminUserVO;
	}

	protected void validateAndRearangePaginationVO(BridgePaginationVo bridgePaginationVo, String defaultOrderBy,
			Boolean forBridge) {

		Integer page = bridgePaginationVo.getPage();
		if (null == page || page == 0) {
			bridgePaginationVo.setPage(ApplicationConstants.DEFAULT_GET_BOOK_PAGE_VALUE);
		}

		Integer limit = bridgePaginationVo.getLimit();
		if (null == limit || limit == 0) {
			bridgePaginationVo.setLimit(ApplicationConstants.DEFAULT_GET_BOOK_LIMIT_VALUE);
		}

		String orderby = bridgePaginationVo.getOrderBy();
		if (forBridge) {
			if (!StringUtils.isEmpty(orderby) && !ApplicationConstants.validBridgesOrderByValues.contains(orderby)) {
				throw new BridgeException(ApplicationCode.INVALID_ORDERBY_FIELD);
			}
		} else {
			if (!StringUtils.isEmpty(orderby) && !ApplicationConstants.validUsersOrderByValues.contains(orderby)) {
				throw new BridgeException(ApplicationCode.INVALID_ORDERBY_FIELD);
			}
		}

		if (null == orderby || StringUtils.isEmpty(orderby)) {
			bridgePaginationVo.setOrderBy(defaultOrderBy);
		}

		String order = bridgePaginationVo.getOrder();
		if (null == order || StringUtils.isEmpty(order)) {
			bridgePaginationVo.setOrder(ApplicationConstants.DEFAULT_GET_BOOK_ORDER_VALUE);
		}
	}

	protected List<AdminCompanyVO> populateListOfCompanyVOFromCompany(List<Company> companies) {
		List<AdminCompanyVO> companyVOs = new ArrayList<AdminCompanyVO>();
		if (null != companies && companies.size() > 0) {
			for (Company company : companies) {
				AdminCompanyVO companyVO = new AdminCompanyVO();
				companyVO.setId(company.getId());
				companyVO.setName(company.getName());
				// companyVO.setType(company.getType());
				companyVOs.add(companyVO);
			}
		}
		return companyVOs;
	}

	/**
	 * This method is used to calculate total page count for report
	 * 
	 * @param totalCount
	 * @param totalRowsToFetch
	 * @return {@link String}
	 */
	protected Integer calculateTotalPageCount(final int totalCount, final int totalRowsToFetch) {
		final Integer pageCount = (int) Math.ceil((double) totalCount / totalRowsToFetch);
		return pageCount;
	}

	/**
	 * This method is used to calculate start index for report
	 * 
	 * @param currentPage
	 * @param totalRowsToFetch
	 * @return {@link Integer} value
	 */
	protected Integer calculateStartIndex(final int currentPage, final int totalRowsToFetch) {
		final Integer startIndex = (currentPage * totalRowsToFetch) - totalRowsToFetch;
		return startIndex;
	}
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public List<Bridge> getAllBridges(){
		return bridgeDAO.getAllBridges();
	}	

	public String maskApiKey(String apiKey){
		if(apiKey==null && StringUtils.isEmpty(apiKey))
			return null;
		if(apiKey!=null && apiKey.length()<4)
			return apiKey;
		StringBuilder masked = new StringBuilder();
		for (int i = 0; i < apiKey.length()-4; i++) {
			masked.append("X");
		}
		masked.append(apiKey.substring(apiKey.length()-4, apiKey.length()));
		return masked.toString();
	}
	
	protected void validateAndRearangePaginationVO(PaginationVO paginationVo,String defaultOrderBy, Boolean forBook) {
		
		Integer page = paginationVo.getPage();
		if(null==page || page==0){
			paginationVo.setPage(ApplicationConstants.DEFAULT_GET_BOOK_PAGE_VALUE);
		}
		
		Integer limit = paginationVo.getLimit();
		if(null==limit || limit==0){
			paginationVo.setLimit(ApplicationConstants.DEFAULT_GET_BOOK_LIMIT_VALUE);
		}
		
		String orderby = paginationVo.getOrderBy();
		if(forBook){
			if(!StringUtils.isEmpty(orderby) && !ApplicationConstants.validBookOrderByValues.contains(orderby)){
				throw new BridgeException(ApplicationCode.INVALID_ORDERBY_FIELD);
			}
		}else{
			if(!StringUtils.isEmpty(orderby) && !ApplicationConstants.validUsersOrderByValues.contains(orderby)){
				throw new BridgeException(ApplicationCode.INVALID_ORDERBY_FIELD);
			}
		}
		
		if(null == orderby || StringUtils.isEmpty(orderby)){
			paginationVo.setOrderBy(defaultOrderBy);
		}
		
		String order = paginationVo.getOrder();
		if(null == order || StringUtils.isEmpty(order)){
			paginationVo.setOrder(ApplicationConstants.DEFAULT_GET_BOOK_ORDER_VALUE);
		}
	}
	

	public Integer createBridgeAdminLog(final Integer userId, final Bridge bridge, final ApplicationAction action,
			final String value) {
		BridgeAdminLog bridgeAdminLog = new BridgeAdminLog();
		bridgeAdminLog.setAdminUser(adminUserDAO.load(userId));
		bridgeAdminLog.setBridge(bridge);
		bridgeAdminLog.setAction(action.getCodeId());
		bridgeAdminLog.setValue(value);
		return bridgeAdminLogDAO.create(bridgeAdminLog);
	}
	

	public void validateAdminPermission(PermissionAction action,AdminUser adminUser){
		
		if(adminUser!=null && ApplicationConstants.USER_ROLE_SUPER_ADMIN.equals(adminUser.getRole().getName())){
			return;
		}
		else{
			Boolean checkPermission=null;
			switch(action){
			case SUPER_ADMIN:
				return;
			case EDIT_SYSTEMUSER:
				checkPermission=adminUser.getEditSystemUser()!=null ?adminUser.getEditSystemUser() :Boolean.FALSE;
				if(!checkPermission)
					throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE_FOR_ADMIN);
				break;
				
			case EDIT_BRIDGE:
				checkPermission=adminUser.getEditBridge()!=null ?adminUser.getEditBridge() :Boolean.FALSE;
				if(!checkPermission)
					throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE_FOR_ADMIN);
				break;
				
			case EDIT_BASICINFO:
				checkPermission=adminUser.getEditBasicInfo()!=null ?adminUser.getEditBasicInfo() :Boolean.FALSE;
				if(!checkPermission)
					throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE_FOR_ADMIN);
				break;
				
			case EDIT_STYLING:
				checkPermission=adminUser.getEditStyling()!=null ?adminUser.getEditStyling() :Boolean.FALSE;
				if(!checkPermission)
					throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE_FOR_ADMIN);
				break;
				
			case EDIT_MANAGE:
				checkPermission=adminUser.getEditManage()!=null ?adminUser.getEditManage() :Boolean.FALSE;
				if(!checkPermission)
					throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE_FOR_ADMIN);
				break;
				
			case EDIT_USERS:
				checkPermission=adminUser.getEditUsers()!=null ?adminUser.getEditUsers() :Boolean.FALSE;
				if(!checkPermission)
					throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE_FOR_ADMIN);
				break;
				
			case EDIT_USERLIMIT:
				checkPermission=adminUser.getEditUserLimit()!=null ?adminUser.getEditUserLimit() :Boolean.FALSE;
				if(!checkPermission)
					throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE_FOR_ADMIN);
				break;
				
			case EDIT_USERCONCURRENCY:
				checkPermission=adminUser.getEditUserConcurrency()!=null ?adminUser.getEditUserConcurrency() :Boolean.FALSE;
				if(!checkPermission)
					throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE_FOR_ADMIN);
				break;
				
			case ALLOW_CONTENTUPLOAD:
				checkPermission=adminUser.getAllowContentUpload()!=null ?adminUser.getAllowContentUpload() :Boolean.FALSE;
				if(!checkPermission)
					throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE_FOR_ADMIN);
				break;
				
			case EDIT_ALLOWANCE:
				checkPermission=adminUser.getEditAllowance()!=null ?adminUser.getEditAllowance() :Boolean.FALSE;
				if(!checkPermission)
					throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE_FOR_ADMIN);
				break;
				
			case EDIT_ACCESS:
				checkPermission=adminUser.getEditAccess()!=null ?adminUser.getEditAccess() :Boolean.FALSE;
				if(!checkPermission)
					throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE_FOR_ADMIN);
				break;
				
			case EDIT_KEY:
				checkPermission=adminUser.getEditKey()!=null ?adminUser.getEditKey() :Boolean.FALSE;
				if(!checkPermission)
					throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE_FOR_ADMIN);
				break;
				
			case EDIT_PURCHASE:
				checkPermission=adminUser.getEditPurchase()!=null ?adminUser.getEditPurchase() :Boolean.FALSE;
				if(!checkPermission)
					throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE_FOR_ADMIN);
				break;
				
			case IS_READ_ONLY:
				checkPermission=adminUser.getIsReadOnly()!=null ? adminUser.getIsReadOnly() :Boolean.TRUE;
				if(checkPermission)
					throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE_FOR_ADMIN);
				break;
				
			default :					
				return;
			}
		}
		
	}

}
