package com.vst.bridge.rest.request;

public class XKeyBatch {
		public int useCount= -1;
		public int count= -1;
		public String userType= null;
		public String notes= null;
}
