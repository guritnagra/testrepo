package com.vst.bridge.rest.response.vo.ancillary;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.vst.bridge.entity.admin.ancillary.Ancillary;

public class AncillaryAdminVO {

	private Integer id;

	private String fileName;
	private String title;

	private String mimeType;
	
	@JsonProperty("sku")
	private String gcpSku;
	private String vbid;

	private Integer fileSize;
	private Integer bridgeId;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX")
	private Date createdAt;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX")
	private Date updatedAt;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX")
	private Date deletedAt;
	private Boolean completed;

	public AncillaryAdminVO(Ancillary ancillary) {
		if (null != ancillary) {
			this.setId(ancillary.getId());
			this.fileName = ancillary.getFileName();
			this.title = ancillary.getTitle();
			this.mimeType = ancillary.getMimeType();
			this.gcpSku = ancillary.getGcpSku();
			this.vbid = ancillary.getVbid();
			this.bridgeId = ancillary.getBridge().getId();
			this.createdAt = ancillary.getCreatedAt();
			this.updatedAt = ancillary.getUpdatedAt();
			this.deletedAt = ancillary.getDeletedAt();
			this.completed = ancillary.isCompleted();
		}

	}

	public AncillaryAdminVO() {

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMimeType() {
		return mimeType;
	}

	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}

	public String getGcpSku() {
		return gcpSku;
	}

	public void setGcpSku(String gcpSku) {
		this.gcpSku = gcpSku;
	}

	public String getVbid() {
		return vbid;
	}

	public void setVbid(String vbid) {
		this.vbid = vbid;
	}

	public Integer getBridgeId() {
		return bridgeId;
	}

	public void setBridgeId(Integer bridgeId) {
		this.bridgeId = bridgeId;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Date getDeletedAt() {
		return deletedAt;
	}

	public void setDeletedAt(Date deletedAt) {
		this.deletedAt = deletedAt;
	}

	public Integer getFileSize() {
		return fileSize;
	}

	public void setFileSize(Integer fileSize) {
		this.fileSize = fileSize;
	}

	public Boolean getCompleted() {
		return completed;
	}

	public void setCompleted(Boolean completed) {
		this.completed = completed;
	}

}
