package com.vst.bridge.rest.input.vo;

import java.util.List;

public class PurchaseRequestVO {
	
	private List<PurchaseVO> purchases;

	public List<PurchaseVO> getPurchases() {
		return purchases;
	}

	public void setPurchases(List<PurchaseVO> purchases) {
		this.purchases = purchases;
	}

}
