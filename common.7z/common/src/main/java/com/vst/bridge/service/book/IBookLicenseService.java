package com.vst.bridge.service.book;

import java.util.List;
import java.util.Map;

import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.rest.response.vo.user.BookLicenseInfoVO;
import com.vst.bridge.rest.response.vo.user.UserCreditsInfoVO;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ConnectLicense;

public interface IBookLicenseService {
	BookLicenseInfoVO checkTrialFunctinalityForVbid(String vbid, BridgeUser user,UserCreditsInfoVO userCreditsInfoVO)throws BridgeException;

	BookLicenseInfoVO checkRentalFunctinalityForVbid(String vbid, BridgeUser user, Bridge bridge)throws BridgeException;

	BookLicenseInfoVO checkFullFunctinalityForVbid(String vbid, BridgeUser user, Bridge bridge)throws BridgeException;

	Map<String, Object> checkVbidHasLaunchFunctionality(List<ConnectLicense> liceseList, String vbid, BridgeUser user)throws BridgeException;
}
