package com.vst.bridge.actions;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.HttpMethod;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.AbortMultipartUploadRequest;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.CompleteMultipartUploadRequest;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadResult;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PartETag;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.UploadPartRequest;
import com.vst.bridge.TomcatUtils;
import com.vst.bridge.VstException;
import com.vst.bridge.rest.response.vo.roster.UploadRosterVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;

public class Aws {

	/**
	 * TODO: change the logic from write file then upload file to just upload directly from InputStream
	 * Uploads an file to AWS.
	 * @param requestdomain domain of site
	 * @param uploadedInputStream stream to uploaded file
	 * @param ext extension of file
	 * @param uploadInputStreamSize size of file
	 * @return URL to file on AWS S3 site
	 * @throws VstException Bridge-specific errors
	 **/
	@SuppressWarnings("unused")
	public static String uploadFile(String requestdomain, InputStream uploadedInputStream, String ext, long uploadInputStreamSize,Boolean isRoster) throws BridgeException 
	{
        final String key= ApplicationConstants.AWS.accessKey; //"fileName1";
        final String uploadId= "99";
        ObjectMetadata objectMetadata= null;
        
        InputStream tempInput = new BufferedInputStream(uploadedInputStream);
        File localTmpFile = null;
        try {
			System.out.println("uploadedInputStream = "+uploadedInputStream.available());
			System.out.println("tempInput = "+tempInput.available());
			
			String filename = UUID.randomUUID().toString()+"."+ext;
			String root=null;
			final String temp=TomcatUtils.getParam("temp-directory");			
			if (temp!=null) {
				root=temp;
			}
        	localTmpFile= new File(root,filename);
        	localTmpFile.deleteOnExit();
        	
        	
       // 	writeStreamToFile(uploadedInputStream, localTmpFile);
        	System.out.println("uploadedInputStream = "+uploadedInputStream.available());
        	System.out.println("tempInput = "+tempInput.available());
        	writeStreamToFile(tempInput, localTmpFile);
			
        	uploadedInputStream = new FileInputStream(localTmpFile);
			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	
        try 
		{	
        	
			AWSCredentials awsCredentials = new BasicAWSCredentials(ApplicationConstants.AWS.accessKey, ApplicationConstants.AWS.secretKey);
	        AmazonS3 s3client = new AmazonS3Client(awsCredentials); //new ProfileCredentialsProvider());	    
	
	     //   List<Bucket> buckets = s3client.listBuckets();
/*	        for(Bucket b : buckets) {
	        	System.out.println("bucket name: "+ b.getName());
	        }*/
	        final String foundBucketName="vbsportaldata";

	        try{
	        	
	            List<PartETag> partETags = new ArrayList<PartETag>();

	            // Step 1: Initialize.
	            InitiateMultipartUploadRequest initRequest = new 
	                 InitiateMultipartUploadRequest(ApplicationConstants.AWS.bucketName, key);
	            InitiateMultipartUploadResult initResponse = 
	            	                   s3client.initiateMultipartUpload(initRequest);

	            long PART_SIZE_5MB = 5242880; // Set part size to 5 MB.
	            objectMetadata = new ObjectMetadata();
	            objectMetadata.setContentLength(uploadInputStreamSize);
	            if(!isRoster)
	            	objectMetadata.setContentType("image/"+ ext);
	            //objectMetadata.set
	            //objectMetadata.s
	            try {
	                // Step 2: Upload parts.
	                long filePosition = 0;
	                for (int i = 1; filePosition < uploadInputStreamSize; i++) {
	                    // Last part can be less than 5 MB. Adjust part size.
	                	long partSize= Math.min(PART_SIZE_5MB, (uploadInputStreamSize - filePosition));
	                	
	                	UploadPartRequest uploadRequest = new UploadPartRequest()//.withUploadId(uploadId)
	                            .withBucketName(ApplicationConstants.AWS.bucketName)
	                            .withKey(key)
	                            .withInputStream(uploadedInputStream)
	                            .withPartNumber(1)
	                            .withPartSize(partSize)
	                            .withLastPart(true)
	                            .withObjectMetadata(objectMetadata);
	                	
	                    // Create request to upload a part.
	                    /*UploadPartRequest*/ uploadRequest = new UploadPartRequest()
	                        .withBucketName(ApplicationConstants.AWS.bucketName).withKey(key)
	                        .withUploadId(initResponse.getUploadId()).withPartNumber(i)
	                        .withInputStream(uploadedInputStream)
	                        .withPartSize(partSize)
	                        .withLastPart(partSize < PART_SIZE_5MB);
	                        //.withFileOffset(filePosition)
	                        //.withFile(file)
	                        //.withPartSize(partSize);

	                    // Upload part and add response to our list.
	                    partETags.add(
	                    		s3client.uploadPart(uploadRequest).getPartETag());

	                    filePosition += partSize;
	                }

	                // Step 3: Complete.
	                CompleteMultipartUploadRequest compRequest = new 
	                             CompleteMultipartUploadRequest(
	                            		 ApplicationConstants.AWS.bucketName, 
	                            		 key, 
	                                        initResponse.getUploadId(), 
	                                        partETags);

	                s3client.completeMultipartUpload(compRequest);
	            } catch (Exception e) {
	                s3client.abortMultipartUpload(new AbortMultipartUploadRequest(
	                		ApplicationConstants.AWS.bucketName, key, initResponse.getUploadId()));
	            }
	        } catch (Exception e) {
                System.err.println(e);
            }
	        
	        try {
	        	
	        	
	        	System.out.println("Uploading a new object to S3 from a file\n");
	       
	        	objectMetadata = new ObjectMetadata();
	        	//objectMetadata.
	        	objectMetadata.setContentLength(uploadInputStreamSize);
	        	if(isRoster)
	        		requestdomain=requestdomain.concat("/roster");
	        	
	        	final String awsObjectKey= requestdomain+"/"+localTmpFile.getName();	//TODO: figure out how to do subfolders, then change "-" to "/"
	        	PutObjectRequest por= new PutObjectRequest(ApplicationConstants.AWS.bucketName, awsObjectKey, localTmpFile);
	            por.setCannedAcl(CannedAccessControlList.PublicRead);
	        	PutObjectResult req= s3client.putObject(por);
	            //fails: PutObjectResult req= s3client.putObject(new PutObjectRequest(Constants.AWS.bucketName, Constants.AWS.accessKey, uploadedInputStream, objectMetadata));

	            System.out.println("eTag: "+req.getETag());
	            //return "https://s3.amazonaws.com/"+Constants.AWS.bucketName+"/"+requestdomain+"/"+filename;
				System.out.println("Generating pre-signed URL.");
				java.util.Date expiration = new java.util.Date();
				long milliSeconds = expiration.getTime();
				milliSeconds += 1000 * 60 * 60* 24* 365* 20; // Add 20 years.
				expiration.setTime(milliSeconds);
	            
				GeneratePresignedUrlRequest generatePresignedUrlRequest= new GeneratePresignedUrlRequest(ApplicationConstants.AWS.bucketName, awsObjectKey);
				generatePresignedUrlRequest.setMethod(HttpMethod.GET); 
				generatePresignedUrlRequest.setExpiration(expiration);

				URL url = s3client.generatePresignedUrl(generatePresignedUrlRequest); 
				final String publicUrl=url.toString().substring(0,url.toString().lastIndexOf('?'));
				
				System.out.println("Pre-Signed URL = " + publicUrl);
				
				return publicUrl;
	         } catch (AmazonServiceException ase) {
	            System.out.println("Caught an AmazonServiceException, which " +
	            		"means your request made it " +
	                    "to Amazon S3, but was rejected with an error response" +
	                    " for some reason.");
	            System.out.println("Error Message:    " + ase.getMessage());
	            System.out.println("HTTP Status Code: " + ase.getStatusCode());
	            System.out.println("AWS Error Code:   " + ase.getErrorCode());
	            System.out.println("Error Type:       " + ase.getErrorType());
	            System.out.println("Request ID:       " + ase.getRequestId());
	            return ase.getMessage();
	        } catch (AmazonClientException ace) {
	            System.out.println("Caught an AmazonClientException, which " +
	            		"means the client encountered " +
	                    "an internal error while trying to " +
	                    "communicate with S3, " +
	                    "such as not being able to access the network.");
	            System.out.println("Error Message: " + ace.getMessage());
	            return ace.getMessage();
	        }
		} catch(Exception ex) {
			throw new BridgeException(ApplicationCode.AWS_ERROR);			
		}
		
		//return "error"; //"https://s3.amazonaws.com/vbsportaldata/kic-etextbooks.vsbportal-stage.vsapplications.com/60d9423c-fc03-4e53-be66-2b4f8c1589b0.png"; //TODO: change
	}
	
	/**
	 * Writes an inputStream to a file.
	 * @param inputStream input stream
	 * @param file file to write to disk
	 * @deprecated only used to make AWS upload work.
	 **/
	static void writeStreamToFile(InputStream inputStream, File file) {
		//InputStream inputStream = null;
		OutputStream outputStream = null;
	 
		try {
			// read this file into InputStream
			//inputStream = new FileInputStream("/Users/mkyong/Downloads/holder.js");
	 
			// write the inputStream to a FileOutputStream
			outputStream = 
	                    new FileOutputStream(file);
	 
			int read = 0;
			byte[] bytes = new byte[1024];
	 
			while ((read = inputStream.read(bytes)) != -1) {
				outputStream.write(bytes, 0, read);
			}
	 
			System.out.println("Done!");
	 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (outputStream != null) {
				try {
					// outputStream.flush();
					outputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
	 
			}
		}
	    }
	
	@SuppressWarnings("unused")
	public static String uploadRosterFile(String requestdomain, InputStream uploadedInputStream, String ext, long uploadInputStreamSize) throws BridgeException 
	{
        final String key= ApplicationConstants.AWS.accessKey; //"fileName1";
        final String uploadId= "99";
        ObjectMetadata objectMetadata= null;
        UploadRosterVO uploadRosterVO = new UploadRosterVO();
        InputStream tempInput = new BufferedInputStream(uploadedInputStream);
        File localTmpFile = null;
        try {
			System.out.println("uploadedInputStream = "+uploadedInputStream.available());
			System.out.println("tempInput = "+tempInput.available());
			
			String filename = UUID.randomUUID().toString()+"."+ext;			
			String root=null;
			final String temp=TomcatUtils.getParam("temp-directory");			
			if (temp!=null) {
				root=temp;
			}
        	localTmpFile= new File(root,filename);
        	localTmpFile.deleteOnExit();
        	
        	
       // 	writeStreamToFile(uploadedInputStream, localTmpFile);
        	System.out.println("uploadedInputStream = "+uploadedInputStream.available());
        	System.out.println("tempInput = "+tempInput.available());
        	writeStreamToFile(tempInput, localTmpFile);
			
        	uploadedInputStream = new FileInputStream(localTmpFile);
			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	
        try 
		{	
        	
			AWSCredentials awsCredentials = new BasicAWSCredentials(ApplicationConstants.AWS.accessKey, ApplicationConstants.AWS.secretKey);
	        AmazonS3 s3client = new AmazonS3Client(awsCredentials); //new ProfileCredentialsProvider());	    
	
	     //   List<Bucket> buckets = s3client.listBuckets();
/*	        for(Bucket b : buckets) {
	        	System.out.println("bucket name: "+ b.getName());
	        }*/
	        final String foundBucketName="vbsportaldata";

	        try{
	        	
	            List<PartETag> partETags = new ArrayList<PartETag>();

	            // Step 1: Initialize.
	            InitiateMultipartUploadRequest initRequest = new 
	                 InitiateMultipartUploadRequest(ApplicationConstants.AWS.bucketName, key);
	            InitiateMultipartUploadResult initResponse = 
	            	                   s3client.initiateMultipartUpload(initRequest);

	            long PART_SIZE_5MB = 5242880; // Set part size to 5 MB.
	            objectMetadata = new ObjectMetadata();
	            objectMetadata.setContentLength(uploadInputStreamSize);
	            //objectMetadata.set
	            //objectMetadata.s
	            try {
	                // Step 2: Upload parts.
	                long filePosition = 0;
	                for (int i = 1; filePosition < uploadInputStreamSize; i++) {
	                    // Last part can be less than 5 MB. Adjust part size.
	                	long partSize= Math.min(PART_SIZE_5MB, (uploadInputStreamSize - filePosition));
	                	
	                	UploadPartRequest uploadRequest = new UploadPartRequest()//.withUploadId(uploadId)
	                            .withBucketName(ApplicationConstants.AWS.bucketName)
	                            .withKey(key)
	                            .withInputStream(uploadedInputStream)
	                            .withPartNumber(1)
	                            .withPartSize(partSize)
	                            .withLastPart(true)
	                            .withObjectMetadata(objectMetadata);
	                	
	                    // Create request to upload a part.
	                    /*UploadPartRequest*/ uploadRequest = new UploadPartRequest()
	                        .withBucketName(ApplicationConstants.AWS.bucketName).withKey(key)
	                        .withUploadId(initResponse.getUploadId()).withPartNumber(i)
	                        .withInputStream(uploadedInputStream)
	                        .withPartSize(partSize)
	                        .withLastPart(partSize < PART_SIZE_5MB);
	                        //.withFileOffset(filePosition)
	                        //.withFile(file)
	                        //.withPartSize(partSize);

	                    // Upload part and add response to our list.
	                    partETags.add(
	                    		s3client.uploadPart(uploadRequest).getPartETag());

	                    filePosition += partSize;
	                }

	                // Step 3: Complete.
	                CompleteMultipartUploadRequest compRequest = new 
	                             CompleteMultipartUploadRequest(
	                            		 ApplicationConstants.AWS.bucketName, 
	                            		 key, 
	                                        initResponse.getUploadId(), 
	                                        partETags);

	                s3client.completeMultipartUpload(compRequest);
	            } catch (Exception e) {
	                s3client.abortMultipartUpload(new AbortMultipartUploadRequest(
	                		ApplicationConstants.AWS.bucketName, key, initResponse.getUploadId()));
	            }
	        } catch (Exception e) {
                System.err.println(e);
            }
	        
	        try {
	        	
	        	
	        	System.out.println("Uploading a new object to S3 from a file\n");
	       
	        	objectMetadata = new ObjectMetadata();
	        	//objectMetadata.
	        	objectMetadata.setContentLength(uploadInputStreamSize);
	        	requestdomain=requestdomain.concat("/roster");
	        	
	        	final String awsObjectKey= requestdomain+"/"+localTmpFile.getName();	//TODO: figure out how to do subfolders, then change "-" to "/"
	        	PutObjectRequest por= new PutObjectRequest(ApplicationConstants.AWS.bucketName, awsObjectKey, localTmpFile);
	            por.setCannedAcl(CannedAccessControlList.PublicRead);
	        	PutObjectResult req= s3client.putObject(por);
	            //fails: PutObjectResult req= s3client.putObject(new PutObjectRequest(Constants.AWS.bucketName, Constants.AWS.accessKey, uploadedInputStream, objectMetadata));

	            System.out.println("eTag: "+req.getETag());
	            //return "https://s3.amazonaws.com/"+Constants.AWS.bucketName+"/"+requestdomain+"/"+filename;
				System.out.println("Generating pre-signed URL.");
				java.util.Date expiration = new java.util.Date();
				long milliSeconds = expiration.getTime();
				milliSeconds += 1000 * 60 * 60* 24* 365* 20; // Add 20 years.
				expiration.setTime(milliSeconds);
	            
				GeneratePresignedUrlRequest generatePresignedUrlRequest= new GeneratePresignedUrlRequest(ApplicationConstants.AWS.bucketName, awsObjectKey);
				generatePresignedUrlRequest.setMethod(HttpMethod.GET); 
				generatePresignedUrlRequest.setExpiration(expiration);

				URL url = s3client.generatePresignedUrl(generatePresignedUrlRequest); 
				final String publicUrl=url.toString().substring(0,url.toString().lastIndexOf('?'));
				
				System.out.println("Pre-Signed URL = " + publicUrl);
				//UploadRosterVO uploadRosterVO = new UploadRosterVO();
				return publicUrl;
				//uploadRosterVO.setFileType(fileType);
				
	         } catch (AmazonServiceException ase) {
	            System.out.println("Caught an AmazonServiceException, which " +
	            		"means your request made it " +
	                    "to Amazon S3, but was rejected with an error response" +
	                    " for some reason.");
	            System.out.println("Error Message:    " + ase.getMessage());
	            System.out.println("HTTP Status Code: " + ase.getStatusCode());
	            System.out.println("AWS Error Code:   " + ase.getErrorCode());
	            System.out.println("Error Type:       " + ase.getErrorType());
	            System.out.println("Request ID:       " + ase.getRequestId());
	            return ase.getMessage();
	        } catch (AmazonClientException ace) {
	            System.out.println("Caught an AmazonClientException, which " +
	            		"means the client encountered " +
	                    "an internal error while trying to " +
	                    "communicate with S3, " +
	                    "such as not being able to access the network.");
	            System.out.println("Error Message: " + ace.getMessage());
	            return ace.getMessage();
	        }
		} catch(Exception ex) {
			throw new BridgeException(ApplicationCode.AWS_ERROR);			
		}
        
		//return "error"; //"https://s3.amazonaws.com/vbsportaldata/kic-etextbooks.vsbportal-stage.vsapplications.com/60d9423c-fc03-4e53-be66-2b4f8c1589b0.png"; //TODO: change
	}
		
}
