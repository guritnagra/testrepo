package com.vst.bridge.rest.response.vo.bridge;

import java.util.HashMap;
import java.util.Map;

public class BridgeConfigRequestVO {
	private Map<String, String> labels = new HashMap<String, String>();
	
	private String entitlementType;
	
	private String notesInfo;

	public Map<String, String> getLabels() {
		return labels;
	}

	public void setLabels(Map<String, String> labels) {
		this.labels = labels;
	}

	public String getEntitlementType() {
		return entitlementType;
	}

	public void setEntitlementType(String entitlementType) {
		this.entitlementType = entitlementType;
	}

	public String getNotesInfo() {
		return notesInfo;
	}

	public void setNotesInfo(String notesInfo) {
		this.notesInfo = notesInfo;
	}
	
}
