package com.vst.bridge.service.book;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vst.bridge.dao.key.IKeyDAO;
import com.vst.bridge.dao.user.book.IBridgeUserBookAssignDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.keys.KeyBatch;
import com.vst.bridge.entity.keys.KeyBatchEntitlement;
import com.vst.bridge.rest.response.vo.RedeemBookVO;
import com.vst.bridge.rest.response.vo.user.BookLicenseInfoVO;
import com.vst.bridge.rest.response.vo.user.ConcurrentBookLicenseInfoVO;
import com.vst.bridge.rest.response.vo.user.UserCreditsInfoVO;
import com.vst.bridge.rest.response.vo.user.UserEntitlementVO;
import com.vst.bridge.util.constant.ApplicationConstants;

@Service("bookEntitlementService")
public class BookEntitlementServiceImpl implements IBookEntitlementService {

	@Autowired
	private IBridgeUserBookAssignDAO bridgeUserBookAssignDAO;

	@Autowired
	private IKeyDAO keyDAO;
	
	@Autowired
	private BookServiceUtil bookServiceUtil;
	@Autowired
	private IBookConcurrencyService bookConcurrencyService;
	
	@Override
	public List<ConcurrentBookLicenseInfoVO> checkConcurrentEntitlementFunctinalityForVbid(String vbid, BridgeUser user, Bridge bridge,String state,UserCreditsInfoVO userCreditsInfoVO) {
		List<ConcurrentBookLicenseInfoVO> ConcurrentBookLicenseInfoVOList = new ArrayList<ConcurrentBookLicenseInfoVO>();
		
		if (bridge.getConcurrencyEnabled()) {
			if(!userCreditsInfoVO.getConcurrencyEntitlements().isEmpty()){
				List<UserEntitlementVO> userEntitlementVOList = userCreditsInfoVO.getConcurrencyEntitlements();
				for(UserEntitlementVO userEntitlementVO:userEntitlementVOList){
					if(state!=null && state.equals(ApplicationConstants.BOOK_LICENSE_STATE_EXPIRED) && ApplicationConstants.REDEEM_TYPE_COMP.equalsIgnoreCase(userEntitlementVO.getType()))
						continue;
					ConcurrentBookLicenseInfoVO concurrentBookLicenseInfoVO = new ConcurrentBookLicenseInfoVO();
					concurrentBookLicenseInfoVO.setId(userEntitlementVO.getId());
					concurrentBookLicenseInfoVO.setName(userEntitlementVO.getEntitlementName());
					concurrentBookLicenseInfoVO.setType(userEntitlementVO.getType());
					Integer concurrenyLimitForVbid = bookConcurrencyService.getconcurrencyLimitForVbid(vbid, bridge);
					List<Integer> keyIds = keyDAO.getKeyIdsForBridge(bridge.getId());
					Integer booksInUseCount = bridgeUserBookAssignDAO.getInUseBookCountForConcurrency(keyIds, vbid,null);
					Integer concurrentCredits = userEntitlementVO.getCredits();
					Integer concurrentCreditsUsed = userEntitlementVO.getUsed();

					if ((concurrentCredits != null && (concurrentCredits == -1 || concurrentCreditsUsed < concurrentCredits))) {
						concurrentBookLicenseInfoVO.setUrl(com.vst.bridge.StringUtils
								.getFormatedString(ApplicationConstants.BOOK_LICENSE_CONCURRENT_ENTITLEMENT, vbid,concurrentBookLicenseInfoVO.getId().toString()));
						concurrentBookLicenseInfoVO.setState(ApplicationConstants.BOOK_LICENSE_STATE_CREDIT);
						if (concurrenyLimitForVbid != null && booksInUseCount >= concurrenyLimitForVbid) {
							concurrentBookLicenseInfoVO.setIsAvailable(Boolean.FALSE);
						}
						ConcurrentBookLicenseInfoVOList.add(concurrentBookLicenseInfoVO);
					}
					
				}
			}
		}
		return ConcurrentBookLicenseInfoVOList;
	}

	@Override
	public List<BookLicenseInfoVO> checkEntitlementFunctionalityForVbid(String vbid, BridgeUser user, Bridge bridge,String state,UserCreditsInfoVO userCreditsInfoVO) {
		List<BookLicenseInfoVO> BookLicenseInfoVOList = new ArrayList<>();	
		
		List<UserEntitlementVO> userEntitlementVOList=userCreditsInfoVO.getEntitlements();
		if(userEntitlementVOList!=null && userEntitlementVOList.size()>0){
			for(UserEntitlementVO userEntitlementVO:userEntitlementVOList){
				if(state!=null && state.equals(ApplicationConstants.BOOK_LICENSE_STATE_EXPIRED) && ApplicationConstants.REDEEM_TYPE_COMP.equalsIgnoreCase(userEntitlementVO.getType()))
					continue;
				BookLicenseInfoVO licensesInfoVO = new BookLicenseInfoVO();			
				licensesInfoVO.setId(userEntitlementVO.getId());
				licensesInfoVO.setName(userEntitlementVO.getEntitlementName());
				licensesInfoVO.setType(userEntitlementVO.getType());			
				Integer credits = userEntitlementVO.getCredits();
				Integer usedCredits = userEntitlementVO.getUsed();
				if ((credits != null && (credits == -1 || usedCredits < credits))) {
					licensesInfoVO.setUrl(com.vst.bridge.StringUtils.getFormatedString(ApplicationConstants.BOOK_LICENSE_ENTITLEMENT, vbid,userEntitlementVO.getId().toString()));
					licensesInfoVO.setState(ApplicationConstants.BOOK_LICENSE_STATE_CREDIT);
					BookLicenseInfoVOList.add(licensesInfoVO);
				}
				
			}
		}
		return BookLicenseInfoVOList;
	}
	@Override
	public BookLicenseInfoVO checkEntitlementFunctionalityForVbidById(String vbid, BridgeUser user, Bridge bridge,Integer entitlementId,String state) {
		
		UserCreditsInfoVO userCreditsInfoVO = bookServiceUtil.getUserCredits(user);
		BookLicenseInfoVO licensesInfoVO=null;
		List<UserEntitlementVO> userEntitlementVOList=userCreditsInfoVO.getEntitlements();
		for(UserEntitlementVO userEntitlementVO:userEntitlementVOList){
			if(state!=null && state.equals(ApplicationConstants.BOOK_LICENSE_STATE_EXPIRED) && ApplicationConstants.REDEEM_TYPE_COMP.equalsIgnoreCase(userEntitlementVO.getType()))
				continue;
			if(entitlementId!=null && entitlementId.equals(userEntitlementVO.getId())){
				licensesInfoVO = new BookLicenseInfoVO();			
				licensesInfoVO.setId(userEntitlementVO.getId());
				licensesInfoVO.setName(userEntitlementVO.getEntitlementName());
				licensesInfoVO.setType(userEntitlementVO.getType());			
				Integer credits = userEntitlementVO.getCredits();
				Integer usedCredits = userEntitlementVO.getUsed();
				if ((credits != null && (credits == -1 || usedCredits < credits))) {
					licensesInfoVO.setUrl(com.vst.bridge.StringUtils.getFormatedString(ApplicationConstants.BOOK_LICENSE_ENTITLEMENT, vbid,userEntitlementVO.getId().toString()));
					licensesInfoVO.setState(ApplicationConstants.BOOK_LICENSE_STATE_CREDIT);
				}
			}			
		}

		return licensesInfoVO;
	}
	
	@Override
	public <T> RedeemBookVO populateRedeemBookVOFromKeyBatchEntitlement(T t) {
		RedeemBookVO redeemBookVO=new RedeemBookVO();
		if(t instanceof KeyBatchEntitlement){
			KeyBatchEntitlement keyBatchEntitlement =(KeyBatchEntitlement)t;			
		redeemBookVO.setCodeType(keyBatchEntitlement.getEntType().getType());
		redeemBookVO.setOnlineDays(keyBatchEntitlement.getEntOnlineDays());
		redeemBookVO.setOnlineDate(keyBatchEntitlement.getEntOnlineExpires());
		redeemBookVO.setOfflineDays(keyBatchEntitlement.getEntOfflineDays());
			redeemBookVO.setOfflineDate(keyBatchEntitlement.getEntOfflineExpires());			
		}
		else if(t instanceof KeyBatch){
			KeyBatch keybatch = (KeyBatch)t;
			redeemBookVO.setCodeType(keybatch.getConcCodeType().getType());
			redeemBookVO.setOnlineDays(keybatch.getConcurrencyDays());
			redeemBookVO.setOnlineDate(keybatch.getConcurrencyExpires());
			redeemBookVO.setOfflineDays(keybatch.getOfflineConcurrencyDays());
			redeemBookVO.setOfflineDate(keybatch.getOfflineConcurrencyExpires());
		}
		
		return redeemBookVO;
	}

}
