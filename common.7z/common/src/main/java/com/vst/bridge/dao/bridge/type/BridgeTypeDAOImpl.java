package com.vst.bridge.dao.bridge.type;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.BridgeType;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeTypeDAO")
public class BridgeTypeDAOImpl extends GenericDAO<BridgeType, Integer> implements IBridgeTypeDAO  {

	public BridgeTypeDAOImpl() {
		super(BridgeType.class);
		// TODO Auto-generated constructor stub
	}

	@Override
	public BridgeType getBridgeForType(String type) throws BridgeException {
		Criteria criteria = getCriteria();
		if(null != type){
			criteria.add(Restrictions.like("type", type));
		}
		List<BridgeType> result =  executeCriteira(criteria);
		return result != null && result.size() > 0 ? result.get(0) : null ;
	}

	@Override
	public List<BridgeType> getAllBridgeTypes() throws BridgeException {
		Criteria criteria = getCriteria();
		return executeCriteira(criteria);
	}

	@Override
	public List<IdValueVO> getTypes() throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.addOrder(Order.asc("type"));
		criteria.setProjection(Projections.projectionList()
				.add( Projections.property("id").as("id"))
				.add( Projections.property("type").as("value")))
				.setResultTransformer(new AliasToBeanResultTransformer(IdValueVO.class));
		return executeCriteira(criteria);
	}

}
