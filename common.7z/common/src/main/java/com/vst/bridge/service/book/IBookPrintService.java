package com.vst.bridge.service.book;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.user.BookLicenseInfoVO;
import com.vst.bridge.util.exception.BridgeException;

public interface IBookPrintService {

	BookLicenseInfoVO checkPrintFunctinalityForVbid(String vbid, BridgeUser user, Bridge bridge)throws BridgeException;

	RestResponse printBook(SessionStatusVO sessionStatusVO, String vbid, String code, HttpServletRequest httpRequest,
			UriInfo uriInfo)throws BridgeException;
}
