package com.vst.bridge.service.job;

public interface IJobSchedulerServices {
	
	public void populateUsersFromBC();
	public void populateCoursesFromBC();
	void generateKpiDataReport();	

}
