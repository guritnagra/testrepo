package com.vst.bridge.dao.admin.password;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.password.ResetPassword;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminUserPasswordDAO extends IGenericDAO<ResetPassword, Integer>{
	ResetPassword getPasswordForAdminId(final Integer adminId,final String tokanId,final Boolean used)throws BridgeException;

	List<ResetPassword> getListByAdminId(Integer adminId, Boolean used) throws BridgeException;
}
