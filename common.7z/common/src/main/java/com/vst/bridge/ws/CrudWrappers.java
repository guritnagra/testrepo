package com.vst.bridge.ws;

import java.io.InputStream;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;

import com.vst.bridge.rest.response.HtmlResponse;
import com.vst.bridge.rest.response.RestResponse;
import com.vst.bridge.util.constant.ApplicationConstants;

public class CrudWrappers {
	public static enum CRUD_TYPE{READ, CREATE, UPDATE, DELETE}
	
	public static RestResponse uploadFile(String uri, InputStream fileStream) {
		RestResponse response= HtmlResponse.instance(Response.Status.OK, "default");
		
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(uri);
		Invocation.Builder builder= target.request(MediaType.APPLICATION_JSON);
		Entity<InputStream> request= Entity.entity(fileStream, MediaType.MULTIPART_FORM_DATA);
		Response jerseyResponse= builder.post(request); 

		System.out.println("---------------------------------");
		System.out.printf("ws-endpoint: %s %s\n", "POST", uri);
		System.out.println("status: "+ jerseyResponse.getStatus());
//		responseStr= response.getEntity(String.class);
//		System.out.println("requestJson: "+ requestJson);
		System.out.println("responseStr: "+ jerseyResponse.toString());
		System.out.println("---------------------------------");
		response= HtmlResponse.instance(Response.Status.fromStatusCode(jerseyResponse.getStatus()), jerseyResponse.readEntity(String.class));

		response.cookie(getCookie(jerseyResponse));	//Constants.REST.PARAMS.STACK_SESSIONID //new NewCookie(Constants.REST.PARAMS.STACK_SESSIONID, 
		
		return response;
	}
	
	/*
	 * performs a Http-GET REST web service call.
	 * @param uri URL
	 * @param lastCookie cookie to add to Request, or null if none sent
	 * @return response
	 **
	public static RestResponse get(String uri, String lastCookie) {
		RestResponse response= HtmlResponse.instance(Response.Status.OK, "default");
		
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(uri);//.path("resource");
		//WebResource webResource = client.resource(uri);
		
		//WebResource.Builder builder = webResource.getRequestBuilder();
		
		Invocation.Builder builder= target.request(MediaType.APPLICATION_JSON_TYPE);
		//invocationBuilder.header("some-header", "true");
		
		// TODO: COOKIE
		if(null != lastCookie) {
			NewCookie c= new NewCookie(Constants.REST.PARAMS.STACK_SESSIONID, lastCookie);
			builder.cookie(c);
		}
		
		//ClientResponse jerseyResponse= builder.accept(MediaType.APPLICATION_JSON).get(ClientResponse.class); //builder.get(ClientResponse.class);

		Response jerseyResponse= target.request(MediaType.APPLICATION_JSON_TYPE).get();
		
		System.out.println("status: "+ jerseyResponse.getStatus());
//		responseStr= response.getEntity(String.class);
		System.out.println("responseStr: "+ jerseyResponse.toString());
		response= HtmlResponse.instance(jerseyResponse.getStatus(), (String)jerseyResponse.readEntity(String.class));
		
		return response;
	}
	
	public static RestResponse del(String uri, String lastCookie) {
		RestResponse response= HtmlResponse.instance(Response.Status.OK, "default");
		
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(uri);
		
		Invocation.Builder builder= target.request(MediaType.APPLICATION_JSON_TYPE);
		
		if(null != lastCookie) {
			NewCookie c= new NewCookie(Constants.REST.PARAMS.COOKIE, lastCookie);
			builder = builder.cookie(c);
		}
		
		Response jerseyResponse= builder.accept(MediaType.APPLICATION_JSON).delete(); //builder.get(ClientResponse.class);

		System.out.println("status: "+ jerseyResponse.getStatus());
//		responseStr= response.getEntity(String.class);
		System.out.println("responseStr: "+ jerseyResponse.toString());
		response= HtmlResponse.instance(jerseyResponse.getStatus(), jerseyResponse.readEntity(String.class));
		
		return response;
	}*/
	
	public static RestResponse webServiceRequest(String uri, CRUD_TYPE crudType, String requestJson, String lastCookie) {
		RestResponse response= HtmlResponse.instance(Response.Status.OK, "default");
		Entity<String> request= null;
		
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(uri);
		
		Invocation.Builder builder= target.request(MediaType.APPLICATION_JSON_TYPE);
		
		if(null != requestJson) {
			request= Entity.entity(requestJson, MediaType.APPLICATION_JSON_TYPE);
		}
		if(null != lastCookie) {
			NewCookie c= new NewCookie(ApplicationConstants.BRIDGE_SESSIONID, lastCookie);
			builder = builder.cookie(c);
		}
		
		Response jerseyResponse= null;
		switch(crudType) {
		case CREATE: //POST
			jerseyResponse= builder.post(request); //builder.get(ClientResponse.class);
			break;
		case UPDATE: //PUT
			jerseyResponse= builder.put(request); //builder.get(ClientResponse.class);
			break;
		case DELETE: //DELETE
			jerseyResponse= builder.delete(); //builder.get(ClientResponse.class);
			break;
		default:
		case READ: //GET
			jerseyResponse= builder.get(); //builder.get(ClientResponse.class);
			break;
		}
		
		System.out.println("---------------------------------");
		System.out.printf("ws-endpoint: %s %s\n", crudType, uri);
		System.out.println("status: "+ jerseyResponse.getStatus());
//		responseStr= response.getEntity(String.class);
		System.out.println("requestJson: "+ requestJson);
		System.out.println("responseStr: "+ jerseyResponse.toString());
		System.out.println("---------------------------------");
		response= HtmlResponse.instance(Response.Status.fromStatusCode(jerseyResponse.getStatus()), jerseyResponse.readEntity(String.class));

		response.cookie(getCookie(jerseyResponse));	//Constants.REST.PARAMS.STACK_SESSIONID //new NewCookie(Constants.REST.PARAMS.STACK_SESSIONID, 
		
		return response;
	}
	
	/*
	 * performs a Http-GET REST web service call.
	 * @param uri URL
	 * @param lastCookie cookie to add to Request, or null if none sent
	 * @return response
	 **
	public static String getUsingApacheClient(String uri, String lastCookie) {
		CloseableHttpClient httpclient = HttpClients.custom().setDefaultCookieStore(null).build();
		HttpGet httpGet = new HttpGet(uri);
		String response;
		
		try {
			if(null != lastCookie) {
				CookieStore cookies= new BasicCookieStore();
				BasicClientCookie2 cookie= new BasicClientCookie2(Constants.REST.PARAMS.COOKIE, lastCookie);
				//cookie.setDomain(?);
				cookie.setPath(Constants.REST.PARAMS.COOKIE_PATH);
				cookies.addCookie(cookie);
				httpclient = HttpClients.custom().setDefaultCookieStore(cookies).build();
				//httpclient.setCookieStore(cookies); 
			}
			CloseableHttpResponse response1 = httpclient.execute(httpGet);
			// The underlying HTTP connection is still held by the response object
			// to allow the response content to be streamed directly from the network socket.
			// In order to ensure correct deallocation of system resources
			// the user MUST call CloseableHttpResponse#close() from a finally clause.
			// Please note that if response content is not fully consumed the underlying
			// connection cannot be safely re-used and will be shut down and discarded
			// by the connection manager. 
			try {
			    System.out.println(response1.getStatusLine());
			    HttpEntity entity1 = response1.getEntity();
			    // do something useful with the response body
			    // and ensure it is fully consumed
			    response= EntityUtils.toString(entity1);
			    System.out.println("get: "+ response);
			    
			    EntityUtils.consume(entity1);
			} finally {
			    response1.close();
			}
		} catch (IOException e) {
			response= e.getMessage();
			e.printStackTrace();
		}
		
		return response;
	}

	**
	 * performs a Http-DELETE REST web service call.
	 * @param uri URL
	 * @param lastCookie cookie to add to Request, or null if none sent
	 * @param json request data
	 * @return response
	 *
	public static RestResponse delete(String uri, String json, String lastCookie) {
		RestResponse restResponse= HtmlResponse.instance(Response.Status.OK, "default");
		
		CookieHandler.setDefault(new CookieManager());
		CloseableHttpClient httpclient = HttpClients.createDefault();
		
		HttpDelete httpPost = new HttpDelete(uri);
//		List<NameValuePair> nvps = new ArrayList<>();
//		nvps.add(new BasicNameValuePair("email", "sean.murphy@ingramcontent.com"));
//		nvps.add(new BasicNameValuePair("password", "password"));
		StringEntity requestEntity= null;
		try {
			requestEntity = new StringEntity(
					null == json ? "" : json,
				    "application/json",
				    "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		try {
			//httpPost.setEntity(requestEntity);
			httpPost.setHeader(Constants.REST.PARAMS.COOKIE, lastCookie);
			CloseableHttpResponse response = httpclient.execute(httpPost);

			try {
				final String status= response.getStatusLine().toString().trim();
			    System.out.println("post status: "+ status);
			    HttpEntity entity = response.getEntity();
			    // do something useful with the response body
			    // and ensure it is fully consumed
			    //System.out.println(EntityUtils.toString(entity2));
			 // set cookies
				lastCookie= (response.getFirstHeader("Set-Cookie") == null ? "" : 
			                     response.getFirstHeader("Set-Cookie").toString());
				
				restResponse.cookie(new NewCookie(Constants.REST.PARAMS.COOKIE, lastCookie));	//Constants.REST.PARAMS.STACK_SESSIONID
			    
			    String strResponse= EntityUtils.toString(entity).replaceAll("\\\\\"", "\"").substring(1);
			    strResponse= strResponse.substring(0, strResponse.length()- 1);
			    System.out.println("post: "+ strResponse);
			    restResponse.setText(strResponse.replaceAll("\"", "\""));
			    //TODO: get Cookie and pass it to next call
			    
			    EntityUtils.consume(entity);
			    
			    restResponse= HtmlResponse.instance(response.getStatusLine().getStatusCode(), strResponse.replaceAll("\\\"", "\""));
				restResponse.cookie(new NewCookie(Constants.REST.PARAMS.COOKIE, lastCookie));	//Constants.REST.PARAMS.STACK_SESSIONID
			    //restResponse.setStatus(new RestStatus(Response.Status.OK, status));
			    //restResponse.setText(strResponse);
			} finally {
			    response.close();
			}
		} catch (IOException e) {
			restResponse.setStatus(new RestStatus(Response.Status.INTERNAL_SERVER_ERROR, e.getMessage()));
			e.printStackTrace();
		}
		
		return restResponse;
	}
	
	*
	 * performs a Http-POST REST web service call.
	 * @param uri URL
	 * @param lastCookie cookie to add to Request, or null if none sent
	 * @param json request data
	 * @return response
	 **
	public static RestResponse post(String uri, String json, String lastCookie) {
		RestResponse restResponse= HtmlResponse.instance(Response.Status.OK, "default");
		
		CookieHandler.setDefault(new CookieManager());
		CloseableHttpClient httpclient = HttpClients.createDefault();
		
		HttpPost httpPost = new HttpPost(uri);
//		List<NameValuePair> nvps = new ArrayList<>();
//		nvps.add(new BasicNameValuePair("email", "sean.murphy@ingramcontent.com"));
//		nvps.add(new BasicNameValuePair("password", "password"));
		StringEntity requestEntity= null;
		try {
			requestEntity = new StringEntity(
					json,
				    "application/json",
				    "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		try {
			httpPost.setEntity(requestEntity);
			httpPost.setHeader(Constants.REST.PARAMS.COOKIE, lastCookie);
			CloseableHttpResponse response = httpclient.execute(httpPost);

			try {
				final String status= response.getStatusLine().toString().trim();
			    System.out.println("post status: "+ status);
			    HttpEntity entity = response.getEntity();
			    // do something useful with the response body
			    // and ensure it is fully consumed
			    //System.out.println(EntityUtils.toString(entity2));
			 // set cookies
				lastCookie= (response.getFirstHeader("Set-Cookie") == null ? "" : 
			                     response.getFirstHeader("Set-Cookie").toString());
				
				restResponse.cookie(new NewCookie(Constants.REST.PARAMS.COOKIE, lastCookie));	//Constants.REST.PARAMS.STACK_SESSIONID
			    
			    String strResponse= EntityUtils.toString(entity).replaceAll("\\\\\"", "\"").substring(1);
			    strResponse= strResponse.substring(0, strResponse.length()- 1);
			    System.out.println("post: "+ strResponse);
			    restResponse.setText(strResponse.replaceAll("\"", "\""));
			    //TODO: get Cookie and pass it to next call
			    
			    EntityUtils.consume(entity);
			    
			    restResponse= HtmlResponse.instance(response.getStatusLine().getStatusCode(), strResponse.replaceAll("\\\"", "\""));
				restResponse.cookie(new NewCookie(Constants.REST.PARAMS.COOKIE, lastCookie));	//Constants.REST.PARAMS.STACK_SESSIONID
			    //restResponse.setStatus(new RestStatus(Response.Status.OK, status));
			    //restResponse.setText(strResponse);
			} finally {
			    response.close();
			}
		} catch (IOException e) {
			restResponse.setStatus(new RestStatus(Response.Status.INTERNAL_SERVER_ERROR, e.getMessage()));
			e.printStackTrace();
		}
		
		return restResponse;
	}*/
	
	public static String getCookieString(RestResponse wsResponse) {
		try {
			String cookieStr= wsResponse.getCookies().get(0).getValue();
			cookieStr= cookieStr.substring(cookieStr.indexOf("stacksessionId=")+15);
			cookieStr= cookieStr.substring(0, cookieStr.indexOf(";"));
			return cookieStr;
		} catch (Exception e) {
			return e.getMessage();
		}
	}
	
	public static NewCookie getCookie(Response jerseyResponse) {
		NewCookie cookie= null;
		
		cookie= jerseyResponse.getCookies().get("Set-Cookie");
		
		if(null == cookie) {
			final String cookieHeader= jerseyResponse.getHeaderString("Set-Cookie");
			if(null != cookieHeader) {
				cookie= new NewCookie(ApplicationConstants.BRIDGE_SESSIONID, cookieHeader);
			}
		}
		
		return cookie;
	}

}
