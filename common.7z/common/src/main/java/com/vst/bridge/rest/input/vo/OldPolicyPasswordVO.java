package com.vst.bridge.rest.input.vo;

public class OldPolicyPasswordVO {
	private String email;
	private String oldPassword;
	private String newPassword;
	private Integer questionId;
	private String questionResponse;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getOldPassword() {
		return oldPassword;
	}
	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public Integer getQuestionId() {
		return questionId;
	}
	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}
	public String getQuestionResponse() {
		return questionResponse;
	}
	public void setQuestionResponse(String questionResponse) {
		this.questionResponse = questionResponse;
	}
	
	
}
