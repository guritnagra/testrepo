package com.vst.bridge.rest.response.vo;

import java.util.Date;
import java.util.List;

import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.rest.input.vo.PermissionLevelVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;


public class AdminUserVO{
	private Integer id;
	private String firstName;
	private String lastName;
	private String email;
	private String type;
	private Long created;
	private Date createdDate;
	private String createdBy;
	private List<AdminGroupVO> groups;
	private List<AdminGroupVO> companies;
	private String label;
	private Integer systemUserId;
	private PermissionLevelVO permission;
	public AdminUserVO(){
		
	}
	
	public AdminUserVO(AdminUser adminUser){
		PermissionLevelVO permission = null;
		if(adminUser.getRole()==null){
			throw new BridgeException("Role missing", ApplicationCode.MISSING_INPUT_FIELD);
		}
		if(adminUser!=null && ApplicationConstants.USER_ROLE_SUPER_ADMIN.equals(adminUser.getRole().getName())){
			permission= new PermissionLevelVO(Boolean.TRUE);
		}
		else{
			permission=new PermissionLevelVO();
			permission.setAllowContentUpload(adminUser.getAllowContentUpload());
			permission.setEditAccess(adminUser.getEditAccess());
			permission.setEditAllowance(adminUser.getEditAllowance());
			permission.setEditBasicInfo(adminUser.getEditBasicInfo());
			permission.setEditBridge(adminUser.getEditBridge());
			permission.setEditManage(adminUser.getEditManage());
			permission.setEditStyling(adminUser.getEditStyling());
			permission.setEditSystemUser(adminUser.getEditSystemUser());
			permission.setEditUserConcurrency(adminUser.getEditUserConcurrency());
			permission.setEditUserLimit(adminUser.getEditUserLimit());
			permission.setEditUsers(adminUser.getEditUsers());
			permission.setIsReadOnly(adminUser.getIsReadOnly());
			permission.setEditKey(adminUser.getEditKey());
			permission.setEditPurchase(adminUser.getEditPurchase());
		}
		this.permission=permission;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Long getCreated() {
		return created;
	}
	public void setCreated(Long created) {
		this.created = created;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public List<AdminGroupVO> getGroups() {
		return groups;
	}
	public void setGroups(List<AdminGroupVO> groups) {
		this.groups = groups;
	}	
	public List<AdminGroupVO> getCompanies() {
		return companies;
	}
	public void setCompanies(List<AdminGroupVO> companies) {
		this.companies = companies;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public Integer getSystemUserId() {
		return systemUserId;
	}
	public void setSystemUserId(Integer systemUserId) {
		this.systemUserId = systemUserId;
	}
	public PermissionLevelVO getPermission() {
		return permission;
	}
	public void setPermission(PermissionLevelVO permission) {
		this.permission = permission;
	}
}
