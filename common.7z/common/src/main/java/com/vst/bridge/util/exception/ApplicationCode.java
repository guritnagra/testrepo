package com.vst.bridge.util.exception;

import java.util.NoSuchElementException;
/**
 * Set of Application Codes that are used for indicating specific error scenarios
 * 
 * @author Irfan.Tamboli
 *
 */
public enum ApplicationCode {

	STATUS_OK("response.ok"),
	INVALID_INPUT("response.input.invalid"),
	BRIDGE_APP_VERSION("bridge.app.version"),
	INVALID_SESSION("response.session.invalid"), 
	USER_NOT_FOUND("response.user.not_found"), 
	BASE_DB_ERROR("response.db.connection_fail"), 
	UNEXPECTED_ERROR("response.internal_server_error"), 
	INSUFFICIENT_PARAMETERS("response.insufficient_data"),
	USER_ALREADY_EXIST("response.duplicate.email"), 
	USER_AUTHENTICATION_FAILED("response.login.invalid_info"),
	FAILED_TO_MD5_HASHING("response.encrypt.hashing_fail"),
	DATA_VALIDATION_ERROR("response.invalid_input_data"),
	MISSING_INPUT_FIELD("response.missing_input_data"),
	ERROR_VALIDATION_INPUT_FIELD("response.invalid_json"),
	SESSION_EXPIRED("response.session.expired"),
	PARSING_ERROR("response.parsing_failed"),
	INVALID_BRIDGE_ACTION("response.no_action"),
	MISSING_EMAIL("response.missing.email"),
	MISSING_PASSWORD("response.missing.password"),
	EMAIL_RESET_PASSWORD_SUBJECT("email.resetpassword.subject"), NO_SUCH_WEBSITE("response.url.no_web_site"),
	RESET_PASSWORD("response.password.reset.ok"),
	RESET_PASSWORD_TOKEN_EXPIRE("response.token.expire"),
	UNSUPPORTED_MEDIA_TYPE("response.invalid.logo.media_type"),
	AWS_ERROR("response.aws.s3.error"),
	BRIDGE_NOT_FOUND("response.bridge.invalid"),
	COMPANY_NOT_FOUND("response.company.invalid"), 
	GROUP_NOT_FOUND("response.group.invalid"),
	CONNECT_API_ERROR("response.connect.error"),
	BOOK_NOT_FOUND("response.book.invalid"),
	
	DUPLICATE_BRIDGE_NAME("response.bridge.duplicate.name"),
	DUPLICATE_COMPANY_NAME("response.company.duplicate.name"),
	DUPLICATE_GROUP_NAME("response.group.duplicate.name"),
	
	KEY_BATCH_NOT_FOUND("response.keybatch.invalid"),
	KEY_CODE_NOT_FOUND("response.keycode.invalid"),
	BRIDGE_USER_NOT_FOUND("response.user.invalid"),
	USE_KEY_ASSOCIATION_NOT_FOUND("response.user.key.invalid"), 
	DUPLICATE_BRIDGE_CODE("response.bridge.duplicate.code"),
	INVALID_ORDERBY_FIELD("response.invalid.orderby"),
	INVALID_BRIDGE_KEY_CODE("response.code.invalid.bridge"),
	LICENSE_NOT_FOUND("response.invalid.vbid"),
	KEY_NOT_FOUND("response.invalid.key.code"),
	KEY_EXPIRED("response.expire.key"),
	DUPLICATE_KEY("response.duplicate.key"),
	UNATHORISED_REQUEST("response.bridge.unathorised"),
	INVALID_BRIDGE_KEY("response.bridge.key"), 
	DUPLICATE_BRIDGE_ALIAS("response.bridge.duplicate.alias"),
	INVALID_BRIDGE_CODE("response.bridge.invalid.code"),
	URL_REDIRECT("response.redirect"),
	KEY_MAX_USER_REACH("response.maxuse.key.code"),
	INVALID_FULL_CREDITS_VALUE("response.invalid.fullCredits"),
	INVALID_REPORT_PAGE("response.invalid.page"),
	EMAIL_NEW_BRIDGE_SUBJECT("email.newbridge.subject"),
	EMAIL_BRIDGE_SETUP_NOTIFICATION_SUBJECT("email.bridgesetupnotification.subject"),
	INSUFFICIENT_PRIVILEGE("response.insufficient_privilege"), 
	INVALID_DATE("response.invalid.date"),
	USER_DELTED_BY_ADMIN("response.user.removed"),
	ROSTER_USER_ACTIVATION_MAIL_SUB("roster.user.email.subject"),
	BOOKSHELF_FULL_USER("response.user.full"),
	NOT_FULL_USER("response.user.not.full"),
	FILE_SIZE_LIMIT_EXCEEDED("response.filesize.limit.exceeded"),
	TEMPLATE_NOT_FOUND("response.template.invalid"),
	UNSUPPORTED_FILE_TYPE("response.filetype.invalid"),
	INVALID_TOKEN("response.invalid.token"),
	ALREADY_USED_TOKEN("response.token.used"),
	EXPIRED_TOKEN("response.token.expired"), 
	BRIDGE_NOT_ROSTERED("response.bridge.not.rostered"), 
	CONCURRENCY_NOT_ENABLED("concurency.not.enabled"), 
	CONCURRENCY_LIMIT_REACHED("concurrency.limit.reached"), 
	RETURN_BOOK_FAILED("return.book.failed"),
	USER_NOT_ROSTERED("response.user.not.rostered"), 
	TENANT_NOT_VALID("response.invalid.tenant"),
	BC_API_ERROR("response.bc.error"),
	INVALID_CONTEXT_TOKEN("invalid.context.token"),
	TOKEN_NOT_FOUND("response.token.not.found"),
	BRIDGE_NOT_INTEGRATED("response.bridge.not.integrated"), 
	PASSWORD_NOT_VALID("response.password.not.valid"),
	PASSWORD_MAX_EXCEEDED("response.password.attempt.exceeded"),
	OLD_SECURITY_QUESTION("response.old.security.question"),
	INVALID_USER_REQUEST("response.invalid.user.request"),
	PASSWORD_NOT_ACCEPTED("response.password.not.accepted"),
	TOO_MANY_REQUESTS_ERROR("response.too.many.requests.error"),
	EMAIL_BRIDGE_ACTIVATION_SUBJECT("email.bridgea.ctivation.subject"),
	KPI_DATA_REPORT_SUBJECT_PROD("email.kpi.data.subject"),
	KPI_DATA_REPORT_SUBJECT_DEV("email.kpi.data.subject.dev"),
	KPI_DATA_REPORT_SUBJECT_STAGE("email.kpi.data.subject.stage"),
	INVALID_ROSTER_HEADER("invalid.roster.header"), 
	PURCHASE_NOT_ENABLED("purchase.not.enabled"),
	INVALID_GROUP_NAME("invalid.group.name"),
	CAPTCHA_MAX_EXCEEDED("captcha.max.attempts.exceeed"),
	CAPTCHA_FAILED("captcha.attempt.failed"), 
	COMPANY_ALREADY_EXIST("company.already.exist"),
	UNAUTHORISED_CONNECT_USER("unauthorized.connect.user"),
	INSUFFICIENT_PRIVILEGE_FOR_ADMIN("insufficient.admin.privilege");
	
	private final String codeId;

	private ApplicationCode(final String codeId) {
		this.codeId = codeId;
	}

	public String getCodeId() {
		return this.codeId;
	}

	/**
	 * Converts an int value into an ErrorCode
	 * 
	 * @param errorCode
	 * @return {@link ApplicationCode}
	 */
	public static ApplicationCode getExceptionCode(final int errorCode) {

		ApplicationCode eErrorCode = null;
		for (final ApplicationCode status : ApplicationCode.values()) {
			if (status.getCodeId().equals(errorCode)){
				eErrorCode = status;
				break;
			}
		}
		if (null == eErrorCode) {
			throw new NoSuchElementException("The received code " + errorCode + " is not valid !!!");
		} else {
			return eErrorCode;
		}
	}
}
