package com.vst.bridge.dao.bridge.book;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.books.BridgeBooks;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeBookDAO extends IGenericDAO<BridgeBooks, Integer>{
	List<String> getBookIdsForBridge(final Integer bridgeId, boolean orderbyRecent, boolean showAllBooks)throws BridgeException;
	List<BridgeBooks> getAllBooksForBridge(final Integer bridgeId)throws BridgeException;
}
