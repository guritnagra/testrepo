package com.vst.bridge.dao.bridge.book;

import java.util.Collection;
import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.entity.bridge.books.BridgeBookPricing;
import com.vst.bridge.util.exception.BridgeException;


public interface IBridgeBookPricingDAO extends IGenericDAO<BridgeBookPricing, Integer>{

	BridgeBookPricing getBookPricingbySku(Integer cacheId, String sku) throws BridgeException;

	List<BridgeBookPricing> getBookPricingByCacheId(Integer cacheId)throws BridgeException;
	
	BridgeBookPricing getBookPricingByRentalType(Integer cacheId,String rentalType)throws BridgeException;

	List<BridgeBookPricing> getBookPricingByCacheIds(List<Integer> cacheIdList);

	List<BridgeBookPricing> getBookPricingBySkus(Collection<String> skuList) throws BridgeException;

	List<BridgeBookPricing> getBookPricingByCacheCollection(Collection<BridgeBookCache> bookCacheCollection);

}
