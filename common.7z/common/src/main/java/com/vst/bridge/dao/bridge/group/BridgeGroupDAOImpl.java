package com.vst.bridge.dao.bridge.group;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.group.BridgeGroup;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeGroupDAO")
public class BridgeGroupDAOImpl extends GenericDAO<BridgeGroup, Integer>implements IBridgeGroupDAO{


	public BridgeGroupDAOImpl() {
		super(BridgeGroup.class);
	}
	
	@Override
	public List<BridgeGroup> getAllGroups(Integer bridgeId, Boolean getDeletedGroups,Boolean getDefaultGroup) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted", getDeletedGroups));
		criteria.add(Restrictions.ne("name", ApplicationConstants.BRIDGE_DEFAULT_GROUP_UNIVERSAL));
		criteria.addOrder(Order.asc("name"));
		List<BridgeGroup> bridgeGroups = executeCriteira(criteria);
		if(getDefaultGroup)
			bridgeGroups.add(0,getDefaultGroup(bridgeId));
		return bridgeGroups;
	}
	
	@Override
	public BridgeGroup getDefaultGroup(Integer bridgeId)throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.eq("name", ApplicationConstants.BRIDGE_DEFAULT_GROUP_UNIVERSAL));
		List<BridgeGroup> results = executeCriteira(criteria);
		return null != results && results.size() > 0 ? results.get(0) : null;
		
	}
	@Override
	public BridgeGroup getDefaultGroup(Integer bridgeId, Boolean deleted)throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted", deleted));
		criteria.add(Restrictions.eq("name", ApplicationConstants.BRIDGE_DEFAULT_GROUP_UNIVERSAL));
		List<BridgeGroup> results = executeCriteira(criteria);
		return null != results && results.size() > 0 ? results.get(0) : null;
		
	}

	@Override
	public List<Integer> getGroupIdsForBridgeId(Integer bridgeId, Boolean withDefaultGroup) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		if(null != withDefaultGroup && !withDefaultGroup){
			criteria.add(Restrictions.ne("name", ApplicationConstants.BRIDGE_DEFAULT_GROUP_UNIVERSAL));
		}
		criteria.setProjection(Projections.property("id"));
		return  executeCriteira(criteria);
	}
	
	@Override
	public List<Integer> getCourseIdsForBridgeId(Integer bridgeId, Boolean withDefaultGroup) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		if(null != withDefaultGroup && !withDefaultGroup){
			criteria.add(Restrictions.ne("name", ApplicationConstants.BRIDGE_DEFAULT_GROUP_UNIVERSAL));
		}
		criteria.setProjection(Projections.property("courseId"));
		return  executeCriteira(criteria);
	}
	
	@Override
	public List<Integer> getCourseIds(Integer bridgeId, List<String> courseIds, Boolean withDefaultGroup) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.in("courseId", courseIds));
		if(null != withDefaultGroup && !withDefaultGroup){
			criteria.add(Restrictions.ne("name", ApplicationConstants.BRIDGE_DEFAULT_GROUP_UNIVERSAL));
		}
		criteria.setProjection(Projections.property("courseId"));
		return  executeCriteira(criteria);
	}

	@Override
	public BridgeGroup getGroupByCourseId(Integer bridgeId, String courseId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("courseId", courseId));
		List<BridgeGroup> results = executeCriteira(criteria);
		return null != results && results.size() > 0 ? results.get(0) : null;
	}

	@Override
	public List<BridgeGroup> getBCGroupsForBridgeId(Integer bridgeId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.isNotNull("courseId"));
		return executeCriteira(criteria);
		
	}

	@Override
	public Integer deleteAllGroupsForBridge(Bridge bridge, AdminUser adminUser) throws BridgeException {
		Session session = getCrntSession();
		String hqlUpdate = "update BridgeGroup bg set bg.deleted = :deleted, bg.deletedBy = :deleted_by, bg.deletedDate = :deleted_date, isActive = :isActive where bg.bridge = :bridge and bg.courseId is not null";
		int updatedEntities = session.createQuery(hqlUpdate)
				.setBoolean("deleted", Boolean.TRUE)
				.setEntity("deleted_by", adminUser)
				.setDate("deleted_date", new Date())
				.setEntity("bridge", bridge)
				.setBoolean("isActive", Boolean.FALSE)
				.executeUpdate();
		return updatedEntities;

	}

	@Override
	public BridgeGroup getBridgeGroupBySourceId(Integer bridgeId, String classSourcedId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("sourceId",classSourcedId));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		List<BridgeGroup> results = executeCriteira(criteria);
		return null != results && results.size() > 0 ? results.get(0) : null;
	}

	@Override
	public List<BridgeGroup> getAllAutoAssignGroups(Integer bridgeId, Boolean getDeletedGroups, Boolean getDefaultGroup)
			throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted", getDeletedGroups));
		criteria.add(Restrictions.ne("name", ApplicationConstants.BRIDGE_DEFAULT_GROUP_UNIVERSAL));
		criteria.add(Restrictions.eq("isAutoAssignUser", Boolean.TRUE));
		criteria.add(Restrictions.eq("isHidden", Boolean.FALSE));
		criteria.addOrder(Order.asc("name"));
		List<BridgeGroup> bridgeGroups = executeCriteira(criteria);
		if(getDefaultGroup)
			bridgeGroups.add(0,getDefaultGroup(bridgeId));
		return bridgeGroups;
	}
	
	@Override
	public List<BridgeGroup> getAllAutoAssignAssetGroup(Integer bridgeId,List<Integer> userGroups, Boolean getDeletedGroups)
			throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted", getDeletedGroups));
		if(userGroups!=null && userGroups.size()>0)
			criteria.add(Restrictions.in("id", userGroups));
		criteria.add(Restrictions.ne("name", ApplicationConstants.BRIDGE_DEFAULT_GROUP_UNIVERSAL));
		criteria.add(Restrictions.eq("isAutoAssignAsset", Boolean.TRUE));
		criteria.add(Restrictions.eq("isHidden", Boolean.FALSE));
		criteria.addOrder(Order.asc("name"));
		List<BridgeGroup> bridgeGroups = executeCriteira(criteria);
		
		return bridgeGroups;
	}

	@Override
	public BridgeGroup getBridgeGroupByName(Integer bridgeId, String groupName) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("name", groupName).ignoreCase());
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		List<BridgeGroup> results = executeCriteira(criteria);
		return null != results && results.size() > 0 ? results.get(0) : null;
	}
}
