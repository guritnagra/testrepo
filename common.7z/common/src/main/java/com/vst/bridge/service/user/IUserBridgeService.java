package com.vst.bridge.service.user;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;

public interface IUserBridgeService {
	RestResponse getBridgeUserInfo(String sessionId, UriInfo uriInfo, String code)throws BridgeException, ConnectApiException;
	RestResponse getBridgeConfig(HttpServletRequest httpRequest, UriInfo uriInfo, String code, String domain)throws BridgeException;
	RestResponse checkBridgeCode(String code,final String domain)throws BridgeException;
}
