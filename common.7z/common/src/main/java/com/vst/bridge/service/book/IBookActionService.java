package com.vst.bridge.service.book;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import org.jdom2.JDOMException;

import com.vst.bridge.VstException;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;

public interface IBookActionService {
	RestResponse launchBook(SessionStatusVO sessionStatusVO, String vbid, String linkLocation, String code, HttpServletRequest httpRequest,
			UriInfo uriInfo)throws BridgeException, VstException, ConnectApiException;

	RestResponse tryBook(SessionStatusVO sessionStatusVO, String vbid, String code, HttpServletRequest httpRequest,
			UriInfo uriInfo)throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException;

	RestResponse rentBook(SessionStatusVO sessionStatusVO, String vbid, String code, HttpServletRequest httpRequest,
			UriInfo uriInfo)throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException;
	
	RestResponse fullBook(SessionStatusVO sessionStatusVO, String vbid, String code, HttpServletRequest httpRequest,
			UriInfo uriInfo)throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException;

	
	RestResponse purchaseBook(SessionStatusVO sessionStatusVO,String vbid,Integer purchaseId,String code)throws BridgeException, ParseException, IOException;

	RestResponse redeemVbid(SessionStatusVO sessionStatusVO, String vbid, Integer entitlementId, String code) throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException;

}
