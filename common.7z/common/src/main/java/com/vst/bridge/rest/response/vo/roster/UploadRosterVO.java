package com.vst.bridge.rest.response.vo.roster;

import com.vst.bridge.util.csv.CSVFileType;

public class UploadRosterVO {
	
	private Integer rosterId;
	private Integer bridgeId;
	private String fileURL;
	private CSVFileType fileType;
	
	public Integer getBridgeId() {
		return bridgeId;
	}
	public void setBridgeId(Integer bridgeId) {
		this.bridgeId = bridgeId;
	}
	public String getFileURL() {
		return fileURL;
	}
	public void setFileURL(String fileURL) {
		this.fileURL = fileURL;
	}
	public CSVFileType getFileType() {
		return fileType;
	}
	public void setFileType(CSVFileType fileType) {
		this.fileType = fileType;
	}
	public Integer getRosterId() {
		return rosterId;
	}
	public void setRosterId(Integer rosterId) {
		this.rosterId = rosterId;
	}
	

}
