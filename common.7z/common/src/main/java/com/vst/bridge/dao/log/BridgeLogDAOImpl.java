package com.vst.bridge.dao.log;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.log.BridgeLog;
import com.vst.bridge.rest.response.vo.report.BookLaunchCountVO;
import com.vst.bridge.util.constant.ApplicationAction;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeLogDAO")
public class BridgeLogDAOImpl extends GenericDAO<BridgeLog, Integer> implements IBridgeLogDAO{

	public BridgeLogDAOImpl() {
		super(BridgeLog.class);
	}

	@Override
	public Integer getTotalActivationsForBook(Integer bridgeId, String vbid) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.like("value", vbid));
		
		Criterion bookFull = Restrictions.like("action", ApplicationAction.FULL_BOOK.getCodeId());
		Criterion bookTry = Restrictions.like("action", ApplicationAction.TRY_BOOK.getCodeId());
		Criterion bookRent = Restrictions.like("action", ApplicationAction.RENT_BOOK.getCodeId());
//		Criterion bookLaunch = Restrictions.like("action", ApplicationAction.LAUNCH_BOOK.getCodeId());
		Disjunction disjunction = Restrictions.disjunction();
							disjunction.add(bookFull);
							disjunction.add(bookTry);
							disjunction.add(bookRent);
//							disjunction.add(bookLaunch);
		criteria.add(disjunction);
		
		criteria.setProjection(Projections.rowCount());
		Long count = (Long) criteria.uniqueResult();
		return count != null && count > 0 ? count.intValue() : 0;
	}

	@Override
	public Integer getTotalIntigrationForBook(Integer bridgeId, String vbid) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.like("value", vbid));
		
		Criterion cartFull = Restrictions.like("action", ApplicationAction.CART_FULL.getCodeId());
		Criterion cartRent = Restrictions.like("action", ApplicationAction.CART_RENT.getCodeId());
		Criterion launch = Restrictions.like("action", ApplicationAction.PRINT_BOOK.getCodeId());
		Disjunction disjunction = Restrictions.disjunction();
							disjunction.add(cartFull);
							disjunction.add(cartRent);
							disjunction.add(launch);
		criteria.add(disjunction);		
		criteria.setProjection(Projections.rowCount());
		Long count = (Long) criteria.uniqueResult();
		return count != null && count > 0 ? count.intValue() : 0;
	}

	@Override
	public Integer getGetCountForAction(Integer bridgeId, String action,String vbid, Date startDate, Date endDate) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		if(null != vbid){
			criteria.add(Restrictions.like("value", vbid));
		}
		if(null != startDate && endDate != null){
			criteria.add(Restrictions.between("createdDate", startDate, endDate));
		}
		criteria.add(Restrictions.like("action", action));
		criteria.setProjection(Projections.rowCount());
		Long count = (Long) criteria.uniqueResult();
		return count != null && count > 0 ? count.intValue() : 0;
	}

	@Override
	public List<Integer> getBridgeLogsForAction(Integer bridgeId, String action, Boolean distonctUsers, Date startDate, Date endDate)
			throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.like("action", action));
		if(null != startDate && endDate != null){
			criteria.add(Restrictions.between("createdDate", startDate, endDate));
		}
		if(distonctUsers){
			criteria.setProjection(Projections.projectionList()
												.add(Projections.groupProperty("user.id")));
		}else{
			criteria.setProjection(Projections.projectionList()
					.add(Projections.property("user.id")));
		}
		return executeCriteira(criteria);
	}

	@Override
	public List<String> getBridgeLogsForKeyRedeemed(Integer bridgeId, Boolean distonctUsers) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.like("action", ApplicationAction.REGISTER_KEY.getCodeId()));
		criteria.setProjection(Projections.projectionList()
				.add(Projections.property("value")));
		return executeCriteira(criteria);
	}

	@Override
	public List<BookLaunchCountVO> getBookLaunched(Integer bridgeId, Date startDate, Date endDate) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.like("action", ApplicationAction.LAUNCH_BOOK.getCodeId()));
		
		if(null != startDate && endDate != null){
			criteria.add(Restrictions.between("createdDate", startDate, endDate));
		}
		
		criteria.setProjection(Projections.projectionList()
				.add(Projections.count("value").as("count"))
				.add(Projections.groupProperty("value").as("vbid")))
				.setResultTransformer(new AliasToBeanResultTransformer(BookLaunchCountVO.class));;
				List<BookLaunchCountVO> result = executeCriteira(criteria);
		return result;
	}
}
