package com.vst.bridge.dao.admin.group.company;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.group.company.AdminGroupCompany;
import com.vst.bridge.entity.company.Company;
import com.vst.bridge.util.exception.BridgeException;

@Repository("adminGroupCompanyDAO")
public class AdminGroupCompanyDAOImpl extends GenericDAO<AdminGroupCompany, Integer> implements IAdminGroupCompanyDAO{
 
	public AdminGroupCompanyDAOImpl() {
		super(AdminGroupCompany.class);
	}

	@Override
	public List<Company> getListOfCompaniesForGroupId(Integer groupId) throws BridgeException {
		List<Company> companies =  null;
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.eq("group.id", groupId));
		List<AdminGroupCompany> results = executeCriteira(criteria);
		if(null != results && results.size() > 0){
			companies = new ArrayList<Company>();
			for(AdminGroupCompany adminGroupCompany : results){
				companies.add(adminGroupCompany.getCompany());
			}
		}
		return companies;
	}

	@Override
	public List<AdminGroupCompany> getListOfGroupCompanies() throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		List<AdminGroupCompany> results = executeCriteira(criteria);
		return results;
	}

	@Override
	public List<Company> getListOfCompaniesForGroupIds(List<Integer> groupIds) throws BridgeException {
		List<Company> companies =  null;
		if(null != groupIds && groupIds.size() > 0){
			Criteria criteria= getCriteria();
			criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
			criteria.add(Restrictions.in("group.id", groupIds));
			List<AdminGroupCompany> results = executeCriteira(criteria);
			if(null != results && results.size() > 0){
				companies = new ArrayList<Company>();
				for(AdminGroupCompany adminGroupCompany : results){
					companies.add(adminGroupCompany.getCompany());
				}
			}
		}
		return companies;
	}
}
