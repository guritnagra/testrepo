package com.vst.bridge.service.user;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.VstException;
import com.vst.bridge.entity.admin.allowance.BridgeAllowanceNotification;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.rest.input.vo.LoginInfoVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.user.AdminInfoVo;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiFieldException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;

public interface IUserAccessService {
	RestResponse login(LoginInfoVO loginInfoVO,HttpServletRequest request,HttpServletResponse httpServletResponse,UriInfo uriInfo, String code, Integer bridgeUserId)throws BridgeException, ParseException, IOException, ConnectApiException, ConnectApiHttpException, ConnectApiXmlException, ConnectApiFieldException, VstException;
	RestResponse logout(final String sessionId, String code, HttpServletRequest request,UriInfo uriInfo)throws BridgeException;
	void sendNotificationMail(Bridge bridge, List<AdminInfoVo> superAdmins,
			BridgeAllowanceNotification lastBridgeAllowanceNotification);
}
