package com.vst.bridge.util.error;

public class ResponseError implements IResponseError{
	
	private String type;
	
	private Object data;

	@Override
	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String getType() {
		return this.type;
	}

	@Override
	public Object getData() {
		return this.data;
	}

	@Override
	public void setData(Object data) {
		this.data = data;
	}
}
