package com.vst.bridge.service.book;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vst.bridge.dao.key.IKeyBatchEntitlementDAO;
import com.vst.bridge.dao.user.book.IBridgeUserBookAssignDAO;
import com.vst.bridge.dao.user.key.IBridgeUserKeyDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.books.BridgeUserBookAssign;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.BridgeUserKey;
import com.vst.bridge.entity.keys.KeyBatch;
import com.vst.bridge.entity.keys.KeyBatchEntitlement;
import com.vst.bridge.rest.response.vo.user.BookLaunchActionVO;
import com.vst.bridge.rest.response.vo.user.BookLicenseInfoVO;
import com.vst.bridge.rest.response.vo.user.UserCreditsInfoVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.connectapi.ConnectLicense;

@Service("bookLicenseService")
public class BookLicenseServiceImpl implements IBookLicenseService {

	@Autowired
	private IBridgeUserBookAssignDAO bridgeUserBookAssignDAO;

	@Autowired
	private IBridgeUserKeyDAO bridgeUserKeyDAO;

	@Autowired 
	private IKeyBatchEntitlementDAO keyBatchEntitlementDAO;
	
	@Autowired
	private BookServiceUtil bookServiceUtil;
	
	@Override
	public BookLicenseInfoVO checkTrialFunctinalityForVbid(String vbid, BridgeUser user,UserCreditsInfoVO userCreditsInfoVO) {
		BookLicenseInfoVO licensesInfoVO = new BookLicenseInfoVO();
		List<BridgeUserKey> userKeysAssigned = bridgeUserKeyDAO.getListOfKeysAssigedForUser(user.getId());
		List<Integer> keyAssignedIds = bookServiceUtil.getIds(userKeysAssigned);
		if (!bridgeUserBookAssignDAO.checkUsedTypeForAssignedIds(keyAssignedIds, vbid,
				ApplicationConstants.BOOK_KEY_USED_TYPE_TRIAL)) {
			if(userCreditsInfoVO==null)
				userCreditsInfoVO = bookServiceUtil.getUserCredits(user);
			Integer bridgeTrialCredits = userCreditsInfoVO.getTrialCredits();
			Integer trialCredits = bridgeTrialCredits;
			Integer trialCreditsUsed = userCreditsInfoVO.getTrailUsed();
			if (trialCredits != null && (trialCredits == -1 || trialCreditsUsed < trialCredits)) {
				licensesInfoVO.setUrl(
						com.vst.bridge.StringUtils.getFormatedString(ApplicationConstants.BOOK_LICENSE_TRIAL, vbid));
				licensesInfoVO.setState(ApplicationConstants.BOOK_LICENSE_STATE_CREDIT);
			}
		}
		return licensesInfoVO;
	}

	@Override
	public BookLicenseInfoVO checkFullFunctinalityForVbid(String vbid, BridgeUser user, Bridge bridge) {
		BookLicenseInfoVO licensesInfoVO = new BookLicenseInfoVO();
		List<BridgeUserKey> userKeysAssigned = bridgeUserKeyDAO.getListOfKeysAssigedForUser(user.getId());
		List<Integer> keyAssignedIds = bookServiceUtil.getIds(userKeysAssigned);
		UserCreditsInfoVO userCreditsInfoVO = bookServiceUtil.getUserCredits(user);
		Integer fullCredits = userCreditsInfoVO.getFullCredits();
		Integer fullCreditsUsed = userCreditsInfoVO.getFullUsed();
		if ((fullCredits != null && (fullCredits == -1 || fullCreditsUsed < fullCredits) && !bridgeUserBookAssignDAO
				.checkUsedTypeForAssignedIds(keyAssignedIds, vbid, ApplicationConstants.BOOK_KEY_USED_TYPE_FULL))) {
			licensesInfoVO
					.setUrl(com.vst.bridge.StringUtils.getFormatedString(ApplicationConstants.BOOK_LICENSE_FULL, vbid));
			licensesInfoVO.setState(ApplicationConstants.BOOK_LICENSE_STATE_CREDIT);
		}
		return licensesInfoVO;
	}

	@Override
	public BookLicenseInfoVO checkRentalFunctinalityForVbid(String vbid, BridgeUser user, Bridge bridge) {
		BookLicenseInfoVO licensesInfoVO = new BookLicenseInfoVO();
		UserCreditsInfoVO userCreditsInfoVO = bookServiceUtil.getUserCredits(user);
		Integer rentalCredits = userCreditsInfoVO.getRentalCredits();
		Integer retalCreditsUsed = userCreditsInfoVO.getRentalUsed();
		if ((rentalCredits != null && (rentalCredits == -1 || retalCreditsUsed < rentalCredits))) {
			licensesInfoVO.setUrl(
					com.vst.bridge.StringUtils.getFormatedString(ApplicationConstants.BOOK_LICENSE_RENTAL, vbid));
			licensesInfoVO.setState(ApplicationConstants.BOOK_LICENSE_STATE_CREDIT);
		}
		return licensesInfoVO;
	}


	@Override
	public Map<String, Object> checkVbidHasLaunchFunctionality(List<ConnectLicense> liceseList, String vbid,
			BridgeUser user) {
		Map<String, Object> result = new HashMap<String, Object>();
		boolean hasValidLicense = false;
		BookLaunchActionVO licensesInfoVO = null;
		if (null != liceseList && liceseList.size() > 0) {
			for (ConnectLicense connectLicense : liceseList) {
				// ****Code for Launch
				if (connectLicense.getSku().equals(vbid)) {
					licensesInfoVO = new BookLaunchActionVO();
					if (connectLicense.getExpired()) {
						licensesInfoVO.setState(ApplicationConstants.BOOK_LICENSE_STATE_EXPIRED);
					} else {
						licensesInfoVO = new BookLaunchActionVO();
						licensesInfoVO.setUrl(com.vst.bridge.StringUtils
								.getFormatedString(ApplicationConstants.BOOK_LICENSE_LAUNCH, vbid));
						licensesInfoVO.setState(ApplicationConstants.BOOK_LICENSE_STATE_ACTIVE);
						if (user != null) {
							List<Integer> userKeyIds = bridgeUserKeyDAO.getUserkeyAssignedIds(user.getId());
							if (null != userKeyIds && userKeyIds.size() > 0) {
								this.getLastActionForVbid(userKeyIds,vbid,licensesInfoVO);
							}
						}
						hasValidLicense = true;
					}
					licensesInfoVO.setExpires(connectLicense.getExpiration());
					// }
					break;
				}
			}
		}
		result.put(ApplicationConstants.BOOK_HAS_VALID_LICENSE, hasValidLicense);
		result.put(ApplicationConstants.BOOK_LICENSE_LAUNCH_WRAPPER, licensesInfoVO);
		return result;
	}

	private void getLastActionForVbid(List<Integer> userKeyIds, String vbid,BookLaunchActionVO bookLaunchActionVO) {
		BridgeUserBookAssign bridgeUserBookAssign = bridgeUserBookAssignDAO.getLastActionForBook(userKeyIds, vbid);
		String entitlementId=null;
		if(bridgeUserBookAssign!=null){
			String actionId=bridgeUserBookAssign.getUsedType();
			if(actionId.startsWith(ApplicationConstants.BOOK_KEY_USED_TYPE_CONCURRENT)){
				KeyBatch keyBatch= bridgeUserBookAssign.getKeyBatch();
				if(keyBatch!=null){
					entitlementId=keyBatch.getId().toString();
					if(keyBatch.getIsReturn()!=null && !keyBatch.getIsReturn()){
						bookLaunchActionVO.setAllowReturn(Boolean.FALSE);
					}
				}				
				if(entitlementId!=null){
					try{
						entitlementId=keyBatch.getConcurrencyEntitlementName();
					}
					catch(NumberFormatException e){
						entitlementId=actionId;
					}
				}
				else{
					entitlementId=ApplicationConstants.BOOK_KEY_USED_TYPE_CONCURRENT;
				}
			}
			else{
				try{
					bookLaunchActionVO.setAllowReturn(Boolean.FALSE);
					KeyBatchEntitlement keyBatchEntitlement = keyBatchEntitlementDAO.get(Integer.valueOf(actionId));
					if(keyBatchEntitlement!=null && keyBatchEntitlement.getEntName()!=null){
						entitlementId=keyBatchEntitlement.getEntName();
					}
				}
				catch(NumberFormatException e){
					entitlementId=actionId;
				}
			}
		}
		else{
			bookLaunchActionVO.setAllowReturn(Boolean.FALSE);
		}
		bookLaunchActionVO.setActiveCredit(entitlementId);
		
	}

}
