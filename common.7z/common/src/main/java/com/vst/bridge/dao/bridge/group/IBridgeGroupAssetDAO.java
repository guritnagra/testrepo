package com.vst.bridge.dao.bridge.group;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.group.GroupAsset;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeGroupAssetDAO extends IGenericDAO<GroupAsset, Integer>{

	List<GroupAsset> getAllBooksForGroup(Integer groupId)throws BridgeException;

	GroupAsset getGroupAsset(Integer groupId,String vbid)throws BridgeException;
	
	List<String> getVbidsForGroupIds(Integer bridgeId, List<Integer> groupIds) throws BridgeException;
	List<String> getVbidsForGroupIds(Integer bridgeId, List<Integer> userGroups, Boolean isDateSorted)throws BridgeException;

	
	List<IdValueVO> getGroupsForVbid(Integer bridgeId,String vbid, Boolean withDefaultGroup)throws BridgeException;

	List<GroupAsset> getAllBooksForGroupIncludeDeleted(Integer groupId) throws BridgeException;

	GroupAsset getGroupAssetIncludingDeleted(Integer groupId, String vbid) throws BridgeException;
	
}
