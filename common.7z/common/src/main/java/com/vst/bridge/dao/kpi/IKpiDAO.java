package com.vst.bridge.dao.kpi;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.kpi.KpiData;
import com.vst.bridge.util.exception.BridgeException;

public interface IKpiDAO extends IGenericDAO<KpiData, Integer>{
	KpiData getKpiData() throws BridgeException; 
}
