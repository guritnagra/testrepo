package com.vst.bridge.rest.response.vo.bridge;


public class BridgeInfoWithFavoriteVO extends BridgeInfoVO{
	private Boolean isFavorite;

	private BridgeConfigRequestVO config = new BridgeConfigRequestVO();
	
	private IntigrationVO integrations;
	
	private Integer trialsDays;
	
	private Integer rentalsDays;
	
	private Integer fullDays;
	
	private Boolean isDefered;
	
	private Boolean keysRequired;
	
	private Long trialExpires;
	private Long rentalExpires;
	private Long fullExpires;
	
	private Integer trialCredits;
	private Integer rentalCredits;
	private Integer fullCredits;
	private Integer concCredits;
	private Integer concDays;
	private Integer offlineConcDays;
	private Long concExpires;
	private Long offlineConcExpires;
	private String concCompType;
	
	private Integer offlineTrialDays;
	private Long offlineTrialExpires;
	private Integer offlineRentalDays;
	private Long offlineRentalExpires;
	private Integer offlineFullDays;
	private Long offlineFullExpires;
	
	private Integer concurrencyLimit; 
	private Boolean isConcurrencyEnabled;
	private Boolean isIntegrated;
	private Integer bcTenantId;
	private Boolean isSampler;
	private String integrationRedirectUrl;
	private Boolean isPurchasesEnabled;
	private Boolean isEmbeddedEnabled;
	
	public Boolean getIsFavorite() {
		return isFavorite;
	}

	public void setIsFavorite(Boolean isFavorite) {
		this.isFavorite = isFavorite;
	}

	public BridgeConfigRequestVO getConfig() {
		return config;
	}

	public void setConfig(BridgeConfigRequestVO config) {
		this.config = config;
	}

	public IntigrationVO getIntegrations() {
		return integrations;
	}

	public void setIntegrations(IntigrationVO integrations) {
		this.integrations = integrations;
	}

	public Integer getTrialsDays() {
		return trialsDays;
	}

	public void setTrialsDays(Integer trialsDays) {
		this.trialsDays = trialsDays;
	}

	public Integer getRentalsDays() {
		return rentalsDays;
	}

	public void setRentalsDays(Integer rentalsDays) {
		this.rentalsDays = rentalsDays;
	}

	public Integer getFullDays() {
		return fullDays;
	}

	public void setFullDays(Integer fullDays) {
		this.fullDays = fullDays;
	}

	public Boolean getIsDefered() {
		return isDefered;
	}

	public void setIsDefered(Boolean isDefered) {
		this.isDefered = isDefered;
	}

	public Boolean getKeysRequired() {
		return keysRequired;
	}

	public void setKeysRequired(Boolean keysRequired) {
		this.keysRequired = keysRequired;
	}

	public Long getTrialExpires() {
		return trialExpires;
	}

	public void setTrialExpires(Long trialExpires) {
		this.trialExpires = trialExpires;
	}

	public Long getRentalExpires() {
		return rentalExpires;
	}

	public void setRentalExpires(Long rentalExpires) {
		this.rentalExpires = rentalExpires;
	}

	public Long getFullExpires() {
		return fullExpires;
	}

	public void setFullExpires(Long fullExpires) {
		this.fullExpires = fullExpires;
	}
	public Integer getTrialCredits() {
		return trialCredits;
	}

	public void setTrialCredits(Integer trialCredits) {
		this.trialCredits = trialCredits;
	}

	public Integer getRentalCredits() {
		return rentalCredits;
	}

	public void setRentalCredits(Integer rentalCredits) {
		this.rentalCredits = rentalCredits;
	}

	public Integer getFullCredits() {
		return fullCredits;
	}

	public void setFullCredits(Integer fullCredits) {
		this.fullCredits = fullCredits;
	}

	public Integer getOfflineTrialDays() {
		return offlineTrialDays;
	}

	public void setOfflineTrialDays(Integer offlineTrialDays) {
		this.offlineTrialDays = offlineTrialDays;
	}

	public Long getOfflineTrialExpires() {
		return offlineTrialExpires;
	}

	public void setOfflineTrialExpires(Long offlineTrialExpires) {
		this.offlineTrialExpires = offlineTrialExpires;
	}

	public Integer getOfflineRentalDays() {
		return offlineRentalDays;
	}

	public void setOfflineRentalDays(Integer offlineRentalDays) {
		this.offlineRentalDays = offlineRentalDays;
	}

	public Long getOfflineRentalExpires() {
		return offlineRentalExpires;
	}

	public void setOfflineRentalExpires(Long offlineRentalExpires) {
		this.offlineRentalExpires = offlineRentalExpires;
	}

	public Integer getOfflineFullDays() {
		return offlineFullDays;
	}

	public void setOfflineFullDays(Integer offlineFullDays) {
		this.offlineFullDays = offlineFullDays;
	}

	public Long getOfflineFullExpires() {
		return offlineFullExpires;
	}

	public void setOfflineFullExpires(Long offlineFullExpires) {
		this.offlineFullExpires = offlineFullExpires;
	}

	public Integer getConcurrencyLimit() {
		return concurrencyLimit;
	}

	public void setConcurrencyLimit(Integer concurrencyLimit) {
		this.concurrencyLimit = concurrencyLimit;
	}

	public Boolean getIsConcurrencyEnabled() {
		return isConcurrencyEnabled;
	}

	public void setIsConcurrencyEnabled(Boolean isConcurrencyEnabled) {
		this.isConcurrencyEnabled = isConcurrencyEnabled;
	}

	public Integer getConcCredits() {
		return concCredits;
	}

	public void setConcCredits(Integer concCredits) {
		this.concCredits = concCredits;
	}

	public Integer getConcDays() {
		return concDays;
	}

	public void setConcDays(Integer concDays) {
		this.concDays = concDays;
	}

	public Integer getOfflineConcDays() {
		return offlineConcDays;
	}

	public void setOfflineConcDays(Integer offlineConcDays) {
		this.offlineConcDays = offlineConcDays;
	}

	public Long getConcExpires() {
		return concExpires;
	}

	public void setConcExpires(Long concExpires) {
		this.concExpires = concExpires;
	}

	public Long getOfflineConcExpires() {
		return offlineConcExpires;
	}

	public void setOfflineConcExpires(Long offlineConcExpires) {
		this.offlineConcExpires = offlineConcExpires;
	}

	public String getConcCompType() {
		return concCompType;
	}

	public void setConcCompType(String concCompType) {
		this.concCompType = concCompType;
	}

	public Boolean getIsIntegrated() {
		return isIntegrated;
	}

	public void setIsIntegrated(Boolean isIntegrated) {
		this.isIntegrated = isIntegrated;
	}

	public Integer getBcTenantId() {
		return bcTenantId;
	}

	public void setBcTenantId(Integer bcTenantId) {
		this.bcTenantId = bcTenantId;
	}

	public Boolean getIsSampler() {
		return isSampler;
	}

	public void setIsSampler(Boolean isSampler) {
		this.isSampler = isSampler;
	}

	public String getIntegrationRedirectUrl() {
		return integrationRedirectUrl;
	}

	public void setIntegrationRedirectUrl(String integrationRedirectUrl) {
		this.integrationRedirectUrl = integrationRedirectUrl;
	}

	public Boolean getIsPurchasesEnabled() {
		return isPurchasesEnabled;
	}

	public void setIsPurchasesEnabled(Boolean isPurchasesEnabled) {
		this.isPurchasesEnabled = isPurchasesEnabled;
	}

	public Boolean getIsEmbeddedEnabled() {
		return isEmbeddedEnabled;
	}

	public void setIsEmbeddedEnabled(Boolean isEmbeddedEnabled) {
		this.isEmbeddedEnabled = isEmbeddedEnabled;
	}

	
	
		
}
