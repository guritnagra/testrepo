package com.vst.bridge.util;

public enum CSVFileType {
	  BRIDGEUSER("sourcedId,status,dateLastModified,orgSourcedIds,role,username,userId,givenName,familyName,identifier,email,sms,phone,agents"),
	  BRIDGEGROUP("text2"),
	  BRIDGEGROUPUSER("text3");

	  private String fileType;

	  CSVFileType(String fileType) {
	    this.fileType = fileType;
	  }

	  public String getFileType() {
	    return this.fileType;
	  }

	  public static CSVFileType fromString(String fileType) {
	    if (fileType != null) {
	      for (CSVFileType ft : CSVFileType.values()) {
	        if (fileType.equalsIgnoreCase(ft.getFileType())) {
	          return ft;
	        }
	      }
	    }
	    return null;
	  }
	}
