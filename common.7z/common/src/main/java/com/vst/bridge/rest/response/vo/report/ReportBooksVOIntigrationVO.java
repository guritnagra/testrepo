package com.vst.bridge.rest.response.vo.report;

public class ReportBooksVOIntigrationVO extends ReportBooksVO{
	private Integer activations;
	private Integer integrations;
	public Integer getActivations() {
		return activations;
	}
	public void setActivations(Integer activations) {
		this.activations = activations;
	}
	public Integer getIntegrations() {
		return integrations;
	}
	public void setIntegrations(Integer integrations) {
		this.integrations = integrations;
	}
}
