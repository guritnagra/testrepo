package com.vst.bridge.dao.bridge.type;

import com.vst.bridge.entity.bridge.CodeTypes;
import com.vst.bridge.util.exception.BridgeException;

public interface ICodeTypesDAO {
	CodeTypes getCodeForType(final String type)throws BridgeException;

}
