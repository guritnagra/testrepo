package com.vst.bridge;

import java.beans.PropertyDescriptor;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.security.MessageDigest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.http.HttpResponse;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.Gson;
import com.owlike.genson.Genson;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;

public class JsonUtils 
{
	
	private static Gson gson = new Gson();
	
	/**
	 * Method converts a passed object into a JSON string
	 * 
	 * @param object
	 * @return {@link String}
	 * @throws ParseException 
	 */
	
	public static String getJsonString(final Object object){
		return gson.toJson(object);
	}
	
	@SuppressWarnings("unchecked")
	public static Map<String,?> parseJson(String jsonStr) throws ParseException
	{
		return (new Genson()).deserialize(jsonStr, Map.class);
		
	}
	
	public static String requestToString(HttpServletRequest hsr) throws ParseException, IOException
	{

			StringBuilder sb = new StringBuilder();
			BufferedReader br = null;
	 
			String line;
			try {
				hsr.setCharacterEncoding("UTF-8");
				
				
				if(hsr.getCharacterEncoding()!=null)
				{
					br = new BufferedReader(new InputStreamReader(hsr.getInputStream(),hsr.getCharacterEncoding()));
				}
				else
				{
					br = new BufferedReader(new InputStreamReader(hsr.getInputStream()));
				}
				while ((line = br.readLine()) != null) 
				{
					sb.append(line);
				}
	 
			}  
			finally 
			{
				try {br.close();} catch (Exception e) {e.printStackTrace();}
			}
	 
		return sb.toString();
	}
	
	public static Map<String,?> parseJson(HttpServletRequest hsr) throws ParseException, IOException
	{
		return parseJson(requestToString(hsr));
	}
	
	@SuppressWarnings("unchecked")
	private static void fixJson(Map<String,?> params)
	{
		Set<String> keys = params.keySet();
		for(String key: keys)
		{
			if(params.get(key)==null)
			{
				params.put(key, null);
			}
			else if(params.get(key) instanceof Map)
			{
				fixJson((Map<String, ?>)params.get(key));
			}
			else if(params.get(key) instanceof List)
			{
				fixJson((List<?>)params.get(key));
			}
		}
	}
	@SuppressWarnings("unchecked")
	private static void fixJson(List<?> params)
	{
		for(Object o: params)
		{
			if(o instanceof Map)
			{
				fixJson((Map<String,?>)o);
			}
			else if(o instanceof List)
			{
				fixJson((List<?>)o);
			}
		}
	}
	
	
	public static String toJson(Map<String,?> params) 
	{
		fixJson(params);
		if(params==null)
		{
			return null;
		}
		else
		{
			return JSONObject.toJSONString(params);
		}
	}
	
	public static String toJson(List<?> params) 
	{
		fixJson(params);
		if(params==null)
		{
			return null;
		}
		else
		{
			return JSONArray.toJSONString(params);
		}
	}

	public static String getRequestBody(HttpServletRequest hsr) throws Exception
	{
			StringBuilder sb = new StringBuilder();
			BufferedReader br = null;
	 
			String line;
			try 
			{
				hsr.setCharacterEncoding("UTF-8");
				
				if(hsr.getCharacterEncoding()!=null)
				{
					br = new BufferedReader(new InputStreamReader(hsr.getInputStream(),hsr.getCharacterEncoding()));
				}
				else
				{
					br = new BufferedReader(new InputStreamReader(hsr.getInputStream()));
				}
				while ((line = br.readLine()) != null) 
				{
					sb.append(line);
				}
	 
			}catch(Exception e){
				throw new Exception("Unable to read request data");
			}
			finally 
			{
				try {br.close();} catch (Exception e) {e.printStackTrace();}
			}
	 
			return sb.toString();
	}

	public static String hash(String string) throws Exception
    {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(string.getBytes());
        
        byte byteData[] = md.digest();
 
        //convert the byte to hex format method 1
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < byteData.length; i++) {
         sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
        }
 
        return sb.toString();
    }
	
	public static <T extends Comparable<? super T>> List<T> merge(List<T> a,List<T>b)
    {
		if(a == null || a.size() == 0){
			return b;
		}
		
		if(b == null || b.size() == 0){
			return a;
		}
		
		PropertyDescriptor[] descriptors = PropertyUtils.getPropertyDescriptors(a.get(0).getClass());
		String propertyName;
	    Object val;

		//Collections.sort(a);
        //Collections.sort(b);
        List<T> result = new ArrayList<T>();
        int i = 0;
        int j = 0;

        for (;;)
        {
            T a1 = a.get(i);
            T b1 = b.get(j);
            if (a1.compareTo(b1) > 0)
            {
                result.add(b1);
                j++;
                if (j == b.size())// no more
                {
                    if (i < a.size() - 1)
                        result.addAll(a.subList(i + 1, a.size()));
                    break;
                }
            } else if (a1.compareTo(b1) == 0)
            {
          	  
          	    try {
          	    		for (PropertyDescriptor descriptor : descriptors) {
          	    			propertyName = descriptor.getName();
          	    			Method method = descriptor.getWriteMethod();
          	    			if(method !=null){
          	    				val = PropertyUtils.getProperty(a1, propertyName);
              	    			if (val != null) {
              	    				PropertyUtils.setProperty(b1, propertyName, val);
              	    			}
          	    			}
          	    			
          	    		}
          	    	} catch (Exception ignore) {
          	    		// not interested in what we can't read or write
          	    		ignore.printStackTrace();
          	    	}
                //result.add(a1);
                result.add(b1);
                
                i++;
                if (i == a.size())
                {
                    if (j < b.size() - 1)
                        result.addAll(b.subList(j + 1, b.size()));
                    break;
                }
                j++;
                if (j == b.size())// no more
                {
                    if (i < a.size() - 1)
                        result.addAll(a.subList(i + 1, a.size()));
                    break;
                }
            } else
            {
                result.add(a1);
                i++;
                if (i == a.size())// no more
                {
                    if (j < b.size() - 1)
                        result.addAll(b.subList(j + 1, b.size()));
                    break;
                }
            }
        }
        return result;
    }	
	
	public static Date getYearStartDate() throws ParseException {
		Calendar c = Calendar.getInstance();
		int month = c.get(Calendar.MONTH) + 1;
		int year = c.get(Calendar.YEAR);
		if (month < 8)
			year--;
		Date date = new SimpleDateFormat("MM/dd/yyyy").parse("08/01/" + year);
		//System.out.println("Current Date : " + new Date(c.getTimeInMillis()) + " Return Date : " + date);
		return date;
	}

	public static Date getMonthStartDate() throws ParseException {
		Calendar c = Calendar.getInstance();
		int month = c.get(Calendar.MONTH) + 1;
		int year = c.get(Calendar.YEAR);
		Date date = new SimpleDateFormat("MM/dd/yyyy").parse(month + "/01/" + year);
		//System.out.println("Current Date : " + new Date(c.getTimeInMillis()) + " Return Date : " + date);
		return date;
	}
	
	public static boolean equals(String jsonStr, String jsonStr2) {
		
		JSONParser parser = new JSONParser();
		
		try {

			final JSONObject jsonObj2= ((JSONObject)parser.parse(jsonStr2));
			//final JSONObject jsonActual= ((JSONObject)parser.parse(JSONObject.escape(wsResponse)));
			final JSONObject jsonObj= ((JSONObject)parser.parse(jsonStr));
			
			return jsonObj.equals(jsonObj2); //(equals(jsonObj2, jsonObj));
		} catch (org.json.simple.parser.ParseException | ClassCastException e) {
			try {
				final JSONArray jsonObj2= ((JSONArray)parser.parse(jsonStr2));
				//final JSONObject jsonActual= ((JSONObject)parser.parse(JSONObject.escape(wsResponse)));
				final JSONArray jsonObj= ((JSONArray)parser.parse(jsonStr));
				
				return jsonObj.equals(jsonObj2); //return(equals(jsonObj2, jsonObj));
			} catch (org.json.simple.parser.ParseException e1) {
				e.printStackTrace();
			}

			return false;
		}
	}
	
	/**
	 * Method will read and return the response as String
	 * 
	 * @param httpResponse
	 * @return {@link String}
	 */
	public static String getResponseAsString(final HttpResponse httpResponse) {
		final String exceptionMsg = "Failed to read response ";
		String responseStr = "";
		try {
			final BufferedReader br = new BufferedReader(new InputStreamReader((httpResponse.getEntity().getContent())));
			String output;
			final StringWriter obj = new StringWriter();
			while ((output = br.readLine()) != null) {
				obj.append(output);
			}
			responseStr = obj.toString();
		} catch (final IllegalStateException e) {
			throw new BridgeException(exceptionMsg,ApplicationCode.INVALID_BRIDGE_ACTION);
		} catch (final IOException e) {
			throw new BridgeException(exceptionMsg,ApplicationCode.INVALID_BRIDGE_ACTION);
		}
		return responseStr;
	}
}
