package com.vst.bridge.service.book;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.books.BridgeBookVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;

public interface IBookBridgeService {
	RestResponse updateBridgesBooks(final Integer bridgeId, Boolean selectAllBooks, HttpServletRequest httpRequest)
			throws BridgeException, ParseException, IOException;

	void refreshBookCache(Integer bridgeId, final String bridgeAPIKey)
			throws BridgeException, ConnectApiException, ConnectApiXmlException, ConnectApiHttpException;

	RestResponse getBooksForBridge(SessionStatusVO sessionStatusVO, BridgePaginationVo bridgePaginationVo,
			String category, Boolean isGrouped, HttpServletRequest request, UriInfo uriInfo) throws BridgeException, ParseException,
			IOException, ConnectApiException, ConnectApiXmlException, ConnectApiHttpException;

	RestResponse getBookForVbid(final Integer bridgeId, final String vbid) throws BridgeException;

	RestResponse updateBridgesBooks(Integer bridgeId, Boolean selectAllBooks, List<BridgeBookVO> bridgeBooksVO,
			HttpServletRequest httpRequest) throws BridgeException, ParseException, IOException;
	
	RestResponse deleteAncillaryBookCache(Integer bridgeId, List<String> vbidList, String vbid,
			HttpServletRequest httpRequest, SessionStatusVO sessionStatusVO);
}
