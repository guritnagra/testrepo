package com.vst.bridge.service.user;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.JsonUtils;
import com.vst.bridge.TomcatUtils;
import com.vst.bridge.VstException;
import com.vst.bridge.VstUtils;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.allowance.IBridgeAllowanceNotificationDAO;
import com.vst.bridge.dao.key.IKeyBatchDAO;
import com.vst.bridge.dao.key.IKeyDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.dao.user.key.IBridgeUserKeyDAO;
import com.vst.bridge.dao.user.session.IBridgeUserSessionDAO;
import com.vst.bridge.entity.admin.allowance.BridgeAllowanceNotification;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.session.BridgeUserSession;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.BridgeUserKey;
import com.vst.bridge.entity.keys.KeyBatch;
import com.vst.bridge.entity.keys.Keys;
import com.vst.bridge.rest.input.vo.LoginInfoVO;
import com.vst.bridge.rest.input.vo.ReCaptchaLoginVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.user.AdminInfoVo;
import com.vst.bridge.rest.response.vo.user.BridgeUserInfoVO;
import com.vst.bridge.rest.response.vo.user.UserDetailsVO;
import com.vst.bridge.util.constant.ApplicationAction;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.date.DateUtility;
import com.vst.bridge.util.email.EmailHandlerService;
import com.vst.bridge.util.email.ExecutorUtility;
import com.vst.bridge.util.error.ErrorHandlerUtil;
import com.vst.bridge.util.error.ResponseError;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.bridge.util.message.TemplateLocationConstants;
import com.vst.bridge.util.recaptcha.ReCaptchaUtil;
import com.vst.connectapi.ApiKeys;
import com.vst.connectapi.ConnectApiWrapper;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiFieldException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;
import com.vst.connectapi.ConnectCredentials;
import com.vst.connectapi.ConnectUser;

@Service("userLoginService")
public class UserAccessServiceImpl implements IUserAccessService {

	@Autowired
	private IBridgeUserDAO bridgeUserDAO;

	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private ErrorHandlerUtil errorHandlerUtility;

	@Autowired
	private IBridgeDAO bridgeDAO;

	@Autowired
	private IBridgeUserSessionDAO bridgeUserSessionDAO;

	@Autowired
	private IBridgeUserKeyDAO bridgeUserKeyDAO;

	@Autowired
	private IKeyDAO keyDAO;

	@Autowired
	private IKeyBatchDAO keyBatchDAO;
	
	@Autowired
	private IUserEntityService userEntityService;

	@Autowired
	private UserServiceUtil userServiceUtil;

	@Autowired
	private EmailHandlerService emailHandlerService;
	
	private Executor executor = ExecutorUtility.getExecutorInstance();
	
	@Autowired
	private IAdminUserDAO adminUserDAO;

	
	@Autowired
	private ReCaptchaUtil reCaptchaUtil;
	
	private List<String> bridgeDomainPostfix;
	
	@Autowired
	private IBridgeAllowanceNotificationDAO bridgeAllowanceNotificationDAO;
	
	public UserAccessServiceImpl() {
		String postfix = TomcatUtils.getParam("bridge-domain-postfix");
		if (null != postfix) {
			bridgeDomainPostfix = new ArrayList<String>();
			String[] postfixs = postfix.split(ApplicationConstants.BRIDGE_DOMAIN_POST_FIX_SEPERATOR);
			for (String string : postfixs) {
				bridgeDomainPostfix.add(string);
			}
		}
	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse login(LoginInfoVO loginInfoVO, HttpServletRequest request,
			HttpServletResponse httpServletResponse, UriInfo uriInfo, String code, Integer bridgeUserId)
			throws BridgeException, ParseException, IOException, ConnectApiException, ConnectApiHttpException,
			ConnectApiXmlException, ConnectApiFieldException, VstException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		String sessionId = null, jsonRequest = null;

		BridgeUser bridgeUser = null;

		String email = loginInfoVO.getEmail();

		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		if (bridge.getPendingApproved()) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		//boolean isSampler = ApplicationConstants.BRIDGE_TYPE_SAMPLER.equals(bridge.getBridgeType().getType());
		boolean isSampler=bridge.getIsSampler();
		if (!isSampler) {
			if (!userServiceUtil.checkEmailExistInBookshelf(email)) {
				if (bridge.getIsRostered() && !this.checkIsFullUser(bridge, loginInfoVO)) {
					throw new BridgeException(ApplicationCode.NOT_FULL_USER);
				}
			} else {
				if (bridge.getIsRostered()) {
					bridgeUser = bridgeUserDAO.getForEmail(bridge.getId(), email);
					if (bridgeUser == null) {
						throw new BridgeException(ApplicationCode.USER_NOT_ROSTERED);
					}
				}
			}
		}

		if (null != bridge && isSampler) {
			if (bridge.getPasswordProtected()) {
				if (null != loginInfoVO && bridge.getPassword().equals(loginInfoVO.getPassword())) {
					bridgeUserId = this.samplerLoginAndNewUser(uriInfo, code, loginInfoVO);
				} else {	
					throw new BridgeException(ApplicationCode.USER_AUTHENTICATION_FAILED);
				}
			} else {
				bridgeUserId = this.samplerLoginAndNewUser(uriInfo, code, loginInfoVO);
			}
		}

		if (null != bridgeUserId && bridgeUserId > 0) {
			sessionId = VstUtils.createSessionid(null);
			bridgeUser = bridgeUserDAO.get(bridgeUserId);
			if (isSampler) {
				Keys keys = new Keys();
				List<String> codes = VstUtils.getKeyCodeValues(1);
				keys.setKeyCode(codes.get(0));
				keys.setTrialCredits(-1);
				keys.setExpireDate(DateUtility.getNextDayEndOfDay());
				keyDAO.create(keys);
				BridgeUserKey bridgeUserKey = new BridgeUserKey();
				bridgeUserKey.setActivationDate(new Date());
				bridgeUserKey.setKey(keys);
				bridgeUserKey.setUser(bridgeUser);
				bridgeUserKeyDAO.saveOrUpdate(bridgeUserKey);
				userServiceUtil.createBridgeLog(bridgeUser.getId(), bridge, ApplicationAction.REGISTER_KEY,
						keys.getKeyCode());
			}
		} else {
			jsonRequest = JsonUtils.getJsonString(loginInfoVO);
			ResponseError responseError = null;
			if(loginInfoVO instanceof ReCaptchaLoginVO){
				responseError = isSampler ? null
						: errorHandlerUtility.validateCaptchaLoginInputParameters(jsonRequest);
			}else{
				responseError = isSampler ? null
						: errorHandlerUtility.validateAdminLoginInputParameters(jsonRequest);
			}
			
			if (null == responseError) {
				sessionId = VstUtils.createSessionid(null);
				try{
					bridgeUser = this.authoticateAndLoginUser(code, loginInfoVO);
				}catch(ConnectApiException | BridgeException e){
					reCaptchaUtil.setPasswordFailure(loginInfoVO, request);
					throw e;
				}
			} else {
				reCaptchaUtil.setPasswordFailure(loginInfoVO, request);
				response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
				response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
				response.setError(responseError);
				return response;
			}
		}

		if (sessionId != null) {
			List<BridgeUserKey> userKeys = bridgeUserKeyDAO.getListOfKeysAssigedForUser(bridgeUser.getId());

			if (!isSampler && (bridge.getDerefedSignIn() || bridge.getIsRostered()) && userKeys.isEmpty()) {
				KeyBatch keyBatch = keyBatchDAO.getKeyBatchForAutoRedeem(bridge.getId());
				Keys key = new Keys();
				if (null == keyBatch) {
					List<BridgeAllowanceNotification> bridgeAllowanceNotificationList = bridgeAllowanceNotificationDAO.getLastBridgeAllowanceNotifications(bridge.getId());
					if(bridgeAllowanceNotificationList == null || bridgeAllowanceNotificationList.isEmpty()){
						emailHandlerService.sendBridgeAllowanceNotificationEmail(bridge, adminUserDAO.getSuperAdmins(),null);
						
					}else{
						for(BridgeAllowanceNotification lastBridgeAllowanceNotification : bridgeAllowanceNotificationList){
							Date lastNotificationDate = lastBridgeAllowanceNotification.getLastNotification();
							Date currentTime = new Date();
							if(((currentTime.getTime()-lastNotificationDate.getTime())/1000)>=43200){
								emailHandlerService.sendBridgeAllowanceNotificationEmail(bridge, adminUserDAO.getSuperAdmins(),lastBridgeAllowanceNotification);
								break;
							}
						}
					}
					
					throw new BridgeException(ApplicationCode.KEY_BATCH_NOT_FOUND);
				}
				Integer fullCredits = null != bridge.getFullCredits() ? bridge.getFullCredits() : 0;
				keyBatch.setFullCredits(fullCredits);
				Integer rentalCredits = null != bridge.getRentalCredits() ? bridge.getRentalCredits() : 0;
				keyBatch.setRentalCredits(rentalCredits);
				Integer trialCredits = null != bridge.getTrialCredits() ? bridge.getTrialCredits() : 0;
				Integer concurrentCredits = null != bridge.getConcurrencyCredits() ? bridge.getConcurrencyCredits() : 0;

				/*if (fullCredits == 0 && rentalCredits == 0 && trialCredits == 0 && concurrentCredits == 0) {
					keyBatch.setTrialCredits(-1);
				} else {
					keyBatch.setTrialCredits(trialCredits);
					keyBatch.setRentalCredits(rentalCredits);
					keyBatch.setFullCredits(fullCredits);
					keyBatch.setConcurrencyCredits(concurrentCredits);
				}*/
				key.setKeyBatch(keyBatch);
				List<String> codes = VstUtils.getKeyCodeValues(1);
				key.setKeyCode("A" + codes.get(0));
				key.setExpireDate(keyBatch.getExpireDate());
				key.setFullCredits(keyBatch.getFullCredits());
				key.setTrialCredits(keyBatch.getTrialCredits());
				key.setRentalCredits(keyBatch.getRentalCredits());
				key.setConcurrencyCredits(keyBatch.getConcurrencyCredits());
				List<Keys> keys = new ArrayList<Keys>();
				keys.add(key);
				keyBatch.setKeys(keys);
				keyDAO.create(key);
				keyBatchDAO.saveOrUpdate(keyBatch);
				BridgeUserKey bridgeUserKey = new BridgeUserKey();
				bridgeUserKey.setDeleted(Boolean.FALSE);
				bridgeUserKey.setActivationDate(new Date());
				bridgeUserKey.setKey(key);
				bridgeUserKey.setUser(bridgeUser);
				bridgeUserKeyDAO.saveOrUpdate(bridgeUserKey);
				userServiceUtil.createBridgeLog(bridgeUser.getId(), bridge, ApplicationAction.REGISTER_KEY,
						key.getKeyCode());
			}

			BridgeUserSession session = new BridgeUserSession();
			session.setSessionId(sessionId);
			session.setUser(bridgeUser);
			bridgeUserSessionDAO.create(session);
			BridgeUserInfoVO userInfoVO = userServiceUtil.populateBridgeUserInfoFromBridgeUser(bridgeUser);
			response.setData(userInfoVO);
			userServiceUtil.createBridgeLog(bridgeUser.getId(), bridgeDAO.getBridgeForCode(code),
					ApplicationAction.LOGIN, sessionId);
		}

		Cookie cookie = new Cookie(ApplicationConstants.BRIDGE_SESSIONID, sessionId);
		cookie.setMaxAge(NewCookie.DEFAULT_MAX_AGE);
		cookie.setSecure(ApplicationConstants.COOKIE_SECURE);
		cookie.setPath("/");
		httpServletResponse.addCookie(cookie);

		return response;
	}

	private Boolean checkIsFullUser(Bridge bridge, LoginInfoVO loginInfoVO) {
		Boolean isFulluser = Boolean.FALSE;

		BridgeUser bridgeUser = bridgeUserDAO.getForEmail(bridge.getId(), loginInfoVO.getEmail());
		if (null != bridgeUser) {
			if (StringUtils.isNotBlank(bridgeUser.getAccessToken()) && StringUtils.isNotBlank(bridgeUser.getGuid())) {
				isFulluser = Boolean.TRUE;
			}
		}
		return isFulluser;
	}

	private String createDummyMailId(String code) {
		StringBuffer sb = new StringBuffer(code);
		sb.append(new SimpleDateFormat("yyyyMMddhhmm").format(new Date()));
		sb.append(Math.round(Math.random() * 1000));
		sb.append(ApplicationConstants.DUMMY_EMAIL_SUFFIX);

		return sb.toString();
	}

	private Integer samplerLoginAndNewUser(UriInfo uriInfo, String code, LoginInfoVO samplerLoginInfoVO)
			throws BridgeException, ParseException, IOException, ConnectApiException, ConnectApiHttpException,
			ConnectApiXmlException, ConnectApiFieldException {
		String dummyMailId = createDummyMailId(code);
		String dummyName = dummyMailId.substring(0, dummyMailId.indexOf(ApplicationConstants.DUMMY_EMAIL_SUFFIX));
		samplerLoginInfoVO.setEmail(dummyMailId);

		UserDetailsVO newDummyUser = new UserDetailsVO();
		newDummyUser.setEmail(dummyMailId);

		newDummyUser.setFirstName(dummyName);
		newDummyUser.setLastName(dummyName);

		RestResponse response = userEntityService.createOrUpdateUser(null, null, null, uriInfo, code, Boolean.TRUE, newDummyUser,
				Boolean.TRUE);

		BridgeUserInfoVO userInfoVO = (BridgeUserInfoVO) response.getData();

		return userInfoVO.getId();

	}

	private BridgeUser authoticateAndLoginUser(String code, final LoginInfoVO loginInfoVO)
			throws ParseException, IOException, ConnectApiException, ConnectApiHttpException {
		BridgeUser bridgeUser = null;

		final String email = loginInfoVO.getEmail();
		final String password = loginInfoVO.getPassword();
		if (StringUtils.isNotBlank(email) && StringUtils.isNotBlank(password) && StringUtils.isNotBlank(code)) {

			Bridge bridge = bridgeDAO.getBridgeForCode(code);
			if (null != bridge) {

				BridgeUser bridgeUser2 = bridgeUserDAO.getForEmail(bridge.getId(), email);
				if(bridge.getKeysRequired()|| bridge.getDerefedSignIn()){
					if(bridgeUser2!=null){
					bridgeUser2.setDeletedBy(null);
					bridgeUser2.setDeleted(null);
					bridgeUserDAO.saveOrUpdate(bridgeUser2);
					}
				}

				if ((bridge.getIsIntegrated() || bridge.getIsRostered()) && bridgeUser2 == null) {
					throw new BridgeException(ApplicationCode.USER_NOT_FOUND);
				}
				if (null != bridgeUser2 && bridgeUser2.getDeleted() != null) {
					throw new BridgeException(ApplicationCode.USER_DELTED_BY_ADMIN);
				}
				ApiKeys key = new ApiKeys(ApplicationConstants.getApiMode(), bridge.getApiKey(), "unused:lti_key",
						"unused:lti_secret");
				ConnectCredentials credentials = ConnectApiWrapper.verifyCredentials(key, email, password);
				if (null != credentials) {
					String guid = credentials.getGuid();
					String accessTocken = credentials.getAccessToken();
					ConnectUser connectUser = ConnectApiWrapper.getUser(key, guid, accessTocken, Boolean.TRUE);
					if (null != connectUser) {
						bridgeUser = bridgeUserDAO.checkUserAllreadyExist(bridge.getId(), guid);
						if (!VstUtils.isValidPassword(password)) {
							
							throw new BridgeException(ApplicationCode.PASSWORD_NOT_VALID);
						}
						int questionId = connectUser.getQuestionId();
						if (Integer.valueOf(questionId).toString()
								.matches(ApplicationConstants.OLD_SECURITY_QUESTION_REGEX)) {
							throw new BridgeException(ApplicationCode.OLD_SECURITY_QUESTION);
						}
						if (bridgeUser != null || (bridgeUser2 != null && bridgeUser2.getDeleted() == null)) {
							bridgeUser = bridgeUser != null ? bridgeUser : bridgeUser2;
							userServiceUtil.populateBridgeUserDetailsFromConnectUser(bridgeUser, bridge, connectUser,
									credentials);
							bridgeUserDAO.saveOrUpdate(bridgeUser);
						} else {
							bridgeUser = new BridgeUser();
							userServiceUtil.populateBridgeUserDetailsFromConnectUser(bridgeUser, bridge, connectUser,
									credentials);
							bridgeUserDAO.create(bridgeUser);
						}
					}
				}
			} else {
				throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
			}
		}
		return bridgeUser;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse logout(String sessionId, String code, HttpServletRequest request, UriInfo uriInfo)
			throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if (null != sessionId && !StringUtils.isEmpty(sessionId)) {
			BridgeUserSession session = bridgeUserSessionDAO.getForSessionId(sessionId, Boolean.FALSE, null);
			if (null != session) {
				session.setDeleted(Boolean.TRUE);
				bridgeUserSessionDAO.update(session);
			}
			userServiceUtil.createBridgeLog(session.getUser().getId(), bridgeDAO.getBridgeForCode(code),
					ApplicationAction.LOGOUT, sessionId);
		}
		return response;
	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void sendNotificationMail(Bridge bridge,List<AdminInfoVo> superAdmins, BridgeAllowanceNotification lastBridgeAllowanceNotification){
		Map<String, Object> paramMap = new HashMap<String, Object>();
		
		paramMap.put(ApplicationConstants.NEW_BRIDGE_TO, bridge.getEmail());
		paramMap.put(ApplicationConstants.NEW_BRIDGE_TO_NAME, bridge.getContactName());
		paramMap.put(ApplicationConstants.NEW_BRIDGE_NAME, bridge.getName());
		paramMap.put(ApplicationConstants.NEW_BRIDGE_CONTACT_MAIL, bridge.getEmail());
		paramMap.put(ApplicationConstants.NEW_BRIDGE_CONTACT_PHONE, bridge.getContactNo());
		paramMap.put(ApplicationConstants.NEW_BRIDGE_DOMAIN, bridge.getCode() + bridgeDomainPostfix.get(0));
		emailHandlerService.sendEmail(TemplateLocationConstants.BRIDGE_ALLOWANCE_NOTIFICATION_TEMPLATE, paramMap);
		//System.out.println("Email sent to bridge contact...!!!");
		paramMap.clear();
		if (null != superAdmins && superAdmins.size() > 0) {
			for (AdminInfoVo adminInfo : superAdmins) {
				paramMap.put(ApplicationConstants.NEW_BRIDGE_TO, adminInfo.getEmail());
				paramMap.put(ApplicationConstants.NEW_BRIDGE_TO_NAME, adminInfo.getName());
				paramMap.put(ApplicationConstants.NEW_BRIDGE_NAME, bridge.getName());
				paramMap.put(ApplicationConstants.NEW_BRIDGE_CONTACT_MAIL, bridge.getEmail());
				paramMap.put(ApplicationConstants.NEW_BRIDGE_CONTACT_PHONE, bridge.getContactNo());
				paramMap.put(ApplicationConstants.NEW_BRIDGE_DOMAIN, bridge.getCode() + bridgeDomainPostfix.get(0));
				emailHandlerService.sendEmail(TemplateLocationConstants.BRIDGE_ALLOWANCE_NOTIFICATION_TEMPLATE, paramMap);
				//System.out.println("Email sent to super admin " + adminInfo.getEmail() );
			}
		}

		if(lastBridgeAllowanceNotification!=null){
			lastBridgeAllowanceNotification.setDeleted(Boolean.TRUE);
			bridgeAllowanceNotificationDAO.saveOrUpdate(lastBridgeAllowanceNotification);
		}
		BridgeAllowanceNotification newBridgeAllowanceNotification = new BridgeAllowanceNotification();
		newBridgeAllowanceNotification.setBridge(bridge);
		bridgeAllowanceNotificationDAO.saveOrUpdate(newBridgeAllowanceNotification);
	}
}


