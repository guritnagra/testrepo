package com.vst.bridge.rest.response.vo.user;

public class UserEmailVO {
	
	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
