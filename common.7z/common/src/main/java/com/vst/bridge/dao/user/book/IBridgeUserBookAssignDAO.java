package com.vst.bridge.dao.user.book;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.books.BridgeUserBookAssign;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeUserBookAssignDAO extends IGenericDAO<BridgeUserBookAssign, Integer>{

	Integer getCountForUsedType(List<Integer> ids,final String type)throws BridgeException;
	
	Boolean checkUsedTypeForAssignedIds(List<Integer> ids,final String vbid,final String type)throws BridgeException;
	
	Integer getUsedCountForUsedType(final Integer keyAssignedId,final String type)throws BridgeException;
	
	BridgeUserBookAssign getLastActionForBook(List<Integer> keyIds,String vbid)throws BridgeException;

	Integer getInUseBookCountForConcurrency(List<Integer> keyIds, String vbid, Integer keyBatchId) throws BridgeException;

	BridgeUserBookAssign getAssignedBookToUser(Integer id, String vbid, String usedType) throws BridgeException;

	Integer getCountForUsedEntitlementType(List<Integer> ids, Integer entitlementId, Boolean isReusableCredit) throws BridgeException;
	
	Integer getConcurrencyCountForUsedEntitlementType(List<Integer> ids,final Integer entitlementId) throws BridgeException;

	
}
