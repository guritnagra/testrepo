package com.vst.bridge.dao.bc;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bc.ContextToken;
import com.vst.bridge.util.exception.BridgeException;


public interface IContextTokenDAO extends IGenericDAO<ContextToken, Integer>{
	
	ContextToken getByContextToken(final String contextToken)throws BridgeException;

}
