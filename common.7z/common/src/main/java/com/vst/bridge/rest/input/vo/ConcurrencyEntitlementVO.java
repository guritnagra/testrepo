package com.vst.bridge.rest.input.vo;

public class ConcurrencyEntitlementVO extends BaseEntitlementVO {
	private Boolean isReturn=Boolean.TRUE;

	public Boolean getIsReturn() {
		return isReturn;
	}

	public void setIsReturn(Boolean isReturn) {
		this.isReturn = isReturn;
	}
	
	
}
