package com.vst.bridge.service.ancillary;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.ancillary.AncillaryAdminVO;
import com.vst.bridge.rest.response.vo.ancillary.AncillaryVO;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.util.constant.UploadType;

public interface IAncillaryServices {

	RestResponse getAncillaryUploadToken(SessionStatusVO sessionStatusVO, Integer bridgeId, UploadType uploadType,
			HttpServletRequest httpRequest, UriInfo uriInfo)
			throws JsonParseException, JsonMappingException, IOException;

	RestResponse getAllAncillaries(SessionStatusVO sessionStatusVO, Integer bridgeId, PaginationVO paginationVO,
			HttpServletRequest httpRequest);

	RestResponse getAncillaryStatus(SessionStatusVO sessionStatusVO, Integer bridgeId, Integer id,
			HttpServletRequest httpRequest) throws JsonParseException, JsonMappingException, IOException;

	RestResponse getAncillary(SessionStatusVO sessionStatusVO, Integer bridgeId, Integer id,
			HttpServletRequest httpRequest);

	RestResponse createAncillary(Integer bridgeId, AncillaryVO ancillaryVO,
			HttpServletRequest httpRequest);

	RestResponse updateAncillary(Integer bridgeId, AncillaryAdminVO ancillaryVO, Integer ancillaryId,
			SessionStatusVO sessionStatusVO, HttpServletRequest httpRequest);

	RestResponse updateAncillary(Integer bridgeId, List<AncillaryAdminVO> ancillaryVOList,
			SessionStatusVO sessionStatusVO, HttpServletRequest httpRequest);

	RestResponse dowloadAncillary(String vbid, HttpServletRequest httpRequest, String code, SessionStatusVO sessionStatusVO)
			throws JsonParseException, JsonMappingException, IOException;

	RestResponse deleteAncillary(Integer bridgeId, List<AncillaryAdminVO> ancillaryAdminVOList,
			HttpServletRequest httpRequest);

	RestResponse deleteAncillary(Integer bridgeId, AncillaryAdminVO ancillaryAdminVO, Integer id, HttpServletRequest httpRequest);


}
