package com.vst.bridge.rest.input.vo;

public class TokenRequestVO {
	private String uploadType;
	private Integer uploadCount;
	public String getUploadType() {
		return uploadType;
	}
	public void setUploadType(String uploadType) {
		this.uploadType = uploadType;
	}
	public Integer getUploadCount() {
		return uploadCount;
	}
	public void setUploadCount(Integer uploadCount) {
		this.uploadCount = uploadCount;
	}
	
	
}
