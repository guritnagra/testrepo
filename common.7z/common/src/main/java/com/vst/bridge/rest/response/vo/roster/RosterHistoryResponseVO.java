package com.vst.bridge.rest.response.vo.roster;

import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.vst.bridge.annotation.custom.CustomDateSerializer;

public class RosterHistoryResponseVO {
	private Integer rosterId;
	private String fileName;
	private Date uploadedDate;
	private long uploadedTime;
	private String uploadedBy;
	private String status;
	//private String downloadURL;
	
	public Integer getRosterId() {
		return rosterId;
	}
	public void setRosterId(Integer rosterId) {
		this.rosterId = rosterId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getUploadedDate() {
		return uploadedDate;
	}
	public void setUploadedDate(Date uploadedDate) {
		this.uploadedDate = uploadedDate;
	}
	public String getUploadedBy() {
		return uploadedBy;
	}
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	/*public String getDownloadURL() {
		return downloadURL;
	}
	public void setDownloadURL(String downloadURL) {
		this.downloadURL = downloadURL;
	}*/
	public long getUploadedTime() {
		return uploadedTime;
	}
	public void setUploadedTime(long uploadedTime) {
		this.uploadedTime = uploadedTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
}
