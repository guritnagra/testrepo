package com.vst.bridge.dao.question;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Projections;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.question.SecurityQuestion;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.util.exception.BridgeException;

@Repository("securityQuestionDAO")
public class SecurityQuestionDAOImpl extends GenericDAO<SecurityQuestion, Integer> implements ISecurityQuestionDAO{

	public SecurityQuestionDAOImpl() {
		super(SecurityQuestion.class);
	}

	@Override
	public List<IdValueVO> getListOfQuestions() throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.setProjection(Projections.projectionList()
				.add( Projections.property("id").as("id"))
				.add( Projections.property("text").as("value")))
				.setResultTransformer(new AliasToBeanResultTransformer(IdValueVO.class));
		return executeCriteira(criteria);
	}
}
