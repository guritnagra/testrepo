package com.vst.bridge.rest.response.vo.group.book;

import java.util.List;

public class BookPurchaseVO {
	
	private List<BridgePurchaseVO> bridgePurchase;
	
	
	private URLVo rent;
	private URLVo print;
	private URLVo full;
	public URLVo getRent() {
		return rent;
	}
	public void setRent(URLVo rent) {
		this.rent = rent;
	}
	public URLVo getPrint() {
		return print;
	}
	public void setPrint(URLVo print) {
		this.print = print;
	}
	public URLVo getFull() {
		return full;
	}
	public void setFull(URLVo full) {
		this.full = full;
	}
}
