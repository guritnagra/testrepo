package com.vst.bridge.dao.admin.ancillary;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.ancillary.AncillaryApiToken;

public interface IAncillaryApiTokenDAO extends IGenericDAO<AncillaryApiToken, Integer>{

}
