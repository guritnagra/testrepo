package com.vst.bridge.rest.response.vo.user;

import java.util.List;

import com.vst.bridge.rest.response.vo.group.BridgeGroupNameVO;

public class UserBooksWithGroupsVO {
	
	List<UserBooksVO> books;
	List<BridgeGroupNameVO> groups;
	
	public List<UserBooksVO> getBooks() {
		return books;
	}
	public void setBooks(List<UserBooksVO> books) {
		this.books = books;
	}
	public List<BridgeGroupNameVO> getGroups() {
		return groups;
	}
	public void setGroups(List<BridgeGroupNameVO> groups) {
		this.groups = groups;
	}
	

}
