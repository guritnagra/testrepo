package com.vst.bridge.service.admin;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.rest.input.vo.KeyBatchesVO;
import com.vst.bridge.rest.input.vo.KeyGenerateRequestVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminUserKeyService {
	RestResponse getKeyBatchesForBridgeId(SessionStatusVO sessionStatusVO, Integer id,
			HttpServletRequest httpRequest, UriInfo uriInfo)throws BridgeException;
	void getKeyBatchFile(SessionStatusVO sessionStatusVO, Object param, HttpServletRequest httpRequest,HttpServletResponse httpServletResponse,
			UriInfo uriInfo);
	RestResponse deleteUserKeyCode(SessionStatusVO sessionStatusVO, Object param, HttpServletRequest httpRequest,
			UriInfo uriInfo)throws BridgeException;
	RestResponse createOrUpdateKeyBatchesForBridgeId(SessionStatusVO sessionStatusVO, KeyBatchesVO keyBatchesVO,
			Integer bridgeId, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException;
	RestResponse generateKeysForBridgeId(SessionStatusVO sessionStatusVO, KeyGenerateRequestVO keyGenerateRequestVO,
			Integer bridgeId, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException, IOException;
	RestResponse updateGeneratedKeysForBridgeId(SessionStatusVO sessionStatusVO, KeyGenerateRequestVO keyGenerateRequestVO,
			Object params, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException, IOException;
	RestResponse getEntitlementForKeybatch(SessionStatusVO sessionStatusVO, Integer bridgeId,
			Integer keyBatchId, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException, IOException;
}
