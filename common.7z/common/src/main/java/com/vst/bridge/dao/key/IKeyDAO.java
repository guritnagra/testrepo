package com.vst.bridge.dao.key;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.keys.Keys;
import com.vst.bridge.util.exception.BridgeException;

public interface IKeyDAO extends IGenericDAO<Keys, Integer>{
	
	Keys getKeyForCode(final String code)throws BridgeException;
	
	Keys getKeyForCode(final String code, Integer bridgeId)throws BridgeException;
	
	List<Keys> getKeysForKeyBatches(List<Integer> keyBatcheIds, Integer startIndex,Integer totalRecordsToFetch,String search)throws BridgeException;

	List<Integer> getKeysForType(Integer bridgeId,String bridgeUserRoleTeacher,List<String> keyCodes)throws BridgeException;

	Integer getTotalRecordsCount(List<Integer> keyBatchIds, String search)throws BridgeException;

	List<Integer> getKeyIdsForBridge(Integer bridgeId) throws BridgeException;
}
