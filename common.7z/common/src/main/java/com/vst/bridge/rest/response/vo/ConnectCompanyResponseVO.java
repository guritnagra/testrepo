package com.vst.bridge.rest.response.vo;

public class ConnectCompanyResponseVO {
	
	private Integer companyId;
	private String name;
	private String apiKey;
	
	public ConnectCompanyResponseVO(){
		
	}
	public ConnectCompanyResponseVO(ConnectCompanyVO companyVO){
		this.companyId=companyVO.getId();
		this.name=companyVO.getName();
	}
	public Integer getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	
	

}
