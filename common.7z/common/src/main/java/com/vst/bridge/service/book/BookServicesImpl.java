package com.vst.bridge.service.book;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import org.jdom2.JDOMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;
import com.vst.bridge.VstException;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.rest.input.vo.BookConcurrencyLimitVO;
import com.vst.bridge.rest.response.vo.RedeemBookVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.books.BridgeBookVO;
import com.vst.bridge.rest.response.vo.bridge.BridgeBooksVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.rest.response.vo.user.BookLicenseInfoVO;
import com.vst.bridge.rest.response.vo.user.ConcurrentBookLicenseInfoVO;
import com.vst.bridge.rest.response.vo.user.UserCreditsInfoVO;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ConnectLicense;

@Service("bookServices")
public class BookServicesImpl implements IBookServices {

	@Autowired
	private IBookActionService bookActionService;
	@Autowired
	private IBookAncillaryService bookAncillaryService;
	@Autowired
	private IBookBridgeService bookBridgeService;
	@Autowired
	private IBookConcurrencyService bookConcurrencyService;
	@Autowired
	private IBookEntitlementService bookEntitlementService;
	@Autowired
	private IBookLicenseService bookLicenseService;
	@Autowired
	private IBookPrintService bookPrintService;

	@Override
	public RestResponse updateBridgesBooks(Integer bridgeId, Boolean selectAllBooks, HttpServletRequest httpRequest)
			throws BridgeException, ParseException, IOException {
		return bookBridgeService.updateBridgesBooks(bridgeId, selectAllBooks, httpRequest);

	}

	@Override
	public void refreshBookCache(Integer bridgeId, String bridgeAPIKey)
			throws BridgeException, ConnectApiException, ConnectApiXmlException, ConnectApiHttpException {
		bookBridgeService.refreshBookCache(bridgeId, bridgeAPIKey);
	}

	@Override
	public RestResponse getBooksForBridge(SessionStatusVO sessionStatusVO, BridgePaginationVo bridgePaginationVo, String category,
			Boolean isGrouped, HttpServletRequest request, UriInfo uriInfo) throws BridgeException, ParseException,
			IOException, ConnectApiException, ConnectApiXmlException, ConnectApiHttpException {
		return bookBridgeService.getBooksForBridge(sessionStatusVO, bridgePaginationVo, category, isGrouped, request, uriInfo);
	}

	@Override
	public RestResponse getBookForVbid(Integer bridgeId, String vbid) throws BridgeException {
		return bookBridgeService.getBookForVbid(bridgeId, vbid);
	}

	@Override
	public RestResponse updateBridgesBooks(Integer bridgeId, Boolean selectAllBooks, List<BridgeBookVO> bridgeBooksVO,
			HttpServletRequest httpRequest) throws BridgeException, ParseException, IOException {
		return bookBridgeService.updateBridgesBooks(bridgeId, selectAllBooks, bridgeBooksVO, httpRequest);
	}

	@Override
	public RestResponse updateBridgeBookAncillaryTitle(Integer bridgeId, BridgeBooksVO bridgeBooksVO, String vbid,
			HttpServletRequest httpRequest) throws BridgeException {
		return bookAncillaryService.updateBridgeBookAncillaryTitle(bridgeId, bridgeBooksVO, vbid, httpRequest);
	}

	@Override
	public RestResponse updateConcurrencyForBooks(SessionStatusVO sessionStatusVO, Integer bridgeId,
			BookConcurrencyLimitVO bookConcurrencyLimitVO, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException {
		return bookConcurrencyService.updateConcurrencyForBooks(sessionStatusVO, bridgeId, bookConcurrencyLimitVO, httpRequest, uriInfo);
	}

	@Override
	public RestResponse concurrentBook(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException {
		return bookConcurrencyService.concurrentBook(sessionStatusVO, vbid, code, httpRequest, uriInfo);
	}

	@Override
	public ConcurrentBookLicenseInfoVO checkConcurrentFunctinalityForVbid(String vbid, BridgeUser user, Bridge bridge) {
		return bookConcurrencyService.checkConcurrentFunctinalityForVbid(vbid, user, bridge);
	}

	@Override
	public Integer getconcurrencyLimitForVbid(String vbid, Bridge bridge) {
		return bookConcurrencyService.getconcurrencyLimitForVbid(vbid, bridge);
	}

	@Override
	public RestResponse returnBook(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, VstException, ConnectApiException, ParseException {
		return bookConcurrencyService.returnBook(sessionStatusVO, vbid, code, httpRequest, uriInfo);
	}

	@Override
	public RestResponse redeemConcurrencyVbid(SessionStatusVO sessionStatusVO, String vbid, Integer entitlementId,
			String code)
			throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException {
		return bookConcurrencyService.redeemConcurrencyVbid(sessionStatusVO, vbid, entitlementId, code);
	}

	@Override
	public BookLicenseInfoVO checkEntitlementFunctionalityForVbidById(String vbid, BridgeUser user, Bridge bridge,
			Integer entitlementId, String state) throws BridgeException {
		return bookEntitlementService.checkEntitlementFunctionalityForVbidById(vbid, user, bridge, entitlementId, state);
	}

	@Override
	public List<ConcurrentBookLicenseInfoVO> checkConcurrentEntitlementFunctinalityForVbid(String vbid, BridgeUser user,
			Bridge bridge, String state, UserCreditsInfoVO userCreditsInfoVO) throws BridgeException {
		return bookEntitlementService.checkConcurrentEntitlementFunctinalityForVbid(vbid, user, bridge, state, userCreditsInfoVO);
	}

	@Override
	public List<BookLicenseInfoVO> checkEntitlementFunctionalityForVbid(String vbid, BridgeUser user, Bridge bridge,
			String state, UserCreditsInfoVO userCreditsInfoVO) throws BridgeException {
		return bookEntitlementService.checkEntitlementFunctionalityForVbid(vbid, user, bridge, state, userCreditsInfoVO);
	}

	@Override
	public <T> RedeemBookVO populateRedeemBookVOFromKeyBatchEntitlement(T t) {
		return bookEntitlementService.populateRedeemBookVOFromKeyBatchEntitlement(t);
	}

	@Override
	public BookLicenseInfoVO checkTrialFunctinalityForVbid(String vbid, BridgeUser user,
			UserCreditsInfoVO userCreditsInfoVO) throws BridgeException {
		return bookLicenseService.checkTrialFunctinalityForVbid(vbid, user, userCreditsInfoVO);
	}

	@Override
	public BookLicenseInfoVO checkRentalFunctinalityForVbid(String vbid, BridgeUser user, Bridge bridge)
			throws BridgeException {
		return bookLicenseService.checkRentalFunctinalityForVbid(vbid, user, bridge);
	}

	@Override
	public BookLicenseInfoVO checkFullFunctinalityForVbid(String vbid, BridgeUser user, Bridge bridge)
			throws BridgeException {
		return bookLicenseService.checkFullFunctinalityForVbid(vbid, user, bridge);
	}

	@Override
	public Map<String, Object> checkVbidHasLaunchFunctionality(List<ConnectLicense> liceseList, String vbid,
			BridgeUser user) throws BridgeException {
		return bookLicenseService.checkVbidHasLaunchFunctionality(liceseList, vbid, user);
	}

	@Override
	public BookLicenseInfoVO checkPrintFunctinalityForVbid(String vbid, BridgeUser user, Bridge bridge)
			throws BridgeException {
		return bookPrintService.checkPrintFunctinalityForVbid(vbid, user, bridge);
	}

	@Override
	public RestResponse printBook(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		return bookPrintService.printBook(sessionStatusVO, vbid, code, httpRequest, uriInfo);
	}

	@Override
	public RestResponse launchBook(SessionStatusVO sessionStatusVO, String vbid, String linkLocation, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, VstException, ConnectApiException {
		return bookActionService.launchBook(sessionStatusVO, vbid, linkLocation, code, httpRequest, uriInfo);
	}

	@Override
	public RestResponse tryBook(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException {
		return bookActionService.tryBook(sessionStatusVO, vbid, code, httpRequest, uriInfo);
	}

	@Override
	public RestResponse rentBook(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException {
		return bookActionService.rentBook(sessionStatusVO, vbid, code, httpRequest, uriInfo);
	}

	@Override
	public RestResponse fullBook(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException {
		return bookActionService.fullBook(sessionStatusVO, vbid, code, httpRequest, uriInfo);
	}

	@Override
	public RestResponse purchaseBook(SessionStatusVO sessionStatusVO, String vbid, Integer purchaseId, String code)
			throws BridgeException, ParseException, IOException {
		return bookActionService.purchaseBook(sessionStatusVO, vbid, purchaseId, code);
	}

	@Override
	public RestResponse redeemVbid(SessionStatusVO sessionStatusVO, String vbid, Integer entitlementId, String code)
			throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException {
		return bookActionService.redeemVbid(sessionStatusVO, vbid, entitlementId, code);
	}

	@Override
	public RestResponse deleteAncillaryBookCache(Integer bridgeId, List<String> vbidList, String vbid,
			HttpServletRequest httpRequest, SessionStatusVO sessionStatusVO) {
		return bookBridgeService.deleteAncillaryBookCache(bridgeId, vbidList, vbid, httpRequest, sessionStatusVO);
	}
}
