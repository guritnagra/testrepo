package com.vst.bridge.rest.response.vo;

import java.io.Serializable;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize
public class EmptyObject implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}