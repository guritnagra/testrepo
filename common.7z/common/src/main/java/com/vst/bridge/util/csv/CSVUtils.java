package com.vst.bridge.util.csv;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Set;

import org.apache.commons.csv.CSVFormat;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CSVUtils {

	private static Logger log = LogManager.getLogger(CSVUtils.class);

	public static Set<String> loadFile(InputStream uploadedInputStream) {
		Set<String> headerSet = null;
		try (Reader in = new InputStreamReader(uploadedInputStream)) {
			headerSet = CSVFormat.EXCEL.withHeader().parse(in).getHeaderMap().keySet();
		} catch (IOException e) {
			log.info("There was an error gtting ", e);
		}
		return headerSet;
	}
}
