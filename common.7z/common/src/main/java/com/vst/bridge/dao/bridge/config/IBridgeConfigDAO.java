package com.vst.bridge.dao.bridge.config;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.BridgeConfig;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeConfigDAO extends IGenericDAO<BridgeConfig, Integer>{

	List<BridgeConfig> getAllConfigForBridgeId(final Integer bridgeId)throws BridgeException;
	
	BridgeConfig getBridgeConfigByKeyName(final Integer bridgeId,String keyName) throws BridgeException;
}
