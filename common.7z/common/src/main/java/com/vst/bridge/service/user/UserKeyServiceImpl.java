package com.vst.bridge.service.user;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.JsonUtils;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.key.IKeyDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.dao.user.book.IBridgeUserBookAssignDAO;
import com.vst.bridge.dao.user.key.IBridgeUserKeyDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.BridgeUserKey;
import com.vst.bridge.entity.keys.Keys;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.user.CreateKeyResponseVO;
import com.vst.bridge.rest.response.vo.user.CreateKeysVO;
import com.vst.bridge.rest.response.vo.user.TotalUsedDetailsVO;
import com.vst.bridge.util.constant.ApplicationAction;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.error.ErrorHandlerUtil;
import com.vst.bridge.util.error.ResponseError;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;

@Service("userKeyService")
public class UserKeyServiceImpl implements IUserKeyService {

	@Autowired
	private IBridgeUserDAO bridgeUserDAO;

	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private ErrorHandlerUtil errorHandlerUtility;

	@Autowired
	private IBridgeDAO bridgeDAO;

	@Autowired
	private IBridgeUserKeyDAO bridgeUserKeyDAO;

	@Autowired
	private IBridgeUserBookAssignDAO bridgeUserBookAssignDAO;

	@Autowired
	private IKeyDAO keyDAO;

	@Autowired
	private UserServiceUtil userServiceUtil;

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse postKeysForUser(SessionStatusVO sessionStatusVO, CreateKeysVO createKey, String vbid,
			String code, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		BridgeUser user = bridgeUserDAO.get(sessionStatusVO.getAdminId());
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		ResponseError responseError = errorHandlerUtility
				.validatePostKeysParameters(JsonUtils.getJsonString(createKey));
		if (responseError == null) {
			Keys key = keyDAO.getKeyForCode(createKey.getCode());
			if (key != null) {
				if (key.getKeyBatch().getBridge().getId() != bridge.getId()) {
					throw new BridgeException(ApplicationCode.INVALID_BRIDGE_KEY_CODE);
				}
				if (null != key.getExpireDate()) {
					if (!key.getExpireDate().after(new Date())) {
						throw new BridgeException(ApplicationCode.KEY_EXPIRED);
					}
				}
				Integer keyUsedCount = bridgeUserKeyDAO.getKeyCodeUsedCount(key.getId());
				if (key.getNoOfUsers() > keyUsedCount) {
					BridgeUserKey userKey = bridgeUserKeyDAO.getUserForCode(user.getId(), key.getId(), Boolean.TRUE);
					if (null != userKey) {
						throw new BridgeException(ApplicationCode.DUPLICATE_KEY);
					}
					BridgeUserKey bridgeUserKey = new BridgeUserKey();
					bridgeUserKey.setDeleted(Boolean.FALSE);
					bridgeUserKey.setActivationDate(new Date());
					bridgeUserKey.setKey(key);
					bridgeUserKey.setUser(user);
					bridgeUserKeyDAO.saveOrUpdate(bridgeUserKey);
					userServiceUtil.createBridgeLog(user.getId(), bridge, ApplicationAction.REGISTER_KEY,
							key.getKeyCode());
					response.setData(this.populateKeysResponseFormUserKeyAssigned(bridgeUserKey));
				} else {
					throw new BridgeException(ApplicationCode.KEY_MAX_USER_REACH);
				}
			} else {
				throw new BridgeException(ApplicationCode.KEY_NOT_FOUND);
			}
		} else {
			response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
			response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
			response.setError(responseError);
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getKeysForUser(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException, IOException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		List<BridgeUserKey> userKeys = bridgeUserKeyDAO.getListOfKeysAssigedForUser(sessionStatusVO.getAdminId());
		if (null != userKeys && userKeys.size() > 0) {
			List<CreateKeyResponseVO> keyList = new ArrayList<CreateKeyResponseVO>();
			for (BridgeUserKey bridgeUserKey : userKeys) {
				keyList.add(this.populateKeysResponseFormUserKeyAssigned(bridgeUserKey));
			}
			response.setData(keyList);
		}
		return response;
	}

	private CreateKeyResponseVO populateKeysResponseFormUserKeyAssigned(BridgeUserKey bridgeUserKey) {
		CreateKeyResponseVO createKeyResponseVO = new CreateKeyResponseVO();

		Keys key = bridgeUserKey.getKey();

		if (null != key && null != key.getExpireDate()) {
			createKeyResponseVO.setExpire(key.getExpireDate().getTime());
			createKeyResponseVO.setExpired(!key.getExpireDate().after(new Date()));
		} else {
			createKeyResponseVO.setExpired(Boolean.FALSE);
		}

		TotalUsedDetailsVO full = new TotalUsedDetailsVO();
		full.setTotal(key.getFullCredits());
		full.setUsed(bridgeUserBookAssignDAO.getUsedCountForUsedType(bridgeUserKey.getId(),
				ApplicationConstants.BOOK_KEY_USED_TYPE_FULL));
		createKeyResponseVO.setFullCredits(full);

		TotalUsedDetailsVO trial = new TotalUsedDetailsVO();
		trial.setTotal(key.getTrialCredits());
		trial.setUsed(bridgeUserBookAssignDAO.getUsedCountForUsedType(bridgeUserKey.getId(),
				ApplicationConstants.BOOK_KEY_USED_TYPE_TRIAL));
		createKeyResponseVO.setTrialCredits(trial);

		TotalUsedDetailsVO rental = new TotalUsedDetailsVO();
		rental.setTotal(key.getRentalCredits());
		rental.setUsed(bridgeUserBookAssignDAO.getUsedCountForUsedType(bridgeUserKey.getId(),
				ApplicationConstants.BOOK_KEY_USED_TYPE_RENTAL));
		createKeyResponseVO.setRetalCredits(rental);

		return createKeyResponseVO;
	}

}
