package com.vst.bridge.service.user;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.VstException;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.user.IntegratedBridgeUserResponseVO;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.exception.BusinessCenterException;
import com.vst.bridge.util.exception.IntegrationException;

public interface IUserValidationService {
	RestResponse validateToken(String code, String token) throws BridgeException;

	RestResponse ssoLoginForIntegratedUser(IntegratedBridgeUserResponseVO integratedBridgeUserResponseVO, String code,
			HttpServletResponse httpResponse, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException,
			ParseException, IOException, BusinessCenterException, VstException, IntegrationException;

}
