package com.vst.bridge;

import com.vst.connectapi.ERRORS;

/**
 * Exception.  To be used to convey information back to caller.
 **/
public final class VstException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	final private ERRORS errorType;
	final Throwable exception;
	
	public VstException(ERRORS errorType) {
		super();
		this.errorType= errorType;
		this.exception= null;
	}
	
	public VstException(String msg,ERRORS errorType) {
		super(msg);
		this.errorType= errorType;
		this.exception= null;
	}
	
	public VstException(String msg, Throwable ex, ERRORS errorType) {
		super(msg);
		this.errorType= errorType;
		this.exception= ex;
	}
	
	public VstException(Throwable ex, ERRORS errorType) {
		super(ex.getMessage());
		this.errorType= errorType;
		this.exception= ex;
	}
	
	public ERRORS getErrorType() {
		return errorType;
	}
}
