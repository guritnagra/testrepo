package com.vst.bridge.service.admin;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.JDOMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.vst.bridge.JsonUtils;
import com.vst.bridge.TomcatUtils;
import com.vst.bridge.VstException;
import com.vst.bridge.VstUtils;
import com.vst.bridge.actions.Aws;
import com.vst.bridge.dao.admin.IAdminFavoriteBridgesDAO;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.admin.IAdminUserLabelDAO;
import com.vst.bridge.dao.admin.group.company.IAdminGroupCompanyDAO;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.allowance.IBridgeEntitlementDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookCacheDAO;
import com.vst.bridge.dao.bridge.config.IBridgeConfigDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupUserDAO;
import com.vst.bridge.dao.bridge.type.IBridgeTypeDAO;
import com.vst.bridge.dao.bridge.type.ICodeTypesDAO;
import com.vst.bridge.dao.company.ICompanyDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.dao.user.key.IBridgeUserKeyDAO;
import com.vst.bridge.entity.admin.allowance.BridgeEntitlement;
import com.vst.bridge.entity.admin.company.AdminCompany;
import com.vst.bridge.entity.admin.user.AdminFavoriteBridge;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.BridgeConfig;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.BridgeUserKey;
import com.vst.bridge.entity.group.BridgeGroup;
import com.vst.bridge.entity.group.GroupUser;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.TenantVO;
import com.vst.bridge.rest.response.vo.bridge.BridgeAdminResponseVO;
import com.vst.bridge.rest.response.vo.bridge.BridgeInfoWithFavoriteVO;
import com.vst.bridge.rest.response.vo.bridge.BridgeSuperAdminResponseVO;
import com.vst.bridge.rest.response.vo.bridge.IntigrationVO;
import com.vst.bridge.rest.response.vo.bridge.user.BridgeUserResponseVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.rest.response.vo.user.AdminInfoVo;
import com.vst.bridge.service.bc.IBusinessCenterServices;
import com.vst.bridge.service.book.IBookServices;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.constant.BridgeConfigConstant;
import com.vst.bridge.util.constant.PermissionAction;
import com.vst.bridge.util.email.EmailHandlerService;
import com.vst.bridge.util.email.ExecutorUtility;
import com.vst.bridge.util.error.ErrorHandlerUtil;
import com.vst.bridge.util.error.ResponseError;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.exception.BusinessCenterException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.bridge.util.message.TemplateLocationConstants;
import com.vst.connectapi.ApiKeys;
import com.vst.connectapi.ConnectApiWrapper;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;

@Service("adminUserBridgeService")
public class AdminUserBridgeServiceImpl implements IAdminUserBridgeService {

	@Autowired
	private IAdminUserDAO adminUserDAO;

	@Autowired
	private ICompanyDAO companyDAO;

	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private ErrorHandlerUtil errorHandlerUtility;

	@Autowired
	private EmailHandlerService emailHandler;

	@Autowired
	private IBridgeDAO bridgeDAO;

	@Autowired
	private IAdminFavoriteBridgesDAO adminFavoriteBridgesDAO;

	@Autowired
	private IBookServices bookServices;

	@Autowired
	private IBridgeConfigDAO bridgeConfigDAO;

	@Autowired
	private IAdminGroupCompanyDAO adminGroupCompanyDAO;

	@Autowired
	private IBridgeGroupDAO bridgeGroupDAO;

	private Logger logger = LogManager.getLogger(AdminUserBridgeServiceImpl.class);

	private List<String> bridgeDomainPostfix;

	private Executor executor = ExecutorUtility.getExecutorInstance();

	@Autowired
	private IBridgeTypeDAO bridgeTypeDAO;

	@Autowired
	private IBridgeBookCacheDAO bridgeBookCacheDAO;

	@Autowired
	private IBridgeGroupUserDAO bridgeGroupUserDAO;

	@Autowired
	private IBridgeUserDAO bridgeUserDAO;

	@Autowired
	private ICodeTypesDAO codeTypesDAO;

	@Autowired
	private IBusinessCenterServices businessCenterServices;

	@Autowired
	private AdminUserServiceUtil adminUserServiceUtil;
	
	@Autowired 
	private IBridgeUserKeyDAO bridgeUserKeyDao;
	
	@Autowired
	private IBridgeEntitlementDAO bridgeEntitlementDAO;
	
	@Autowired
	private IAdminUserLabelDAO adminUserLabelDAO;

	public AdminUserBridgeServiceImpl() {
		String postfix = TomcatUtils.getParam("bridge-domain-postfix");
		if (null != postfix) {
			bridgeDomainPostfix = new ArrayList<String>();
			String[] postfixs = postfix.split(ApplicationConstants.BRIDGE_DOMAIN_POST_FIX_SEPERATOR);
			for (String string : postfixs) {
				bridgeDomainPostfix.add(string);
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse uploadLogo(SessionStatusVO sessionStatusVO, Object param, HttpServletRequest httpRequest,
			UriInfo uriInfo) throws BridgeException, IOException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Map<String, Object> params = (Map<String, Object>) param;
		MultipartFile uploadFile = (MultipartFile) params.get(ApplicationConstants.UPLOAD_LOGO_FILE_DETAILS);
		final String fileName = uploadFile.getOriginalFilename();
		final String ext = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();

		if (!(ext.equals("xml") || ext.equals("jpg") || ext.equals("png") || ext.equals("gif") || ext.equals("jpeg") || ext.equals("svg"))) {
			response = new RestResponse(Response.Status.UNSUPPORTED_MEDIA_TYPE.getStatusCode(),
					ApplicationCode.UNSUPPORTED_MEDIA_TYPE.getCodeId(),
					localeMessageUtility.getMessage(ApplicationCode.UNSUPPORTED_MEDIA_TYPE.getCodeId()));
		} else {

			InputStream uploadedInputStream = uploadFile.getInputStream();
			Map<String, String> urlMap = new HashMap<>();
			final String imgUrl = Aws.uploadFile(VstUtils.getDomain(uriInfo, httpRequest), uploadedInputStream, ext,
					uploadFile.getSize(), Boolean.FALSE);
			urlMap.put("url", imgUrl);
			response.setData(urlMap);
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getBridgesList(SessionStatusVO sessionStatusVO, BridgePaginationVo bridgePaginationVo,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		String role = sessionStatusVO.getRoleName();
		List<Bridge> bridges = new ArrayList<Bridge>(0);
		Boolean isSuperAdmin = false;
		AdminUser adminUser = adminUserDAO.get(sessionStatusVO.getAdminId());
		List<Integer> companyIds = null;
		adminUserServiceUtil.validateAndRearangePaginationVO(bridgePaginationVo,
				ApplicationConstants.DEFAULT_GET_BRIDGE_ORDER_BY_VALUE, Boolean.TRUE);
		if (StringUtils.equals(role, ApplicationConstants.USER_ROLE_SUPER_ADMIN)) {
			isSuperAdmin = true;
		} else {
		}

		Integer startIndex = adminUserServiceUtil.calculateStartIndex(bridgePaginationVo.getPage(),
				bridgePaginationVo.getLimit());
		if (StringUtils.equals(role, ApplicationConstants.USER_ROLE_SUPER_ADMIN)) {
			bridges = bridgeDAO.getBrigesList(null, Boolean.FALSE, startIndex, bridgePaginationVo,isSuperAdmin);
			isSuperAdmin = true;
		} else {
			List<AdminCompany> adminCompanies = adminUser.getCompanies();
			companyIds = new ArrayList<Integer>();
			if (null != adminCompanies && adminCompanies.size() > 0) {
				for (AdminCompany adminCompany : adminCompanies) {
					companyIds.add(adminCompany.getCompany().getId());
				}
			}			
			bridges = bridgeDAO.getBrigesList(companyIds, Boolean.FALSE, startIndex, bridgePaginationVo,Boolean.FALSE);
		}
		Integer totalRecords = bridgeDAO.getBridgesCount(companyIds, Boolean.FALSE, bridgePaginationVo, isSuperAdmin);
		Integer totalPages = adminUserServiceUtil.calculateTotalPageCount(totalRecords, bridgePaginationVo.getLimit());
		Integer offset = this.calculateOffsetValue(bridgePaginationVo.getPage(),bridgePaginationVo.getLimit());
		PaginationVO paginationVO = new PaginationVO(bridgePaginationVo.getPage(), bridgePaginationVo.getLimit(),
				totalPages, bridgePaginationVo.getOrderBy(), bridgePaginationVo.getOrder(),
				bridgePaginationVo.getSearch(), totalRecords,offset);
		response.setMetadata(paginationVO);

		List<? extends BridgeAdminResponseVO> bridgeResponseVo = this
				.populateBridgeResponseVOFromBridgeEntities(adminUser, bridges, isSuperAdmin);
		response.setData(bridgeResponseVo);
		return response;
	}
	
	private Integer calculateOffsetValue(Integer page, Integer limit) {
		if(page!=null){
			return (page-1)*limit;
		}
		return 0;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getBridgeForId(SessionStatusVO sessionStatusVO, final Integer bridgeId,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		List<Bridge> bridges = new ArrayList<Bridge>(0);
		String role = sessionStatusVO.getRoleName();
		Boolean isSuperAdmin = false;
		AdminUser adminUser = adminUserDAO.get(sessionStatusVO.getAdminId());
		if (null != bridgeId) {
			Bridge bridge = bridgeDAO.get(bridgeId);
			if (bridge == null || bridge.getDeleted()) {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			bridges.add(bridge);
			if (StringUtils.equals(role, ApplicationConstants.USER_ROLE_SUPER_ADMIN)) {
				isSuperAdmin = Boolean.TRUE;
			}
			List<? extends BridgeAdminResponseVO> bridgeResponseVo = this
					.populateBridgeResponseVOFromBridgeEntities(adminUser, bridges, isSuperAdmin);
			response.setData(bridgeResponseVo);
		} else {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse createOrUpdateBridges(BridgeInfoWithFavoriteVO bridgeInfoWithFavoriteVO,
			SessionStatusVO sessionStatusVO, Integer id, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException, ConnectApiException, ConnectApiXmlException,
			ConnectApiHttpException, VstException, BusinessCenterException {
		
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		AdminUser adminUser = adminUserDAO.get(sessionStatusVO.getAdminId());
		adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_BRIDGE, adminUser);
		Boolean refreshBooks = Boolean.FALSE;
		Boolean sendActivationEmail = Boolean.FALSE;
		List<Bridge> bridges = new ArrayList<Bridge>(0);
		final String domain= VstUtils.getDomain(uriInfo, httpRequest);

		ResponseError responseError = id == null
				? errorHandlerUtility.validateBridgeVOParameters(JsonUtils.getJsonString(bridgeInfoWithFavoriteVO))
				: null;
		Bridge bridge = null;
		if (null == responseError) {
			bridge = null != id ? bridgeDAO.get(id) : new Bridge();
			if ((null == bridge && null != id) || bridge.getDeleted()) {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			Integer companyId = bridgeInfoWithFavoriteVO.getCompany();
			if (null != companyId && companyId > 0) {
				bridge.setCompany(companyDAO.load(companyId));

			}
			String bridgeType = bridgeInfoWithFavoriteVO.getBridgeType();
			if (null != bridgeType && !StringUtils.isEmpty(bridgeType)) {
				bridge.setBridgeType(bridgeTypeDAO.getBridgeForType(bridgeType));
			}

			String apiKey = bridgeInfoWithFavoriteVO.getApiKey();
			if (null != apiKey && !StringUtils.isEmpty(apiKey)
					&& sessionStatusVO.getRoleName().equals(ApplicationConstants.USER_ROLE_SUPER_ADMIN)) {
				apiKey = apiKey.trim();
				if(apiKey.startsWith("XXXX"))
					apiKey=bridge.getApiKey();
				bridge.setApiKey(apiKey);
				String connectCompanyName = ConnectApiWrapper.getConnectCompany(apiKey);
				bridge.setConnectCompany(connectCompanyName);
			}

			Boolean isPending = bridgeInfoWithFavoriteVO.getIsPending();
			if (null != isPending /* && !isPending */ && sessionStatusVO.getRoleName()
					.equals(ApplicationConstants.USER_ROLE_SUPER_ADMIN)) {
				/*
				 * if(!isPending){ bookServices.refreshBookCache(id,token); }
				 */
				if (!isPending) {
					refreshBooks = Boolean.TRUE;
					sendActivationEmail = Boolean.TRUE;
				}

				bridge.setPendingApproved(bridgeInfoWithFavoriteVO.getIsPending());
			}
			String name = bridgeInfoWithFavoriteVO.getName();
			if (null != name && !StringUtils.isEmpty(name) && !StringUtils.equals(name, bridge.getName())) {
				bridgeDAO.checkBridgeNameExist(name,bridge.getId());
				bridge.setName(name.trim());
			}
			String language = bridgeInfoWithFavoriteVO.getLanguage();
			if (null != language && !StringUtils.isEmpty(language)) {
				bridge.setLanguage(language.trim());
			}
			String contactEmail = bridgeInfoWithFavoriteVO.getContactEmail();
			if (null != contactEmail && !StringUtils.isEmpty(contactEmail)) {
				bridge.setEmail(contactEmail.trim());
			}
			String contactName = bridgeInfoWithFavoriteVO.getContactName();
			if (null != contactName && !StringUtils.isEmpty(contactName)) {
				bridge.setContactName(contactName.trim());
			}
			String contactPhone = bridgeInfoWithFavoriteVO.getContactPhone();
			if (null != contactPhone && !StringUtils.isEmpty(contactPhone)) {
				bridge.setContactNo(contactPhone.trim());
			}
			String code = bridgeInfoWithFavoriteVO.getCode();
			if (null != code && !StringUtils.isEmpty(code) && !StringUtils.equals(bridge.getCode(), code)) {
				if (!code.matches(ApplicationConstants.BRIDGE_CODE_ALLOWDED_PATTERN)) {
					throw new BridgeException(ApplicationCode.INVALID_BRIDGE_CODE);
				}
				bridgeDAO.checkBridgeCodeUnique(code);
				bridge.setCode(code.trim());
			}

			String alias = bridgeInfoWithFavoriteVO.getAlias();
			if (null != alias && !StringUtils.isEmpty(alias) && !StringUtils.equals(bridge.getDomainAlias(), alias)) {
				bridgeDAO.checkBridgeAliasUnique(alias);
				bridge.setDomainAlias(alias.trim());
			}
			String password = bridgeInfoWithFavoriteVO.getPassword();
			if (null != password && !StringUtils.isEmpty(password)
					&& !StringUtils.equals(password, bridge.getPassword())) {
				bridge.setPassword(password.trim());
			}
			Boolean isPasswordProtected = bridgeInfoWithFavoriteVO.getIsPasswordProtected();
			if (null != isPasswordProtected) {
				bridge.setPasswordProtected(isPasswordProtected);
			}
			String bookshelfUrl = bridgeInfoWithFavoriteVO.getBookshelfUrl();

			if (null != bookshelfUrl && !StringUtils.equals(bookshelfUrl, bridge.getBookshelfUrl())) {
				bridge.setBookshelfUrl(bookshelfUrl);
			}
			/*
			 * if(!StringUtils.equals(bridge.getBookshelfUrl(), bookshelfUrl)){
			 * bridge.setBookshelfUrl(bookshelfUrl); }
			 */

			Boolean isRostered = bridgeInfoWithFavoriteVO.getIsRostored();
			if (null != isRostered) {
				bridge.setIsRostered(isRostered);
			}

			Date currentDate = new Date();
			bridge.setLastModifier(adminUser);
			bridge.setModifiedDate(currentDate);
			Boolean favorite = bridgeInfoWithFavoriteVO.getIsFavorite();

			if (null != favorite && favorite) {
				AdminFavoriteBridge favoriteBridge = adminFavoriteBridgesDAO
						.checkAdminFavoriteBridgeExist(adminUser.getId(), bridge.getId(), null);
				if (null == favoriteBridge) {
					favoriteBridge = new AdminFavoriteBridge();
					favoriteBridge.setBridge(bridge);
					favoriteBridge.setUser(adminUser);
				} else {
					favoriteBridge.setDeleted(Boolean.FALSE);
				}
				adminFavoriteBridgesDAO.create(favoriteBridge);
			} else {
				AdminFavoriteBridge favoriteBridge = adminFavoriteBridgesDAO
						.checkAdminFavoriteBridgeExist(adminUser.getId(), bridge.getId(), null);
				if (null != favoriteBridge) {
					favoriteBridge.setDeleted(Boolean.TRUE);
					adminFavoriteBridgesDAO.saveOrUpdate(favoriteBridge);
				}
			}
			bridges.add(bridge);
			response.setCode(id != null && id > 0 ? Response.Status.OK.getStatusCode()
					: Response.Status.CREATED.getStatusCode());
			Boolean isSuperAdmin = false;
			if (StringUtils.equals(sessionStatusVO.getRoleName(), ApplicationConstants.USER_ROLE_SUPER_ADMIN)) {
				isSuperAdmin = Boolean.TRUE;
			}
			Set<BridgeConfig> bridgeConfigs = bridge.getConfigs();
			Map<String, String> bridgeLabels = bridgeInfoWithFavoriteVO.getConfig().getLabels();
			boolean notesInfoFlag = false;
			String notesInfo = bridgeInfoWithFavoriteVO.getConfig().getNotesInfo();
			if (null != bridgeLabels && bridgeLabels.size() > 0) {

				if (null != bridgeConfigs && bridgeConfigs.size() > 0) {
					Iterator<BridgeConfig> bridgeConfigIterator = bridgeConfigs.iterator();
					// for(BridgeConfig bridgeConfig : bridgeConfigs){

					while (bridgeConfigIterator.hasNext()) {
						BridgeConfig bridgeConfig = bridgeConfigIterator.next();
						Iterator<Map.Entry<String, String>> mapIerator = bridgeLabels.entrySet().iterator();
						while (mapIerator.hasNext()) {
							Map.Entry<String, String> entry = mapIerator.next();
							if (StringUtils.equals(bridgeConfig.getKeyName(), "label." + entry.getKey())) {
								bridgeConfig.setKeyValue(entry.getValue());
								bridgeConfig.setDeleted(Boolean.FALSE);
								mapIerator.remove();
								bridgeConfigIterator.remove();
							}
						}
					}
					// }
				}
			}
			String entitlementType = bridgeInfoWithFavoriteVO.getConfig().getEntitlementType();

			// Mark as deleted lebels which was not passed in request
			boolean entitlementFlag = false;

			if (bridgeConfigs.size() > 0) {
				for (BridgeConfig bridgeConfig : bridgeConfigs) {
					if (bridgeConfig.getKeyName().contains("label.")) {
						bridgeConfig.setDeleted(Boolean.TRUE);
					}
					if ("entitlementType".equals(bridgeConfig.getKeyName()) && !bridgeConfig.getDeleted()) {
						entitlementFlag = true;
						if (null == entitlementType) {
							bridgeConfig.setDeleted(Boolean.TRUE);
						} else if (!entitlementType.equals(bridgeConfig.getKeyValue())) {
							bridgeConfig.setKeyValue(entitlementType);
						}
					}
					if ("notesInfo".equals(bridgeConfig.getKeyName()) && !bridgeConfig.getDeleted() && bridgeInfoWithFavoriteVO.getIsPending()==null) {
						notesInfoFlag = true;
						if (null == notesInfo) {
							bridgeConfig.setDeleted(Boolean.TRUE);
						} else if (!notesInfo.equals(bridgeConfig.getKeyValue())) {
							bridgeConfig.setKeyValue(notesInfo);
						}
					}
				}

			}
			if (null != entitlementType && !entitlementFlag) {
				BridgeConfig bridgeConfig = new BridgeConfig();
				bridgeConfig.setKeyName("entitlementType");
				bridgeConfig.setKeyValue(entitlementType);
				bridgeConfig.setBridge(bridge);
				bridgeConfigs.add(bridgeConfig);
			}

			// Add new labels for bridge
			if (null != bridgeLabels && bridgeLabels.size() > 0) {
				for (Map.Entry<String, String> entry : bridgeLabels.entrySet()) {
					BridgeConfig bridgeConfig = new BridgeConfig();
					bridgeConfig.setKeyName("label." + entry.getKey());
					bridgeConfig.setKeyValue(entry.getValue());
					bridgeConfig.setBridge(bridge);
					bridgeConfigs.add(bridgeConfig);
				}
			}

			IntigrationVO intigrationVO = bridgeInfoWithFavoriteVO.getIntegrations();

			if (null != intigrationVO) {
				bridge.setFullURL(intigrationVO.geteText());
				bridge.setPrintBookURL(intigrationVO.getTextBook());
				bridge.setRentalURL(intigrationVO.getRental());
				bridge.seteTextPrice(StringUtils.stripToNull(intigrationVO.geteTextPrice()));
				bridge.setRentalPrice(StringUtils.stripToNull(intigrationVO.getRentalPrice()));
				bridge.setTextBookPrice(StringUtils.stripToNull(intigrationVO.getTextBookPrice()));
			}

			bridge.setTrialDays(bridgeInfoWithFavoriteVO.getTrialsDays());

			bridge.setRentalDays(bridgeInfoWithFavoriteVO.getRentalsDays());

			bridge.setFullDays(bridgeInfoWithFavoriteVO.getFullDays());

			Long trialDate = bridgeInfoWithFavoriteVO.getTrialExpires();
			if (null != trialDate && trialDate > 0) {
				bridge.setTrialExpires(new Date(trialDate));
			} else {
				bridge.setTrialExpires(null);
			}

			Long rentalDate = bridgeInfoWithFavoriteVO.getRentalExpires();
			if (null != rentalDate && rentalDate > 0) {
				bridge.setRentalExpires(new Date(rentalDate));
			} else {
				bridge.setRentalExpires(null);
			}

			Long fullDate = bridgeInfoWithFavoriteVO.getFullExpires();
			if (null != fullDate && fullDate > 0) {
				bridge.setFullExpires(new Date(fullDate));
			} else {
				bridge.setFullExpires(null);
			}

			Boolean deferedSignIn = bridgeInfoWithFavoriteVO.getIsDefered();
			if (null != deferedSignIn) {
				bridge.setDerefedSignIn(deferedSignIn);
			}

			Boolean keysRequired = bridgeInfoWithFavoriteVO.getKeysRequired();
			if (null != keysRequired) {
				bridge.setKeysRequired(keysRequired);
			}
			/*
			 * else if(id == null){ bridge.setKeysRequired(Boolean.TRUE); }
			 */

			Integer trialCredits = bridgeInfoWithFavoriteVO.getTrialCredits();

			Integer rentalCredits = bridgeInfoWithFavoriteVO.getRentalCredits();

			Integer fullCredits = bridgeInfoWithFavoriteVO.getFullCredits();

			Integer concCredits = bridgeInfoWithFavoriteVO.getConcCredits();

			Boolean isConcurrencyEnabled = bridgeInfoWithFavoriteVO.getIsConcurrencyEnabled() != null
					? bridgeInfoWithFavoriteVO.getIsConcurrencyEnabled() : bridge.getConcurrencyEnabled();

			if (trialCredits == null && rentalCredits == null && fullCredits == null && concCredits == null) {
				if (isConcurrencyEnabled != null && isConcurrencyEnabled) {
					if (ApplicationConstants.BRIDGE_COMPANY_TYPE_PUBLISHER.equals(bridgeType)) {
						concCredits = 1;
						if (id != null && !bridge.getConcurrencyEnabled()) {
							bridge.setTrialCredits(null);
							bridge.setRentalCredits(null);
							bridge.setFullCredits(null);
						}
					}
				} else if (isConcurrencyEnabled != null && !isConcurrencyEnabled
						&& ApplicationConstants.BRIDGE_COMPANY_TYPE_PUBLISHER.equals(bridgeType)) {
					trialCredits = -1;
					if (id != null && bridge.getConcurrencyEnabled()) {
						bridge.setConcurrencyCredits(null);
						bridge.setRentalCredits(null);
						bridge.setFullCredits(null);
					}
				}
			}
			if (ApplicationConstants.BRIDGE_TYPE_INSTITUTIONAL.equals(bridgeType)) {
				if (isConcurrencyEnabled != null && isConcurrencyEnabled) {
					concCredits = -1;
					trialCredits = null;
					fullCredits = null;
					rentalCredits = null;
					bridge.setTrialCredits(trialCredits);
					bridge.setRentalCredits(rentalCredits);
					bridge.setFullCredits(fullCredits);
				} else if ((isConcurrencyEnabled != null && !isConcurrencyEnabled)) {
					fullCredits = -1;
					trialCredits = null;
					concCredits = null;
					rentalCredits = null;
					bridge.setTrialCredits(trialCredits);
					bridge.setRentalCredits(rentalCredits);
					bridge.setConcurrencyCredits(concCredits);
				}
				for (BridgeConfig bridgeConfig : bridgeConfigs) {
					if ("entitlementType".equals(bridgeConfig.getKeyName()) && !bridgeConfig.getDeleted()
							&& isConcurrencyEnabled != null) {
						if (isConcurrencyEnabled) {
							bridgeConfig.setKeyValue("Concurrency");
							break;
						} else {
							bridgeConfig.setKeyValue("Full License");
							break;
						}
					}
				}
			}

			if (null != trialCredits) {
				bridge.setTrialCredits(trialCredits);
			}
			if (null != rentalCredits) {
				bridge.setRentalCredits(rentalCredits);
			}
			if (null != fullCredits) {
				bridge.setFullCredits(fullCredits);
			}
			if (null != concCredits) {
				bridge.setConcurrencyCredits(concCredits);
			}

			bridge.setOfflineTrialDays(bridgeInfoWithFavoriteVO.getOfflineTrialDays());

			bridge.setOfflineRentalDays(bridgeInfoWithFavoriteVO.getOfflineRentalDays());

			bridge.setOfflineFullDays(bridgeInfoWithFavoriteVO.getOfflineFullDays());

			Long offlineTrialDate = bridgeInfoWithFavoriteVO.getOfflineTrialExpires();
			if (null != offlineTrialDate && offlineTrialDate > 0) {
				bridge.setOfflineTrialExpires(new Date(offlineTrialDate));
			} else {
				bridge.setOfflineTrialExpires(null);
			}

			Long offlineRentalDate = bridgeInfoWithFavoriteVO.getOfflineRentalExpires();
			if (null != offlineRentalDate && offlineRentalDate > 0) {
				bridge.setOfflineRentalExpires(new Date(offlineRentalDate));
			} else {
				bridge.setOfflineRentalExpires(null);
			}

			Long offlineFullDate = bridgeInfoWithFavoriteVO.getOfflineFullExpires();
			if (null != offlineFullDate && offlineFullDate > 0) {
				bridge.setOfflineFullExpires(new Date(offlineFullDate));
			} else {
				bridge.setOfflineFullExpires(null);
			}

			String compType = bridgeInfoWithFavoriteVO.getConcCompType();
			if (null != compType && !StringUtils.isEmpty(compType)) {
				bridge.setCodeType(codeTypesDAO.getCodeForType(compType));
			}
			Long concDate = bridgeInfoWithFavoriteVO.getConcExpires();
			if (null != concDate && concDate > 0) {
				bridge.setConcurrencyExpires(new Date(concDate));
			} else {
				bridge.setConcurrencyExpires(null);
			}
			Long offlineConcDate = bridgeInfoWithFavoriteVO.getOfflineConcExpires();
			if (null != offlineConcDate && offlineConcDate > 0) {
				bridge.setOfflineConcurrencyExpires(new Date(offlineConcDate));
			} else {
				bridge.setOfflineConcurrencyExpires(null);
			}
			bridge.setConcurrencyDays(bridgeInfoWithFavoriteVO.getConcDays());
			bridge.setOfflineConcurrencyDays(bridgeInfoWithFavoriteVO.getOfflineConcDays());

			List<BridgeBookCache> bookCacheList = bridgeBookCacheDAO.getCacheBooksWithConcurrencyLimit(id);
			if (isSuperAdmin && isConcurrencyEnabled != null)
				bridge.setConcurrencyEnabled(isConcurrencyEnabled);
			if (isConcurrencyEnabled != null) {
				if (isConcurrencyEnabled) {
					Integer concurrencyLimit = bridgeInfoWithFavoriteVO.getConcurrencyLimit();
					if (concurrencyLimit != null) {
						if (bookCacheList.size() > 0) {
							for (BridgeBookCache bookCache : bookCacheList) {
								bookCache.setConcurrencyLimit(null);
							}
							bridgeBookCacheDAO.saveOrUpdateAll(bookCacheList);
						}
						bridge.setConcurrencyLimit(concurrencyLimit);
					}	
				}
			}

			Boolean isIntegrated = bridgeInfoWithFavoriteVO.getIsIntegrated();
			if (isIntegrated != null) {
				bridge.setIsIntegrated(isIntegrated);
				if (isIntegrated) {
					Integer bcTenantId = bridgeInfoWithFavoriteVO.getBcTenantId();
					if (bcTenantId != null) {
						bridge.setBcTenantId(bcTenantId);
						TenantVO tenantVO = this.getBusinessCenterTenant(bcTenantId, bridge.getApiKey());
						if (tenantVO != null) {
							bridge.setBcTenantName(tenantVO.getName());
						}

					}					
				}
			}
			if(bridge!=null && bridge.getIsIntegrated()!=null){
				if(bridge.getIsIntegrated()){
					String integrationRedirectUrl=bridgeInfoWithFavoriteVO.getIntegrationRedirectUrl();					
					if (null != integrationRedirectUrl && !StringUtils.equals(integrationRedirectUrl, bridge.getIntegrationRedirectUrl())) {
						bridge.setIntegrationRedirectUrl(integrationRedirectUrl);
					}
				}				
			}			
			Boolean isSampler = bridgeInfoWithFavoriteVO.getIsSampler();
			if(null != isSampler){
				bridge.setIsSampler(isSampler);
			}
			
			Boolean isPurchasesEnabled = bridgeInfoWithFavoriteVO.getIsPurchasesEnabled();
			if (null != isPurchasesEnabled) {
				bridge.setIsPurchasesEnabled(isPurchasesEnabled);
			}
			
			Boolean isEmbeddedEnabled= bridgeInfoWithFavoriteVO.getIsEmbeddedEnabled()!=null ?bridgeInfoWithFavoriteVO.getIsEmbeddedEnabled() : Boolean.FALSE;
			if(null!=isEmbeddedEnabled){
				bridge.setIsEmbeddedEnabled(isEmbeddedEnabled);
			}

			bridgeDAO.saveOrUpdate(bridge);

			if (null != notesInfo && !notesInfoFlag) {
				BridgeConfig bridgeConfig = new BridgeConfig();
				bridgeConfig.setKeyName("notesInfo");
				bridgeConfig.setKeyValue(notesInfo);
				bridgeConfig.setBridge(bridge);
				bridgeConfigs.add(bridgeConfig);
			}
			List<? extends BridgeAdminResponseVO> bridgeResponseVo = this
					.populateBridgeResponseVOFromBridgeEntities(adminUser, bridges, isSuperAdmin);
			response.setData(bridgeResponseVo);

			/**** Email Notification *******/
			if (id == null) {

				BridgeGroup universalGroup = new BridgeGroup();
				universalGroup.setBridge(bridge);
				universalGroup.setName(ApplicationConstants.BRIDGE_DEFAULT_GROUP_UNIVERSAL);
				universalGroup.setCreatedBy(adminUser);
				universalGroup.setModifiedBy(adminUser);
				universalGroup.setCreatedDate(currentDate);
				universalGroup.setModifiedDate(currentDate);
				bridgeGroupDAO.saveOrUpdate(universalGroup);
				String url = httpRequest.getRequestURL().toString();
				url = url.substring(0, url.indexOf("//")) + "//" + domain;
				this.sendBridgeCreatedEmail(bridgeResponseVo.get(0), adminUserDAO.getSuperAdmins(),url);
			}
			if (sendActivationEmail) {
				String url = httpRequest.getRequestURL().toString();
				url = url.substring(0, url.indexOf("//")) + "//" + domain;
				sendBridgeActivatedEmail(bridge, url);
			}

			if (refreshBooks) {
				this.refreshBooksForBridge(id, apiKey);
				if(bridge.getIsIntegrated()!=null && bridge.getIsIntegrated())
					this.refreshIntegratedBridge(bridge,sessionStatusVO,httpRequest,uriInfo);
			}

		} else {
			response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
			response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
			response.setError(responseError);
		}
		// }

		return response;
	}
	
	private void refreshIntegratedBridge(final Bridge bridge, final SessionStatusVO sessionStatusVO, final HttpServletRequest httpRequest,final UriInfo uriInfo) {
		final Runnable runnable = new Runnable() {
			
		   @Override
		   public void run() {
			   try {
				logger.info("refreshIntegratedBridge: Refreshing Users & assets for bridge Id = {}",bridge.getId());
				businessCenterServices.getUsersForTenantId(sessionStatusVO, bridge.getId(), bridge.getBcTenantId(), httpRequest, uriInfo, null, Boolean.FALSE);
				businessCenterServices.createOrUpdateCoursesForTenantId(sessionStatusVO, bridge.getId(), bridge.getBcTenantId(), httpRequest, uriInfo, null, Boolean.FALSE);
				logger.info("refreshIntegratedBridge : Refreshing completed");
			} catch (BridgeException | BusinessCenterException | IOException | ConnectApiException | JDOMException | ParseException e) {
				logger.error("The was an issue refreshing users and assets for bridge with id: " + bridge.getId(), e);
			} 
		   }
		  };
		  this.executor.execute(runnable);
				
				}

	private void sendBridgeActivatedEmail(final Bridge bridge, final String url) {
		final Runnable runnable = new Runnable() {

			@Override
			public void run() {
				Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put(ApplicationConstants.NEW_BRIDGE_TO, bridge.getEmail());
				paramMap.put(ApplicationConstants.NEW_BRIDGE_CONTACT_NAME, bridge.getContactName());
				paramMap.put(ApplicationConstants.NEW_BRIDGE_NAME, bridge.getName());
				paramMap.put(ApplicationConstants.EMAIL_ACTIVATION_LINK, url);
				emailHandler.sendEmail(TemplateLocationConstants.BRIDGE_ACCTIVATION_NOTIFICATION_TEMPLATE, paramMap);
			}

		};
		this.executor.execute(runnable);

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getBridgeIntigrationForBridgeId(SessionStatusVO sessionStatusVO, Integer id,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Bridge bridge = bridgeDAO.get(id);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		response.setData(populateIntigrationVoFromBridge(bridge));
		return response;
	}

	private IntigrationVO populateIntigrationVoFromBridge(Bridge bridge) {
		IntigrationVO intigrationVO = new IntigrationVO();
		intigrationVO.seteText(bridge.getFullURL());
		intigrationVO.setRental(bridge.getRentalURL());
		intigrationVO.setTextBook(bridge.getPrintBookURL());
		intigrationVO.seteTextPrice(bridge.geteTextPrice());
		intigrationVO.setRentalPrice(bridge.getRentalPrice());
		intigrationVO.setTextBookPrice(bridge.getTextBookPrice());
		return intigrationVO;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse updateBridgeIntigrationForBridgeId(SessionStatusVO sessionStatusVO, IntigrationVO intigrationVO,
			Integer id, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Bridge bridge = bridgeDAO.get(id);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		/*
		 * final String inputJson = JsonUtils.requestToString(httpRequest);
		 * if(null !=inputJson && !StringUtils.isEmpty(inputJson) ){
		 * IntigrationVO intigrationVO = (new Genson()).deserialize(inputJson,
		 * IntigrationVO.class);
		 */
		if (null != intigrationVO) {
			bridge.setFullURL(intigrationVO.geteText());
			bridge.setPrintBookURL(intigrationVO.getTextBook());
			bridge.setRentalURL(intigrationVO.getRental());
			bridge.seteTextPrice(StringUtils.stripToNull(intigrationVO.geteTextPrice()));
			bridge.setRentalPrice(StringUtils.stripToNull(intigrationVO.getRentalPrice()));
			bridge.setTextBookPrice(StringUtils.stripToNull(intigrationVO.getTextBookPrice()));
			bridgeDAO.saveOrUpdate(bridge);
			response.setData(populateIntigrationVoFromBridge(bridge));
		}

		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getBridgeConfigForId(SessionStatusVO sessionStatusVO, Integer bridgeId,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if (null != bridgeId) {
			Bridge bridge = bridgeDAO.get(bridgeId);
			if (null != bridge) {
				Set<BridgeConfig> configs = new HashSet<BridgeConfig>(
						bridgeConfigDAO.getAllConfigForBridgeId(bridgeId));
				Map<String, Object> configVo = populateBridgeConfigResponseMapFromConfigs(configs, bridge);
				response.setData(configVo);
			} else {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			if (bridge.getDeleted()) {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
		} else {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		return response;
	}

	private Map<String, Object> populateBridgeConfigResponseMapFromConfigs(Set<BridgeConfig> configs, Bridge bridge) {
		Map<String, Object> configMap = new HashMap<String, Object>();
		Map<String, String> labels = new HashMap<String, String>();
		String purchasePromoCode = bridge.getPurchasePromoCode();
		if (null != purchasePromoCode && !StringUtils.isEmpty(purchasePromoCode)) {
			configMap.put(BridgeConfigConstant.PURCHASING_RENTAL_PROMO_CODE, purchasePromoCode);
		}

		if (null != configs && configs.size() > 0) {
			for (BridgeConfig config : configs) {
				if (!config.getDeleted()) {
					if (config.getKeyName().contains("label.")) {
						if (config.getKeyName().contains("purchaseButton")
								&& ApplicationConstants.BRIDGE_TYPE_INSTITUTIONAL
										.equals(bridge.getBridgeType().getType()))
							continue;
						labels.put(config.getKeyName().substring("label.".length()), config.getKeyValue());
					} else {
						configMap.put(config.getKeyName(), config.getKeyValue());
					}
				}
			}
		}
		if (!bridge.getPendingApproved()) {
			String forgotPasswordUrl = new ApiKeys(ApplicationConstants.getApiMode(), bridge.getApiKey(), null, null)
					.getPasswordUrl();
			configMap.put(ApplicationConstants.BRIDGE_CONFIG_FORGOT_PASSWORD_URL, forgotPasswordUrl);
		}

		if (null != bridge.getBridgeType())
			configMap.put(ApplicationConstants.BRIDGE_CONFIG_COMPANY_TYPE, bridge.getBridgeType().getType());
		configMap.put(ApplicationConstants.BRIDGE_CONFIG_PROTECTED_PASSWORD, bridge.getPasswordProtected().toString());
		configMap.put("labels", labels);
		return configMap;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse updateBridgeConfigForId(SessionStatusVO sessionStatusVO, Integer id,
			Map<String, String> requestMap, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		AdminUser adminUser = adminUserDAO.get(sessionStatusVO.getAdminId());
		adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_STYLING, adminUser);
		Bridge bridge = bridgeDAO.get(id);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}

		Set<BridgeConfig> bridgeConfigs = null;

		if (requestMap != null && requestMap.size() > 0) {
			Iterator<Map.Entry<String, String>> mapIerator = requestMap.entrySet().iterator();

			while (mapIerator.hasNext()) {
				Map.Entry<String, String> entry = mapIerator.next();
				switch (entry.getKey()) {
				case BridgeConfigConstant.PURCHASING_RENTAL_PROMO_CODE:
					bridge.setPurchasePromoCode(entry.getValue());
					mapIerator.remove();
					break;

				case BridgeConfigConstant.PURCHASING_RENTAL_URL:
					bridge.setRentalURL(entry.getValue());
					mapIerator.remove();
					break;

				case BridgeConfigConstant.PURCHASING_TEXT_BOOK_URL:
					bridge.setPrintBookURL(entry.getValue());
					mapIerator.remove();
					break;

				case BridgeConfigConstant.PURCHASING_E_TEXT_URL:
					bridge.setFullURL(entry.getValue());
					mapIerator.remove();
					break;
				}
				bridgeConfigs = bridge.getConfigs();
				if (null != bridgeConfigs && bridgeConfigs.size() > 0) {
					for (BridgeConfig config : bridgeConfigs) {
						if (StringUtils.contains(entry.getKey(), "label")) {
							String key = entry.getKey().replaceFirst("label", "label.");
							if (StringUtils.equals(config.getKeyName(), key)) {
								config.setKeyValue(entry.getValue());
								config.setDeleted(Boolean.FALSE);
								mapIerator.remove();
							}
						} else if (StringUtils.equals(config.getKeyName(), entry.getKey())) {
							config.setKeyValue(entry.getValue());
							config.setDeleted(Boolean.FALSE);
							mapIerator.remove();
						}
					}
				}
			}
			if (requestMap.size() > 0) {
				if (bridgeConfigs == null) {
					bridgeConfigs = new HashSet<BridgeConfig>();
				}
				for (Map.Entry<String, String> entry : requestMap.entrySet()) {
					BridgeConfig newConfig = new BridgeConfig();
					newConfig.setBridge(bridge);
					if (StringUtils.contains(entry.getKey(), "label")) {
						String key = entry.getKey().replaceFirst("label", "label.");
						newConfig.setKeyName(key);
					} else {
						newConfig.setKeyName(entry.getKey());
					}
					newConfig.setKeyValue(entry.getValue());
					bridgeConfigs.add(newConfig);
				}
			}
			bridgeDAO.saveOrUpdate(bridge);
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse deleteBridge(SessionStatusVO sessionStatusVO, Integer bridgeId, HttpServletRequest httpRequest,
			UriInfo uriInfo) throws BridgeException {

		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		AdminUser adminUser = adminUserDAO.get(sessionStatusVO.getAdminId());
		adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_BRIDGE, adminUser);
		if (null != bridgeId) {
			Bridge bridge = bridgeDAO.get(bridgeId);
			if (bridge == null || bridge.getDeleted()) {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}

			bridge.setDeleted(Boolean.TRUE);
			bridge.setDeletedTime(new Date());
			bridge.setDeletedBy(sessionStatusVO.getAdminId());
			bridgeDAO.saveOrUpdate(bridge);
		} else {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}

		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse getBridgeTypes() throws BridgeException {

		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		List<IdValueVO> types = bridgeTypeDAO.getTypes();
		response.setData(types);

		return response;
	}

	private List<BridgeUserResponseVO> getFilteredUserResponseVO(String searchParam, Integer bridgeId) {
		PaginationVO paginationVO= new PaginationVO(null, null, null, null, null, searchParam, null,0);
		this.validateAndRearangePaginationVO(paginationVO, ApplicationConstants.DEFAULT_GET_USER_ORDER_BY_VALUE, Boolean.FALSE);
		return bridgeUserDAO.getUsersForBridge(bridgeId, paginationVO);
		
	}
	
private void validateAndRearangePaginationVO(PaginationVO paginationVo,String defaultOrderBy, Boolean forBook) {
		
		Integer page = paginationVo.getPage();
		if(null==page || page==0){
			paginationVo.setPage(ApplicationConstants.DEFAULT_GET_BOOK_PAGE_VALUE);
		}
		
		Integer limit = paginationVo.getLimit();
		if(null==limit || limit==0){
			paginationVo.setLimit(ApplicationConstants.DEFAULT_GET_BOOK_LIMIT_VALUE);
		}
		
		String orderby = paginationVo.getOrderBy();
		if(forBook){
			if(!StringUtils.isEmpty(orderby) && !ApplicationConstants.validBookOrderByValues.contains(orderby)){
				throw new BridgeException(ApplicationCode.INVALID_ORDERBY_FIELD);
			}
		}else{
			if(!StringUtils.isEmpty(orderby) && !ApplicationConstants.validUsersOrderByValues.contains(orderby)){
				throw new BridgeException(ApplicationCode.INVALID_ORDERBY_FIELD);
			}
		}
		
		if(null == orderby || StringUtils.isEmpty(orderby)){
			paginationVo.setOrderBy(defaultOrderBy);
		}
		
		String order = paginationVo.getOrder();
		if(null == order || StringUtils.isEmpty(order)){
			paginationVo.setOrder(ApplicationConstants.DEFAULT_GET_BOOK_ORDER_VALUE);
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse deleteBridgeUsers(SessionStatusVO sessionStatusVO, Integer bridgeId,
			List<Integer> usersToRemove, Boolean deleteAll, String search, Boolean isUngrouped) throws BridgeException, ParseException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if (null != bridgeId) {

			Bridge bridge = bridgeDAO.get(bridgeId);
			Integer loggedInUser = sessionStatusVO.getAdminId();
			if (bridge == null || bridge.getDeleted()) {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			Date currentDate = new Date();
			List<Integer> userIds = new ArrayList<Integer>();
			if (null != deleteAll && deleteAll) {
				List<BridgeUser> bridgeUsers = new ArrayList<BridgeUser>();
				List<BridgeUserResponseVO> allFilteredBridgeUsers =this.getFilteredUserResponseVO(search, bridgeId);
				isUngrouped=isUngrouped!=null ?isUngrouped :Boolean.FALSE;
				if (null != allFilteredBridgeUsers && allFilteredBridgeUsers.size() > 0) {
					for (BridgeUserResponseVO userResponseVo : allFilteredBridgeUsers) {
						BridgeUser user = bridgeUserDAO.get(userResponseVo.getId());						
						if(isUngrouped){							
							if (bridge.getIsIntegrated()) {
								if (StringUtils.isNotEmpty(user.getTenantUserId()))
									continue;
							}
							List<BridgeGroup> userGroups = bridgeGroupUserDAO.getGroupsForUser(userResponseVo.getId(), Boolean.FALSE, Boolean.TRUE, Boolean.TRUE);
							if(userGroups.isEmpty()){
								user.setDeleted(currentDate);
								user.setDeletedBy(loggedInUser);
								bridgeUsers.add(user);
								userIds.add(user.getId());
							}						
						}else{
							if (bridge.getIsIntegrated()) {
								if (StringUtils.isNotEmpty(user.getTenantUserId()))
									continue;
							}
							user.setDeleted(currentDate);
							user.setDeletedBy(loggedInUser);
							bridgeUsers.add(user);
							userIds.add(user.getId());
					}
					}
					bridgeUserDAO.saveOrUpdateAll(bridgeUsers);
					if(null != userIds && userIds.size()>0){
					List<GroupUser> groupUserList = bridgeGroupUserDAO.getBridgeGroupUsers(bridgeId, userIds);
					if (groupUserList != null && groupUserList.size() > 0) {
						for (GroupUser groupUser : groupUserList) {
							groupUser.setSelected(Boolean.FALSE);
						}
						bridgeGroupUserDAO.saveOrUpdateAll(groupUserList);
					}
				}
				}
			} else if (null != usersToRemove && usersToRemove.size() > 0) {
				for (Integer userId : usersToRemove) {
					BridgeUser bridgeUser = bridgeUserDAO.get(userId);
					if (bridgeUser == null) {
						throw new BridgeException(ApplicationCode.USER_NOT_FOUND);
					}
					bridgeUser.setDeleted(currentDate);
					bridgeUser.setDeletedBy(loggedInUser);
					bridgeUserDAO.saveOrUpdate(bridgeUser);
					userIds.add(bridgeUser.getId());
				}
				List<GroupUser> groupUserList = bridgeGroupUserDAO.getBridgeGroupUsers(bridgeId, userIds);
				if (groupUserList != null && groupUserList.size() > 0) {
					for (GroupUser groupUser : groupUserList) {
						groupUser.setSelected(Boolean.FALSE);
					}
					bridgeGroupUserDAO.saveOrUpdateAll(groupUserList);
				}
			}
			if((bridge.getKeysRequired()|| bridge.getDerefedSignIn()|| bridge.getIsRostered()) && userIds !=null){
				for(Integer userId:userIds){
					List<BridgeUserKey> bridgeUserKeyList = bridgeUserKeyDao.getListOfKeysAssigedForUser(userId);
					for(BridgeUserKey bridgeUserKey:bridgeUserKeyList){
						bridgeUserKey.setDeleted(Boolean.TRUE);
						bridgeUserKeyDao.saveOrUpdate(bridgeUserKey);
					}
				}
			}
		} else {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}

		return response;
	}

	private List<? extends BridgeAdminResponseVO> populateBridgeResponseVOFromBridgeEntities(AdminUser adminUser,
			List<Bridge> bridges, Boolean isSuperAdmin) {

		List<BridgeAdminResponseVO> bridgeAdminVOResponseList = new ArrayList<BridgeAdminResponseVO>();
		if (null != bridges && bridges.size() > 0) {
			for (Bridge bridge : bridges) {
				BridgeAdminResponseVO bridgeResponseVO = null;
				if (isSuperAdmin) {
					bridgeResponseVO = new BridgeSuperAdminResponseVO();
					((BridgeSuperAdminResponseVO) bridgeResponseVO).setApiKey(adminUserServiceUtil.maskApiKey(bridge.getApiKey()));
				} else {
					bridgeResponseVO = new BridgeAdminResponseVO();
				}
				Boolean isPending = bridge.getPendingApproved() || bridge.getApiKey() == null
						|| StringUtils.isEmpty(bridge.getApiKey()) ? Boolean.TRUE : Boolean.FALSE;
				bridgeResponseVO.setIsPending(isPending);
				bridgeResponseVO.setId(bridge.getId());
				bridgeResponseVO.setName(bridge.getName());
				bridgeResponseVO.setLanguage(bridge.getLanguage());
				bridgeResponseVO.setCompany(bridge.getCompany().getId());
				bridgeResponseVO.setCompanyName(bridge.getCompany().getName());
				bridgeResponseVO.setDomain(bridge.getCode() + bridgeDomainPostfix.get(0));
				bridgeResponseVO.setContactEmail(bridge.getEmail());
				bridgeResponseVO.setContactName(bridge.getContactName());
				bridgeResponseVO.setContactPhone(bridge.getContactNo());

				bridgeResponseVO.setPassword(bridge.getPassword());
				bridgeResponseVO.setIsPasswordProtected(bridge.getPasswordProtected());
				if (null != bridge.getBridgeType()) {
					bridgeResponseVO.setBridgeType(bridge.getBridgeType().getType());
				}
				bridgeResponseVO.setBookshelfUrl(bridge.getBookshelfUrl());
				AdminUser creator = bridge.getLastModifier();
				bridgeResponseVO.setLastEditor(
						com.vst.bridge.StringUtils.getFullName(creator.getFirstName(), creator.getLastName()));

				bridgeResponseVO.setLastUpdatedDate(bridge.getModifiedDate());
				bridgeResponseVO.setLastUpdated(bridge.getModifiedDate().getTime());
				AdminFavoriteBridge favoriteBridge = adminFavoriteBridgesDAO
						.checkAdminFavoriteBridgeExist(adminUser.getId(), bridge.getId(), Boolean.FALSE);
				bridgeResponseVO.setIsFavorite(favoriteBridge != null ? Boolean.TRUE : Boolean.FALSE);
				bridgeResponseVO.setCode(bridge.getCode());
				bridgeResponseVO.setAlias(bridge.getDomainAlias());

				bridgeResponseVO.setIsRostored(bridge.getIsRostered());

				// Added on 24-03-2016 to resolve UI allowances tab multiple
				// calls
				Set<BridgeConfig> configs = new HashSet<BridgeConfig>(
						bridgeConfigDAO.getAllConfigForBridgeId(bridge.getId()));
				Map<String, Object> configVo = populateBridgeConfigResponseMapFromConfigs(configs, bridge);
				bridgeResponseVO.setConfig(configVo);

				bridgeResponseVO.setIntegrations(populateIntigrationVoFromBridge(bridge));

				bridgeResponseVO.setIsDefered(bridge.getDerefedSignIn());

				bridgeResponseVO.setKeysRequired(bridge.getKeysRequired());

				bridgeResponseVO.setTrialCredits(bridge.getTrialCredits());

				bridgeResponseVO.setRentalCredits(bridge.getRentalCredits());

				bridgeResponseVO.setFullCredits(bridge.getFullCredits());

				if (null != bridge.getTrialDays() || null != bridge.getTrialExpires()) {
					bridgeResponseVO.setTrialsDays(bridge.getTrialDays());
					bridgeResponseVO.setTrialExpires(bridge.getTrialExpires());
				} else {
					bridgeResponseVO.setTrialsDays(30);
				}

				if (null != bridge.getRentalDays() || null != bridge.getRentalExpires()) {
					bridgeResponseVO.setRentalsDays(bridge.getRentalDays());
					bridgeResponseVO.setRentalExpires(bridge.getRentalExpires());
				} else {
					bridgeResponseVO.setRentalsDays(30);
				}

				if (null != bridge.getFullDays() || null != bridge.getFullExpires()) {
					bridgeResponseVO.setFullDays(bridge.getFullDays());
					bridgeResponseVO.setFullExpires(bridge.getFullExpires());
				} else {
					bridgeResponseVO.setFullDays(365);
				}

				if (null != bridge.getOfflineTrialDays() || null != bridge.getOfflineTrialExpires()) {
					bridgeResponseVO.setOfflineTrialDays(bridge.getOfflineTrialDays());
					bridgeResponseVO.setOfflineTrialExpires(bridge.getOfflineTrialExpires());
				} else {
					bridgeResponseVO.setOfflineTrialDays(30);
				}

				if (null != bridge.getOfflineRentalDays() || null != bridge.getOfflineRentalExpires()) {
					bridgeResponseVO.setOfflineRentalDays(bridge.getOfflineRentalDays());
					bridgeResponseVO.setOfflineRentalExpires(bridge.getOfflineRentalExpires());
				} else {
					bridgeResponseVO.setOfflineRentalDays(30);
				}

				if (null != bridge.getOfflineFullDays() || null != bridge.getOfflineFullExpires()) {
					bridgeResponseVO.setOfflineFullDays(bridge.getOfflineFullDays());
					bridgeResponseVO.setOfflineFullExpires(bridge.getOfflineFullExpires());
				} else {
					bridgeResponseVO.setOfflineFullDays(365);
				}
				bridgeResponseVO.setIsConcurrencyEnabled(bridge.getConcurrencyEnabled());
				if (bridge.getConcurrencyEnabled()) {

					bridgeResponseVO.setConcCredits(bridge.getConcurrencyCredits());

					if (null != bridge.getConcurrencyDays() || null != bridge.getConcurrencyExpires()) {
						bridgeResponseVO.setConcDays(bridge.getConcurrencyDays());
						bridgeResponseVO.setConcExpires(bridge.getConcurrencyExpires());
					} else {
						bridgeResponseVO.setConcDays(30);
					}
					if (null != bridge.getOfflineConcurrencyDays() || null != bridge.getOfflineConcurrencyExpires()) {
						bridgeResponseVO.setOfflineConcDays(bridge.getOfflineConcurrencyDays());
						bridgeResponseVO.setOfflineConcExpires(bridge.getOfflineConcurrencyExpires());
					} else {
						bridgeResponseVO.setOfflineConcDays(30);
					}
					if (null != bridge.getCodeType()) {
						bridgeResponseVO.setConcCompType(bridge.getCodeType().getType());
					} else {
						bridgeResponseVO.setConcCompType(ApplicationConstants.REDEEM_TYPE_COMP);
					}
				}

				bridgeResponseVO.setConcurrencyLimit(bridge.getConcurrencyLimit());
				bridgeResponseVO.setIsIntegrated(bridge.getIsIntegrated());
				bridgeResponseVO.setBcTenantId(bridge.getBcTenantId());
				bridgeResponseVO.setConnectCompany(bridge.getConnectCompany());
				bridgeResponseVO.setBusinessCenterTenant(bridge.getBcTenantName());
				bridgeResponseVO.setIsSampler(bridge.getIsSampler());
				bridgeResponseVO.setIntegrationRedirectUrl(bridge.getIntegrationRedirectUrl());
				bridgeResponseVO.setIsPurchasesEnabled(bridge.getIsPurchasesEnabled());
				bridgeResponseVO.setIsEmbeddedEnabled(bridge.getIsEmbeddedEnabled());
				this.populateAllowanceFlag(bridge,bridgeResponseVO);
				bridgeAdminVOResponseList.add(bridgeResponseVO);
			}
		}
		return bridgeAdminVOResponseList;
	}

	private void populateAllowanceFlag(Bridge bridge, BridgeAdminResponseVO bridgeResponseVO) {
		
		Boolean isAllowanceSet=Boolean.FALSE;
		if(bridge!=null && bridge.getDerefedSignIn()){
			List<BridgeEntitlement> allowanceList= bridgeEntitlementDAO.getBridgeEntitlements(bridge.getId());
			if(allowanceList!=null && allowanceList.size()>0){
				isAllowanceSet=Boolean.TRUE;
			}
			else if(bridge!=null && bridge.getDerefedSignIn() && bridge.getConcurrencyEnabled()){
				if(bridge.getConcurrencyCredits()!=null && bridge.getConcurrencyCredits()!=0)
					isAllowanceSet=Boolean.TRUE;
			}
			
		}
		
		bridgeResponseVO.setIsAllowanceSet(isAllowanceSet);
		
		
	}

	private TenantVO getBusinessCenterTenant(Integer bcTenantId, String apiKey)
			throws BusinessCenterException, JsonParseException, JsonMappingException, IOException {
		RestResponse bcResponse = businessCenterServices.getTenant(bcTenantId, apiKey);
		return (TenantVO) bcResponse.getData();

	}

	private void refreshBooksForBridge(final Integer id, final String apiKey) {
		final Runnable runnable = new Runnable() {

			@Override
			public void run() {
				try {
					logger.info("refreshBooksForBridge : Refreshing books for bridge Id = {}", id);
					bookServices.refreshBookCache(id, apiKey);
					logger.info("refreshBooksForBridge : Refreshing completed");
				} catch (BridgeException e) {
					e.printStackTrace();
				} catch (ConnectApiException e) {
					e.printStackTrace();
				} catch (ConnectApiXmlException e) {
					e.printStackTrace();
				} catch (ConnectApiHttpException e) {
					e.printStackTrace();
				}
			}
		};
		this.executor.execute(runnable);

	}

	/**** Email Notification method 
	 * @param url *******/
	private void sendBridgeCreatedEmail(final BridgeAdminResponseVO bridgeResponseVo,
			final List<AdminInfoVo> superAdmins, final String url) {

		final Runnable runnable = new Runnable() {

			@Override
			public void run() {
				Map<String, Object> paramMap = new HashMap<String, Object>();
				if (null != superAdmins && superAdmins.size() > 0) {
					for (AdminInfoVo adminInfo : superAdmins) {
						paramMap.put(ApplicationConstants.NEW_BRIDGE_TO, adminInfo.getEmail());
						paramMap.put(ApplicationConstants.NEW_BRIDGE_TO_NAME, adminInfo.getName());
						paramMap.put(ApplicationConstants.NEW_BRIDGE_NAME, bridgeResponseVo.getName());
						paramMap.put(ApplicationConstants.NEW_BRIDGE_CONTACT_NAME, bridgeResponseVo.getContactName());
						paramMap.put(ApplicationConstants.NEW_BRIDGE_CONTACT_MAIL, bridgeResponseVo.getContactEmail());
						paramMap.put(ApplicationConstants.NEW_BRIDGE_CONTACT_PHONE, bridgeResponseVo.getContactPhone());
						paramMap.put(ApplicationConstants.NEW_BRIDGE_DOMAIN, bridgeResponseVo.getDomain());
						paramMap.put(ApplicationConstants.NEW_BRIDGE_COMPANY_NAME, bridgeResponseVo.getCompanyName());
						paramMap.put(ApplicationConstants.NEW_BRIDGE_TYPE, bridgeResponseVo.getBridgeType());
						emailHandler.sendEmail(TemplateLocationConstants.NEW_BRIDGE_NOTIFICATION_TEMPLATE, paramMap);
					}
					paramMap.put(ApplicationConstants.CODE, bridgeResponseVo);
					paramMap.put(ApplicationConstants.URL_COMPANY, url);
					emailHandler.sendHipChatNotification(TemplateLocationConstants.HIPCHAT_NOTIFICATION, paramMap);
				}

			}
		};
		this.executor.execute(runnable);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getAdminLabels(HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		response.setData(adminUserLabelDAO.getListOfLabels());
		return response;
	}

}
