package com.vst.bridge.rest.response.vo.user;

import java.util.Date;

public class AccessCodeResponseVO {
	
	private String redeemCode;
	private Date expires;
	public String getRedeemCode() {
		return redeemCode;
	}
	public void setRedeemCode(String redeemCode) {
		this.redeemCode = redeemCode;
	}
	public Date getExpires() {
		return expires;
	}
	public void setExpires(Date expires) {
		this.expires = expires;
	}

}
