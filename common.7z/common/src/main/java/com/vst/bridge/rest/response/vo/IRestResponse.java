package com.vst.bridge.rest.response.vo;

import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;

public interface IRestResponse {
	public Response buildResponseWithCookies(NewCookie...cookies);
	public Response buildResponse();
}
