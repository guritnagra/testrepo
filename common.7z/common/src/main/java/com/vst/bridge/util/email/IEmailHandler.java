package com.vst.bridge.util.email;

import java.util.Map;

import com.vst.bridge.util.exception.BridgeException;

public interface IEmailHandler {
	public void sendEmail(final String templateName,final Map<String, Object> paramMap)throws BridgeException;
}
