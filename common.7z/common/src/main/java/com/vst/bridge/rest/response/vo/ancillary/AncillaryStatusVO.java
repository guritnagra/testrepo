package com.vst.bridge.rest.response.vo.ancillary;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AncillaryStatusVO {
	

	private String virusScan;
	private String uploaded;
	private String statusMessage;
	
	@JsonProperty(value="virus_scan", required=true)
	public String getVirusScan() {
		return virusScan;
	}
	public void setVirusScan(String virusScan) {
		this.virusScan = virusScan;
	}
	@JsonProperty(value="uploaded", required=true)
	public String getUploaded() {
		return uploaded;
	}
	public void setUploaded(String uploaded) {
		this.uploaded = uploaded;
	}
	@JsonProperty(value="status_message", required=true)
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	
	

}
