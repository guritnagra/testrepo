package com.vst.bridge.dao.admin;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.user.AdminFavoriteBridge;
import com.vst.bridge.util.exception.BridgeException;

@Repository("adminFavoriteBridgesDAO")
public class AdminFavoriteBridgesDAOImpl extends GenericDAO<AdminFavoriteBridge, Integer> implements IAdminFavoriteBridgesDAO{

	public AdminFavoriteBridgesDAOImpl() {
		super(AdminFavoriteBridge.class);
	}

	@Override
	public AdminFavoriteBridge checkAdminFavoriteBridgeExist(Integer adminId,
			Integer bridgeId,Boolean getDeleted) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("user.id", adminId));
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		if(null != getDeleted){
			criteria.add(Restrictions.eq("deleted", getDeleted));
		}
		List<AdminFavoriteBridge> result = executeCriteira(criteria);
		return null!= result && result.size() > 0 ?  result.get(0): null;
	}
}
