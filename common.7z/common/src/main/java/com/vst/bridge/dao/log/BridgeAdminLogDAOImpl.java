package com.vst.bridge.dao.log;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.log.BridgeAdminLog;
import com.vst.bridge.rest.response.vo.report.BookLaunchCountVO;
import com.vst.bridge.util.constant.ApplicationAction;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeAdminLogDAO")
public class BridgeAdminLogDAOImpl extends GenericDAO<BridgeAdminLog, Integer> implements IBridgeAdminLogDAO{

	public BridgeAdminLogDAOImpl() {
		super(BridgeAdminLog.class);
	}

	@Override
	public List<String> getUploadsForAdmin(final Integer bridgeId,final AdminUser admin)throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.like("admin.id", admin.getId()));	
		criteria.add(Restrictions.like("action", ApplicationAction.ANCILLARY_UPLOAD.getCodeId()));
		
		criteria.setProjection(Projections.projectionList()
				.add(Projections.property("value")));
		return executeCriteira(criteria);
	}

	@Override
	public Integer getGetCountForAction(Integer bridgeId, String action,String vbid, Date startDate, Date endDate) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		if(null != vbid){
			criteria.add(Restrictions.like("value", vbid));
		}
		if(null != startDate && endDate != null){
			criteria.add(Restrictions.between("createdDate", startDate, endDate));
		}
		criteria.add(Restrictions.like("action", action));
		criteria.setProjection(Projections.rowCount());
		Long count = (Long) criteria.uniqueResult();
		return count != null && count > 0 ? count.intValue() : 0;
	}

	@Override
	public List<Integer> getBridgeLogsForAction(Integer bridgeId, String action, Boolean distonctUsers, Date startDate, Date endDate)
			throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.like("action", action));
		if(null != startDate && endDate != null){
			criteria.add(Restrictions.between("createdDate", startDate, endDate));
		}
		if(distonctUsers){
			criteria.setProjection(Projections.projectionList()
												.add(Projections.groupProperty("admin.id")));
		}else{
			criteria.setProjection(Projections.projectionList()
					.add(Projections.property("admin.id")));
		}
		return executeCriteira(criteria);
	}

	@Override
	public List<String> getBridgeLogsForAdminUser(final Integer bridgeId,final AdminUser adminUser)throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("admin.id", adminUser.getId()));
		criteria.setProjection(Projections.projectionList()
				.add(Projections.property("value")));
		return executeCriteira(criteria);
	}

	@Override
	public List<BookLaunchCountVO> getAncillariesUploaded(Integer bridgeId, Date startDate, Date endDate) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.like("action", ApplicationAction.ANCILLARY_UPLOAD.getCodeId()));
		
		if(null != startDate && endDate != null){
			criteria.add(Restrictions.between("createdDate", startDate, endDate));
		}
		
		criteria.setProjection(Projections.projectionList()
				.add(Projections.count("value").as("count"))
				.add(Projections.groupProperty("value").as("vbid")))
				.setResultTransformer(new AliasToBeanResultTransformer(BookLaunchCountVO.class));;
				List<BookLaunchCountVO> result = executeCriteira(criteria);
		return result;
	}
}
