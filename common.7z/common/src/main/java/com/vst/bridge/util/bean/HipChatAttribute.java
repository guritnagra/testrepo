package com.vst.bridge.util.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class HipChatAttribute {
	private String label;
	private HipChatValue value;
	
	public HipChatAttribute() {
		this.value = new HipChatValue();
	}

	@JsonProperty(value = "label", required = true)
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	@JsonProperty(value = "value", required = true)
	public HipChatValue getValue() {
		return value;
	}

	public void setValue(HipChatValue value) {
		this.value = value;
	}

}
