package com.vst.bridge.dao.log;

import java.util.Date;
import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.log.BridgeLog;
import com.vst.bridge.rest.response.vo.report.BookLaunchCountVO;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeLogDAO extends IGenericDAO<BridgeLog, Integer>{
	
	public Integer getTotalActivationsForBook(final Integer bridgeId,final String vbid)throws BridgeException;
	
	public Integer getTotalIntigrationForBook(final Integer bridgeId,final String vbid)throws BridgeException;

	public Integer getGetCountForAction(Integer id, String action,String vbid, Date startDate, Date endDate)throws BridgeException;
	
	public List<Integer> getBridgeLogsForAction(final Integer bridgeId,final String action,final Boolean distonctUsers, Date startDate, Date endDate)throws BridgeException;
	
	public List<String> getBridgeLogsForKeyRedeemed(final Integer bridgeId,final Boolean distonctUsers)throws BridgeException;
	
	public List<BookLaunchCountVO> getBookLaunched(final Integer bridgeId,final Date startDate, final Date endDate)throws BridgeException;
	
}
