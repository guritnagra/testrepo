package com.vst.bridge.dao.role;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.user.Role;
import com.vst.bridge.util.exception.BridgeException;

public interface IRoleDAO extends IGenericDAO<Role,Integer>{
	
	public Role getRoleByName(String role) throws BridgeException;

}
