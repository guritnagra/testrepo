package com.vst.bridge.rest.response;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

public class HtmlResponse extends RestResponse
{

	public static HtmlResponse instance(Response.Status code, String text)
	{
		return new HtmlResponse(code,text);
	}
	
	public static HtmlResponse redirect(Response.Status code, String text, String url)
	{
		return new HtmlResponse(code,text);
	}
	
	public static HtmlResponse instance(Response.Status code, String text, String filename)
	{
		return new HtmlResponse(code,text, filename);
	}
	
	private HtmlResponse(Response.Status code, String text)
	{
		this.code = code;
		this.text = text;
	}
	
	private HtmlResponse(Response.Status code, String text, String filename)
	{
		this.code = code;
		this.text = text;
		this.filename = filename;
	}

	public Response build(HttpServletRequest hsr) 
	{
		ResponseBuilder rb = Response.status(this.getCode()).entity(this.getText());
		
		for(NewCookie cookie: this.cookies) {
			rb.cookie(cookie);
		}
		
		rb.header("Content-Type", "text/html");
		
	    if(filename!=null)
	    {
	    	
			rb.header("Content-Disposition","attachment; filename=\"" + filename + "\"");
	    }
		
		return rb.build();
	}

}
