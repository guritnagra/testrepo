package com.vst.bridge.rest.response.vo.bridge;

import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.vst.bridge.annotation.custom.CustomDateSerializer;
import com.vst.bridge.rest.response.vo.EmptyObject;

public class BridgeAdminResponseVO{
	private Integer id;
	private String name;
	private String language;
	private String code;
	private String domain;
	private Integer company;
	private String companyName;
	//private String companyType;
	private String contactEmail;
	private String contactName;
	private String contactPhone;
	private Boolean isFavorite;
	private String lastEditor;
	private Date lastUpdatedDate;
	private Long lastUpdated;
	private String alias;
	
	private Boolean isPending;
	private Boolean isPasswordProtected;
	private String password;
	private String bridgeType;
	private String bookshelfUrl;
	
	private Boolean isDefered;
	
	private Boolean isRostored;
	
	private Boolean keysRequired;
	
	private Object config = new EmptyObject();
	
	private Object integrations = new EmptyObject();
	
	private Integer trialsDays;
	private Integer rentalsDays;
	private Integer fullDays;
	private Date trialExpires;
	private Date rentalExpires;
	private Date fullExpires;
	
	private Integer trialCredits;
	private Integer rentalCredits;
	private Integer fullCredits;
	
	private Integer offlineTrialDays;
	private Date offlineTrialExpires;
	private Integer offlineRentalDays;
	private Date offlineRentalExpires;
	private Integer offlineFullDays;
	private Date offlineFullExpires;
	
	private Integer concurrencyLimit;
	private Boolean isConcurrencyEnabled;
	
	private Integer concCredits;
	private Integer concDays;
	private Integer offlineConcDays;
	private Date concExpires;
	private Date offlineConcExpires;
	private String concCompType;
	private Boolean isIntegrated;
	private Integer bcTenantId;
	private String businessCenterTenant;
	private String connectCompany;
	private Boolean isSampler;
	private String integrationRedirectUrl;
	private Boolean isPurchasesEnabled;
	private Boolean isAllowanceSet;
	private Boolean isEmbeddedEnabled;
		
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public Integer getCompany() {
		return company;
	}
	public void setCompany(Integer company) {
		this.company = company;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	/*public String getCompanyType() {
		return companyType;
	}
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}*/
	public String getContactEmail() {
		return contactEmail;
	}
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public String getContactPhone() {
		return contactPhone;
	}
	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}
	public Boolean getIsFavorite() {
		return isFavorite;
	}
	public void setIsFavorite(Boolean isFavorite) {
		this.isFavorite = isFavorite;
	}

	public String getLastEditor() {
		return lastEditor;
	}
	public void setLastEditor(String lastEditor) {
		this.lastEditor = lastEditor;
	}
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public Long getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(Long lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	
	public Boolean getIsPending() {
		return isPending;
	}
	public void setIsPending(Boolean isPending) {
		this.isPending = isPending;
	}
	public Boolean getIsPasswordProtected() {
		return isPasswordProtected;
	}
	public void setIsPasswordProtected(Boolean isPasswordProtected) {
		this.isPasswordProtected = isPasswordProtected;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getBridgeType() {
		return bridgeType;
	}
	public void setBridgeType(String bridgeType) {
		this.bridgeType = bridgeType;
	}
	public String getBookshelfUrl() {
		return bookshelfUrl;
	}
	public void setBookshelfUrl(String bookshelfUrl) {
		this.bookshelfUrl = bookshelfUrl;
	}
	public Object getConfig() {
		return config;
	}
	public void setConfig(Object config) {
		this.config = config;
	}
	public Object getIntegrations() {
		return integrations;
	}
	public void setIntegrations(Object integrations) {
		this.integrations = integrations;
	}
	public Boolean getIsDefered() {
		return isDefered;
	}
	public void setIsDefered(Boolean isDefered) {
		this.isDefered = isDefered;
	}
	public Boolean getKeysRequired() {
		return keysRequired;
	}
	public void setKeysRequired(Boolean keysRequired) {
		this.keysRequired = keysRequired;
	}
	public Integer getTrialsDays() {
		return trialsDays;
	}
	public void setTrialsDays(Integer trialsDays) {
		this.trialsDays = trialsDays;
	}
	public Integer getRentalsDays() {
		return rentalsDays;
	}
	public void setRentalsDays(Integer rentalsDays) {
		this.rentalsDays = rentalsDays;
	}
	public Integer getFullDays() {
		return fullDays;
	}
	public void setFullDays(Integer fullDays) {
		this.fullDays = fullDays;
	}
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getTrialExpires() {
		return trialExpires;
	}
	public void setTrialExpires(Date trialExpires) {
		this.trialExpires = trialExpires;
	}
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getRentalExpires() {
		return rentalExpires;
	}
	public void setRentalExpires(Date rentalExpires) {
		this.rentalExpires = rentalExpires;
	}
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getFullExpires() {
		return fullExpires;
	}
	public void setFullExpires(Date fullExpires) {
		this.fullExpires = fullExpires;
	}
	public Integer getTrialCredits() {
		return trialCredits;
	}

	public void setTrialCredits(Integer trialCredits) {
		this.trialCredits = trialCredits;
	}

	public Integer getRentalCredits() {
		return rentalCredits;
	}

	public void setRentalCredits(Integer rentalCredits) {
		this.rentalCredits = rentalCredits;
	}

	public Integer getFullCredits() {
		return fullCredits;
	}

	public void setFullCredits(Integer fullCredits) {
		this.fullCredits = fullCredits;
	}
	public Integer getOfflineTrialDays() {
		return offlineTrialDays;
	}
	public void setOfflineTrialDays(Integer offlineTrialDays) {
		this.offlineTrialDays = offlineTrialDays;
	}
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getOfflineTrialExpires() {
		return offlineTrialExpires;
	}
	public void setOfflineTrialExpires(Date offlineTrialExpires) {
		this.offlineTrialExpires = offlineTrialExpires;
	}
	public Integer getOfflineRentalDays() {
		return offlineRentalDays;
	}
	public void setOfflineRentalDays(Integer offlineRentalDays) {
		this.offlineRentalDays = offlineRentalDays;
	}
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getOfflineRentalExpires() {
		return offlineRentalExpires;
	}
	public void setOfflineRentalExpires(Date offlineRentalExpires) {
		this.offlineRentalExpires = offlineRentalExpires;
	}
	public Integer getOfflineFullDays() {
		return offlineFullDays;
	}
	public void setOfflineFullDays(Integer offlineFullDays) {
		this.offlineFullDays = offlineFullDays;
	}
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getOfflineFullExpires() {
		return offlineFullExpires;
	}
	public void setOfflineFullExpires(Date offlineFullExpires) {
		this.offlineFullExpires = offlineFullExpires;
	}
	public Boolean getIsRostored() {
		return isRostored;
	}
	public void setIsRostored(Boolean isRostored) {
		this.isRostored = isRostored;
	}

	public Integer getConcurrencyLimit() {
		return concurrencyLimit;
	}

	public void setConcurrencyLimit(Integer concurrencyLimit) {
		this.concurrencyLimit = concurrencyLimit;
	}
	public Boolean getIsConcurrencyEnabled() {
		return isConcurrencyEnabled;
	}
	public void setIsConcurrencyEnabled(Boolean isConcurrencyEnabled) {
		this.isConcurrencyEnabled = isConcurrencyEnabled;
	}
	public Integer getConcCredits() {
		return concCredits;
	}
	public void setConcCredits(Integer concCredits) {
		this.concCredits = concCredits;
	}
	public Integer getConcDays() {
		return concDays;
	}
	public void setConcDays(Integer concDays) {
		this.concDays = concDays;
	}
	public Integer getOfflineConcDays() {
		return offlineConcDays;
	}
	public void setOfflineConcDays(Integer offlineConcDays) {
		this.offlineConcDays = offlineConcDays;
	}
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getConcExpires() {
		return concExpires;
	}
	public void setConcExpires(Date concExpires) {
		this.concExpires = concExpires;
	}
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getOfflineConcExpires() {
		return offlineConcExpires;
	}
	public void setOfflineConcExpires(Date offlineConcExpires) {
		this.offlineConcExpires = offlineConcExpires;
	}
	public String getConcCompType() {
		return concCompType;
	}
	public void setConcCompType(String concCompType) {
		this.concCompType = concCompType;
	}
	public Boolean getIsIntegrated() {
		return isIntegrated;
	}
	public void setIsIntegrated(Boolean isIntegrated) {
		this.isIntegrated = isIntegrated;
	}
	public Integer getBcTenantId() {
		return bcTenantId;
	}
	public void setBcTenantId(Integer bcTenantId) {
		this.bcTenantId = bcTenantId;
	}
	public String getConnectCompany() {
		return connectCompany;
	}
	public void setConnectCompany(String connectCompany) {
		this.connectCompany = connectCompany;
	}
	public String getBusinessCenterTenant() {
		return businessCenterTenant;
	}
	public void setBusinessCenterTenant(String businessCenterTenant) {
		this.businessCenterTenant = businessCenterTenant;
	}
	public Boolean getIsSampler() {
		return isSampler;
	}
	public void setIsSampler(Boolean isSampler) {
		this.isSampler = isSampler;
	}
	public String getIntegrationRedirectUrl() {
		return integrationRedirectUrl;
	}
	public void setIntegrationRedirectUrl(String integrationRedirectUrl) {
		this.integrationRedirectUrl = integrationRedirectUrl;
	}
	public Boolean getIsPurchasesEnabled() {
		return isPurchasesEnabled;
	}
	public void setIsPurchasesEnabled(Boolean isPurchasesEnabled) {
		this.isPurchasesEnabled = isPurchasesEnabled;
	}
	public Boolean getIsAllowanceSet() {
		return isAllowanceSet;
	}
	public void setIsAllowanceSet(Boolean isAllowanceSet) {
		this.isAllowanceSet = isAllowanceSet;
	}
	public Boolean getIsEmbeddedEnabled() {
		return isEmbeddedEnabled;
	}
	public void setIsEmbeddedEnabled(Boolean isEmbeddedEnabled) {
		this.isEmbeddedEnabled = isEmbeddedEnabled;
	}
	
	
	
}
