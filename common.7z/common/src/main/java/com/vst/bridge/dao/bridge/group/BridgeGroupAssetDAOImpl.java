package com.vst.bridge.dao.bridge.group;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.group.GroupAsset;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.BridgeException;


@Repository("bridgeGroupAssetDAO")
public class BridgeGroupAssetDAOImpl extends GenericDAO<GroupAsset, Integer> implements IBridgeGroupAssetDAO{

	public BridgeGroupAssetDAOImpl() {
		super(GroupAsset.class);
	}

	@Override
	public List<GroupAsset> getAllBooksForGroup(Integer groupId) throws BridgeException{
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("group.id", groupId));
		criteria.add(Restrictions.eq("selected", Boolean.TRUE));
		return executeCriteira(criteria);
	}

	@Override
	public List<GroupAsset> getAllBooksForGroupIncludeDeleted(Integer groupId) throws BridgeException{
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("group.id", groupId));
		return executeCriteira(criteria);
	}

	@Override
	public GroupAsset getGroupAsset(Integer groupId, String vbid) throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("group.id", groupId));
		criteria.add(Restrictions.like("vbid", vbid));
		//criteria.add(Restrictions.eq("selected", Boolean.TRUE));
		List<GroupAsset> results = executeCriteira(criteria);
		return null != results && results.size() > 0 ? results.get(0) : null;
	}
	@Override
	public GroupAsset getGroupAssetIncludingDeleted(Integer groupId, String vbid) throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("group.id", groupId));
		criteria.add(Restrictions.like("vbid", vbid));
		List<GroupAsset> results = executeCriteira(criteria);
		return null != results && results.size() > 0 ? results.get(0) : null;
	}

	@Override
	public List<String> getVbidsForGroupIds(Integer bridgeId, List<Integer> groupIds) throws BridgeException {

		List<String> vbids = null;
		if(null != groupIds && groupIds.size()>0){
			Criteria criteria= getCriteria();
			criteria.createAlias("group", "groupAlias");
			criteria.add(Restrictions.eq("groupAlias.bridge.id", bridgeId));
			criteria.add(Restrictions.in("group.id", groupIds));
			criteria.add(Restrictions.eq("selected", Boolean.TRUE));
			criteria.add(Restrictions.eq("groupAlias.deleted", Boolean.FALSE));

		Criterion criteria1 = Restrictions.gt("groupAlias.expiredDate", new Date());
		Criterion criteria2 = Restrictions.isNull("groupAlias.expiredDate");
		Criterion disjuctionCriteria = Restrictions.disjunction()
										.add(criteria1)
										.add(criteria2);
		criteria.add(disjuctionCriteria);			

			criteria.setProjection(Projections.property("vbid"));
			vbids = executeCriteira(criteria);
		}
		return vbids;
	}

	@Override
	public List<String> getVbidsForGroupIds(Integer bridgeId, List<Integer> groupIds, Boolean isDateSorted)  throws BridgeException{
		Criteria criteria = getCriteria();
		criteria.createAlias("group", "groupAlias");
		criteria.add(Restrictions.eq("groupAlias.bridge.id", bridgeId));
		criteria.add(Restrictions.in("group.id", groupIds));
		criteria.add(Restrictions.eq("selected", Boolean.TRUE));
		criteria.add(Restrictions.eq("groupAlias.deleted", Boolean.FALSE));

		Criterion criteria1 = Restrictions.gt("groupAlias.expiredDate", new Date());
		Criterion criteria2 = Restrictions.isNull("groupAlias.expiredDate");
		Criterion disjuctionCriteria = Restrictions.disjunction().add(criteria1).add(criteria2);
		criteria.add(disjuctionCriteria);

		criteria.setProjection(Projections.property("vbid"));
		criteria.addOrder(Order.desc("lastUpdated"));
		List<String> vbids = executeCriteira(criteria);
		return vbids;
	}

	@Override
	public List<IdValueVO> getGroupsForVbid(Integer bridgeId, String vbid, Boolean withDefaultGroup) throws BridgeException {
		
		Criteria criteria= getCriteria();
		criteria.createAlias("group", "groupAlias");
		criteria.add(Restrictions.eq("groupAlias.bridge.id", bridgeId));
		criteria.add(Restrictions.like("vbid", vbid));
		criteria.add(Restrictions.eq("selected", Boolean.TRUE));
		criteria.addOrder(Order.asc("groupAlias.name"));
		
		if(null != withDefaultGroup && !withDefaultGroup){
			criteria.add(Restrictions.ne("groupAlias.name", ApplicationConstants.BRIDGE_DEFAULT_GROUP_UNIVERSAL));
		}
		
		criteria.setProjection(Projections.projectionList()
				.add( Projections.property("groupAlias.id").as("id"))
				.add( Projections.property("groupAlias.name").as("value")))
				.setResultTransformer(new AliasToBeanResultTransformer(IdValueVO.class));
		
		return executeCriteira(criteria);
	}
}