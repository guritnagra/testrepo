package com.vst.bridge.rest.response.vo.report;

import java.util.Date;

public class ReportUserVO {
	private String email;
	private String firstName;
	private String lastName;
	private Date activationDate;
	private Long activation;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getActivationDate() {
		return activationDate;
	}
	public void setActivationDate(Date activationDate) {
		this.activationDate = activationDate;
	}
	public Long getActivation() {
		return activation;
	}
	public void setActivation(Long activation) {
		this.activation = activation;
	}
	
}
