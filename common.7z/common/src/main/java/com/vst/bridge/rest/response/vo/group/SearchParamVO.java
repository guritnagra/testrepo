package com.vst.bridge.rest.response.vo.group;

public class SearchParamVO {
	
	private String searchString;
	private Boolean isGrouped;
	public String getSearchString() {
		return searchString;
	}
	public void setSearchString(String searchString) {
		this.searchString = searchString;
	}
	public Boolean getIsGrouped() {
		return isGrouped;
	}
	public void setIsGrouped(Boolean isGrouped) {
		this.isGrouped = isGrouped;
	}
	
	

}
