package com.vst.bridge.dao.bridge.book;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.NullPrecedence;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.BridgeException;


@Repository("bridgeBookCacheDAO")
public class BridgeBookCacheDAOImpl extends GenericDAO<BridgeBookCache, Integer> implements IBridgeBookCacheDAO{
	
	private Logger log = LogManager.getLogger(BridgeBookCacheDAOImpl.class);

	public BridgeBookCacheDAOImpl() {
		super(BridgeBookCache.class);
	}

	@Override
	public List<BridgeBookCache> getCacheBooks(final Integer bridgeId,final Integer startIndex,BridgePaginationVo paginationVo, 
			List<String> vbids,Boolean isUser, String category)throws BridgeException {
		Criteria criteria = getCriteria();
		if(null != bridgeId && bridgeId > 0){
			criteria.add(Restrictions.eq("bridge.id", bridgeId));
		}
		if(null != category){
			criteria.add(Restrictions.eq("category", category));
		}
		if(null!=paginationVo){
			Integer totalRecordToFetch = paginationVo.getLimit();
			if(null != startIndex && null != totalRecordToFetch  && totalRecordToFetch > 0){
				criteria.setFirstResult(startIndex);
				criteria.setMaxResults(totalRecordToFetch);
			}
			if(null != vbids && vbids.size() > 0){
				criteria.add(Restrictions.in("vbid", vbids));
			}else if(isUser){
				return null;
			}else if(vbids != null && vbids.size()==0) {
				return null;
			}
				
			String search = paginationVo.getSearch();
			criteria.createAlias("ancillary","ancillary", JoinType.LEFT_OUTER_JOIN);
			if(null!=search && !StringUtils.isEmpty(search)){
				
				Criterion criterion1 = Restrictions.like("vbid", "%"+search+"%");
				Criterion criterion2 = Restrictions.like("ebookIsbn", "%"+search+"%");
				Criterion criterion3 = Restrictions.like("textbookIsbn", "%"+search+"%");
				Criterion criterion4 = Restrictions.like("author", "%"+search+"%");
				Criterion criterion5 = Restrictions.like("fileType", "%"+search+"%");
				Criterion criterion6 = Restrictions.like("title", "%"+search+"%");
				Criterion criterion7 = Restrictions.like("edition", "%"+search+"%");
				Criterion criterion8 = Restrictions.between("ancillary.createdAt", searchDateFormatter(search), searchDateFormatterPlusOne(search));
				Criterion criterion9 = Restrictions.eqOrIsNull("concurrencyLimit",+checkForNumber(search));
				
				
	
				Criterion completeCriterion = Restrictions.disjunction()
																	.add(criterion1)
																	.add(criterion2)
																	.add(criterion3)
																	.add(criterion4)
																	.add(criterion5)
																	.add(criterion6)
																	.add(criterion7)
																	.add(criterion8)
																	.add(criterion9);;
				
				criteria.add(completeCriterion);
			}
			
			String orderBy = paginationVo.getOrderBy();
			if(null != orderBy && !StringUtils.isEmpty(orderBy) && !StringUtils.equals(orderBy, ApplicationConstants.BOOK_USER_ORDER_BY_RECENT)){
				String order = paginationVo.getOrder();
				if("lastModifiedDate".equals(orderBy)){
					orderBy = "ancillary.createdAt";
				}
				if(order.equals(ApplicationConstants.SORTING_ORDER_ASC)){
					criteria.addOrder(Order.asc(orderBy));
				}else{
					criteria.addOrder(Order.desc(orderBy));
				}
			}
		}
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		return executeCriteira(criteria);
	}

	@Override
	public Integer getCacheBookCount(Integer bridgeId,
			BridgePaginationVo paginationVo,List<String> vbids, Boolean isUser, String category) throws BridgeException {
		Criteria criteria = getCriteria();
		if(null != bridgeId && bridgeId > 0){
			criteria.add(Restrictions.eq("bridge.id", bridgeId));
		}
		if(null != vbids && vbids.size() > 0){
			criteria.add(Restrictions.in("vbid", vbids));
		}else if(isUser && vbids != null && vbids.size()==0){
			return 0;
		}
		if(null != category){
			criteria.add(Restrictions.eq("category", category));
		}
		String search = paginationVo.getSearch();
		if(null!=search && !StringUtils.isEmpty(search)){
			
			Criterion criterion1 = Restrictions.like("vbid", "%"+search+"%");
			Criterion criterion2 = Restrictions.like("ebookIsbn", "%"+search+"%");
			Criterion criterion3 = Restrictions.like("textbookIsbn", "%"+search+"%");
			Criterion criterion4 = Restrictions.like("author", "%"+search+"%");
			Criterion criterion5 = Restrictions.like("fileType", "%"+search+"%");
			Criterion criterion6 = Restrictions.like("title", "%"+search+"%");
			Criterion criterion7 = Restrictions.like("edition", "%"+search+"%");
			Criterion criterion8 = Restrictions.eqOrIsNull("concurrencyLimit",checkForNumber(search));
			
			Criterion completeCriterion = Restrictions.disjunction()
																.add(criterion1)
																.add(criterion2)
																.add(criterion3)
																.add(criterion4)
																.add(criterion5)
																.add(criterion6)
																.add(criterion7)
																.add(criterion8);
			criteria.add(completeCriterion);

		}

		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		List<BridgeBookCache> result = executeCriteira(criteria);
		if(null != result && result.size()>0){
			return result.size();
		}
 		return 0;
	}
	
	@Override
	public List<BridgeBookCache> getCacheBooks(Integer bridgeId,BridgePaginationVo paginationVo,List<String> vbids, Boolean isUser, String category) throws BridgeException {

		Criteria criteria = getCriteria();
		if(null != bridgeId && bridgeId > 0){
			criteria.add(Restrictions.eq("bridge.id", bridgeId));
		}
		if(null != vbids && vbids.size() > 0){
			criteria.add(Restrictions.in("vbid", vbids));
		}else if(isUser){
			return null;
		}else if(vbids != null && vbids.size()==0) {
			return null;
		}
		
		if(null != category){
			criteria.add(Restrictions.eq("category", category));
		}
		if(null!=paginationVo){				

			String search = paginationVo.getSearch();
			criteria.createAlias("ancillary","ancillary", JoinType.LEFT_OUTER_JOIN);
			if(null!=search && !StringUtils.isEmpty(search)){
				Criterion criterion1 = Restrictions.like("vbid", "%"+search+"%");
				Criterion criterion2 = Restrictions.like("ebookIsbn", "%"+search+"%");
				Criterion criterion3 = Restrictions.like("textbookIsbn", "%"+search+"%");
				Criterion criterion4 = Restrictions.like("author", "%"+search+"%");
				Criterion criterion5 = Restrictions.like("fileType", "%"+search+"%");
				Criterion criterion6 = Restrictions.like("title", "%"+search+"%");
				Criterion criterion7 = Restrictions.like("edition", "%"+search+"%");
				Criterion criterion8 = Restrictions.between("ancillary.createdAt", searchDateFormatter(search), searchDateFormatterPlusOne(search));
				Criterion criterion9 = Restrictions.eqOrIsNull("concurrencyLimit", checkForNumber(search));
				
				Criterion completeCriterion = Restrictions.disjunction()
																	.add(criterion1)
																	.add(criterion2)
																	.add(criterion3)
																	.add(criterion4)
																	.add(criterion5)
																	.add(criterion6)
																	.add(criterion7)
																	.add(criterion8)
																	.add(criterion9);
				
				criteria.add(completeCriterion);
			}
			
			String orderBy = paginationVo.getOrderBy();
			if("lastModifiedDate".equals(orderBy)){
				orderBy = "ancillary.createdAt";
			}
			if(null != orderBy && !StringUtils.isEmpty(orderBy) && !StringUtils.equals(orderBy, ApplicationConstants.BOOK_USER_ORDER_BY_RECENT)){
				String order = paginationVo.getOrder();
				if(order.equals(ApplicationConstants.SORTING_ORDER_ASC)){
					criteria.addOrder(Order.asc(orderBy).nulls(NullPrecedence.LAST));
				}else{
					criteria.addOrder(Order.desc(orderBy).nulls(NullPrecedence.LAST));
				}
			}
		}
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		return executeCriteira(criteria);
	}


	@Override
	public BridgeBookCache getBookForVbid(Integer bridgeId, String vbid)
			throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.like("vbid", vbid));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		List<BridgeBookCache> result =  executeCriteira(criteria);
		return null!=result && result.size() >0 ? result.get(0) : null;
	}

	@Override
	public BridgeBookCache getCacheBooksForVbid(String vbid) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.like("vbid", vbid));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		List<BridgeBookCache> result =  executeCriteira(criteria);
		return null!=result && result.size() >0 ? result.get(0) : null;
	}
	
	@Override
	public BridgeBookCache getCacheBooksForEbookIsbn(Integer bridgeId, String isbn) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.like("ebookIsbn", isbn));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		List<BridgeBookCache> result =  executeCriteira(criteria);
		return null!=result && result.size() >0 ? result.get(0) : null;
	}

	@Override
	public List<BridgeBookCache> getCacheBooks(Integer bridgeId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		List<BridgeBookCache> result =  executeCriteira(criteria);
		return result;
	}

	@Override
	public List<String> getCacheBookVbids(Integer bridgeId) throws BridgeException {

		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		criteria.setProjection(Projections.projectionList()
				.add(Projections.groupProperty("vbid")));
		return executeCriteira(criteria);
	}

	@Override
	public List<BridgeBookCache> getCacheBooksWithConcurrencyLimit(Integer bridgeId) {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		criteria.add(Restrictions.isNotNull("concurrencyLimit"));
		List<BridgeBookCache> result =  executeCriteira(criteria);
		return result;
	}

	@Override
	public int deleteAllCacheBooksForBridge(Integer bridgeId) {
		Session session = getCrntSession();
		String hqlUpdate = "update BridgeBookCache bc set bc.deleted = :deleted, last_updated = :last_updated where bc.bridge.id = :bridge_id and ancillary_id is null and bc.deleted=0";
		int updatedEntities = session.createQuery(hqlUpdate)
				.setBoolean("deleted", Boolean.TRUE)
				.setTimestamp("last_updated", new Date())
				.setParameter("bridge_id", bridgeId)
				.executeUpdate();
		return updatedEntities;
	}

	@Override
	public List<Integer> getCacheBookIds(Integer bridgeId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		criteria.setProjection(Projections.projectionList()
				.add(Projections.property("id")));
		return executeCriteira(criteria);
	}
	@Override
	public BridgeBookCache checkForExistingBookAndReturn(Integer bridgeId, String vbid)
			throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.like("vbid", vbid));
		List<BridgeBookCache> result =  executeCriteira(criteria);
		return null!=result && result.size() >0 ? result.get(0) : null;
	}

	@Override
	public List<BridgeBookCache> getAllCacheBooks(Integer bridgeId, boolean deleted) {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.isNull("ancillary"));
		criteria.add(Restrictions.eq("deleted",deleted));
		List<BridgeBookCache> result =  executeCriteira(criteria);
		return result;
	}
	@Override
	public List<BridgeBookCache> getCacheBooksForVbidList(Integer bridgeId,Collection<String> vbids) {
		if(null == vbids || vbids.isEmpty()){
			return null;
		}
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.in("vbid", vbids));
		criteria.add(Restrictions.isNull("ancillary"));
		List<BridgeBookCache> result =  executeCriteira(criteria);
		return result;
	}
	@Override
	public List<BridgeBookCache> getAncillaryCacheBooksForVbidList(Integer bridgeId,Collection<String> vbids) {
		if(null == vbids || vbids.isEmpty()){
			return null;
		}
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.in("vbid", vbids));
		criteria.add(Restrictions.isNotNull("ancillary"));
		List<BridgeBookCache> result =  executeCriteira(criteria);
		return result;
	}
	
	
	@Override
	public List<BridgeBookCache> getCacheBooksNotInVbidList(Integer bridgeId,Collection<String> vbidCollection) {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		if(null != vbidCollection && !vbidCollection.isEmpty()){
			criteria.add(Restrictions.not(Restrictions.in("vbid", vbidCollection)));
		}
		criteria.add(Restrictions.isNull("ancillary"));
		List<BridgeBookCache> result =  executeCriteira(criteria);
		return result;
	}

	private Integer checkForNumber(String search) {
		Integer concurrecy = 0;
		try{
			concurrecy = Integer.parseInt(search);
		}catch(NumberFormatException e){
			log.debug("criteria not a number "+search);
		}
		
		return concurrecy;
	}

	private Date searchDateFormatter(String search) {

		Date searchDate = null;
		boolean parsable = false;
		if (false == parsable) {
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("M/d/YYYY");
				searchDate = dateFormat.parse(search);
				parsable = true;
			} catch (ParseException e) {
				log.debug("failed to parse date using M/d/YYYY");
			}
		}
		if (false == parsable) {
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");
				searchDate = dateFormat.parse(search);
				parsable = true;
			} catch (ParseException e) {
				log.debug("failed to parse date using MM/dd/YYYY");
			}
		}
		if (false == parsable) {
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("M-d-YYYY");
				searchDate = dateFormat.parse(search);
				parsable = true;
			} catch (ParseException e) {
				log.debug("failed to parse date using M-d-YYYY");
			}

		}

		if (false == parsable) {
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-YYYY");
				searchDate = dateFormat.parse(search);
				parsable = true;
			} catch (ParseException e) {
				log.debug("failed to parse date using MM-dd-YYYY");
			}

		}
		
		if(!parsable){
			log.warn("date parse failed using default date");
			searchDate = new Date();
		}

		return searchDate;
	}
	
	private Date searchDateFormatterPlusOne(String search) {
		Date searchDate = searchDateFormatter(search);
		Calendar cal = Calendar.getInstance();
		cal.setTime(searchDate);
		cal.add(Calendar.DATE, 1);
		searchDate = cal.getTime();
		return searchDate;
	}

}
