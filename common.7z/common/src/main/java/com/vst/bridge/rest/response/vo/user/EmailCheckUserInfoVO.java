package com.vst.bridge.rest.response.vo.user;

public class EmailCheckUserInfoVO {
	private String email;
	private Boolean exist =  false;
	private String message;
	private Boolean fulluser = false;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Boolean getExist() {
		return exist;
	}
	public void setExist(Boolean exist) {
		this.exist = exist;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Boolean getFulluser() {
		return fulluser;
	}
	public void setFulluser(Boolean fulluser) {
		this.fulluser = fulluser;
	}
	
}
