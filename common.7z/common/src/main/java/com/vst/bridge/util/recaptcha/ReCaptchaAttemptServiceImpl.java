package com.vst.bridge.util.recaptcha;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.dao.log.IBridgeLoginAttemptDAO;
import com.vst.bridge.entity.bridge.log.BridgeLoginAttempt;

@Service("reCaptchaAttemptService")
public class ReCaptchaAttemptServiceImpl implements IReCaptchaAttemptService {
	@Autowired 
	IBridgeLoginAttemptDAO bridgeLoginAttemptDAO;

	/* (non-Javadoc)
	 * @see com.vst.bridge.util.recaptcha.IReCaptchaAttemptService#reCaptchaSuccessful(java.lang.String)
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.READ_COMMITTED)
	public void reCaptchaSuccessful(String username, String ipAddress){
		BridgeLoginAttempt loginAttempt = bridgeLoginAttemptDAO.getAttemptsByUserName(username);
		if(null == loginAttempt){
			loginAttempt = new BridgeLoginAttempt();
			loginAttempt.setUsername(username);
		}
		loginAttempt.setFailureCount(0);
		loginAttempt.setLastSuccess(new Date());
		loginAttempt.setIpAddress(ipAddress);
		if(null == loginAttempt.getId())
			bridgeLoginAttemptDAO.saveOrUpdate(loginAttempt);
	}
	/* (non-Javadoc)
	 * @see com.vst.bridge.util.recaptcha.IReCaptchaAttemptService#reCaptchaFailure(java.lang.String)
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.READ_COMMITTED)
	public void reCaptchaFailure(String username, String ipAddress){
		BridgeLoginAttempt loginAttempt = bridgeLoginAttemptDAO.getAttemptsByUserName(username);
		if(null == loginAttempt){
			loginAttempt = new BridgeLoginAttempt();
			loginAttempt.setUsername(username);
		}
		int failureCount = loginAttempt.getFailureCount();
		loginAttempt.setFailureCount(++failureCount);
		loginAttempt.setLastFailure(new Date());
		loginAttempt.setIpAddress(ipAddress);
		if(null == loginAttempt.getId())
			bridgeLoginAttemptDAO.saveOrUpdate(loginAttempt);
	}
	
	/* (non-Javadoc)
	 * @see com.vst.bridge.util.recaptcha.IReCaptchaAttemptService#isBlocked(java.lang.String)
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.READ_COMMITTED)
	public Boolean isBlocked(String username, String ipAddress){
		boolean blocked = true;
		BridgeLoginAttempt loginAttempt = bridgeLoginAttemptDAO.getAttemptsByUserName(username);
		if(null == loginAttempt){
			return !blocked;
		}else if (loginAttempt.getFailureCount() >= IReCaptchaAttemptService.MAX_ATTEMPTS_CAPTCHA + IReCaptchaAttemptService.MAX_ATTEMPTS_PW -1){
			Calendar cal = Calendar.getInstance();
			cal.setTime(loginAttempt.getLastFailure());
			cal.add(Calendar.MINUTE, 30);
			if(new Date().after(cal.getTime())){
				loginAttempt.setFailureCount(0);
				return !blocked;
			}else {
				return blocked;
			}
		}
		return !blocked;
	}
	@Override
	@Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.READ_COMMITTED)
	public int getUnsuccessfulAttempts(String username, String ipAddress){
		BridgeLoginAttempt loginAttempt = bridgeLoginAttemptDAO.getAttemptsByUserName(username);
		return null == loginAttempt ? 0 : loginAttempt.getFailureCount();
	}
	@Override
	@Transactional(isolation=Isolation.READ_COMMITTED)
	public Date getLastUnsuccessfulTime(String username, String ipAddress){
		BridgeLoginAttempt loginAttempt = bridgeLoginAttemptDAO.getAttemptsByUserName(username);
		return null == loginAttempt ? null : loginAttempt.getLastFailure();
	}
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.READ_COMMITTED)
	public void resetLastUnsuccessful(String username, String ipAddress){
		BridgeLoginAttempt loginAttempt = bridgeLoginAttemptDAO.getAttemptsByUserName(username);
		if(null == loginAttempt){
			loginAttempt = new BridgeLoginAttempt();
			loginAttempt.setUsername(username);
		}
		loginAttempt.setFailureCount(0);
		loginAttempt.setIpAddress(ipAddress);
		if(null == loginAttempt.getId())
			bridgeLoginAttemptDAO.saveOrUpdate(loginAttempt);
	}
	
}
