package com.vst.bridge.rest.response.vo;

import com.vst.bridge.util.exception.ApplicationCode;

public class SessionStatusVO {
	private Integer adminId;
	private String roleName;
	private ApplicationCode errorCode;
	
	public SessionStatusVO() {}
	
	public SessionStatusVO(ApplicationCode errorCode) {
		this.errorCode = errorCode;
	}
	
	public Integer getAdminId() {
		return adminId;
	}
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public ApplicationCode getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(ApplicationCode errorCode) {
		this.errorCode = errorCode;
	}
}
