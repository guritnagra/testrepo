package com.vst.bridge.service.user;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;

public interface IUserBookService {
	RestResponse getBooks(SessionStatusVO sessionStatusVO, Integer groupId, String vbidId, String code,
			BridgePaginationVo bridgePaginationVo, String category, Boolean isDefered)
			throws BridgeException, ConnectApiException;
	RestResponse getBooksForDeferSignIn(HttpServletRequest httpRequest, UriInfo uriInfo, String code, String domain,BridgePaginationVo bridgePaginationVo) throws BridgeException, ConnectApiException;
	
}
