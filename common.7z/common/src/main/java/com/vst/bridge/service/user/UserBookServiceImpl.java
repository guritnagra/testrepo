package com.vst.bridge.service.user;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookCacheDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookPricingDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupAssetDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupUserDAO;
import com.vst.bridge.dao.bridge.purchase.IBridgePurchaseDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.entity.admin.ancillary.Ancillary;
import com.vst.bridge.entity.admin.purchase.BridgePurchase;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.entity.bridge.books.BridgeBookPricing;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.group.BridgeGroup;
import com.vst.bridge.entity.group.GroupAsset;
import com.vst.bridge.entity.group.GroupUser;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.ancillary.AncillaryBookVO;
import com.vst.bridge.rest.response.vo.group.BridgeGroupNameVO;
import com.vst.bridge.rest.response.vo.group.book.BridgePurchaseVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.rest.response.vo.user.AncillaryDownloadActionVO;
import com.vst.bridge.rest.response.vo.user.BookLaunchActionVO;
import com.vst.bridge.rest.response.vo.user.BookLicenseVO;
import com.vst.bridge.rest.response.vo.user.UserBooksVO;
import com.vst.bridge.rest.response.vo.user.UserBooksWithGroupsVO;
import com.vst.bridge.rest.response.vo.user.UserCreditsInfoVO;
import com.vst.bridge.service.book.IBookServices;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.connectapi.ApiKeys;
import com.vst.connectapi.ConnectApiWrapper;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectLicense;

@Service("userBookService")
public class UserBookServiceImpl implements IUserBookService {

	@Autowired
	private IBridgeUserDAO bridgeUserDAO;

	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private IBridgeDAO bridgeDAO;

	@Autowired
	private IBridgeBookCacheDAO bridgeBookCacheDAO;

	@Autowired
	private IBookServices bookServices;

	@Autowired
	private IBridgeGroupUserDAO bridgeGroupUserDAO;

	@Autowired
	private IBridgeGroupDAO bridgeGroupDAO;

	@Autowired
	private IBridgeGroupAssetDAO bridgeGroupAssetDAO;

	@Autowired
	private IBridgeBookPricingDAO bridgeBookPricingDAO;
	
	@Autowired 
	private IBridgePurchaseDAO bridgePurchaseDAO;
	
	@Autowired
	private UserServiceUtil userServiceUtil;

	/***
	 * Function to get list of book for user
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getBooks(SessionStatusVO sessionStatusVO, Integer groupId, String vbidId, String code,
			BridgePaginationVo bridgePaginationVo, String category, Boolean isDefered) throws BridgeException, ConnectApiException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (null == bridge) {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		Integer bridgeId = bridge.getId();
		BridgeUser user = null;
		String apiKey = null;
		ApiKeys key = null;
		Map<String, List<ConnectLicense>> licenses = null;

		if (!isDefered) {
			/** Getting book liceses from connect for user **/
			user = bridgeUserDAO.get(sessionStatusVO.getAdminId());
			apiKey = bridge.getApiKey();
			key = new ApiKeys(ApplicationConstants.getApiMode(), apiKey, "unused:lti_key", "unused:lti_secret");
			licenses = ConnectApiWrapper.getLicenses(key, user.getAccessToken(), vbidId);
		}

		if (vbidId == null) {
			List<Integer> userGroups = new ArrayList<Integer>();
			BridgeGroup bg =null;
			if (groupId != null) {
				bg = bridgeGroupDAO.get(groupId);
				if(bg!=null && !bg.getDeleted() && bg.getIsAutoAssignUser()){
					userGroups.add(groupId);
				}
			}
			if (groupId != null) {
				GroupUser groupUser = bridgeGroupUserDAO.getGroupUser(groupId, user.getId(), Boolean.FALSE,
						Boolean.TRUE, Boolean.TRUE);
				if (null != groupUser) {
					userGroups.add(groupUser.getGroup().getId());
				}
			} else {
				if (user != null) {
					userGroups = bridgeGroupUserDAO.getGroupIdsForUser(bridgeId, user.getId(), Boolean.FALSE,
							Boolean.TRUE, Boolean.TRUE);
				}
				List<BridgeGroup> autoAssignGroups = bridgeGroupDAO.getAllAutoAssignGroups(bridgeId, Boolean.FALSE, Boolean.FALSE);
				for(BridgeGroup bg1 : autoAssignGroups){
					userGroups.add(bg1.getId());
				}
				userGroups = null != userGroups ? userGroups : new ArrayList<Integer>();
				BridgeGroup universalGroup = bridgeGroupDAO.getDefaultGroup(bridgeId);
				if (null != universalGroup) {
					userGroups.add(0, universalGroup.getId());
				}
			}
			String orderBy = bridgePaginationVo.getOrderBy();
			List<String> vbids = null;
			List<BridgeBookCache> sortedBookList = null;
			List<BridgeGroup> autoAssignAssetGroups =bridgeGroupDAO.getAllAutoAssignAssetGroup(bridgeId,userGroups, Boolean.FALSE);
			if((bg==null || (bg!=null && bg.getIsAutoAssignAsset())) && autoAssignAssetGroups!=null && autoAssignAssetGroups.size()>0){
				sortedBookList=bridgeBookCacheDAO.getCacheBooks(bridgeId, bridgePaginationVo, null, Boolean.FALSE, category);
				vbids= new ArrayList<>();
				for(BridgeBookCache bbc :sortedBookList){
					vbids.add(bbc.getVbid());
				}					
			}
			else{			
				if (StringUtils.equals(orderBy, ApplicationConstants.BOOK_USER_ORDER_BY_RECENT)) {
					vbids = bridgeGroupAssetDAO.getVbidsForGroupIds(bridgeId, userGroups, Boolean.TRUE);
					sortedBookList = new ArrayList<BridgeBookCache>();
				} else {
					vbids = bridgeGroupAssetDAO.getVbidsForGroupIds(bridgeId, userGroups);
				}
			}

			Boolean licensed = bridgePaginationVo != null ? bridgePaginationVo.getLicensed() : null;
			this.validateAndRearangePaginationVO(bridgePaginationVo);
			Integer startIndex = calculateStartIndexForReport(bridgePaginationVo.getPage(),
					bridgePaginationVo.getLimit());
			
			
			if (null != licensed && licensed) {
				Set<String> bridgeBookVbidSet = new HashSet<>(bridgeBookCacheDAO.getCacheBookVbids(bridgeId));
				Set<String> matchedVbids = new HashSet<>();
				
				checkForLicensedVbids(licenses, vbids, bridgeBookVbidSet, matchedVbids);
				
				vbids = new ArrayList<String>(matchedVbids);
			}

			Integer totalRecords = bridgeBookCacheDAO.getCacheBookCount(bridge.getId(), bridgePaginationVo, vbids,
					Boolean.TRUE, category);
			List<BridgeBookCache> books = bridgeBookCacheDAO.getCacheBooks(bridge.getId(), startIndex,
					bridgePaginationVo, vbids, Boolean.TRUE, category);
			if (null != sortedBookList) {
				for (String vbid : vbids) {
					for (BridgeBookCache bbCache : books) {
						if (bbCache.getVbid().equals(vbid)) {
							sortedBookList.add(bbCache);
							break;
						}
					}
				}
				books = sortedBookList;
			}

			Integer totalPages = calculateTotalPageCount(totalRecords, bridgePaginationVo.getLimit());
			List<UserBooksVO> booksVo = new ArrayList<UserBooksVO>();
			if (null != books && books.size() > 0) {
				for (BridgeBookCache cacheBook : books) {
					booksVo.add(populateBridgeBooksVOFromConnectBook(cacheBook, licenses, bridge, user, isDefered));
				}
			}

			ArrayList<BridgeGroupNameVO> groupList = new ArrayList<BridgeGroupNameVO>();
			for (Integer id : userGroups) {
				BridgeGroupNameVO bridgeGroupNameVO = new BridgeGroupNameVO();
				BridgeGroup bridgeGroup = bridgeGroupDAO.get(id);
				String groupName = bridgeGroup.getName();
				if (!StringUtils.equals(ApplicationConstants.BRIDGE_DEFAULT_GROUP_UNIVERSAL, groupName)) {
					bridgeGroupNameVO.setId(bridgeGroup.getId());
					bridgeGroupNameVO.setName(groupName);
					groupList.add(bridgeGroupNameVO);
				}
			}

			UserBooksWithGroupsVO userBooksWithGroupsVO = new UserBooksWithGroupsVO();
			userBooksWithGroupsVO.setGroups(groupList);
			userBooksWithGroupsVO.setBooks(booksVo);
			Integer offset= this.calculateOffsetValue(bridgePaginationVo.getPage(), bridgePaginationVo.getLimit());
			PaginationVO paginationVO = new PaginationVO(bridgePaginationVo.getPage(), bridgePaginationVo.getLimit(),
					totalPages, bridgePaginationVo.getOrderBy(), bridgePaginationVo.getOrder(),
					bridgePaginationVo.getSearch(), totalRecords,offset);
			response.setMetadata(paginationVO);
			response.setData(userBooksWithGroupsVO);
		} else {
			List<IdValueVO> groupList = bridgeGroupUserDAO.getGroupsForUserId(bridge.getId(), user.getId());
			BridgeGroup bridgeGroup = bridgeGroupDAO.getDefaultGroup(bridge.getId());
			List<BridgeGroup> autoAssignGroups=bridgeGroupDAO.getAllAutoAssignGroups(bridgeId, Boolean.FALSE, Boolean.FALSE);
			if(autoAssignGroups!=null && autoAssignGroups.size()>0){
				for(BridgeGroup autoAssignGroup:autoAssignGroups){
					IdValueVO idValueVO = new IdValueVO();
					idValueVO.setId(autoAssignGroup.getId());
					groupList.add(idValueVO);
				}
			}
			IdValueVO defaultGroup = new IdValueVO();
			defaultGroup.setId(bridgeGroup.getId());
			groupList.add(defaultGroup);	
			for(IdValueVO idValue:groupList){
				int group = idValue.getId();
				GroupAsset asset = bridgeGroupAssetDAO.getGroupAsset(group, vbidId);
				if(asset!=null && asset.getSelected()){
					BridgeBookCache cacheBook = bridgeBookCacheDAO.getBookForVbid(bridgeId, vbidId);
					UserBooksVO booksVo = populateBridgeBooksVOFromConnectBook(cacheBook, licenses, bridge, user, isDefered);
					response.setData(booksVo);
					return response;
				}
			}
			response.setCode(HttpStatus.SC_NOT_FOUND);
		}

		return response;
	}
	
	private void checkForLicensedVbids(final Map<String, List<ConnectLicense>> licenses, final List<String> vbids,
			final Set<String> bridgeBookVbidSet, final Set<String> matchedVbids) {
		licenses.forEach((licenseVbid, licenseList) -> {
			if (null != licenseList && !licenseList.isEmpty()) {
				ConnectLicense connectLicense = licenseList.get(0);
				if (false == connectLicense.getExpired()) {
					if (null != vbids && vbids.contains(licenseVbid)) {
						matchedVbids.add(licenseVbid);
					} else if (null != bridgeBookVbidSet && bridgeBookVbidSet.contains(licenseVbid)) {
						matchedVbids.add(licenseVbid);
					}
				}
			}
		});
	}
	
	private Integer calculateOffsetValue(Integer page, Integer limit) {
		if(page!=null){
			return (page-1)*limit;
		}
		return 0;
	}

	/**
	 * Function to populate BridgeBookVO from BridgeCatcheBook
	 * 
	 * @param cacheBook
	 * @param licenses
	 * @param user
	 * @return
	 */
	private UserBooksVO populateBridgeBooksVOFromConnectBook(BridgeBookCache cacheBook,
			Map<String, List<ConnectLicense>> licenses, Bridge bridge, BridgeUser user, Boolean isDefered) {
		UserBooksVO bridgeBooksVO = new UserBooksVO();
		Ancillary ancillary = cacheBook.getAncillary();
		if (null != cacheBook) {
			bridgeBooksVO.setAuthor(cacheBook.getAuthor());
			bridgeBooksVO.setCoverImageUrl(cacheBook.getCoverImageUrl());
			
			String title = cacheBook.getTitle();
			/*title = StringEscapeUtils.unescapeHtml(title);
			title = StringEscapeUtils.unescapeJava(title);
			title = HTMLParserUtil.parseHTML(title);*/
			bridgeBooksVO.setTitle(title);
			
			String description = cacheBook.getDescription();
			/*description = StringEscapeUtils.unescapeHtml(description);
			description = StringEscapeUtils.unescapeJava(description);
			description = HTMLParserUtil.parseHTML(description);*/
			bridgeBooksVO.setDescription(description);
			bridgeBooksVO.seteBookIsbn(cacheBook.getEbookIsbn());
			bridgeBooksVO.setTextbookIsbn(cacheBook.getTextbookIsbn());
			
			bridgeBooksVO.setVbid(cacheBook.getVbid());
			bridgeBooksVO.setEdition(cacheBook.getEdition());
			bridgeBooksVO.setFileType(cacheBook.getFileType());
			bridgeBooksVO.setCategory(cacheBook.getCategory());
			if(bridge.getIsPurchasesEnabled()!=null && bridge.getIsPurchasesEnabled() && (ancillary == null))
				bridgeBooksVO.setPurchase(getPurchaseOptionsForVbid(cacheBook, bridge, user));
			if (!isDefered && (null == ancillary)) {
				bridgeBooksVO.setFunctions(getLicenseForVbid(licenses, cacheBook.getVbid(), bridge, user));
			}
			if(null != ancillary){
				bridgeBooksVO.setAncillaryMetaData(new AncillaryBookVO(ancillary));
				BookLicenseVO functions = new BookLicenseVO();
				functions.setDownload(getAncillaryDownload(cacheBook.getVbid()));
				bridgeBooksVO.setFunctions(functions);
			}
			
		}
		return bridgeBooksVO;
	}

	private AncillaryDownloadActionVO getAncillaryDownload(String vbid) {
		AncillaryDownloadActionVO downloadAction = new AncillaryDownloadActionVO();
		downloadAction.setState("downloadable");
		downloadAction.setUrl(com.vst.bridge.StringUtils.getFormatedString(ApplicationConstants.ANCILLARY_DOWNLOAD, vbid));
	    return downloadAction;
	}

	/***
	 * Function to check is any license from connect available for vbid
	 * 
	 * @param licenses
	 * @param vbid
	 * @param bridge
	 * @param user
	 * @return
	 */
	private BookLicenseVO getLicenseForVbid(Map<String, List<ConnectLicense>> licenses, String vbid, Bridge bridge,
			BridgeUser user) {
		BookLicenseVO licensesVO = new BookLicenseVO();

		if (vbid != null && StringUtils.isNotEmpty(vbid)) {
			List<ConnectLicense> liceseList = licenses.get(vbid);
			
			
			
			Map<String, Object> result = bookServices.checkVbidHasLaunchFunctionality(liceseList, vbid, user);
			
			BookLaunchActionVO launchAvailable = (BookLaunchActionVO) result
					.get(ApplicationConstants.BOOK_LICENSE_LAUNCH_WRAPPER);

			licensesVO.setLaunch(launchAvailable);
			
			UserCreditsInfoVO userCreditsInfoVO = userServiceUtil.getUserCredits(user);
			/*if (launchAvailable == null || (launchAvailable != null && !StringUtils
					.equals(launchAvailable.getActiveCredit(), ApplicationConstants.BOOK_KEY_USED_TYPE_FULL))) {
				licensesVO.setFull(bookServices.checkFullFunctinalityForVbid(vbid, user, bridge));
			}

			if (launchAvailable == null || (launchAvailable != null
					&& !StringUtils.equals(launchAvailable.getActiveCredit(),
							ApplicationConstants.BOOK_KEY_USED_TYPE_FULL)
					&& !StringUtils.equals(launchAvailable.getActiveCredit(),
							ApplicationConstants.BOOK_KEY_USED_TYPE_RENTAL))) {
				licensesVO.setRental(bookServices.checkRentalFunctinalityForVbid(vbid, user, bridge));
			}*/

			if (launchAvailable == null || (launchAvailable != null
					&& !StringUtils.equals(launchAvailable.getActiveCredit(),
							ApplicationConstants.BOOK_KEY_USED_TYPE_FULL)
					&& !StringUtils.equals(launchAvailable.getActiveCredit(),
							ApplicationConstants.BOOK_KEY_USED_TYPE_RENTAL)
					&& !StringUtils.equals(launchAvailable.getActiveCredit(),
							ApplicationConstants.BOOK_KEY_USED_TYPE_TRIAL)
					&& !StringUtils.equals(launchAvailable.getState(),
							ApplicationConstants.BOOK_LICENSE_STATE_EXPIRED))) {
				licensesVO.setTrial(bookServices.checkTrialFunctinalityForVbid(vbid, user,userCreditsInfoVO));
			}
			/*if (launchAvailable == null || (launchAvailable != null
					&& !StringUtils.equals(launchAvailable.getActiveCredit(),
							ApplicationConstants.BOOK_KEY_USED_TYPE_CONCURRENT)
					&& !StringUtils.equals(launchAvailable.getActiveCredit(),
							ApplicationConstants.BOOK_KEY_USED_TYPE_FULL))) {
				licensesVO.setConcurrency(bookServices.checkConcurrentFunctinalityForVbid(vbid, user, bridge));
			} *//*
				 * else{ ConcurrentBookLicenseInfoVO
				 * concurrentBookLicenseInfoVO= new
				 * ConcurrentBookLicenseInfoVO();
				 * //concurrentBookLicenseInfoVO.setIsAvailable(Boolean.FALSE);
				 * licensesVO.setConcurrency(concurrentBookLicenseInfoVO); }
				 */
			if(launchAvailable==null){
				licensesVO.setEntitlements(bookServices.checkEntitlementFunctionalityForVbid(vbid, user, bridge,null,userCreditsInfoVO));
			}
			else if(launchAvailable!=null && ApplicationConstants.BOOK_LICENSE_STATE_EXPIRED.equals(launchAvailable.getState())){
				String state=launchAvailable.getState();
				licensesVO.setEntitlements(bookServices.checkEntitlementFunctionalityForVbid(vbid, user, bridge,state,userCreditsInfoVO));
			}
		/*	if (launchAvailable == null || (launchAvailable != null
					&& !StringUtils.equals(launchAvailable.getActiveCredit(),
							ApplicationConstants.BOOK_KEY_USED_TYPE_CONCURRENT)
					&& !StringUtils.equals(launchAvailable.getActiveCredit(),
							ApplicationConstants.BOOK_KEY_USED_TYPE_FULL))) {
				licensesVO.setConcurrency(bookServices.checkConcurrentFunctinalityForVbid(vbid, user, bridge));
			}*/
			if(bridge.getConcurrencyEnabled()){
				if(launchAvailable==null){
					licensesVO.setConcurrencyEntitlements(bookServices.checkConcurrentEntitlementFunctinalityForVbid(vbid, user, bridge,null,userCreditsInfoVO));
				}
				else if(launchAvailable!=null && ApplicationConstants.BOOK_LICENSE_STATE_EXPIRED.equals(launchAvailable.getState())){
					String state=launchAvailable.getState();
					licensesVO.setConcurrencyEntitlements(bookServices.checkConcurrentEntitlementFunctinalityForVbid(vbid, user, bridge,state,userCreditsInfoVO));
				}
			
			}
		}
		return licensesVO;
	}

	private List<BridgePurchaseVO> getPurchaseOptionsForVbid(BridgeBookCache bookCache, Bridge bridge, BridgeUser user) {
		/*BookPurchaseVO bookPurchaseVO = new BookPurchaseVO();
		DisplayPricing displayPrice = new DisplayPricing();*/
		
		List<BridgePurchase> bridgePurchaseList = new ArrayList<>();
		List<BridgePurchaseVO> bridgePurchaseVOList = new ArrayList<BridgePurchaseVO>();
		bridgePurchaseList = bridgePurchaseDAO.getBridgePurchases(bridge.getId());
		BridgeBookPricing baseVbidPricing = bridgeBookPricingDAO.getBookPricingByRentalType(bookCache.getId(), null);
		
		if(!bridgePurchaseList.isEmpty()){
			for(BridgePurchase bridgePurchase:bridgePurchaseList){
				BridgePurchaseVO bridgePurchaseVO = new BridgePurchaseVO();
				bridgePurchaseVO.setId(bridgePurchase.getId());
				bridgePurchaseVO.setPurchaseName(bridgePurchase.getPurchaseName());
				String url = com.vst.bridge.StringUtils.getFormatedString(ApplicationConstants.BOOK_PURCHASE,
						bookCache.getVbid(),bridgePurchase.getId().toString());
				bridgePurchaseVO.setUrl(url);
				if (baseVbidPricing != null) {
					if (StringUtils.equals(ApplicationConstants.PUBLISHER_PRICE_TYPE,
							bridgePurchase.getDisplayPricing())){
						bridgePurchaseVO.setPrice(baseVbidPricing.getPublisherPrice());
					}else if (StringUtils.equals(ApplicationConstants.DIGITAL_PRICE_TYPE,
							bridgePurchase.getDisplayPricing())){
						bridgePurchaseVO.setPrice(baseVbidPricing.getDigitalPrice());
					}else{
							BridgeBookPricing rentalVbidPricing = bridgeBookPricingDAO.getBookPricingByRentalType(bookCache.getId(), bridgePurchase.getDisplayPricing());
						if (rentalVbidPricing != null) {
							bridgePurchaseVO.setPrice(rentalVbidPricing.getDigitalPrice());
						}
					}
				}
				bridgePurchaseVOList.add(bridgePurchaseVO);
			}
		}
		
		
		
		/*displayPrice.seteTextPriceType(bridge.geteTextPrice());
		displayPrice.setRentalPriceType(bridge.getRentalPrice());
		displayPrice.setTextBookPriceType(bridge.getTextBookPrice());
		BridgeBookPricing baseVbidPricing = bridgeBookPricingDAO.getBookPricingByRentalType(bookCache.getId(), null);
		String rentalURL = bridge.getRentalURL();
		if (StringUtils.isNotBlank(rentalURL)) {

			URLVo urlVo = new URLVo();
			BridgePurchaseVO bridgePurchaseVO = new BridgePurchaseVO();
			String url = com.vst.bridge.StringUtils.getFormatedString(ApplicationConstants.BOOK_PURCHASE,
					bookCache.getVbid());
			bridgePurchaseVO.setUrl(url);
			if (StringUtils.isNotEmpty(displayPrice.getRentalPriceType())) {
				if (baseVbidPricing != null) {
					if (StringUtils.equals(ApplicationConstants.PUBLISHER_PRICE_TYPE,
							displayPrice.getRentalPriceType()))
						bridgePurchaseVO.setPrice(baseVbidPricing.getPublisherPrice());
					else if (StringUtils.equals(ApplicationConstants.DIGITAL_PRICE_TYPE,
							displayPrice.getRentalPriceType()))
						bridgePurchaseVO.setPrice(baseVbidPricing.getDigitalPrice());
					else {
						BridgeBookPricing rentalVbidPricing = bridgeBookPricingDAO
								.getBookPricingByRentalType(bookCache.getId(), displayPrice.getRentalPriceType());
						if (rentalVbidPricing != null) {
							bridgePurchaseVO.setPrice(rentalVbidPricing.getDigitalPrice());
						}
					}

				}
			}
			bookPurchaseVO.setRent(urlVo);
		}

		String fullURL = bridge.getFullURL();
		if (StringUtils.isNotBlank(fullURL)) {
			URLVo urlVo = new URLVo();
			String url = com.vst.bridge.StringUtils.getFormatedString(ApplicationConstants.BOOK_PURCHASE_FULL,
					bookCache.getVbid());
			urlVo.setUrl(url);
			if (StringUtils.isNotEmpty(displayPrice.geteTextPriceType())) {
				if (baseVbidPricing != null) {
					if (StringUtils.equals(ApplicationConstants.PUBLISHER_PRICE_TYPE,
							displayPrice.geteTextPriceType())) {
						urlVo.setPrice(baseVbidPricing.getPublisherPrice());
					} else {
						urlVo.setPrice(baseVbidPricing.getDigitalPrice());
					}
				}
			}
			bookPurchaseVO.setFull(urlVo);
		}

		String printURL = bridge.getPrintBookURL();
		if (StringUtils.isNotBlank(printURL)) {
			URLVo urlVo = new URLVo();
			String url = com.vst.bridge.StringUtils.getFormatedString(ApplicationConstants.BOOK_PURCHASE_PRINT,
					bookCache.getVbid());
			urlVo.setUrl(url);
			if (StringUtils.isNotEmpty(displayPrice.getTextBookPriceType())) {
				if (baseVbidPricing != null) {
					if (StringUtils.equals(ApplicationConstants.DIGITAL_PRICE_TYPE,
							displayPrice.getTextBookPriceType())) {
						urlVo.setPrice(baseVbidPricing.getDigitalPrice());
					} else {
						urlVo.setPrice(baseVbidPricing.getPublisherPrice());
					}
				}
			}
			bookPurchaseVO.setPrint(urlVo);
		}*/

		return bridgePurchaseVOList;
	}

	/***
	 * Function to add default pagination values for get book function
	 * 
	 * @param bridgePaginationVo
	 */
	@SuppressWarnings("deprecation")
	private void validateAndRearangePaginationVO(BridgePaginationVo bridgePaginationVo) {

		Integer page = bridgePaginationVo.getPage();
		if (null == page || page == 0) {
			bridgePaginationVo.setPage(ApplicationConstants.DEFAULT_GET_BOOK_PAGE_VALUE);
		}

		Integer limit = bridgePaginationVo.getLimit();
		if (null == limit || limit == 0) {
			bridgePaginationVo.setLimit(ApplicationConstants.DEFAULT_GET_BOOK_LIMIT_VALUE);
		}

		String orderby = bridgePaginationVo.getOrderBy();
		if (!StringUtils.isEmpty(orderby) && !ApplicationConstants.validBookOrderByValues.contains(orderby)) {
			throw new BridgeException(ApplicationCode.INVALID_ORDERBY_FIELD);
		}
		if (null == orderby || StringUtils.isEmpty(orderby)) {
			bridgePaginationVo.setOrderBy(ApplicationConstants.DEFAULT_GET_BOOK_ORDER_BY_VALUE);
		}

		String order = bridgePaginationVo.getOrder();
		if (null == order || StringUtils.isEmpty(order)) {
			bridgePaginationVo.setOrder(ApplicationConstants.DEFAULT_GET_BOOK_ORDER_VALUE);
		}		
	}

	/**
	 * This method is used to calculate total page count for report
	 * 
	 * @param totalCount
	 * @param totalRowsToFetch
	 * @return {@link String}
	 */
	private Integer calculateTotalPageCount(final int totalCount, final int totalRowsToFetch) {
		final Integer pageCount = (int) Math.ceil((double) totalCount / totalRowsToFetch);
		return pageCount;
	}

	/**
	 * This method is used to calculate start index for report
	 * 
	 * @param currentPage
	 * @param totalRowsToFetch
	 * @return {@link Integer} value
	 */
	private Integer calculateStartIndexForReport(final int currentPage, final int totalRowsToFetch) {
		final Integer startIndex = (currentPage * totalRowsToFetch) - totalRowsToFetch;
		return startIndex;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getBooksForDeferSignIn(HttpServletRequest httpRequest, UriInfo uriInfo, String code,
			String domain, BridgePaginationVo bridgePaginationVo) throws BridgeException, ConnectApiException {
		RestResponse response = null;
		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (null == bridge) {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		if (null != bridge.getDerefedSignIn() || bridge.getDerefedSignIn()) {
			response = this.getBooks(null, null, null, code, bridgePaginationVo,null, true);
		} else {
			throw new BridgeException(ApplicationCode.SESSION_EXPIRED);
		}

		return response;
	}

}
