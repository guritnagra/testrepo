package com.vst.bridge.dao.admin;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.user.AdminUserLabel;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminUserLabelDAO extends IGenericDAO<AdminUserLabel, Integer>{
	public List<AdminUserLabel> getAllLabels()throws BridgeException;	
	public List<IdValueVO> getListOfLabels() throws BridgeException ;
	public AdminUserLabel getLabelByName(final String label)throws BridgeException ;
	
}