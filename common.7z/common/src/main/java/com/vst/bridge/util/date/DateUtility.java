	package com.vst.bridge.util.date;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.Hours;
import org.joda.time.Months;

import com.vst.bridge.util.constant.ApplicationConstants;

public class DateUtility {
	
	private static DateFormat formatter= new SimpleDateFormat("MM/dd/yyyy");
	
	public static Calendar DateToCalendar(Date date){ 
		  Calendar cal = Calendar.getInstance();
		  cal.setTime(date);
		  return cal;
		}
	
	public static Integer expireDaysRemaing(Date expire){
		DateTime dateTime1 = new DateTime();
		DateTime dateTime2 = new DateTime(expire);
		Integer diffrence = Days.daysBetween(dateTime1, dateTime2).getDays();
		return diffrence;
	}
	
	public static Integer expireMonthsRemaing(Date expire){
		DateTime dateTime1 = new DateTime();
		DateTime dateTime2 = new DateTime(expire);
		Integer diffrence = Months.monthsBetween(dateTime1, dateTime2).getMonths();
		return diffrence;
	}
	
	
	public static String getBridgeFormatedDate(Date date){
		 return formatter.format(date);
	}
	
	public static void main(String[] args) throws ParseException{
		
		Date date = formatter.parse("08/22/2016");
		//2016-08-22 16:32:38
		//2016-08-24 16:32:38
		//System.out.println(expireDaysRemaing(date));
		//System.out.println(formatter.format(new Date()));
		
		//System.out.println("getEndOfDay+1->"+getNextDayEndOfDay());	
		/*Date d1= new Date();
		d1.setSeconds(-20);*/
		
		String sku="9789871981502T1R180";
		
		if(sku.matches(ApplicationConstants.BOOK_LICENSES_RENTAL_KEY_CHECK_REGREX))
			System.out.println("matches");
		
		
		System.out.println("seconds :"+secondsBetweenTime(date));
		
		
	}
	public static Date getNextDayEndOfDay() {
	    Calendar calendar = Calendar.getInstance();
	    int year = calendar.get(Calendar.YEAR);
	    int month = calendar.get(Calendar.MONTH);
	    int day = calendar.get(Calendar.DATE);
	    calendar.set(year, month, day, 23, 59, 59);
	    calendar.add(Calendar.DATE, 1);
	    return calendar.getTime();
	}
	
	/**
	 * Adds number of days passed in the argument to current date and returns new Date
	 * @param days
	 * @return Date
	 */
	public static Date addDays(int days){
	    Calendar cal = Calendar.getInstance();
	    cal.setTime(new Date());
	    cal.add(Calendar.DATE, days);
	    return cal.getTime();
	}
	
	public static Date getDateStartOfDay(Date date){
	    Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
	    int year = calendar.get(Calendar.YEAR);
	    int month = calendar.get(Calendar.MONTH);
	    int day = calendar.get(Calendar.DATE);
	    calendar.set(year, month, day, 0, 0, 0);
	    return calendar.getTime();
	}
	
	public static Date getDateEndOfDay(Date date){
	    Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
	    int year = calendar.get(Calendar.YEAR);
	    int month = calendar.get(Calendar.MONTH);
	    int day = calendar.get(Calendar.DATE);
	    calendar.set(year, month, day, 23, 59, 59);
	    return calendar.getTime();
	}
	
	public static int getDiffrenceBeetweenDatesInHours(Date d1,Date d2){		
		DateTime dt1 = new DateTime(d1);
		DateTime dt2 = new DateTime(d2);
		return Hours.hoursBetween(dt1, dt2).getHours() % 24;
	}
	
	public static Date convertStringToDate(String dateStr) {
		Date date = null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");	 //2016-08-01T00:00:00Z
			date = sdf.parse(dateStr);
			

		} catch (ParseException e) {

			e.printStackTrace();
		}
		return date;
	}
	
	public static long secondsBetweenTime(Date fromDate){
		long currentDateTime= new Date().getTime();
		long dateTime1 = fromDate.getTime();
		long seconds=(currentDateTime-dateTime1)/1000;
		return seconds;
	}

}
