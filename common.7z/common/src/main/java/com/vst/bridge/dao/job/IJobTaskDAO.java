package com.vst.bridge.dao.job;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.job.JobTask;

public interface IJobTaskDAO extends IGenericDAO<JobTask, Integer>{

}
