package com.vst.bridge.rest.response.vo.user;

public class ContextTokenVO {
	
	private String contextToken;

	public String getContextToken() {
		return contextToken;
	}

	public void setContextToken(String contextToken) {
		this.contextToken = contextToken;
	}

}
