package com.vst.bridge.rest.response.vo.ancillary;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AncillaryUploadTokenVO {
	@JsonProperty(value="token", required=true)
	private String token;
	@JsonProperty(value="expired_date", required=false)
	private Date expiresOn;
	private String callbackUrl;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public Date getExpiresOn() {
		return expiresOn;
	}

	public void setExpiresOn(Date expiresOn) {
		this.expiresOn = expiresOn;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallBackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}


}
