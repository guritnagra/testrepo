package com.vst.bridge.dao.user.token;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.user.token.BridgeUserResetPassword;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeUserResetPasswordDAO extends IGenericDAO<BridgeUserResetPassword, Integer>{

	Integer getChangePasswordCountByMail(String email) throws BridgeException;

	BridgeUserResetPassword getRequestByToken(String token)throws BridgeException;

}
