package com.vst.bridge.ws;

import java.util.List;

import org.glassfish.jersey.server.wadl.config.WadlGeneratorConfig;
import org.glassfish.jersey.server.wadl.config.WadlGeneratorDescription;
import org.glassfish.jersey.server.wadl.internal.generators.WadlGeneratorApplicationDoc;
import org.glassfish.jersey.server.wadl.internal.generators.WadlGeneratorGrammarsSupport;
import org.glassfish.jersey.server.wadl.internal.generators.resourcedoc.WadlGeneratorResourceDocSupport;

//import com.sun.jersey.api.wadl.config.WadlGeneratorConfig;
//import com.sun.jersey.server.wadl.generators.WadlGeneratorApplicationDoc;
//import com.sun.jersey.server.wadl.generators.WadlGeneratorGrammarsSupport;
//import com.sun.jersey.server.wadl.generators.resourcedoc.WadlGeneratorResourceDocSupport;
//import com.sun.jersey.api.wadl.config.WadlGeneratorDescription;

public class CustomWadlGeneratorConfig extends WadlGeneratorConfig 
{
	@Override
	public List<WadlGeneratorDescription> configure() 
	{
		return generator( WadlGeneratorApplicationDoc.class )
		      .prop( "applicationDocsStream", "application-doc.xml" )
		      .generator( WadlGeneratorGrammarsSupport.class )
		      .prop( "grammarsStream", "application-grammars.xml" )
		      .generator( WadlGeneratorResourceDocSupport.class )
		      .prop( "resourceDocStream", "resourcedoc.xml" )
		      .descriptions();
	}
}
