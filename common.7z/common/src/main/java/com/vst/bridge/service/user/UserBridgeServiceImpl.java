package com.vst.bridge.service.user;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.config.IBridgeConfigDAO;
import com.vst.bridge.dao.user.session.IBridgeUserSessionDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.BridgeConfig;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.rest.response.vo.RedirectURLVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.user.BridgeUserConfigVO;
import com.vst.bridge.rest.response.vo.user.BridgeUserInfoVO;
import com.vst.bridge.rest.response.vo.user.ConcurrencyCreditUsedDetailsVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.connectapi.ApiKeys;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;

@Service("userBridgeService")
public class UserBridgeServiceImpl implements IUserBridgeService {

	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private IBridgeDAO bridgeDAO;

	@Autowired
	private IBridgeUserSessionDAO bridgeUserSessionDAO;

	private List<String> bridgeDomainPostfix;

	@Autowired
	private IBridgeConfigDAO bridgeConfigDAO;

	@Autowired
	private UserServiceUtil userServiceUtil;

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getBridgeUserInfo(String sessionId, UriInfo uriInfo, String code)
			throws BridgeException, ConnectApiException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (null != bridge) {
			if (bridge.getPendingApproved()) {
				throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
			}
			if (null != sessionId && StringUtils.isNotEmpty(sessionId)) {
				BridgeUser bridgeUser = bridgeUserSessionDAO.getBridgeUserForSessionId(sessionId);
				if (bridgeUser == null) {
					throw new BridgeException(ApplicationCode.USER_NOT_FOUND);
				}
				BridgeUserInfoVO userInfoVO = userServiceUtil.populateBridgeUserInfoFromBridgeUser(bridgeUser);
				if(!bridge.getConcurrencyEnabled()){
					ConcurrencyCreditUsedDetailsVO disabledConcurrency = new ConcurrencyCreditUsedDetailsVO();
					disabledConcurrency.setTotal(0);
					userInfoVO.setConcurrencyCredits(disabledConcurrency);
				}
				response.setData(userInfoVO);
			}
		} else {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getBridgeConfig(HttpServletRequest httpRequest, UriInfo uriInfo, String code, String domain)
			throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		Boolean bridgeFound = Boolean.FALSE;
		if (bridge != null) {
			BridgeUserConfigVO bridgeUserConfigVO = populateBridgeUserConfigFromBridgeConfig(bridge);
			response.setData(bridgeUserConfigVO);
			bridgeFound = Boolean.TRUE;
		} else if (null != domain && StringUtils.isNotEmpty(domain)) {
			bridge = bridgeDAO.getBridgeForAlias(domain);
			if (null != bridge) {
				RedirectURLVO redirectURLVO = new RedirectURLVO();
				redirectURLVO.setUrl(bridge.getCode() + bridgeDomainPostfix.get(0));
				response = new RestResponse(Response.Status.FOUND.getStatusCode(),
						ApplicationCode.URL_REDIRECT.getCodeId(),
						localeMessageUtility.getMessage(ApplicationCode.URL_REDIRECT.getCodeId()));
				response.setData(redirectURLVO);
				bridgeFound = Boolean.TRUE;
			}
		}

		if (!bridgeFound) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		return response;
	}

	private BridgeUserConfigVO populateBridgeUserConfigFromBridgeConfig(Bridge bridge) {
		BridgeUserConfigVO userConfigVO = new BridgeUserConfigVO();
		List<BridgeConfig> bridgeConfigs = bridgeConfigDAO.getAllConfigForBridgeId(bridge.getId());
		Map<String, String> configs = new HashMap<String, String>();

		Map<String, String> labels = new HashMap<String, String>();

		if (null != bridgeConfigs && bridgeConfigs.size() > 0) {
			for (BridgeConfig config : bridgeConfigs) {
				if (config.getKeyName().contains("label.")) {
					/*if (config.getKeyName().contains("purchaseButton")
							&& ApplicationConstants.BRIDGE_TYPE_INSTITUTIONAL.equals(bridge.getBridgeType().getType()))
						continue;*/
					labels.put(config.getKeyName().substring("label.".length()), config.getKeyValue());
				} else {
					configs.put(config.getKeyName(), config.getKeyValue());
				}
			}
		}
		Boolean isPending = bridge.getPendingApproved() || bridge.getApiKey() == null
				|| StringUtils.isEmpty(bridge.getApiKey()) ? Boolean.TRUE : Boolean.FALSE;
		//Boolean isIntegrated = Boolean.FALSE;
	//	if (ApplicationConstants.BRIDGE_COMPANY_TYPE_PUBLISHER.equals(bridge.getBridgeType().getType()))
		Boolean	isIntegrated = StringUtils.isNotEmpty(bridge.getRentalURL()) || StringUtils.isNotEmpty(bridge.getFullURL())
					|| StringUtils.isNotEmpty(bridge.getPrintBookURL()) ? Boolean.TRUE : Boolean.FALSE;
		userConfigVO.setIsPending(isPending);
		if (!isPending) {
			String forgotPasswordUrl = new ApiKeys(ApplicationConstants.getApiMode(), bridge.getApiKey(), null, null)
					.getPasswordUrl();
			configs.put(ApplicationConstants.BRIDGE_CONFIG_FORGOT_PASSWORD_URL, forgotPasswordUrl);
		}
		if (null != bridge.getBridgeType())
			configs.put(ApplicationConstants.BRIDGE_CONFIG_COMPANY_TYPE, bridge.getBridgeType().getType());
		configs.put(ApplicationConstants.BRIDGE_CONFIG_PROTECTED_PASSWORD, bridge.getPasswordProtected().toString());

		userConfigVO.setLabels(labels);
		userConfigVO.setIsDefered(bridge.getDerefedSignIn());
		userConfigVO.setIsIntegrated(isIntegrated); // This flag doesn't
													// represent integrated
													// bridges(BC bridges), it
													// is for identifying if
													// purchase URL is
													// integrated to bridge or
													// not
		userConfigVO.setIsRostered(bridge.getIsRostered());
		userConfigVO.setIsBCIntegrated(bridge.getIsIntegrated());
		userConfigVO.setKeysRequired(bridge.getKeysRequired());
		userConfigVO.setConfig(configs);
		userConfigVO.setCode(bridge.getCode());
		userConfigVO.setLanguage(bridge.getLanguage());
		userConfigVO.setName(bridge.getName());
		userConfigVO.setIsSampler(bridge.getIsSampler());
		userConfigVO.setIsEmbeddedEnabled(bridge.getIsEmbeddedEnabled());
		if(bridge.getIsEmbeddedEnabled()!=null && bridge.getIsEmbeddedEnabled()){
			String brandedUrl=StringUtils.isEmpty(bridge.getBookshelfUrl()) ? ApiKeys.getEmbeddedBridgeReaderBrand(ApplicationConstants.getApiMode()): bridge.getBookshelfUrl();
			userConfigVO.setBrandedUrl(brandedUrl);
		}
		return userConfigVO;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse checkBridgeCode(final String code, final String domain) throws BridgeException {
		RestResponse response = null;

		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		Boolean bridgeFound = Boolean.FALSE;
		if (bridge != null) {
			bridgeFound = Boolean.TRUE;
		} else if (null != domain && StringUtils.isNotEmpty(domain)) {
			bridge = bridgeDAO.getBridgeForAlias(domain);
			if (null != bridge) {
				RedirectURLVO redirectURLVO = new RedirectURLVO();
				redirectURLVO.setUrl(bridge.getCode() + bridgeDomainPostfix.get(0));
				response = new RestResponse(Response.Status.FOUND.getStatusCode(),
						ApplicationCode.URL_REDIRECT.getCodeId(),
						localeMessageUtility.getMessage(ApplicationCode.URL_REDIRECT.getCodeId()));
				response.setData(redirectURLVO);
				bridgeFound = Boolean.TRUE;
			}
		}

		if (!bridgeFound) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		return response;
	}

}
