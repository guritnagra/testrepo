package com.vst.bridge.rest.input.vo;

import java.util.List;

public class AllowanceRequestVO {
	
	private List<ConcurrencyEntitlementVO> concurrencyEntitlements;
	private List<EntitlementVO> entitlements;
	public List<ConcurrencyEntitlementVO> getConcurrencyEntitlements() {
		return concurrencyEntitlements;
	}
	public void setConcurrencyEntitlements(List<ConcurrencyEntitlementVO> concurrencyEntitlements) {
		this.concurrencyEntitlements = concurrencyEntitlements;
	}
	public List<EntitlementVO> getEntitlements() {
		return entitlements;
	}
	public void setEntitlements(List<EntitlementVO> entitlements) {
		this.entitlements = entitlements;
	}	
	
	
}
