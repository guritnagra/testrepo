package com.vst.bridge.util.recaptcha;

import java.util.Date;

public interface IReCaptchaAttemptService {
	public static final int MAX_ATTEMPTS_CAPTCHA = 3;
	
	public static final int MAX_ATTEMPTS_PW = 3;
	
	void reCaptchaSuccessful(String username, String ipAddress);

	void reCaptchaFailure(String username, String ipAddress);

	Boolean isBlocked(String username, String ipAddress);

	int getUnsuccessfulAttempts(String username, String ipAddress);

	Date getLastUnsuccessfulTime(String username, String ipAddress);
	
	void resetLastUnsuccessful(String username, String ipAddress);



}