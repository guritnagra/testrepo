package com.vst.bridge.rest.response.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ContextVO {

	@JsonProperty("lti_sequence_ident")
	private String ltiSequenceIdent;
	@JsonProperty("service_path")
	private String servicePath;
	@JsonProperty("tenant_id")
	private String tenantId;
	private String strategy;
	private String tactic;
	@JsonProperty("b2_version")
	private String b2Version;
	@JsonProperty("context_label")
	private String contextLabel;
	@JsonProperty("custom_user_data_source_id")
	private String customUserDataSourceId;
	@JsonProperty("lis_person_name_family")
	private String lisPersonNameFamily;
	@JsonProperty("resource_link_id")
	private String resourceLinkId;
	@JsonProperty("launch_presentation_return_url")
	private String launchPresentationReturnUrl;
	@JsonProperty("lti_version")
	private String ltiVersion;
	@JsonProperty("tool_consumer_instance_contact_email")
	private String toolConsumerInstanceContactEmail;
	@JsonProperty("custom_user_uuid")
	private String customUserUuid;
	@JsonProperty("user_id ")
	private String userId;
	@JsonProperty("lti_message_type")
	private String ltiMessageType;
	@JsonProperty("custom_user_student_id")
	private String customUserStudentId;
	@JsonProperty("custom_adoption_data_return_url")
	private String customAdoptionDataReturnUrl;
	@JsonProperty("custom_user_name")
	private String customUserName;
	@JsonProperty("context_title")
	private String contextTitle;
	@JsonProperty("tool_consumer_instance_name")
	private String toolConsumerInstanceName;
	@JsonProperty("lms_version")
	private String lmsVersion;
	@JsonProperty("custom_user_id")
	private String customUserId;
	@JsonProperty("custom_context_role")
	private String customContextRole;
	@JsonProperty("custom_user_batch_uid")
	private String customUserBatchUid;
	@JsonProperty("context_type")
	private String contextType;
	@JsonProperty("tool_consumer_instance_description")
	private String toolConsumerInstanceDescription;
	@JsonProperty("context_id")
	private String contextId;
	private String roles;
	@JsonProperty("custom_adoption_data_sourcedid")
	private String customAdoptionDataSourcedid;
	@JsonProperty("lis_person_contact_email_primary")
	private String lisPersonContactEmailPrimary;
	@JsonProperty("lis_person_name_given")
	private String lisPersonNameGiven;
	@JsonProperty("result_status ")
	private String resultStatus;
	@JsonProperty("result_message_key")
	private String resultMessageKey;
	@JsonProperty("result_message")
	private String resultMessage;
	private String course;
	@JsonProperty("tos_return")
	private String tosReturn;
	@JsonProperty("last_name ")
	private String lastName;
	@JsonProperty("alternate_return_url")
	private String alternateReturnUrl;
	@JsonProperty("email_address")
	private String emailAddress;
	@JsonProperty("first_name")
	private String firstName;
	@JsonProperty("base_url")
	private String baseUrl;
	@JsonProperty("pay_term")
	private String payTerm;
	@JsonProperty("tenant_user_id")
	private String tenantUserId;
	@JsonProperty("tenant_user_guid")
	private String tenantUserGuid;
	@JsonProperty("tenant_user_access_token")
	private String tenantUserAccessToken;
	@JsonProperty("bookholder_customer")
	private String bookholderCustomer;
	private String vbid;
	private String sku;
	@JsonProperty("bookmeta_vbid")
	private String bookmetaVbid;
	@JsonProperty("book_type")
	private String bookType;
	@JsonProperty("resolved_course")
	private String resolved_course;
	private String location;
	@JsonProperty("custom_location")
	private String customLocation;
	@JsonProperty("bh_resource_links")
	private List<String> bhResourceLinks;
	public String getLtiSequenceIdent() {
		return ltiSequenceIdent;
	}
	public void setLtiSequenceIdent(String ltiSequenceIdent) {
		this.ltiSequenceIdent = ltiSequenceIdent;
	}
	public String getServicePath() {
		return servicePath;
	}
	public void setServicePath(String servicePath) {
		this.servicePath = servicePath;
	}
	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	public String getStrategy() {
		return strategy;
	}
	public void setStrategy(String strategy) {
		this.strategy = strategy;
	}
	public String getTactic() {
		return tactic;
	}
	public void setTactic(String tactic) {
		this.tactic = tactic;
	}
	public String getB2Version() {
		return b2Version;
	}
	public void setB2Version(String b2Version) {
		this.b2Version = b2Version;
	}
	public String getContextLabel() {
		return contextLabel;
	}
	public void setContextLabel(String contextLabel) {
		this.contextLabel = contextLabel;
	}
	public String getCustomUserDataSourceId() {
		return customUserDataSourceId;
	}
	public void setCustomUserDataSourceId(String customUserDataSourceId) {
		this.customUserDataSourceId = customUserDataSourceId;
	}
	public String getLisPersonNameFamily() {
		return lisPersonNameFamily;
	}
	public void setLisPersonNameFamily(String lisPersonNameFamily) {
		this.lisPersonNameFamily = lisPersonNameFamily;
	}
	public String getResourceLinkId() {
		return resourceLinkId;
	}
	public void setResourceLinkId(String resourceLinkId) {
		this.resourceLinkId = resourceLinkId;
	}
	public String getLaunchPresentationReturnUrl() {
		return launchPresentationReturnUrl;
	}
	public void setLaunchPresentationReturnUrl(String launchPresentationReturnUrl) {
		this.launchPresentationReturnUrl = launchPresentationReturnUrl;
	}
	public String getLtiVersion() {
		return ltiVersion;
	}
	public void setLtiVersion(String ltiVersion) {
		this.ltiVersion = ltiVersion;
	}
	public String getToolConsumerInstanceContactEmail() {
		return toolConsumerInstanceContactEmail;
	}
	public void setToolConsumerInstanceContactEmail(String toolConsumerInstanceContactEmail) {
		this.toolConsumerInstanceContactEmail = toolConsumerInstanceContactEmail;
	}
	public String getCustomUserUuid() {
		return customUserUuid;
	}
	public void setCustomUserUuid(String customUserUuid) {
		this.customUserUuid = customUserUuid;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getLtiMessageType() {
		return ltiMessageType;
	}
	public void setLtiMessageType(String ltiMessageType) {
		this.ltiMessageType = ltiMessageType;
	}
	public String getCustomUserStudentId() {
		return customUserStudentId;
	}
	public void setCustomUserStudentId(String customUserStudentId) {
		this.customUserStudentId = customUserStudentId;
	}
	public String getCustomAdoptionDataReturnUrl() {
		return customAdoptionDataReturnUrl;
	}
	public void setCustomAdoptionDataReturnUrl(String customAdoptionDataReturnUrl) {
		this.customAdoptionDataReturnUrl = customAdoptionDataReturnUrl;
	}
	public String getCustomUserName() {
		return customUserName;
	}
	public void setCustomUserName(String customUserName) {
		this.customUserName = customUserName;
	}
	public String getContextTitle() {
		return contextTitle;
	}
	public void setContextTitle(String contextTitle) {
		this.contextTitle = contextTitle;
	}
	public String getToolConsumerInstanceName() {
		return toolConsumerInstanceName;
	}
	public void setToolConsumerInstanceName(String toolConsumerInstanceName) {
		this.toolConsumerInstanceName = toolConsumerInstanceName;
	}
	public String getLmsVersion() {
		return lmsVersion;
	}
	public void setLmsVersion(String lmsVersion) {
		this.lmsVersion = lmsVersion;
	}
	public String getCustomUserId() {
		return customUserId;
	}
	public void setCustomUserId(String customUserId) {
		this.customUserId = customUserId;
	}
	public String getCustomContextRole() {
		return customContextRole;
	}
	public void setCustomContextRole(String customContextRole) {
		this.customContextRole = customContextRole;
	}
	public String getCustomUserBatchUid() {
		return customUserBatchUid;
	}
	public void setCustomUserBatchUid(String customUserBatchUid) {
		this.customUserBatchUid = customUserBatchUid;
	}
	public String getContextType() {
		return contextType;
	}
	public void setContextType(String contextType) {
		this.contextType = contextType;
	}
	public String getToolConsumerInstanceDescription() {
		return toolConsumerInstanceDescription;
	}
	public void setToolConsumerInstanceDescription(String toolConsumerInstanceDescription) {
		this.toolConsumerInstanceDescription = toolConsumerInstanceDescription;
	}
	public String getContextId() {
		return contextId;
	}
	public void setContextId(String contextId) {
		this.contextId = contextId;
	}
	public String getRoles() {
		return roles;
	}
	public void setRoles(String roles) {
		this.roles = roles;
	}
	public String getCustomAdoptionDataSourcedid() {
		return customAdoptionDataSourcedid;
	}
	public void setCustomAdoptionDataSourcedid(String customAdoptionDataSourcedid) {
		this.customAdoptionDataSourcedid = customAdoptionDataSourcedid;
	}
	public String getLisPersonContactEmailPrimary() {
		return lisPersonContactEmailPrimary;
	}
	public void setLisPersonContactEmailPrimary(String lisPersonContactEmailPrimary) {
		this.lisPersonContactEmailPrimary = lisPersonContactEmailPrimary;
	}
	public String getLisPersonNameGiven() {
		return lisPersonNameGiven;
	}
	public void setLisPersonNameGiven(String lisPersonNameGiven) {
		this.lisPersonNameGiven = lisPersonNameGiven;
	}
	public String getResultStatus() {
		return resultStatus;
	}
	public void setResultStatus(String resultStatus) {
		this.resultStatus = resultStatus;
	}
	public String getResultMessageKey() {
		return resultMessageKey;
	}
	public void setResultMessageKey(String resultMessageKey) {
		this.resultMessageKey = resultMessageKey;
	}
	public String getResultMessage() {
		return resultMessage;
	}
	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getTosReturn() {
		return tosReturn;
	}
	public void setTosReturn(String tosReturn) {
		this.tosReturn = tosReturn;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAlternateReturnUrl() {
		return alternateReturnUrl;
	}
	public void setAlternateReturnUrl(String alternateReturnUrl) {
		this.alternateReturnUrl = alternateReturnUrl;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getBaseUrl() {
		return baseUrl;
	}
	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}
	public String getPayTerm() {
		return payTerm;
	}
	public void setPayTerm(String payTerm) {
		this.payTerm = payTerm;
	}
	public String getTenantUserId() {
		return tenantUserId;
	}
	public void setTenantUserId(String tenantUserId) {
		this.tenantUserId = tenantUserId;
	}
	public String getTenantUserGuid() {
		return tenantUserGuid;
	}
	public void setTenantUserGuid(String tenantUserGuid) {
		this.tenantUserGuid = tenantUserGuid;
	}
	public String getTenantUserAccessToken() {
		return tenantUserAccessToken;
	}
	public void setTenantUserAccessToken(String tenantUserAccessToken) {
		this.tenantUserAccessToken = tenantUserAccessToken;
	}
	public String getBookholderCustomer() {
		return bookholderCustomer;
	}
	public void setBookholderCustomer(String bookholderCustomer) {
		this.bookholderCustomer = bookholderCustomer;
	}
	public String getVbid() {
		return vbid;
	}
	public void setVbid(String vbid) {
		this.vbid = vbid;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getBookmetaVbid() {
		return bookmetaVbid;
	}
	public void setBookmetaVbid(String bookmetaVbid) {
		this.bookmetaVbid = bookmetaVbid;
	}
	public String getBookType() {
		return bookType;
	}
	public void setBookType(String bookType) {
		this.bookType = bookType;
	}
	public String getResolved_course() {
		return resolved_course;
	}
	public void setResolved_course(String resolved_course) {
		this.resolved_course = resolved_course;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public List<String> getBhResourceLinks() {
		return bhResourceLinks;
	}
	public void setBhResourceLinks(List<String> bhResourceLinks) {
		this.bhResourceLinks = bhResourceLinks;
	}
	public String getCustomLocation() {
		return customLocation;
	}
	public void setCustomLocation(String customLocation) {
		this.customLocation = customLocation;
	}

}