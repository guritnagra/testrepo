package com.vst.bridge.rest.response.vo;

import com.vst.bridge.rest.input.vo.AllowanceRequestVO;

public class BridgeAllowanceResponseVO extends AllowanceRequestVO {
	
	private Integer bridgeId;
	private Boolean isConcurrencyEnabled;

	public Integer getBridgeId() {
		return bridgeId;
	}

	public void setBridgeId(Integer bridgeId) {
		this.bridgeId = bridgeId;
	}

	public Boolean getIsConcurrencyEnabled() {
		return isConcurrencyEnabled;
	}

	public void setIsConcurrencyEnabled(Boolean isConcurrencyEnabled) {
		this.isConcurrencyEnabled = isConcurrencyEnabled;
	}

}
