package com.vst.bridge.dao.user.session;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.session.BridgeUserSession;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeUserSessionDAO")
public class BridgeUserSessionDAOImpl extends GenericDAO<BridgeUserSession, Integer> implements IBridgeUserSessionDAO{

	public BridgeUserSessionDAOImpl() {
		super(BridgeUserSession.class);
	}

	@Override
	public BridgeUserSession getForSessionId(String sessionId, Boolean updateLastAcess, Date lastAcessdate)
			throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.like("sessionId", sessionId));
		if(updateLastAcess){
			criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
			Criterion criterion1 = Restrictions.or(Restrictions.isNull("lastAccess"), Restrictions.gt("lastAccess",lastAcessdate));
			criteria.add(criterion1);
		}
		List<BridgeUserSession> sessions = executeCriteira(criteria);
		return null != sessions && sessions.size()>0 ? sessions.get(0) : null;
	}

	@Override
	public BridgeUser getBridgeUserForSessionId(String sessionId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.like("sessionId", sessionId));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		List<BridgeUserSession> userSession = executeCriteira(criteria);
		return null != userSession && userSession.size() > 0? userSession.get(0).getUser() : null;
	}
}
