package com.vst.bridge.dao.admin;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.user.AdminUserLabel;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.util.exception.BridgeException;

@Repository("adminUserLabelDAO")
public class AdminUserLabelDAOImpl extends GenericDAO<AdminUserLabel, Integer> implements IAdminUserLabelDAO{

	public AdminUserLabelDAOImpl() {
		super(AdminUserLabel.class);
	}

	@Override
	public List<AdminUserLabel> getAllLabels() throws BridgeException {
		Criteria criteria = getCriteria();
		List<AdminUserLabel> adminUserLabelList= executeCriteira(criteria);
		
		return adminUserLabelList;
	}

	@Override
	public List<IdValueVO> getListOfLabels() throws BridgeException {		
		Criteria criteria = getCriteria();
		criteria.setProjection(Projections.projectionList()
				.add( Projections.property("id").as("id"))
				.add( Projections.property("label").as("value")))
				.setResultTransformer(new AliasToBeanResultTransformer(IdValueVO.class));
		return executeCriteira(criteria);
		
	}

	@Override
	public AdminUserLabel getLabelByName(String label) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("label", label));
		List<AdminUserLabel> result= executeCriteira(criteria);
		return null!=result && result.size() >0 ? result.get(0) : null;
	}

	
}
