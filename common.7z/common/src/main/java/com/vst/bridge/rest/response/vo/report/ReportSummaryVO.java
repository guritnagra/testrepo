package com.vst.bridge.rest.response.vo.report;

public class ReportSummaryVO {
	private Integer teachers;
	private Integer students;
	private Integer total;
	public Integer getTeachers() {
		return teachers;
	}
	public void setTeachers(Integer teachers) {
		this.teachers = teachers;
	}
	public Integer getStudents() {
		return students;
	}
	public void setStudents(Integer students) {
		this.students = students;
	}
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}
	
}
