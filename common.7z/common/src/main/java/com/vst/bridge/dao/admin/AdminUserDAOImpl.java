package com.vst.bridge.dao.admin;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.vst.bridge.StringUtils;
import com.vst.bridge.TomcatUtils;
import com.vst.bridge.dao.admin.session.IAdminSessionDAO;
import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.session.AdminSession;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.rest.response.vo.user.AdminInfoVo;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.BridgeException;

@Repository("adminUserDAO")
public class AdminUserDAOImpl extends GenericDAO<AdminUser, Integer> implements IAdminUserDAO{

	/**
	 * Represents the logger of the application.
	 */
	
	@Autowired
	private IAdminSessionDAO adminSessionDAO;
	
	public AdminUserDAOImpl() {
		super(AdminUser.class);
	}

	@Override
	public AdminUser authonticateAdminUser(String email, String password)throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.like("email", email));
		criteria.add(Restrictions.like("password", StringUtils.hash(password)));
		List<AdminUser> result = executeCriteira(criteria);
		return result != null && result.size()>0 ? result.get(0) : null;
	}

	@Override
	public AdminUser getAdminUserForSessionId(String sessionId)
			throws BridgeException {
		Criteria criteria = getCriteria(AdminSession.class);
		criteria.add(Restrictions.like("sessionId", sessionId));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MINUTE, -30);
		Criterion criterion1 = Restrictions.or(Restrictions.isNull("lastAccessDate"), Restrictions.gt("lastAccessDate",calendar.getTime()));
		criteria.add(criterion1);
		List<AdminSession> sessions = executeCriteira(criteria);
		if( null != sessions && sessions.size()>0){
			AdminSession adminSession = sessions.get(0);
			adminSession.setLastAccessDate(calendar.getTime());
			adminSessionDAO.update(adminSession);
			return adminSession.getAdmin();
		}
		return null;
	}

	@Override
	public List<AdminUser> getAllUsersForAdmin(Integer startIndex, BridgePaginationVo paginationVo) throws BridgeException {
		Criteria criteria = getCriteria();
		List<AdminUser> users = new ArrayList<AdminUser>();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		if(null!=paginationVo){
			Integer totalRecordToFetch = paginationVo.getLimit();
			if(null != startIndex && null != totalRecordToFetch  && totalRecordToFetch > 0){
				criteria.setFirstResult(startIndex);
				criteria.setMaxResults(totalRecordToFetch);
			}
			
			String search = paginationVo.getSearch();
			if(null!=search && !org.apache.commons.lang.StringUtils.isEmpty(search)){
				Criterion criterion1 = Restrictions.ilike("firstName", "%"+search+"%");
				Criterion criterion2 = Restrictions.ilike("lastName", "%"+search+"%");
				Criterion criterion3 = Restrictions.ilike("email", "%"+search+"%");
				Criterion completeCriterion = Restrictions.disjunction()
																	.add(criterion1)
																	.add(criterion2)
																	.add(criterion3);
				
				criteria.add(completeCriterion);
			}
			String orderBy = paginationVo.getOrderBy();
			if(null != orderBy && !org.apache.commons.lang.StringUtils.isEmpty(orderBy)){
				String order = paginationVo.getOrder();
				if(order.equals(ApplicationConstants.SORTING_ORDER_ASC)){
					criteria.addOrder(Order.asc(orderBy));
				}else{
					criteria.addOrder(Order.desc(orderBy));
				}
			}
		}
		List<AdminUser> results= executeCriteira(criteria);
		users.addAll(results);
		return users;
	}

	@Override
	public Boolean checkPasswordExistInDb(String password)
			throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.like("password", password));
		List<AdminUser> users = executeCriteira(criteria);
		return null != users && users.size() > 0 ? Boolean.TRUE : Boolean.FALSE;
	}

	@Override
	public Boolean checkEmailExistInDb(String email) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.ilike("email", email));
		List<AdminUser> users = executeCriteira(criteria);
		return null != users && users.size() > 0 ? Boolean.TRUE : Boolean.FALSE;
	}

	@Override
	public AdminUser getForEmail(String email) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.like("email", email));
		List<AdminUser> users = executeCriteira(criteria);
		return null != users && users.size() > 0 ? users.get(0) : null;
	}

	@Override
	public Integer getUserCount(BridgePaginationVo paginationVo) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		String search = paginationVo.getSearch();
		if(null!=search && !org.apache.commons.lang.StringUtils.isEmpty(search)){
			Criterion criterion1 = Restrictions.ilike("firstName", "%"+search+"%");
			Criterion criterion2 = Restrictions.ilike("lastName", "%"+search+"%");
			Criterion criterion3 = Restrictions.ilike("email", "%"+search+"%");
			Criterion completeCriterion = Restrictions.disjunction()
																.add(criterion1)
																.add(criterion2)
																.add(criterion3);
			
			criteria.add(completeCriterion);
		}
		List<AdminUser> users = executeCriteira(criteria);
		return null != users && users.size() > 0 ? users.size() : 0;
	}

	@Override
	public List<AdminInfoVo> getSuperAdmins() throws BridgeException {
		Criteria criteria = getCriteria();
		
		criteria.createAlias("role", "roleAlias");
		criteria.add(Restrictions.like("roleAlias.name", ApplicationConstants.USER_ROLE_SUPER_ADMIN));
		criteria.setProjection(Projections.projectionList()
				.add( Projections.property("firstName").as("name"))
				.add( Projections.property("email").as("email")))
				.setResultTransformer(new AliasToBeanResultTransformer(AdminInfoVo.class));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		return executeCriteira(criteria);
	}

	@Override
	public AdminUser getDummyJobUser() throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.like("email", TomcatUtils.getParam("job_scheduler_user")));
		List<AdminUser> users = executeCriteira(criteria);
		return null != users && users.size() > 0 ? users.get(0) : null;
	}

	@Override
	public AdminUser getAdminForSystemUserId(Integer systemUserId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.like("systemUserId", systemUserId));
		List<AdminUser> users = executeCriteira(criteria);
		return null != users && users.size() > 0 ? users.get(0) : null;
	}
	
	
}
