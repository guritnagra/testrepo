package com.vst.bridge.service.job;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.JDOMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.TomcatUtils;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.job.IJobTaskDAO;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.job.JobTask;
import com.vst.bridge.rest.response.vo.BridgeTenantVO;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.service.bc.IBusinessCenterServices;
import com.vst.bridge.service.report.IKpiDataReportService;
import com.vst.bridge.util.constant.ApplicationConstants.JobRecordType;
import com.vst.bridge.util.constant.ApplicationConstants.JobStatus;
import com.vst.bridge.util.constant.ApplicationConstants.JobType;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.exception.BusinessCenterException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;

//@EnableAsync
@Service("jobSchedulerServices")
public class JobSchedulerServicesImpl implements IJobSchedulerServices {
	
	private static Logger logger = LogManager.getLogger(JobSchedulerServicesImpl.class);
	
	@Autowired
	private IBridgeDAO bridgeDAO;
	
	@Autowired
	private IJobTaskDAO jobTaskDAO;
	
	@Autowired
	IAdminUserDAO adminUserDAO;
	
	@Autowired
	private IBusinessCenterServices businessCenterServices;
	
	@Autowired
	private IKpiDataReportService kpiDataReportService;

	@Override
	@Transactional
	public void populateUsersFromBC() {
		logger.info("-----populateUsersFromBC() started-----");
		List<BridgeTenantVO> integratedBridgeList = bridgeDAO.getIntegratedBridgesTenant();
		SessionStatusVO sessionStatusVO= new SessionStatusVO();	
		
		AdminUser adminUser=adminUserDAO.getForEmail(TomcatUtils.getParam("job_scheduler_user"));		
		sessionStatusVO.setAdminId(adminUser.getId());  //Dummy admin for job scheduler calls
		
		for(BridgeTenantVO bridgeTenantVO :integratedBridgeList){
			JobTask jobTask = this.populateJobTastStatusVO(new JobTask(),bridgeTenantVO,JobStatus.STARTED.name(),JobType.USERCOURSEJOB.name(),JobRecordType.USERS.name());
			Integer jobId=jobTaskDAO.create(jobTask);			
			//Populating users from quartz job
			try {
				businessCenterServices.getUsersForTenantId(sessionStatusVO, bridgeTenantVO.getBridgeId(), bridgeTenantVO.getBcTenantId(), null, null,jobTask,Boolean.TRUE);
			} catch (BridgeException | BusinessCenterException | IOException | ConnectApiException e) {
				e.printStackTrace();
				
			}
			if(!(JobStatus.ERROR.name()).equals(jobTask.getJobStatus())){
				jobTask.setJobStatus(JobStatus.COMPLETED.name());
				jobTaskDAO.saveOrUpdate(jobTask);
			}
			
		}	
		logger.info("-----populateUsersFromBC() Completed-----");
		populateCoursesFromBC();
	}

	@Override
	@Async
	@Transactional
	public void populateCoursesFromBC() {
		//populating Courses & users in courses from quartz job
		logger.info("-----populateCoursesFromBC() started-----");
		List<BridgeTenantVO> integratedBridgeList = bridgeDAO.getIntegratedBridgesTenant();
		SessionStatusVO sessionStatusVO= new SessionStatusVO();	
		
		AdminUser adminUser=adminUserDAO.getForEmail(TomcatUtils.getParam("job_scheduler_user"));		
		sessionStatusVO.setAdminId(adminUser.getId());
		for(BridgeTenantVO bridgeTenantVO :integratedBridgeList){
			JobTask courseJobTask = this.populateJobTastStatusVO(new JobTask(),bridgeTenantVO,JobStatus.STARTED.name(),JobType.USERCOURSEJOB.name(),JobRecordType.COURSES.name());
			Integer courseJobTaskId=jobTaskDAO.create(courseJobTask);			
			try {
				businessCenterServices.createOrUpdateCoursesForTenantId(sessionStatusVO, bridgeTenantVO.getBridgeId(), bridgeTenantVO.getBcTenantId(), null, null,courseJobTask, Boolean.TRUE);
			} catch (BridgeException | BusinessCenterException | IOException | ConnectApiException | JDOMException
					| ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();				
			}
			if(!(JobStatus.ERROR.name()).equals(courseJobTask.getJobStatus())){
				courseJobTask.setJobStatus(JobStatus.COMPLETED.name());
				jobTaskDAO.saveOrUpdate(courseJobTask);
			}
			
		}
		logger.info("-----populateCoursesFromBC() completed-----");
	}
	
	@Override
	@Async
	@Transactional
	public void generateKpiDataReport(){
		logger.info("-----generateKpiDataReport() started-----");
		kpiDataReportService.generateKpiDataReport();
		logger.info("-----generateKpiDataReport() finished-----");
	}

	private JobTask populateJobTastStatusVO(JobTask jobTask, BridgeTenantVO bridgeTenantVO, String jobStatus, String jobType,
			String jobRecordType) {		
		jobTask.setBridgeId(bridgeTenantVO.getBridgeId());
		jobTask.setTenantId(bridgeTenantVO.getBcTenantId());
		jobTask.setJobStatus(jobStatus);
		jobTask.setJobType(jobType);
		jobTask.setRecordType(jobRecordType);
		return jobTask;
		
	}

}
