package com.vst.bridge.rest.response.vo.user;

public class CreateKeysVO {
	private String code;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = null != code ? code.trim() : code;
	}

}
