package com.vst.bridge.service.user;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vst.bridge.MapDB;
import com.vst.bridge.VstException;
import com.vst.bridge.VstUtils;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.allowance.IBridgeAllowanceNotificationDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookCacheDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupAssetDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupDAO;
import com.vst.bridge.dao.key.IKeyBatchDAO;
import com.vst.bridge.dao.key.IKeyDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.dao.user.key.IBridgeUserKeyDAO;
import com.vst.bridge.dao.user.session.IBridgeUserSessionDAO;
import com.vst.bridge.dao.user.token.IBridgeUserEmailTokenDAO;
import com.vst.bridge.entity.admin.allowance.BridgeAllowanceNotification;
import com.vst.bridge.entity.base.BaseEntity;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.entity.bridge.session.BridgeUserSession;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.BridgeUserKey;
import com.vst.bridge.entity.bridge.user.token.BridgeUserEmailToken;
import com.vst.bridge.entity.group.BridgeGroup;
import com.vst.bridge.entity.group.GroupAsset;
import com.vst.bridge.entity.keys.KeyBatch;
import com.vst.bridge.entity.keys.Keys;
import com.vst.bridge.rest.response.vo.ContextVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.user.BridgeUserInfoVO;
import com.vst.bridge.rest.response.vo.user.IntegratedBridgeUserResponseVO;
import com.vst.bridge.rest.response.vo.user.RostereUserInfoVO;
import com.vst.bridge.util.constant.ApplicationAction;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.date.DateUtility;
import com.vst.bridge.util.email.EmailHandlerService;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.exception.BusinessCenterException;
import com.vst.bridge.util.exception.IntegrationException;
import com.vst.bridge.util.message.LocaleMessageUtility;

@Service("userValidationService")
public class UserValidationServiceImpl implements IUserValidationService {
	@Autowired
	private IBridgeUserDAO bridgeUserDAO;

	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private IBridgeDAO bridgeDAO;

	@Autowired
	private IBridgeUserSessionDAO bridgeUserSessionDAO;

	@Autowired
	private IBridgeUserKeyDAO bridgeUserKeyDAO;

	@Autowired
	private IKeyDAO keyDAO;

	@Autowired
	private IKeyBatchDAO keyBatchDAO;

	@Autowired
	private IBridgeUserEmailTokenDAO bridgeUserEmailTokenDAO;

	@Autowired
	private IBridgeBookCacheDAO bridgeBookCacheDAO;

	@Autowired
	private IBridgeGroupAssetDAO bridgeGroupAssetDAO;

	@Autowired
	private IBridgeGroupDAO bridgeGroupDAO;

	@Autowired
	private UserServiceUtil userServiceUtil;

	@Autowired
	private ObjectMapper objectMapper;

	private Logger log = LogManager.getLogger(UserValidationServiceImpl.class);

	@Autowired
	private EmailHandlerService emailHandler;

	@Autowired
	private IAdminUserDAO adminUserDAO;

	@Autowired
	private IBridgeAllowanceNotificationDAO bridgeAllowanceNotificationDAO;

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false)
	public RestResponse validateToken(String code, String token) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (bridge == null) {
			throw new BridgeException("Token " + token, ApplicationCode.NO_SUCH_WEBSITE);
		}
		if (StringUtils.isNotBlank(token)) {

			BridgeUserEmailToken bridgeUserEmailToken = bridgeUserEmailTokenDAO.getForToken(token);
			if (null != bridgeUserEmailToken) {
				Date currentDate = new Date();
				Boolean used = bridgeUserEmailToken.getUsed();
				if (null != used && used) {
					throw new BridgeException(ApplicationCode.ALREADY_USED_TOKEN);
				}
				Date tokenCreatedDate = bridgeUserEmailToken.getCreatedDate();
				if (DateUtility.getDiffrenceBeetweenDatesInHours(tokenCreatedDate, currentDate) >= 12) {
					throw new BridgeException("Token " + token, ApplicationCode.EXPIRED_TOKEN);
				}
				String email = bridgeUserEmailToken.getEmail();
				BridgeUser bridgeUser = bridgeUserDAO.getForEmail(bridgeUserEmailToken.getBridge().getId(), email);
				RostereUserInfoVO rostereUserInfoVO = new RostereUserInfoVO();
				rostereUserInfoVO.setEmail(email);
				rostereUserInfoVO.setFirstName(bridgeUser.getFirstName());
				rostereUserInfoVO.setLastName(bridgeUser.getLastName());
				response.setData(rostereUserInfoVO);
			} else {
				throw new BridgeException("Token " + token, ApplicationCode.INVALID_TOKEN);
			}

		} else {
			throw new BridgeException("Token " + token, ApplicationCode.INVALID_INPUT);
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false)
	public RestResponse ssoLoginForIntegratedUser(IntegratedBridgeUserResponseVO integratedBridgeUserResponseVO,
			String code, HttpServletResponse httpResponse, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException, BusinessCenterException, VstException, IntegrationException {
		String requestString = VstUtils.getUrlWithProtocol(httpRequest, VstUtils.getDomain(uriInfo, httpRequest));
		URL requestUrl = new URL(requestString+ApplicationConstants.USER_ERROR_PAGE);
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		String sessionId = null;
		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (bridge == null) {
			throw new BridgeException(
					"No bridge found with code: " + code + " with context "
							+ integratedBridgeUserResponseVO.getContextVO().getLtiSequenceIdent(),
					ApplicationCode.NO_SUCH_WEBSITE);
		}

		BridgeUser bridgeUser = bridgeUserDAO
				.getBridgeUserByTenantUserId(integratedBridgeUserResponseVO.getTenantUserId(), bridge.getId());
		if (bridgeUser == null) {
			throw new BridgeException(
					"The user with tenant user id: " + integratedBridgeUserResponseVO.getTenantUserId()
							+ " was not found with context "
							+ integratedBridgeUserResponseVO.getContextVO().getLtiSequenceIdent(),
					ApplicationCode.USER_NOT_FOUND);
		} else if (bridgeUser.getAccessToken() == null && bridgeUser.getGuid() == null) {
			throw new BridgeException(
					"The user with tenant user id: " + integratedBridgeUserResponseVO.getTenantUserId()
							+ " is not a full user with context "
							+ integratedBridgeUserResponseVO.getContextVO().getLtiSequenceIdent(),
					ApplicationCode.NOT_FULL_USER);
		}

		boolean isIntegrated = bridge.getIsIntegrated();
		if (isIntegrated) {
			sessionId = VstUtils.createSessionid(null);
			List<BridgeUserKey> userKeys = bridgeUserKeyDAO.getListOfKeysAssigedForUser(bridgeUser.getId());

			if (userKeys.isEmpty()) {
				getKeysForSSOLaunch(bridge, bridgeUser);
			}

			BridgeUserSession session = new BridgeUserSession();
			session.setSessionId(sessionId);
			session.setUser(bridgeUser);
			bridgeUserSessionDAO.create(session);
			BridgeUserInfoVO userInfoVO = userServiceUtil.populateBridgeUserInfoFromBridgeUser(bridgeUser);
			Map<String, String> metadata = new HashMap<>();
			populateMetaData(metadata, integratedBridgeUserResponseVO, bridge);
			response.setMetadata(metadata);
			response.setData(userInfoVO);
			userServiceUtil.createBridgeLog(bridgeUser.getId(), bridgeDAO.getBridgeForCode(code),
					ApplicationAction.LOGIN, sessionId);
		} else {

			throw new IntegrationException(
					"Bridge with id:" + bridge.getId() + " not integrated with context "
							+ integratedBridgeUserResponseVO.getContextVO().getLtiSequenceIdent(),
					ApplicationCode.BRIDGE_NOT_INTEGRATED,requestUrl);
		}
		Cookie cookie = new Cookie(ApplicationConstants.BRIDGE_SESSIONID, sessionId);
		cookie.setMaxAge(NewCookie.DEFAULT_MAX_AGE);
		cookie.setSecure(ApplicationConstants.COOKIE_SECURE);
		cookie.setPath("/");
		httpResponse.addCookie(cookie);

		return response;
	}

	private void getKeysForSSOLaunch(Bridge bridge, BridgeUser bridgeUser) {
		KeyBatch keyBatch = keyBatchDAO.getKeyBatchForAutoRedeem(bridge.getId());
		Keys key = new Keys();
		if (null == keyBatch) {
			List<BridgeAllowanceNotification> bridgeAllowanceNotificationList = bridgeAllowanceNotificationDAO
					.getLastBridgeAllowanceNotifications(bridge.getId());
			if (bridgeAllowanceNotificationList == null || bridgeAllowanceNotificationList.isEmpty()) {
				emailHandler.sendBridgeAllowanceNotificationEmail(bridge, adminUserDAO.getSuperAdmins(), null);

			} else {
				for (BridgeAllowanceNotification lastBridgeAllowanceNotification : bridgeAllowanceNotificationList) {
					Date lastNotificationDate = lastBridgeAllowanceNotification.getLastNotification();
					Date currentTime = new Date();
					if (((currentTime.getTime() - lastNotificationDate.getTime()) / 1000) >= 43200) {
						emailHandler.sendBridgeAllowanceNotificationEmail(bridge, adminUserDAO.getSuperAdmins(),
								lastBridgeAllowanceNotification);
						break;
					}
				}
			}
			throw new BridgeException(ApplicationCode.KEY_BATCH_NOT_FOUND);
		}
		Integer fullCredits = null != bridge.getFullCredits() ? bridge.getFullCredits() : 0;
		keyBatch.setFullCredits(fullCredits);
		Integer rentalCredits = null != bridge.getRentalCredits() ? bridge.getRentalCredits() : 0;
		keyBatch.setRentalCredits(rentalCredits);
		Integer trialCredits = null != bridge.getTrialCredits() ? bridge.getTrialCredits() : 0;
		Integer concurrentCredits = null;
		if (bridge.getConcurrencyEnabled()) {
			concurrentCredits = null != bridge.getConcurrencyCredits() ? bridge.getConcurrencyCredits() : 0;
		}
		key.setKeyBatch(keyBatch);
		List<String> codes = VstUtils.getKeyCodeValues(1);
		key.setKeyCode("A" + codes.get(0));
		key.setExpireDate(keyBatch.getExpireDate());
		key.setFullCredits(keyBatch.getFullCredits());
		key.setTrialCredits(keyBatch.getTrialCredits());
		key.setRentalCredits(keyBatch.getRentalCredits());
		key.setConcurrencyCredits(keyBatch.getConcurrencyCredits());
		List<Keys> keys = new ArrayList<Keys>();
		keys.add(key);
		keyBatch.setKeys(keys);
		keyDAO.create(key);
		keyBatchDAO.saveOrUpdate(keyBatch);
		BridgeUserKey bridgeUserKey = new BridgeUserKey();
		bridgeUserKey.setDeleted(Boolean.FALSE);
		bridgeUserKey.setActivationDate(new Date());
		bridgeUserKey.setKey(key);
		bridgeUserKey.setUser(bridgeUser);
		bridgeUserKeyDAO.saveOrUpdate(bridgeUserKey);
		userServiceUtil.createBridgeLog(bridgeUser.getId(), bridge, ApplicationAction.REGISTER_KEY, key.getKeyCode());
	}

	private void populateMetaData(Map<String, String> metadata,
			IntegratedBridgeUserResponseVO integratedBridgeUserResponseVO, Bridge bridge) {
		ContextVO context = integratedBridgeUserResponseVO.getContextVO();
		if (!StringUtils.isEmpty(context.getLocation()) || !StringUtils.isEmpty(context.getCustomLocation()))
			try {
				createDeepLinkSsoPath(context, bridge, metadata, integratedBridgeUserResponseVO);
			} catch (JsonProcessingException e) {
				throw new BridgeException(
						"There was an issue with sso integration token: " + context.getLtiSequenceIdent(),
						ApplicationCode.UNEXPECTED_ERROR, e);
			}

		else {
			/*
			 * For existing SSO functionality with no DeepLink location Option1:
			 * Send to bridge collection page Option2: Send to book details page
			 * 
			 */
			createSsoPath(context, bridge, metadata);
		}

	}

	private void createSsoPath(ContextVO context, BaseEntity bridge, Map<String, String> metadata) {
		String vbid = null;
		if(!StringUtils.isEmpty(context.getVbid()))
		{
			vbid = context.getVbid();
		}
		else if(!StringUtils.isEmpty(context.getSku()))
		{
			vbid = context.getSku();
		}
		else if(!StringUtils.isEmpty(context.getBookmetaVbid()))
		{
			vbid = context.getBookmetaVbid();
		}
		else
		{
			vbid = "BOOKSHELF-TUTORIAL";
		}
		

		vbid = checkVbidForRental(vbid);
		BridgeBookCache book = findBookForBridgeAndUser(vbid, bridge.getId(), context);
		vbid = null == book ? "BOOKSHELF-TUTORIAL" : book.getVbid();
		String location = "BOOKSHELF-TUTORIAL".equals(vbid) ? ApplicationConstants.BRIDGE_COLLECTION
				: ApplicationConstants.BRIDGE_BOOK_DETAILS + vbid;
		try {
			URLEncoder.encode(location, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			log.error("There was a problem encoding the URL with context: " + context.getLtiSequenceIdent(), e);
		}
		metadata.put("location", location);
		log.info("SSO launch with token: " + context.getLtiSequenceIdent());
	}

	private String checkVbidForRental(String vbid) {
	    Pattern p = Pattern.compile("R[0-9]+$");
	    Matcher m = p.matcher(vbid);
		if(m.find()){
			vbid = vbid.replaceAll("R[0-9]+$", "");
		}
		return vbid;
	}

	private void createDeepLinkSsoPath(ContextVO context, Bridge bridge, Map<String, String> metadata,
			IntegratedBridgeUserResponseVO integratedBridgeUserResponseVO) throws JsonProcessingException {
		String vbid = StringUtils.isEmpty(context.getBookmetaVbid()) ? vbid = context.getSku()
				: context.getBookmetaVbid();
		if (StringUtils.isEmpty(vbid)) {
			vbid = context.getVbid();
		}

		BridgeBookCache book = findBookForBridgeAndUser(vbid, bridge.getId(), context);
		metadata.put("vbid", null != book ? book.getVbid() : "BOOKSHELF-TUTORIAL");
		String location = StringUtils.isEmpty(context.getLocation()) ? context.getCustomLocation()
				: context.getLocation();
		try {
			location = URLEncoder.encode(location, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			log.error("There was a problem encoding the sso deep link location URL " + location, e);
		}
		metadata.put("location", "/books/" + metadata.get("vbid") + "/launch?" + ApplicationConstants.DEEPLINK_LOCATION
				+ "=" + location);
		String token = objectMapper.writeValueAsString(context);
		if (null != integratedBridgeUserResponseVO.getTenantUserId()) {
			MapDB.getInstance().getStore().put(integratedBridgeUserResponseVO.getTenantUserId(), token);
			log.info("Token " + context.getLtiSequenceIdent() + " persisted in-memory");
		}
		log.info("SSO deeplink with token " + context.getLtiSequenceIdent());
	}

	private BridgeBookCache findBookForBridgeAndUser(String vbid, int bridgeId, ContextVO context) {
		BridgeBookCache book = null;
		if (null != vbid) {
			book = bridgeBookCacheDAO.getBookForVbid(bridgeId, vbid);
			if (null == book) {
				book = bridgeBookCacheDAO.getCacheBooksForEbookIsbn(bridgeId, vbid);
			}
			if (book != null && StringUtils.isNotEmpty(context.getResolved_course())) {
				try {
					refreshGroupAsset(bridgeId, context, book);
				} catch (BridgeException e) {
					log.error("No group found for course id: " + context.getResolved_course() + " with context "
							+ context.getLtiSequenceIdent(), e);
				}
			}
		}
		return book;
	}

	private void refreshGroupAsset(int bridgeId, ContextVO contextVO, BridgeBookCache book) throws BridgeException {
		BridgeGroup bridgeGroup = bridgeGroupDAO.getGroupByCourseId(bridgeId, contextVO.getResolved_course());

		if (bridgeGroup == null) {
			throw new BridgeException("Context " + contextVO.getLtiSequenceIdent(), ApplicationCode.GROUP_NOT_FOUND);
		}
		String vbid = null == contextVO.getBookmetaVbid() ? contextVO.getVbid() : contextVO.getBookmetaVbid();
		GroupAsset asset = bridgeGroupAssetDAO.getGroupAsset(bridgeGroup.getId(), vbid);
			asset = null !=	asset ? asset : new GroupAsset();
			asset.setGroup(bridgeGroup);
			asset.setSelected(Boolean.TRUE);
			asset.setVbid(book.getVbid());
			bridgeGroupAssetDAO.saveOrUpdate(asset);
			log.info("Created/updated group asset with id: " + asset.getId() + " with context " + contextVO.getLtiSequenceIdent());
		}

}
