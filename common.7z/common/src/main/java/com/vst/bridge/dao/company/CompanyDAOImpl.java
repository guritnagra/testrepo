package com.vst.bridge.dao.company;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.company.Company;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;

@Repository("companyDAO")
public class CompanyDAOImpl extends GenericDAO<Company, Integer> implements ICompanyDAO{

	public CompanyDAOImpl() {
		super(Company.class);
	}

	@Override
	public List<Company> getAllCompanies(Integer startIndex, PaginationVO paginationVo) throws BridgeException {
		Criteria criteria = getCriteria();
		//criteria.addOrder(Order.asc("name"));
		if(null!=paginationVo){
			
			Integer totalRecordToFetch = paginationVo.getLimit();
			if(null != startIndex && null != totalRecordToFetch  && totalRecordToFetch > 0){
				criteria.setFirstResult(startIndex);
				criteria.setMaxResults(totalRecordToFetch);
			}
			
			String searchParam =  paginationVo.getSearch();
			if(StringUtils.isNotBlank(searchParam)){
				
				
				Criterion criterion1 = Restrictions.ilike("name", "%"+searchParam+"%");
				
				
				Criterion completeCriterion = Restrictions.disjunction()
						.add(criterion1);
						
				criteria.add(completeCriterion);
			}
			
			if(StringUtils.equals(paginationVo.getOrder(), ApplicationConstants.SORTING_ORDER_ASC)){
				criteria.addOrder(Order.asc(paginationVo.getOrderBy()));
			}else{
				criteria.addOrder(Order.desc(paginationVo.getOrderBy()));
			}
		}
		return executeCriteira(criteria);
	}

	@Override
	public Company getForName(String name) throws BridgeException {
		Criteria criteria = getCriteria();
		if(null != name){
			criteria.add(Restrictions.like("name", name));
		}
		List<Company> result =  executeCriteira(criteria);
		return result != null && result.size() > 0 ? result.get(0) : null ;
	}

	@Override
	public void checkCompanyNameExist(String name) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.like("name", name.trim()));
		List<Bridge> result = executeCriteira(criteria);
		 if(null != result && result.size() > 0){
			 throw new BridgeException(ApplicationCode.DUPLICATE_COMPANY_NAME);
		 }
	}

	@Override
	public Company getCompanyByApiKey(String apiKey) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.like("apiKey", apiKey));
		List<Company> result =  executeCriteira(criteria);
		return result != null && result.size() > 0 ? result.get(0) : null ;
	}

	@Override
	public List<Company> getCompaniesByIds(List<Integer> companyList) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.in("id", companyList));
		List<Company> result =  executeCriteira(criteria);
		return result;
	}
	
	@Override
	public Integer getAllCompaniesCount(PaginationVO paginationVo) throws BridgeException {
		Criteria criteria = getCriteria();
		//criteria.addOrder(Order.asc("name"));
		if(null!=paginationVo){		
			String searchParam =  paginationVo.getSearch();
			if(StringUtils.isNotBlank(searchParam)){
				
				
				Criterion criterion1 = Restrictions.ilike("name", "%"+searchParam+"%");
				
				
				Criterion completeCriterion = Restrictions.disjunction()
						.add(criterion1);
						
				criteria.add(completeCriterion);
			}	
		}
		List<Company> result = executeCriteira(criteria);
		if(null != result && result.size()>0){
			return result.size();
		}
 		return 0;
	}
}
