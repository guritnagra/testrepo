package com.vst.bridge.rest.response.vo.bridge;

public class IntigrationVO {
	private String eText;
	private String rental;
	private String textBook;
	private String eTextPrice;
	private String rentalPrice;
	private String textBookPrice;
	public String geteText() {
		return eText;
	}
	public void seteText(String eText) {
		this.eText = eText;
	}
	public String getRental() {
		return rental;
	}
	public void setRental(String rental) {
		this.rental = rental;
	}
	public String getTextBook() {
		return textBook;
	}
	public void setTextBook(String textBook) {
		this.textBook = textBook;
	}
	public String geteTextPrice() {
		return eTextPrice;
	}
	public void seteTextPrice(String eTextPrice) {
		this.eTextPrice = eTextPrice;
	}
	public String getRentalPrice() {
		return rentalPrice;
	}
	public void setRentalPrice(String rentalPrice) {
		this.rentalPrice = rentalPrice;
	}
	public String getTextBookPrice() {
		return textBookPrice;
	}
	public void setTextBookPrice(String textBookPrice) {
		this.textBookPrice = textBookPrice;
	}
	
}
