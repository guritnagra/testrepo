package com.vst.bridge.service.book;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.dao.bridge.book.IBridgeBookCacheDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookPricingDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupAssetDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupDAO;
import com.vst.bridge.dao.key.IKeyBatchDAO;
import com.vst.bridge.dao.key.IKeyBatchEntitlementDAO;
import com.vst.bridge.dao.log.IBridgeLogDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.dao.user.book.IBridgeUserBookAssignDAO;
import com.vst.bridge.dao.user.key.IBridgeUserKeyDAO;
import com.vst.bridge.entity.admin.ancillary.Ancillary;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.entity.bridge.books.BridgeBookPricing;
import com.vst.bridge.entity.bridge.log.BridgeLog;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.BridgeUserKey;
import com.vst.bridge.entity.keys.KeyBatch;
import com.vst.bridge.entity.keys.KeyBatchEntitlement;
import com.vst.bridge.entity.keys.Keys;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.ancillary.AncillaryBookVO;
import com.vst.bridge.rest.response.vo.bridge.BridgeBooksVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.rest.response.vo.user.UserCreditsInfoVO;
import com.vst.bridge.rest.response.vo.user.UserEntitlementVO;
import com.vst.bridge.util.constant.ApplicationAction;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.constant.DataType;
import com.vst.bridge.util.constant.MimeType;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.connectapi.ConnectBook;

@Service("bridgeServiceUtil")
public class BookServiceUtil {
	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private IBridgeUserBookAssignDAO bridgeUserBookAssignDAO;

	@Autowired
	private IBridgeBookCacheDAO bridgeBookCacheDAO;

	@Autowired
	private IBridgeUserDAO bridgeUserDAO;

	@Autowired
	private IBridgeUserKeyDAO bridgeUserKeyDAO;

	@Autowired
	private IBridgeLogDAO bridgeLogDAO;

	@Autowired
	private IBridgeGroupDAO bridgeGroupDAO;

	@Autowired
	private IBridgeGroupAssetDAO bridgeGroupAssetDAO;

	@Autowired
	private IBridgeBookPricingDAO bridgeBookPricingDAO;

	@Autowired
	private IKeyBatchEntitlementDAO keyBatchEntitlementDAO;

	@Autowired
	private IKeyBatchDAO keyBatchDAO;
	private Logger log = LogManager.getLogger(BookServiceUtil.class);

	public RestResponse getDefaultRestResponse() {
		return new RestResponse(Response.Status.OK.getStatusCode(), ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
	}
	
	@Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.READ_COMMITTED, readOnly=false)
	public void addOrRefreshBridgeBookCacheFromConnectBooks(Map<DataType, Map<String, ConnectBook>> connectBookMap, String apiKey, Bridge bridge) {
		if(null == bridge){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		List<BridgeBookCache> allCacheBooks = bridgeBookCacheDAO.getAllCacheBooks(bridge.getId(), Boolean.FALSE);
		Map<String,BridgeBookPricing> pricingMap = getPricingForBridgeBookCacheCollection(allCacheBooks);	
		Map<String, BridgeBookCache> completedRefreshBookMap = new HashMap<>();
		Map<String, ConnectBook> rentalConnectBooks = connectBookMap.get(DataType.CONNECT_RENTAL_MAP);
		Map<String, ConnectBook> standardConnectBook = connectBookMap.get(DataType.CONNECT_STANDARD_MAP);
		int deletedCount=0, createdCount=0, refreshedCount=0, count=0;
		for(BridgeBookCache bookCache:allCacheBooks){
			ConnectBook connectBook = standardConnectBook.remove(bookCache.getVbid());
			if(null != connectBook){
				populateBridgeBookCacheFromConnectBook(connectBook, apiKey, bridge, bookCache, pricingMap);
				completedRefreshBookMap.put(bookCache.getVbid(), bookCache);
				refreshedCount++;
			}else{	
				bookCache.setDeleted(Boolean.TRUE);
				bookCache.setLastModifiedDate(new Date());
				bridgeBookCacheDAO.update(bookCache);
				if(++count % 50 == 0){
					bridgeBookCacheDAO.flushAndClear();
				}
				deletedCount++;
			}
		}
		log.info(refreshedCount+" books refreshed for bridge id: "+bridge.getId());
		log.info(deletedCount+" books deleted for bridge id: "+bridge.getId());
		if(!standardConnectBook.isEmpty()){
			for(ConnectBook connectBook:standardConnectBook.values()){
				BridgeBookCache bookCache = populateBridgeBookCacheFromConnectBook(connectBook, apiKey, bridge, new BridgeBookCache(), pricingMap);
				completedRefreshBookMap.put(bookCache.getVbid(), bookCache);
				createdCount++;
			}
		}
		log.info(createdCount+" books created for bridge id: "+bridge.getId());
		if(null != completedRefreshBookMap && !completedRefreshBookMap.isEmpty()){
			saveOrUpdateBookCacheCollection(completedRefreshBookMap.values());
		}
		if(!rentalConnectBooks.isEmpty()){
			populateBridgeBookCacheFromConnectBook(rentalConnectBooks.values(), apiKey, bridge, completedRefreshBookMap, pricingMap);
		}
		deleteOldPricing(pricingMap);

	}

	private void deleteOldPricing(Map<String, BridgeBookPricing> pricingMap) {
		Collection<BridgeBookPricing> bookPricingCollection = pricingMap.values();
		for(BridgeBookPricing pricing:bookPricingCollection){
			pricing.setDeleted(Boolean.TRUE);
		}
		bridgeBookPricingDAO.saveOrUpdateAll(bookPricingCollection);
	}

	protected List<BridgeBooksVO> populateBridgeBooksVOFromConnectBook(List<BridgeBookCache> cacheBooks, Bridge bridge,
			BridgePaginationVo bridgePaginationVo, Boolean isGrouped) {
		List<BridgeBooksVO> books = populateBridgeBooksVOFromConnectBook(cacheBooks, bridge, isGrouped);
		List<BridgeBooksVO> responseBridgeBooksVO = new ArrayList<BridgeBooksVO>();

		Integer startIndex = calculateStartIndexForReport(bridgePaginationVo.getPage(), bridgePaginationVo.getLimit());
		Integer totalRecordToFetch = bridgePaginationVo.getLimit();

		bridgePaginationVo.setCount(books.size());

		for (int i = startIndex; i < books.size() && totalRecordToFetch > 0; i++) {
			responseBridgeBooksVO.add(books.get(i));
			totalRecordToFetch--;
		}

		return responseBridgeBooksVO;
	}

	/**
	 * This method is used to calculate start index for report
	 * 
	 * @param currentPage
	 * @param totalRowsToFetch
	 * @return {@link Integer} value
	 */
	private Integer calculateStartIndexForReport(final int currentPage, final int totalRowsToFetch) {
		final Integer startIndex = (currentPage * totalRowsToFetch) - totalRowsToFetch;
		return startIndex;
	}
	@Transactional(propagation=Propagation.REQUIRED, readOnly=true)
	public List<BridgeBooksVO> populateBridgeBooksVOFromConnectBook(List<BridgeBookCache> cacheBooks, Bridge bridge,
			Boolean isGrouped) {
		List<BridgeBooksVO> books = new ArrayList<BridgeBooksVO>();

		List<Integer> bridgeGroupIds = bridgeGroupDAO.getGroupIdsForBridgeId(bridge.getId(), Boolean.TRUE);

		List<String> groupVbids = bridgeGroupAssetDAO.getVbidsForGroupIds(bridge.getId(), bridgeGroupIds);

		if (null != cacheBooks && cacheBooks.size() > 0) {

			for (BridgeBookCache cacheBook : cacheBooks) {
				BridgeBooksVO bridgeBooksVO = new BridgeBooksVO();
				Integer concurrencyLimit = cacheBook.getConcurrencyLimit() != null ? cacheBook.getConcurrencyLimit()
						: bridge.getConcurrencyLimit();
				bridgeBooksVO.setConcurrencyLimit(concurrencyLimit);
				String vbid = cacheBook.getVbid();
				buildCacheBook(bridgeBooksVO, cacheBook);

				if (groupVbids != null) {
					bridgeBooksVO.setIsGroupMember(groupVbids.contains(vbid));
				}

				if (null != isGrouped && groupVbids != null) {
					if (isGrouped && bridgeBooksVO.getIsGroupMember()) {
						books.add(bridgeBooksVO);
					} else if (!isGrouped && !bridgeBooksVO.getIsGroupMember()) {
						books.add(bridgeBooksVO);
					}
				} else {
					books.add(bridgeBooksVO);
				}
			}
		}
		return books;
	}

	@Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.READ_COMMITTED, readOnly=false)
	public BridgeBookCache populateBridgeBookCacheFromConnectBook(ConnectBook connectBook, String apiKey,
			Bridge bridge, BridgeBookCache cacheBook, Map<String,BridgeBookPricing> pricingMap) {
		Date currentDate = new Date();
		cacheBook.setApiKey(apiKey);
		cacheBook.setAuthor(connectBook.getAuthor());
		cacheBook.setBridge(bridge);
		cacheBook.setCoverImageUrl(connectBook.getCoverImageUrl());

		String title = connectBook.getTitle();
		/*title = StringEscapeUtils.escapeJava(title);
		title = HTMLParserUtil.parseHTML(title);
		title = StringEscapeUtils.escapeHtml(title);*/
		cacheBook.setTitle(title);

		String description = connectBook.getDescription();
		/*description = StringEscapeUtils.escapeJava(description);
		description = HTMLParserUtil.parseHTML(description);
		description = StringEscapeUtils.escapeHtml(description);*/
		cacheBook.setDescription(description);

		cacheBook.setEbookIsbn(connectBook.getEBookIsbn());
		cacheBook.setTextbookIsbn(connectBook.getTextbookIsbn());

		cacheBook.setVbid(connectBook.getVbid());
		cacheBook.setLastModifiedDate(currentDate);
		cacheBook.setEdition(connectBook.getEdition());
		cacheBook.setFileType(MimeType.ETEXT.toString());
		BridgeBookPricing bookPricing = pricingMap.remove(connectBook.getSku());
		cacheBook.setCategory(MimeType.Category.ETEXT.toString());
		bookPricing = bookPricing != null ? bookPricing : new BridgeBookPricing();
		bookPricing.setBookCache(cacheBook);
		bookPricing.setDigitalPrice(connectBook.getDigitalPrice());
		bookPricing.setPublisherPrice(connectBook.getPublisherPrice());
		String sku = connectBook.getSku();
		bookPricing.setSku(connectBook.getSku());
		if (null != sku && "Rental".equals(connectBook.getType())) {
			bookPricing.setPriceType(sku.substring(sku.lastIndexOf("R")));
		}
		List<BridgeBookPricing> bookPricingList = new ArrayList<BridgeBookPricing>();
		bookPricingList.add(bookPricing);
		cacheBook.setBookPricing(bookPricingList);
		cacheBook.setDeleted(Boolean.FALSE);
		// String sku=connectBook.getSku();
		/*
		 * cacheBook.setSku(connectBook.getSku());
		 * 
		 * cacheBook.setDigitalPrice(connectBook.getDigitalPrice());
		 * cacheBook.setPublisherPrice(connectBook.getPublisherPrice());
		 */
		return cacheBook;
	}

	@Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.READ_COMMITTED, readOnly=false)
	public void populateBridgeBookCacheFromConnectBook(Collection<ConnectBook> connectBooks, String apiKey,
			Bridge bridge, Map<String, BridgeBookCache> refreshedCacheBooks, Map<String,BridgeBookPricing> pricingMap) {
		List<BridgeBookPricing> bookPricingList = new ArrayList<BridgeBookPricing>();
		if (null != connectBooks && connectBooks.size() > 0) {
			for (ConnectBook connectBook : connectBooks) {
				BridgeBookCache cache = refreshedCacheBooks.get(connectBook.getVbid());
				if(null != cache){
						String sku = connectBook.getSku();
					BridgeBookPricing bookPricing = pricingMap.remove(sku);
						bookPricing = bookPricing != null ? bookPricing : new BridgeBookPricing();
						bookPricing.setBookCache(cache);
						bookPricing.setSku(sku);
						bookPricing.setDigitalPrice(connectBook.getDigitalPrice());
						bookPricing.setPublisherPrice(connectBook.getPublisherPrice());
					if (null != sku && "Rental".equals(connectBook.getType())) {
						bookPricing.setPriceType(sku.substring(sku.lastIndexOf("R")));
					}
					if (null == bookPricing.getId()) {
						bookPricingList.add(bookPricing);
					}
				}				
			}
			if (bookPricingList.size() > 0) {
				bridgeBookPricingDAO.saveOrUpdateAll(bookPricingList);
			}
		}
	}

	private void buildCacheBook(BridgeBooksVO bridgeBooksVO, BridgeBookCache cacheBook) {

		bridgeBooksVO.setAuthor(cacheBook.getAuthor());
		bridgeBooksVO.setCoverImageUrl(cacheBook.getCoverImageUrl());

		String title = cacheBook.getTitle();
		/*title = StringEscapeUtils.unescapeHtml(title);
		title = StringEscapeUtils.unescapeJava(title);
		title = HTMLParserUtil.parseHTML(title);*/
		bridgeBooksVO.setTitle(title);

		String description = cacheBook.getDescription();
		/*description = StringEscapeUtils.unescapeHtml(description);
		description = StringEscapeUtils.unescapeJava(description);
		description = HTMLParserUtil.parseHTML(description);*/
		bridgeBooksVO.setDescription(description);

		bridgeBooksVO.setTextbookIsbn(cacheBook.getTextbookIsbn());
		bridgeBooksVO.seteBookIsbn(cacheBook.getEbookIsbn());

		bridgeBooksVO.setVbid(cacheBook.getVbid());
		bridgeBooksVO.setEdition(cacheBook.getEdition());
		bridgeBooksVO.setFileType(cacheBook.getFileType());
		bridgeBooksVO.setCategory(cacheBook.getCategory());
		if (null != cacheBook.getAncillary()) {
			bridgeBooksVO.setAncillaryMetaData(createAncillaryMetaData(cacheBook.getAncillary()));
		}

	}

	private AncillaryBookVO createAncillaryMetaData(Ancillary ancillary) {
		AncillaryBookVO metaData = new AncillaryBookVO(ancillary);
		return metaData;
	}

	protected List<Integer> getIds(List<BridgeUserKey> userKeysAssigned) {
		List<Integer> keys = null;
		if (null != userKeysAssigned && userKeysAssigned.size() > 0) {
			keys = new ArrayList<Integer>();
			for (BridgeUserKey userKey : userKeysAssigned) {
				keys.add(userKey.getId());
			}
		}
		return keys;
	}

	protected UserCreditsInfoVO getUserCredits(BridgeUser bridgeUser) {
		UserCreditsInfoVO userCreditsInfoVO = new UserCreditsInfoVO();
		List<BridgeUserKey> userKeysAssigned = bridgeUserKeyDAO.getListOfKeysAssigedForUser(bridgeUser.getId());
		List<Keys> keysAssiged = getUserKeys(userKeysAssigned);
		List<Integer> keyBatchIdList = null;
		Integer trialCredits = 0;
		Integer fullCredits = 0;
		Integer rentalCredits = 0;
		Integer concurrencyCredits = 0;
		if (keysAssiged != null && keysAssiged.size() > 0) {
			keyBatchIdList = getKeyBatchList(keysAssiged);
		}

		if (null != keysAssiged && keysAssiged.size() > 0) {
			for (Keys key : keysAssiged) {
				if (key.getTrialCredits() != null && key.getTrialCredits() != -1) {
					trialCredits = trialCredits + key.getTrialCredits();
				} else if (key.getTrialCredits() != null && key.getTrialCredits() == -1) {
					trialCredits = -1;
					break;
				}
			}
			for (Keys key : keysAssiged) {
				if (key.getFullCredits() != null && key.getFullCredits() != -1) {
					fullCredits = fullCredits + key.getFullCredits();
				} else if (key.getFullCredits() != null && key.getFullCredits() == -1) {
					fullCredits = -1;
					break;
				}
			}
			for (Keys key : keysAssiged) {
				if (key.getRentalCredits() != null && key.getRentalCredits() != -1) {
					rentalCredits = rentalCredits + key.getRentalCredits();
				} else if (key.getRentalCredits() != null && key.getRentalCredits() == -1) {
					rentalCredits = -1;
					break;
				}
			}
			if (keyBatchIdList != null && keyBatchIdList.size() > 0) {
				Collections.sort(keyBatchIdList);
			}
			List<KeyBatch> keyBatchList = new ArrayList<KeyBatch>();
			for (Integer keyBatchId : keyBatchIdList) {
				keyBatchList.add(keyBatchDAO.get(keyBatchId));
			}
			List<Integer> keyAssigedIds = getIds(userKeysAssigned);
			if (keyBatchList.size() > 0) {
				Bridge bridge = keyBatchList.get(0).getBridge();
				Map<String, UserEntitlementVO> concEntitlementMap = new HashMap<>();
				if (bridge != null && bridge.getConcurrencyEnabled()) {
					String mapKey = null;
					UserEntitlementVO concurrencyUserEntitlementVO = null;
					for (KeyBatch keybatch : keyBatchList) {
						if (keybatch.getConcurrencyEntitlementName() != null) {
							if (keybatch.getConcurrencyDays() == null && keybatch.getConcurrencyExpires() != null
									&& new Date().after(keybatch.getConcurrencyExpires())) {
								continue;
							}
							mapKey = keybatch.getConcurrencyEntitlementName().toLowerCase();
							concurrencyUserEntitlementVO = concEntitlementMap.get(mapKey);
							if (concurrencyUserEntitlementVO != null) {
								if (concurrencyUserEntitlementVO.getCredits() != null) {
									this.calculateUserConcurrencyEntitlementId(concurrencyUserEntitlementVO, keybatch);
								}
								concurrencyUserEntitlementVO.setCredits(this
										.calculateUserTotalConcurrencyCredits(concurrencyUserEntitlementVO, keybatch));
								concurrencyUserEntitlementVO.setUsed(this.calculateUserUsedConcurrencyCredits(
										concurrencyUserEntitlementVO, keyAssigedIds, keybatch));
								// concurrencyUserEntitlementVO.setId(keybatch.getId());
								concurrencyUserEntitlementVO.setType(keybatch.getConcCodeType().getType());
							} else {
								concurrencyUserEntitlementVO = new UserEntitlementVO();
								mapKey = keybatch.getConcurrencyEntitlementName().toLowerCase();
								concurrencyUserEntitlementVO.setEntitlementName(mapKey);
								concurrencyUserEntitlementVO.setCredits(keybatch.getConcurrencyCredits());
								concurrencyUserEntitlementVO.setId(keybatch.getId());
								concurrencyUserEntitlementVO.setUsed(bridgeUserBookAssignDAO
										.getConcurrencyCountForUsedEntitlementType(keyAssigedIds, keybatch.getId()));
								concurrencyUserEntitlementVO.setType(keybatch.getConcCodeType().getType());
							}
							concEntitlementMap.put(mapKey, concurrencyUserEntitlementVO);
						}
					}
					userCreditsInfoVO.setConcurrencyEntitlements(this.populateEntitlements(concEntitlementMap));
				}
			}

			Integer trailUsed = bridgeUserBookAssignDAO.getCountForUsedType(keyAssigedIds,
					ApplicationConstants.BOOK_KEY_USED_TYPE_TRIAL);
			Integer fullUsed = bridgeUserBookAssignDAO.getCountForUsedType(keyAssigedIds,
					ApplicationConstants.BOOK_KEY_USED_TYPE_FULL);
			Integer rentalUsed = bridgeUserBookAssignDAO.getCountForUsedType(keyAssigedIds,
					ApplicationConstants.BOOK_KEY_USED_TYPE_RENTAL);
			Integer concurrencyUsed = bridgeUserBookAssignDAO.getCountForUsedType(keyAssigedIds,
					ApplicationConstants.BOOK_KEY_USED_TYPE_CONCURRENT);
			userCreditsInfoVO.setFullCredits(fullCredits);
			userCreditsInfoVO.setTrialCredits(trialCredits);
			userCreditsInfoVO.setFullUsed(fullUsed);
			userCreditsInfoVO.setTrailUsed(trailUsed);
			userCreditsInfoVO.setRentalCredits(rentalCredits);
			userCreditsInfoVO.setRentalUsed(rentalUsed);
			userCreditsInfoVO.setConcurrencyCredits(concurrencyCredits);
			userCreditsInfoVO.setConcurrencyUsed(concurrencyUsed);

			// New allowance with standard and comp
			// List<Integer> keyBatchList = getKeyBatchList(keysAssiged);
			List<KeyBatchEntitlement> keyBatchEntitlementList = new ArrayList<>();
			for (Integer keyBatchId : keyBatchIdList) {
				List<KeyBatchEntitlement> keyBatchEntitlements = keyBatchEntitlementDAO
						.getEntitlementsByKeyBatches(keyBatchId);
				if (keyBatchEntitlements != null)
					keyBatchEntitlementList.addAll(keyBatchEntitlements);
			}

			List<UserEntitlementVO> UserEntitlementVOList = this.populateUserEntitlements(keyBatchEntitlementList,
					keyAssigedIds);
			userCreditsInfoVO.setEntitlements(UserEntitlementVOList);
		}
		return userCreditsInfoVO;
	}

	private List<UserEntitlementVO> populateUserEntitlements(List<KeyBatchEntitlement> keyBatchEntitlementList,
			List<Integer> keyAssigedIds) {
		if (keyBatchEntitlementList != null && keyBatchEntitlementList.size() > 0) {
			Map<String, UserEntitlementVO> entitlementMap = new HashMap<>();
			// List<UserEntitlementVO> UserEntitlementVOList = new
			// ArrayList<UserEntitlementVO>();
			String mapKey = null;
			UserEntitlementVO userEntitlementVO = null;
			for (KeyBatchEntitlement keyBatchEntitlement : keyBatchEntitlementList) {
				if (keyBatchEntitlement.getEntOnlineDays() == null && keyBatchEntitlement.getEntOnlineExpires() != null
						&& new Date().after(keyBatchEntitlement.getEntOnlineExpires())) {
					continue;
				}
				mapKey = keyBatchEntitlement.getEntName().toLowerCase();
				userEntitlementVO = entitlementMap.get(mapKey);
				if (userEntitlementVO != null) {
					if (userEntitlementVO.getCredits() != null) {
						calculateUserEntitlementId(userEntitlementVO, keyBatchEntitlement);
					}
					userEntitlementVO
							.setCredits(this.calculateUserTotalCredits(userEntitlementVO, keyBatchEntitlement));
					userEntitlementVO.setUsed(
							this.calculateUserUsedCredits(userEntitlementVO, keyAssigedIds, keyBatchEntitlement));
					// userEntitlementVO.setId(keyBatchEntitlement.getId());
					userEntitlementVO.setType(keyBatchEntitlement.getEntType().getType());
				} else {
					userEntitlementVO = new UserEntitlementVO();
					userEntitlementVO.setCredits(keyBatchEntitlement.getEntCredits());
					mapKey = keyBatchEntitlement.getEntName().toLowerCase();
					userEntitlementVO.setEntitlementName(mapKey);
					userEntitlementVO.setId(keyBatchEntitlement.getId());
					Boolean isReusableCredit = keyBatchEntitlement.getEntIsReusableCredit() != null
							? keyBatchEntitlement.getEntIsReusableCredit() : Boolean.FALSE;
					userEntitlementVO.setUsed(bridgeUserBookAssignDAO.getCountForUsedEntitlementType(keyAssigedIds,
							keyBatchEntitlement.getId(), isReusableCredit));
					userEntitlementVO.setType(keyBatchEntitlement.getEntType().getType());
				}
				entitlementMap.put(mapKey, userEntitlementVO);
			}
			return this.populateEntitlements(entitlementMap);
		}
		return null;
	}

	private List<Integer> getKeyBatchList(List<Keys> keysAssiged) {
		List<Integer> keyBatchList = new ArrayList<Integer>();
		for (Keys key : keysAssiged) {
			if (key.getKeyBatch() != null)
				keyBatchList.add(key.getKeyBatch().getId());
		}
		return keyBatchList;
	}

	private List<Keys> getUserKeys(List<BridgeUserKey> userKeysAssigned) {
		List<Keys> keys = null;
		if (null != userKeysAssigned && userKeysAssigned.size() > 0) {
			keys = new ArrayList<Keys>();
			for (BridgeUserKey userKey : userKeysAssigned) {
				keys.add(userKey.getKey());
			}
		}
		return keys;
	}

	private void calculateUserConcurrencyEntitlementId(UserEntitlementVO userEntitlementVO, KeyBatch keybatch) {
		if (userEntitlementVO.getCredits() == -1)
			return;
		if (userEntitlementVO.getUsed() != null && userEntitlementVO.getUsed() >= userEntitlementVO.getCredits()) {
			userEntitlementVO.setId(keybatch.getId());
		}

	}

	private Integer calculateUserTotalConcurrencyCredits(UserEntitlementVO concurrencyUserEntitlementVO,
			KeyBatch keybatch) {
		Integer credits = concurrencyUserEntitlementVO.getCredits() != null ? concurrencyUserEntitlementVO.getCredits()
				: 0;
		if (credits == -1) {
			credits = -1;
		} else if (keybatch.getConcurrencyCredits() != null && keybatch.getConcurrencyCredits() != -1) {
			credits = credits + keybatch.getConcurrencyCredits();
		} else if (keybatch.getConcurrencyCredits() != null && keybatch.getConcurrencyCredits() == -1) {
			credits = -1;
		}

		return credits;
	}

	private Integer calculateUserUsedConcurrencyCredits(UserEntitlementVO concurrencyUserEntitlementVO,
			List<Integer> keyAssigedIds, KeyBatch keybatch) {
		Integer credits = concurrencyUserEntitlementVO.getCredits() != null ? concurrencyUserEntitlementVO.getCredits()
				: 0;
		if (credits == -1) {
			return credits;
		}
		Integer usedCredits = concurrencyUserEntitlementVO.getUsed() != null ? concurrencyUserEntitlementVO.getUsed()
				: 0;
		if (concurrencyUserEntitlementVO.getId() != null && keybatch.getId() != null
				&& concurrencyUserEntitlementVO.getId() != keybatch.getId())
			usedCredits = usedCredits + bridgeUserBookAssignDAO.getConcurrencyCountForUsedEntitlementType(keyAssigedIds,
					keybatch.getId());
		return usedCredits;
	}

	private void calculateUserEntitlementId(UserEntitlementVO userEntitlementVO,
			KeyBatchEntitlement keyBatchEntitlement) {
		if (userEntitlementVO.getCredits() == -1)
			return;
		if (userEntitlementVO.getUsed() != null && userEntitlementVO.getUsed() >= userEntitlementVO.getCredits()) {
			userEntitlementVO.setId(keyBatchEntitlement.getId());
		}

	}

	private Integer calculateUserTotalCredits(UserEntitlementVO userEntitlementVO,
			KeyBatchEntitlement keyBatchEntitlement) {
		Integer credits = userEntitlementVO.getCredits() != null ? userEntitlementVO.getCredits() : 0;
		if (credits == -1) {
			credits = -1;
		} else if (keyBatchEntitlement.getEntCredits() != null && keyBatchEntitlement.getEntCredits() != -1) {
			credits = credits + keyBatchEntitlement.getEntCredits();
		} else if (keyBatchEntitlement.getEntCredits() != null && keyBatchEntitlement.getEntCredits() == -1) {
			credits = -1;
		}

		return credits;
	}

	private Integer calculateUserUsedCredits(UserEntitlementVO userEntitlementVO, List<Integer> keyAssigedIds,
			KeyBatchEntitlement keyBatchEntitlement) {
		Integer credits = userEntitlementVO.getCredits() != null ? userEntitlementVO.getCredits() : 0;
		if (credits == -1) {
			return 0;
		}
		Integer usedCredits = userEntitlementVO.getUsed() != null ? userEntitlementVO.getUsed() : 0;
		if (userEntitlementVO.getId() != null && keyBatchEntitlement.getId() != null
				&& userEntitlementVO.getId() != keyBatchEntitlement.getId())
			usedCredits = usedCredits + bridgeUserBookAssignDAO.getCountForUsedEntitlementType(keyAssigedIds,
					keyBatchEntitlement.getId(), keyBatchEntitlement.getEntIsReusableCredit());
		return usedCredits;
	}

	private List<UserEntitlementVO> populateEntitlements(Map<String, UserEntitlementVO> entitlementMap) {
		List<UserEntitlementVO> userEntitlementList = new ArrayList<>();
		Set<String> entitlementKeysSet = entitlementMap.keySet();
		for (String entitlementKey : entitlementKeysSet) {
			UserEntitlementVO concUserEntitlementVO = entitlementMap.get(entitlementKey);
			concUserEntitlementVO
					.setEntitlementName(StringUtils.capitalize(concUserEntitlementVO.getEntitlementName()));
			userEntitlementList.add(concUserEntitlementVO);
		}
		return userEntitlementList;
	}

	protected Integer createBridgeLog(final Integer userId, final Bridge bridge, final ApplicationAction action,
			final String value) {
		BridgeLog bridgeLog = new BridgeLog();
		bridgeLog.setUser(bridgeUserDAO.load(userId));
		bridgeLog.setBridge(bridge);
		bridgeLog.setAction(action.getCodeId());
		bridgeLog.setValue(value);
		return bridgeLogDAO.create(bridgeLog);
	}

	protected ApplicationAction getActionType(String type) {
		if (ApplicationConstants.REDEEM_TYPE_COMP.equalsIgnoreCase(type))
			return ApplicationAction.TRY_BOOK;
		else
			return ApplicationAction.FULL_BOOK;
	}
	
	Map<String,BridgeBookPricing> getPricingForBridgeBookCacheCollection(Collection<BridgeBookCache> bookCacheCollection){
		Map<String,BridgeBookPricing> bridgeBookPricingMap = new HashMap<String, BridgeBookPricing>();
		if(null == bookCacheCollection || bookCacheCollection.isEmpty()){
			return new HashMap<>();
		}
		List<BridgeBookPricing> bookPricingList = bridgeBookPricingDAO.getBookPricingByCacheCollection(bookCacheCollection);
		int count=0;
		for(BridgeBookPricing bookPricing:bookPricingList){
			BridgeBookPricing dupePrice = bridgeBookPricingMap.put(bookPricing.getSku(), bookPricing);
			if (null != dupePrice){
				dupePrice.setDeleted(Boolean.TRUE);
				bridgeBookPricingDAO.saveOrUpdate(dupePrice);
				if(++count % 50 == 0){
					bridgeBookPricingDAO.flushAndClear();
				}
			}

		}
		return bridgeBookPricingMap;
	}

	@Transactional(propagation = Propagation.REQUIRED, isolation=Isolation.READ_COMMITTED, readOnly = false)
	public void saveOrUpdateBookCacheCollection(Collection<BridgeBookCache> collectionOfBookCache) {
		bridgeBookCacheDAO.saveOrUpdateAll(collectionOfBookCache);
	}
}
