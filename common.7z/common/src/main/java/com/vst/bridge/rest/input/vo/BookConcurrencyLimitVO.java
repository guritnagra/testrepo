package com.vst.bridge.rest.input.vo;

import java.util.List;

public class BookConcurrencyLimitVO {
	
	private List<String> vbids;
	private Integer concurrencyLimit;

	public Integer getConcurrencyLimit() {
		return concurrencyLimit;
	}

	public void setConcurrencyLimit(Integer concurrencyLimit) {
		this.concurrencyLimit = concurrencyLimit;
	}

	public List<String> getVbids() {
		return vbids;
	}

	public void setVbids(List<String> vbids) {
		this.vbids = vbids;
	}

}
