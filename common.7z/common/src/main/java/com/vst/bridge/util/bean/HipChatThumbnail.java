package com.vst.bridge.util.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class HipChatThumbnail extends HipChatIcon {
	private String url2;
	private Integer width;
	private Integer height;
	
	@JsonProperty(value="url@2x", required=true)
	public String getUrl2() {
		return url2;
	}
	public void setUrl2(String url2) {
		this.url2 = url2;
	}
	@JsonProperty(value="width", required=true)
	public Integer getWidth() {
		return width;
	}
	public void setWidth(Integer width) {
		this.width = width;
	}
	@JsonProperty(value="height", required=true)
	public Integer getHeight() {
		return height;
	}
	public void setHeight(Integer height) {
		this.height = height;
	}
	
	
}
