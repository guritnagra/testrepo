package com.vst.bridge.rest.input.vo;

public class PermissionLevelVO {
	
	private Boolean editSystemUser=Boolean.FALSE;
	private Boolean editBridge=Boolean.FALSE;	
	private Boolean editBasicInfo=Boolean.FALSE;
	private Boolean editStyling=Boolean.FALSE;
	private Boolean editManage=Boolean.FALSE;
	private Boolean editUsers=Boolean.FALSE;
	private Boolean editUserLimit=Boolean.FALSE;
	private Boolean editUserConcurrency=Boolean.FALSE; 
	private Boolean allowContentUpload=Boolean.FALSE;
	private Boolean editAllowance=Boolean.FALSE;
	private Boolean editAccess=Boolean.FALSE;
	private Boolean isReadOnly=Boolean.TRUE;
	private Boolean editKey=Boolean.FALSE;
	private Boolean editPurchase=Boolean.FALSE;
	
	public PermissionLevelVO(){
		
	}
	
	public PermissionLevelVO(Boolean isSuperAdmin){
		editSystemUser=Boolean.TRUE;
		editBridge=Boolean.TRUE;	
		editBasicInfo=Boolean.TRUE;
		editStyling=Boolean.TRUE;
		editManage=Boolean.TRUE;
		editUsers=Boolean.TRUE;
		editUserLimit=Boolean.TRUE;
		editUserConcurrency=Boolean.TRUE; 
		allowContentUpload=Boolean.TRUE;
		editAllowance=Boolean.TRUE;
		editAccess=Boolean.TRUE;
		isReadOnly=Boolean.FALSE;
		editKey=Boolean.TRUE;
		editPurchase=Boolean.TRUE;
	}
	
	public Boolean getEditSystemUser() {
		return editSystemUser;
	}
	public void setEditSystemUser(Boolean editSystemUser) {
		this.editSystemUser = editSystemUser;
	}
	public Boolean getEditBridge() {
		return editBridge;
	}
	public void setEditBridge(Boolean editBridge) {
		this.editBridge = editBridge;
	}
	public Boolean getEditBasicInfo() {
		return editBasicInfo;
	}
	public void setEditBasicInfo(Boolean editBasicInfo) {
		this.editBasicInfo = editBasicInfo;
	}
	public Boolean getEditStyling() {
		return editStyling;
	}
	public void setEditStyling(Boolean editStyling) {
		this.editStyling = editStyling;
	}
	public Boolean getEditManage() {
		return editManage;
	}
	public void setEditManage(Boolean editManage) {
		this.editManage = editManage;
	}
	public Boolean getEditUsers() {
		return editUsers;
	}
	public void setEditUsers(Boolean editUsers) {
		this.editUsers = editUsers;
	}
	public Boolean getEditUserLimit() {
		return editUserLimit;
	}
	public void setEditUserLimit(Boolean editUserLimit) {
		this.editUserLimit = editUserLimit;
	}
	public Boolean getEditUserConcurrency() {
		return editUserConcurrency;
	}
	public void setEditUserConcurrency(Boolean editUserConcurrency) {
		this.editUserConcurrency = editUserConcurrency;
	}
	public Boolean getAllowContentUpload() {
		return allowContentUpload;
	}
	public void setAllowContentUpload(Boolean allowContentUpload) {
		this.allowContentUpload = allowContentUpload;
	}
	public Boolean getEditAllowance() {
		return editAllowance;
	}
	public void setEditAllowance(Boolean editAllowance) {
		this.editAllowance = editAllowance;
	}
	public Boolean getEditAccess() {
		return editAccess;
	}
	public void setEditAccess(Boolean editAccess) {
		this.editAccess = editAccess;
	}
	public Boolean getIsReadOnly() {
		return isReadOnly;
	}
	public void setIsReadOnly(Boolean isReadOnly) {
		this.isReadOnly = isReadOnly;
	}

	public Boolean getEditKey() {
		return editKey;
	}

	public void setEditKey(Boolean editKey) {
		this.editKey = editKey;
	}

	public Boolean getEditPurchase() {
		return editPurchase;
	}

	public void setEditPurchase(Boolean editPurchase) {
		this.editPurchase = editPurchase;
	}
	
	

}
