package com.vst.bridge.dao.group;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.group.Group;
import com.vst.bridge.util.exception.BridgeException;

public interface IGroupDAO extends IGenericDAO<Group, Integer>{

	List<Group> getAllGroups()throws BridgeException;
	Group getGroupForName(final String name)throws BridgeException;
	void checkGroupNameExist(String name)throws BridgeException;
}
