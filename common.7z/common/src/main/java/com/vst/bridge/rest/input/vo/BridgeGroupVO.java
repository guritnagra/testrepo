package com.vst.bridge.rest.input.vo;

import com.vst.bridge.annotation.custom.InputRequired;

public class BridgeGroupVO {
	
	private String groupName;
	@InputRequired(required=false)	
	private long activationTime;
	@InputRequired(required=false)
	private long expirationTime;	
	@InputRequired(required=false)
	private Boolean isAutoAssignUser;
	@InputRequired(required=false)
	private Boolean isHidden;
	@InputRequired(required=false)
	private Boolean isAutoAssignAsset;
	
	
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	public long getActivationTime() {
		return activationTime;
	}
	public void setActivationTime(long activationTime) {
		this.activationTime = activationTime;
	}	
	public long getExpirationTime() {
		return expirationTime;
	}
	public void setExpirationTime(long expirationTime) {
		this.expirationTime = expirationTime;
	}
	public Boolean getIsAutoAssignUser() {
		return isAutoAssignUser;
	}
	public void setIsAutoAssignUser(Boolean isAutoAssignUser) {
		this.isAutoAssignUser = isAutoAssignUser;
	}
	public Boolean getIsHidden() {
		return isHidden;
	}
	public void setIsHidden(Boolean isHidden) {
		this.isHidden = isHidden;
	}
	public Boolean getIsAutoAssignAsset() {
		return isAutoAssignAsset;
	}
	public void setIsAutoAssignAsset(Boolean isAutoAssignAsset) {
		this.isAutoAssignAsset = isAutoAssignAsset;
	}
}
