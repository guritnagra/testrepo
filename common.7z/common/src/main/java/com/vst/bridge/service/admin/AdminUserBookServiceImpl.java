package com.vst.bridge.service.admin;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.user.CreateKeysVO;
import com.vst.bridge.service.book.IBookServices;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;

@Service("adminUserBookService")
public class AdminUserBookServiceImpl implements IAdminUserBookService {
	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private IBookServices bookServices;
	
	@Autowired
	private AdminUserServiceUtil adminUserServiceUtil; 

	private Logger logger = LogManager.getLogger(IAdminUserBookService.class);

	@Async
	@Override
	public RestResponse refreshBookCache(CreateKeysVO password, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ConnectApiException, ConnectApiXmlException, ParseException, IOException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		List<Bridge> bridges = adminUserServiceUtil.getAllBridges();
		if (null != bridges && bridges.size() > 0) {
			if (null != password && password.getCode() != null && StringUtils.isNotEmpty(password.getCode())
					&& (StringUtils.equals(password.getCode(), ApplicationConstants.getBookCacheRefreshPassword()))) {
				for (Bridge bridge : bridges) {
					logger.info("refreshBookCache : get books for bridge id " + bridge.getId());
					try {
						if (bridge.getApiKey() != null) {
							bookServices.refreshBookCache(bridge.getId(), bridge.getApiKey());
						}
						logger.info("refreshBookCache : refreshing completed for bridge id " + bridge.getId());
					}catch (ConnectApiHttpException cae){
						logger.error("There was an error refreshing catalog of bridge with id: "+bridge.getId()+", connect catalog call failed, due to status"+cae.getCode());
					}
					catch (Exception e) {
						logger.error("There was an error refreshing bridge with id: "+bridge.getId(), e);
					}
				}
			} else {
				response = new RestResponse(Response.Status.UNAUTHORIZED.getStatusCode(),
						ApplicationCode.UNATHORISED_REQUEST.getCodeId(),
						localeMessageUtility.getMessage(ApplicationCode.UNATHORISED_REQUEST.getCodeId()));
			}
		}
		return response;
	}
}
