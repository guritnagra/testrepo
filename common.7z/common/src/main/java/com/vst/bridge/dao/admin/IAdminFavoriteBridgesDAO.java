package com.vst.bridge.dao.admin;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.user.AdminFavoriteBridge;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminFavoriteBridgesDAO extends IGenericDAO<AdminFavoriteBridge, Integer>{
	AdminFavoriteBridge checkAdminFavoriteBridgeExist(final Integer adminId,final Integer bridgeId,Boolean getDeleted)throws BridgeException;
}
