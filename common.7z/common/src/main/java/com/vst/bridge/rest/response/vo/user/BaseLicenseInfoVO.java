package com.vst.bridge.rest.response.vo.user;

import java.util.Date;

public class BaseLicenseInfoVO {

	private String state;
	private String url;
	private Long expires;
	
	public BaseLicenseInfoVO() {
		super();
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public Long getExpires() {
		return expires;
	}
	public void setExpires(Long expires) {
		this.expires = expires;
	}
	
	public Boolean hasLisenceValid(){
	//	return  this.expires != null && this.expires < new Date().getTime() ? Boolean.TRUE : Boolean.FALSE;
		if( this.expires != null ){
			if(this.expires < new Date().getTime()){
				return Boolean.TRUE;
			}
		}
		return  Boolean.FALSE;
	}
}