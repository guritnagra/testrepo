package com.vst.bridge.dao.user.token;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.user.token.BridgeUserResetPassword;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeUserResetPasswordDAO")
public class BridgeUserResetPasswordDAOImpl extends GenericDAO<BridgeUserResetPassword, Integer> implements IBridgeUserResetPasswordDAO{
	
	public BridgeUserResetPasswordDAOImpl() {
		super(BridgeUserResetPassword.class);
	}

	@Override
	public Integer getChangePasswordCountByMail(String email) throws BridgeException {
		Criteria criteria = getCriteria();
		Date curDate=new Date();			
		criteria.add(Restrictions.eq("email",email));
		criteria.add(Restrictions.gt("createdDate", new Date(curDate.getTime()-60000)));  //60000 ms = 1 Minute
		List<BridgeUserResetPassword> resetPasswordList=executeCriteira(criteria);
		return null != resetPasswordList && resetPasswordList.size() > 0 ? resetPasswordList.size() : 0;
		
	}

	@Override
	public BridgeUserResetPassword getRequestByToken(String token) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.like("token", token));		
		List<BridgeUserResetPassword> result = executeCriteira(criteria);
		return null!= result && result.size() > 0? result.get(0) : null;
	}

}
