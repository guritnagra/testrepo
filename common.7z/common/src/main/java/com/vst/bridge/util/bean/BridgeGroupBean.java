package com.vst.bridge.util.bean;

import java.util.Date;

public class BridgeGroupBean extends BridgeBean {
	
	private String sourcedId;
	private String status;
	private Date dateLastModified;
	private String title;
	private String grade;
	private String courseSourcedId;
	private String classCode;
	private String classType;
	private String location;
	private String schoolSourcedId;
	private String termSourcedId;
	private String  subjects;
	
	public String getSourcedId() {
		return sourcedId;
	}
	public void setSourcedId(String sourcedId) {
		this.sourcedId = sourcedId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getDateLastModified() {
		return dateLastModified;
	}
	public void setDateLastModified(Date dateLastModified) {
		this.dateLastModified = dateLastModified;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getCourseSourcedId() {
		return courseSourcedId;
	}
	public void setCourseSourcedId(String courseSourcedId) {
		this.courseSourcedId = courseSourcedId;
	}
	public String getClassCode() {
		return classCode;
	}
	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}
	public String getClassType() {
		return classType;
	}
	public void setClassType(String classType) {
		this.classType = classType;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getSchoolSourcedId() {
		return schoolSourcedId;
	}
	public void setSchoolSourcedId(String schoolSourcedId) {
		this.schoolSourcedId = schoolSourcedId;
	}
	public String getTermSourcedId() {
		return termSourcedId;
	}
	public void setTermSourcedId(String termSourcedId) {
		this.termSourcedId = termSourcedId;
	}
	public String getSubjects() {
		return subjects;
	}
	public void setSubjects(String subjects) {
		this.subjects = subjects;
	}
	
	
	

}
