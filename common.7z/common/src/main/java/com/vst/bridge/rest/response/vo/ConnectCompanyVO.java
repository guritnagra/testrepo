package com.vst.bridge.rest.response.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class ConnectCompanyVO {
	
	/*
	 * {
  "id": 2005,
  "name": "Bridge",
  "category": "institution",
  "description": "Bridge Admin company for creation of system users and other VST level access.",
  "business_center_company": false,
  "business_center_type": "",
  "lms_integration": false,
  "lms_type": null,
  "billing_enabled": false,
  "international": false,
  "country_id": null,
  "country_name": null,
  "distribution_sets": [],
  "can_create_add_drop_codes": false,
  "can_create_promo_codes": false,
  "can_create_p_plus_e_codes": false,
  "publisher_restrictions": [],
  "distributor_restrictions": [],
  "has_children": false,
  "is_child": false,
  "has_imprints": false,
  "has_catalog": false,
  "fulfillment_relationships": [],
  "child_ids": []
}
	 */
	
	private Integer id;
	private String name;
	private String category;
	private String description;
	@JsonProperty("business_center_company")
	private String businessCenterCompany;
	@JsonProperty("business_center_type")
	private String businessCenterType;
	@JsonProperty("lms_integration")
	private String lmsIntegration;
	@JsonProperty("lms_type")
	private String lmsType;
	@JsonProperty("billing_enabled")
	private String billingEnabled;
	private String international;
	@JsonProperty("country_id")
	private String countryId;
	@JsonProperty("country_name")
	private String countryName;
	@JsonProperty("has_children")
	private String hasChildren;
	//child_ids
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getBusinessCenterCompany() {
		return businessCenterCompany;
	}
	public void setBusinessCenterCompany(String businessCenterCompany) {
		this.businessCenterCompany = businessCenterCompany;
	}
	public String getBusinessCenterType() {
		return businessCenterType;
	}
	public void setBusinessCenterType(String businessCenterType) {
		this.businessCenterType = businessCenterType;
	}
	public String getLmsIntegration() {
		return lmsIntegration;
	}
	public void setLmsIntegration(String lmsIntegration) {
		this.lmsIntegration = lmsIntegration;
	}
	public String getLmsType() {
		return lmsType;
	}
	public void setLmsType(String lmsType) {
		this.lmsType = lmsType;
	}
	public String getBillingEnabled() {
		return billingEnabled;
	}
	public void setBillingEnabled(String billingEnabled) {
		this.billingEnabled = billingEnabled;
	}
	public String getInternational() {
		return international;
	}
	public void setInternational(String international) {
		this.international = international;
	}
	public String getCountryId() {
		return countryId;
	}
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getHasChildren() {
		return hasChildren;
	}
	public void setHasChildren(String hasChildren) {
		this.hasChildren = hasChildren;
	}
	
	
	

}
