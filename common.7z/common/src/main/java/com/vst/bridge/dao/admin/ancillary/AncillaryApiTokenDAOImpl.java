package com.vst.bridge.dao.admin.ancillary;

import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.ancillary.AncillaryApiToken;

@Repository("ancillaryApiTokenDao")
public class AncillaryApiTokenDAOImpl extends GenericDAO<AncillaryApiToken, Integer> implements IAncillaryApiTokenDAO {

	public AncillaryApiTokenDAOImpl() {
		super(AncillaryApiToken.class);
	}

	
}
