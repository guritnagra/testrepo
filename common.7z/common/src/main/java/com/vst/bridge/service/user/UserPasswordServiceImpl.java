package com.vst.bridge.service.user;

import java.io.IOException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executor;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.vst.bridge.TomcatUtils;
import com.vst.bridge.VstException;
import com.vst.bridge.VstUtils;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.question.ISecurityQuestionDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.dao.user.token.IBridgeUserEmailTokenDAO;
import com.vst.bridge.dao.user.token.IBridgeUserResetPasswordDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.token.BridgeUserEmailToken;
import com.vst.bridge.entity.bridge.user.token.BridgeUserResetPassword;
import com.vst.bridge.rest.input.vo.OldPolicyPasswordVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.user.BridgeUserInfoVO;
import com.vst.bridge.rest.response.vo.user.EmailCheckUserInfoVO;
import com.vst.bridge.rest.response.vo.user.UpdatePasswordVO;
import com.vst.bridge.rest.response.vo.user.UserDetailsVO;
import com.vst.bridge.rest.response.vo.user.UserEmailVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.email.EmailHandlerService;
import com.vst.bridge.util.email.ExecutorUtility;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.bridge.util.message.TemplateLocationConstants;
import com.vst.connectapi.ApiKeys;
import com.vst.connectapi.ConnectApiWrapper;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiFieldException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;
import com.vst.connectapi.ConnectCredentials;
import com.vst.connectapi.ConnectUser;

@Service("userPasswordService")
public class UserPasswordServiceImpl implements IUserPasswordService {

	private static Logger logger = LogManager.getLogger(UserServicesImpl.class);

	@Autowired
	private IBridgeUserDAO bridgeUserDAO;

	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private IBridgeDAO bridgeDAO;

	@Autowired
	private ISecurityQuestionDAO securityQuestionDAO;

	@Autowired
	private IBridgeUserEmailTokenDAO bridgeUserEmailTokenDAO;

	@Autowired
	private EmailHandlerService emailHandler;

	@Autowired
	private IBridgeUserResetPasswordDAO bridgeUserResetPasswordDAO;

	@Autowired
	private UserServiceUtil userServiceUtil;

	private Executor executor = ExecutorUtility.getExecutorInstance();

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse resetPasswordRequest(HttpServletRequest httpRequest, UserEmailVO userEmailVO, String domain,
			String code) throws BridgeException, ConnectApiException, VstException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		String email = userEmailVO.getEmail();
		if (StringUtils.isNotBlank(email)) {

			BridgeUser bridgeUser = bridgeUserDAO.getForEmail(email);
			Boolean bookshelfUser = userServiceUtil.checkEmailExistInBookshelf(email);

			if (bookshelfUser) {
				Integer requestCount = bridgeUserResetPasswordDAO.getChangePasswordCountByMail(email);
				if (requestCount >= Integer.parseInt(TomcatUtils.getParam("request_per_minute_limit"))) {
					throw new BridgeException(ApplicationCode.TOO_MANY_REQUESTS_ERROR);
				}
				String forgotPwdUrl = ApiKeys.getJigsawDomainUrl(ApplicationConstants.getApiMode()) + "forgot";
				RestTemplate restTemplate = new RestTemplate();
				HttpHeaders headers = new HttpHeaders();
				headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
				MultiValueMap<String, String> bodyMap = new LinkedMultiValueMap<>();
				bodyMap.add(ApplicationConstants.EMAIL_JIGSAW, email);
				bodyMap.add(ApplicationConstants.DOMAIN_JIGSAW, domain);
				bodyMap.add(ApplicationConstants.UPDATEURL_JIGSAW,
						VstUtils.getUrlWithProtocol(httpRequest, domain) + "/#/user/forgot");
				Map<String, String> paramMap = new HashMap<String, String>();
				HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(
						bodyMap, headers);
				ResponseEntity<String> jigsawResponse = restTemplate.exchange(forgotPwdUrl, HttpMethod.POST, request,
						String.class, paramMap);
				if (jigsawResponse.getStatusCode() != HttpStatus.OK) {
					throw new BridgeException(ApplicationCode.UNEXPECTED_ERROR);
				} else {
					BridgeUserResetPassword bridgeUserResetPassword = new BridgeUserResetPassword(); // This
																										// is
																										// only
																										// for
																										// count
																										// purpose,
																										// not
																										// for
																										// token
																										// validation
					bridgeUserResetPassword.setEmail(email);
					bridgeUserResetPassword.setToken("JIGSAW-REQ");
					bridgeUserResetPassword.setUsed(Boolean.TRUE);
					bridgeUserResetPasswordDAO.create(bridgeUserResetPassword);
				}
			} else {
				if (bridgeUser != null)
					throw new BridgeException(ApplicationCode.NOT_FULL_USER);
				else
					throw new BridgeException(ApplicationCode.USER_NOT_FOUND);
			}

		} else {
			throw new BridgeException(ApplicationCode.INVALID_INPUT);
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse updatePassword(UpdatePasswordVO updatePasswordVO, String domain) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		String token = updatePasswordVO.getToken();

		BridgeUserResetPassword bridgeUserResetPassword = bridgeUserResetPasswordDAO.getRequestByToken(token);
		if (bridgeUserResetPassword != null) {
			// Not-bookshelf user but bridgeUser flow
		} else {
			String updatePasswordUrl = ApiKeys.getJigsawDomainUrl(ApplicationConstants.getApiMode()) + "forgot/"
					+ token;
			RestTemplate restTemplate = new RestTemplate();
			Map<String, String> paramMap = new HashMap<String, String>();

			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

			MultiValueMap<String, String> bodyMap = new LinkedMultiValueMap<>();
			bodyMap.add(ApplicationConstants.USER_TOKEN_JIGSAW, token);
			bodyMap.add(ApplicationConstants.USER_PASSWORD_JIGSAW, updatePasswordVO.getNewPassword());
			HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(bodyMap,
					headers);
			ResponseEntity<String> jigsawResponse = null;
			try {
				jigsawResponse = restTemplate.exchange(updatePasswordUrl, HttpMethod.PUT, request, String.class,
						paramMap);
			} catch (HttpClientErrorException e) {
				e.printStackTrace();
				String errorMsg = e.getMessage();
				logger.info("Error message " + errorMsg);
				throw new BridgeException(ApplicationCode.INVALID_TOKEN);
			} catch (Exception ex) {
				throw new BridgeException(ApplicationCode.UNEXPECTED_ERROR);
			}
			logger.info("updatePassword response code : " + jigsawResponse.getStatusCode());
			logger.info("updatePassword response body : " + jigsawResponse.getBody());
			if (jigsawResponse.getStatusCode() != HttpStatus.OK) {
				throw new BridgeException(ApplicationCode.UNEXPECTED_ERROR);
			}
		}

		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse updateOldPolicyPassword(OldPolicyPasswordVO oldPolicyPasswordVO, String code)
			throws BridgeException, ParseException, IOException, ConnectApiException, ConnectApiHttpException,
			ConnectApiXmlException, ConnectApiFieldException, VstException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		//boolean isSampler = ApplicationConstants.BRIDGE_TYPE_SAMPLER.equals(bridge.getBridgeType().getType());
		boolean isSampler=bridge.getIsSampler();
		if (isSampler) {
			throw new BridgeException(ApplicationCode.INVALID_USER_REQUEST);
		}

		final String email = oldPolicyPasswordVO.getEmail();
		final String oldPassword = oldPolicyPasswordVO.getOldPassword();
		final String newPassword = oldPolicyPasswordVO.getNewPassword();

		if (newPassword != null && !VstUtils.isValidPassword(newPassword)) {
			throw new BridgeException(ApplicationCode.PASSWORD_NOT_ACCEPTED);
		}
		ApiKeys key = new ApiKeys(ApplicationConstants.getApiMode(), bridge.getApiKey(), "unused:lti_key",
				"unused:lti_secret");
		ConnectCredentials credentials = ConnectApiWrapper.verifyCredentials(key, email, oldPassword);
		if (credentials != null) {
			String guid = credentials.getGuid();
			String accessToken = credentials.getAccessToken();
			ConnectUser connectoldUser = ConnectApiWrapper.getUser(key, guid, accessToken, Boolean.TRUE);
			BridgeUser bridgeUser = bridgeUserDAO.getForEmail(bridge.getId(), email);
			if ((bridge.getIsIntegrated() || bridge.getIsRostered()) && bridgeUser == null) {
				throw new BridgeException(ApplicationCode.USER_NOT_FOUND);
			} else if (bridgeUser == null) {
				bridgeUser = new BridgeUser();
				userServiceUtil.populateBridgeUserDetailsFromConnectUser(bridgeUser, bridge, connectoldUser,
						credentials);
				bridgeUserDAO.create(bridgeUser);
			} else {
				bridgeUser.setAccessToken(accessToken);
				bridgeUser.setGuid(guid);
				bridgeUserDAO.saveOrUpdate(bridgeUser);
			}
			UserDetailsVO newDetailsVO = new UserDetailsVO();
			newDetailsVO.setEmail(email);
			if (newPassword != null) { // For setting old security question only
										// when password is as per policy
				newDetailsVO.setPassword(newPassword);
			}
			newDetailsVO.setQuestionId(oldPolicyPasswordVO.getQuestionId());
			newDetailsVO.setQuestionResponse(oldPolicyPasswordVO.getQuestionResponse());
			newDetailsVO.setPromotionSubscription(connectoldUser.getPromotionSubscription());
			newDetailsVO.setSurveySubscription(connectoldUser.getSurveySubscription());
			newDetailsVO.setFirstName(bridgeUser.getFirstName());
			newDetailsVO.setLastName(bridgeUser.getLastName());
			ConnectUser connectNewUser = ConnectApiWrapper.updateUser(key, bridgeUser, newDetailsVO);
			if (connectNewUser == null) {
				throw new BridgeException(ApplicationCode.USER_AUTHENTICATION_FAILED);
			} else {
				BridgeUserInfoVO userInfoVO = userServiceUtil.populateBridgeUserInfoFromBridgeUser(bridgeUser);
				response.setData(userInfoVO);
			}

		} else {
			throw new BridgeException(ApplicationCode.UNATHORISED_REQUEST);
		}

		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse checkUserEmail(String domain, UserEmailVO userEmailVO, String code,
			HttpServletRequest httpRequest) throws BridgeException, ConnectApiException, VstException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		String url = httpRequest.getRequestURL().toString();
		url = url.substring(0, url.indexOf("//")) + "//" + domain + "/#/complete-account?token=";

		EmailCheckUserInfoVO emailCheckUserInfoVO = null;
		Boolean fullUser = Boolean.FALSE;
		String email = userEmailVO.getEmail();
		if (StringUtils.isNotBlank(email)) {

			if (userServiceUtil.checkEmailExistInBookshelf(email)) {
				throw new BridgeException(ApplicationCode.BOOKSHELF_FULL_USER);
			}

			emailCheckUserInfoVO = new EmailCheckUserInfoVO();

			Bridge bridge = bridgeDAO.getBridgeForCode(code);
			if (bridge == null) {
				throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
			}

			BridgeUser bridgeUser = bridgeUserDAO.getForEmail(bridge.getId(), email);

			if (bridge.getIsRostered() && bridgeUser == null) {
				throw new BridgeException(ApplicationCode.USER_NOT_FOUND);
			}

			if (null != bridgeUser) {
				String accesstoken = bridgeUser.getAccessToken();
				String guid = bridgeUser.getGuid();
				if (StringUtils.isNotBlank(accesstoken) && StringUtils.isNotBlank(guid)) {
					fullUser = Boolean.TRUE;
				}
				if (!fullUser && bridge.getIsRostered()) {
					String token = UUID.randomUUID().toString();

					List<BridgeUserEmailToken> previousList = bridgeUserEmailTokenDAO.getList(bridge.getId(), email,
							Boolean.FALSE);
					if (null != previousList && previousList.size() > 0) {
						for (BridgeUserEmailToken emailToken : previousList) {
							emailToken.setDeleted(Boolean.TRUE);
						}
						bridgeUserEmailTokenDAO.saveOrUpdateAll(previousList);
					}
					Date currentDate = new Date();
					BridgeUserEmailToken newToken = new BridgeUserEmailToken();
					newToken.setBridge(bridge);
					newToken.setEmail(email);
					newToken.setUsed(Boolean.FALSE);
					newToken.setCreatedDate(currentDate);
					newToken.setToken(token);
					bridgeUserEmailTokenDAO.create(newToken);
					this.sendActivationEmail(bridgeUser, bridge, url + token);
					emailCheckUserInfoVO.setMessage("Email sent for activation");
				}

			}
			emailCheckUserInfoVO.setEmail(email);
			response.setData(emailCheckUserInfoVO);
		} else {
			throw new BridgeException(ApplicationCode.INVALID_INPUT);
		}
		return response;
	}

	private void sendActivationEmail(final BridgeUser user, final Bridge bridge, final String url) {

		final Runnable runnable = new Runnable() {

			@Override
			public void run() {
				Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put(ApplicationConstants.RESET_PASSWORD_TO, user.getEmail());
				paramMap.put(ApplicationConstants.EMAIL_BRIDGE_NAME, bridge.getName());
				paramMap.put(ApplicationConstants.RESET_PASSWORD_USER_NAME, user.getFirstName());
				paramMap.put(ApplicationConstants.EMAIL_ACTIVATION_LINK, url);
				emailHandler.sendEmail(TemplateLocationConstants.USER_ACCTIVATION_NOTIFICATION_TEMPLATE, paramMap);
			}
		};
		this.executor.execute(runnable);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getQuestions(HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		response.setData(securityQuestionDAO.getListOfQuestions());
		return response;
	}

}
