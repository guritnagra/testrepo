package com.vst.bridge.dao.user;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.rest.response.vo.BCUserVO;
import com.vst.bridge.rest.response.vo.bridge.user.BridgeUserResponseVO;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeUserDAO")
public class BridgeUserDAOImpl extends GenericDAO<BridgeUser, Integer> implements IBridgeUserDAO{

	/**
	 * Represents the logger of the application.
	 */
	private static Logger logger = LogManager.getLogger(BridgeUserDAOImpl.class);
	
	public BridgeUserDAOImpl() {
		super(BridgeUser.class);
	}

	@Override
	public BridgeUser checkUserAllreadyExist(Integer id, String guid, Integer role_id) throws BridgeException {
		logger.info("checkUserAllreadyExist : request to check bridge {},giud {} exist",id,guid);
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", id));
		criteria.add(Restrictions.like("guid", guid));
		criteria.add(Restrictions.eq("role.id", role_id));
		criteria.add(Restrictions.isNull("deleted"));
		criteria.addOrder(Order.desc("createdDate"));
		List<BridgeUser> result = executeCriteira(criteria);
		return null!=result && result.size() > 0? result.get(0) : null;
	}
	
	@Override
	public BridgeUser checkUserAllreadyExist(Integer id, String guid) throws BridgeException {
		logger.info("checkUserAllreadyExist : request to check bridge {},giud {} exist",id,guid);
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", id));
		criteria.add(Restrictions.like("guid", guid));
		criteria.add(Restrictions.isNull("deleted"));
		criteria.addOrder(Order.desc("createdDate"));
		List<BridgeUser> result = executeCriteira(criteria);
		return null!=result && result.size() > 0? result.get(0) : null;
	}

	@Override
	public BridgeUser getForEmail(String email) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.like("email", email));
		criteria.add(Restrictions.isNull("deleted"));
		List<BridgeUser> result = executeCriteira(criteria);
		return null!=result && result.size() > 0? result.get(0) : null;
	}
	
	@Override
	public BridgeUser getForEmail(Integer bridgeId,String email) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.like("email", email));
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
	//	criteria.add(Restrictions.isNull("deleted"));
		List<BridgeUser> result = executeCriteira(criteria);
		return null!=result && result.size() > 0? result.get(0) : null;
	}
	
	@Override
	public List<BridgeUserResponseVO> getUsersForBridge(Integer bridgeId, final Integer startIndex, PaginationVO paginationVo)
			throws BridgeException {
		
		Criteria criteria= getCriteria();
		//criteria.createAlias("user", "userAlias");
		if(null!=paginationVo){
			
			Integer totalRecordToFetch = paginationVo.getLimit();
			if(null != startIndex && null != totalRecordToFetch  && totalRecordToFetch > 0){
				criteria.setFirstResult(startIndex);
				criteria.setMaxResults(totalRecordToFetch);
			}
			
			String searchParam =  paginationVo.getSearch();
			if(StringUtils.isNotBlank(searchParam)){
				
				
				Criterion criterion1 = Restrictions.ilike("firstName", "%"+searchParam+"%");
				Criterion criterion2 = Restrictions.ilike("lastName", "%"+searchParam+"%");
				Criterion criterion3 = Restrictions.ilike("email", "%"+searchParam+"%");
				
				Criterion completeCriterion = Restrictions.disjunction()
						.add(criterion1)
						.add(criterion2)
						.add(criterion3);
				criteria.add(completeCriterion);
			}
			if(StringUtils.equals(paginationVo.getOrder(), ApplicationConstants.SORTING_ORDER_ASC)){
				criteria.addOrder(Order.asc(paginationVo.getOrderBy()));
			}else{
				criteria.addOrder(Order.desc(paginationVo.getOrderBy()));
			}
		}
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		//return executeCriteira(criteria);
		criteria.add(Restrictions.isNull("deleted"));
		criteria.setProjection(Projections.projectionList()
				.add( Projections.property("id").as("id"))
				.add( Projections.property("firstName").as("firstName"))
				.add( Projections.property("email").as("email"))
				.add( Projections.property("lastName").as("lastName"))
				.add(Projections.property("createdDate").as("activationDate")))
				.setResultTransformer(new AliasToBeanResultTransformer(BridgeUserResponseVO.class));
				
		return executeCriteira(criteria);
	}
	
	@Override
	public List<BridgeUserResponseVO> getUsersForBridge(Integer bridgeId, PaginationVO paginationVo) throws BridgeException {
		
		Criteria criteria= getCriteria();
		//criteria.createAlias("user", "userAlias");
		if(null!=paginationVo){
			
			String searchParam =  paginationVo.getSearch();
			if(StringUtils.isNotBlank(searchParam)){
				
				
				Criterion criterion1 = Restrictions.ilike("firstName", "%"+searchParam+"%");
				Criterion criterion2 = Restrictions.ilike("lastName", "%"+searchParam+"%");
				Criterion criterion3 = Restrictions.ilike("email", "%"+searchParam+"%");
				
				Criterion completeCriterion = Restrictions.disjunction()
						.add(criterion1)
						.add(criterion2)
						.add(criterion3);
				criteria.add(completeCriterion);
			}
			if(StringUtils.equals(paginationVo.getOrder(), ApplicationConstants.SORTING_ORDER_ASC)){
				criteria.addOrder(Order.asc(paginationVo.getOrderBy()));
			}else{
				criteria.addOrder(Order.desc(paginationVo.getOrderBy()));
			}
		}
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		//return executeCriteira(criteria);
		criteria.add(Restrictions.isNull("deleted"));
		criteria.setProjection(Projections.projectionList()
				.add( Projections.property("id").as("id"))
				.add( Projections.property("firstName").as("firstName"))
				.add( Projections.property("email").as("email"))
				.add( Projections.property("lastName").as("lastName"))
				.add(Projections.property("createdDate").as("activationDate"))
				.add(Projections.property("tenantUserId").as("tenantUserId")))
				.setResultTransformer(new AliasToBeanResultTransformer(BridgeUserResponseVO.class));
				
		return executeCriteira(criteria);
	}
	
	@Override
	public Integer getUsersCountForBridge(Integer bridgeId, PaginationVO paginationVo)
			throws BridgeException {
		Criteria criteria= getCriteria();
		if(null!=paginationVo){
			
			String searchParam =  paginationVo.getSearch();
			if(StringUtils.isNotBlank(searchParam)){
				
				
				Criterion criterion1 = Restrictions.ilike("firstName", "%"+searchParam+"%");
				Criterion criterion2 = Restrictions.ilike("lastName", "%"+searchParam+"%");
				Criterion criterion3 = Restrictions.ilike("email", "%"+searchParam+"%");
				
				Criterion completeCriterion = Restrictions.disjunction()
						.add(criterion1)
						.add(criterion2)
						.add(criterion3);
				criteria.add(completeCriterion);
			}
		}
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.isNull("deleted"));		
		criteria.setProjection(Projections.projectionList()
				.add( Projections.property("id").as("id"))
				.add( Projections.property("firstName").as("firstName"))
				.add( Projections.property("email").as("email"))
				.add( Projections.property("lastName").as("lastName")))
				.setResultTransformer(new AliasToBeanResultTransformer(BridgeUserResponseVO.class));
				
		List<BridgeUserResponseVO> result = executeCriteira(criteria);
		if (null != result && result.size() > 0) {
			return result.size();
		}
			
		return 0;
	}

	@Override
	public List<Integer> getUserIdsForBridge(Integer bridgeId) throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.isNull("deleted"));
		criteria.setProjection(Projections.projectionList()
											.add( Projections.property("id")));
		return executeCriteira(criteria);
	}

	@Override
	public BridgeUser getForUser(Integer bridgeId, Integer userId) throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("id", userId));
		List<BridgeUser> result = executeCriteira(criteria);
		return null!=result && result.size() > 0? result.get(0) : null;
	}

	@Override
	public List<BridgeUser> getAllUsersForBridge(Integer bridgeId) throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.isNull("deleted"));
		return executeCriteira(criteria);
	}

	@Override
	public BridgeUser getBridgeUserByTenantUserId(String tenantUserId, Integer bridgeId) throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("tenantUserId", tenantUserId));
		List<BridgeUser> result = executeCriteira(criteria);
		return null!=result && result.size() > 0? result.get(0) : null;
	}
	
	@Override
	public BridgeUser getBridgeUserByTenantUser(BCUserVO bcUserVO, Integer bridgeId) throws BridgeException {
		Criteria criteria= getCriteria();
		if(null == bcUserVO){
			return null;
		}
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("tenantUserId", bcUserVO.getId()));
		if(null != bcUserVO.getIsInstructor() && Boolean.valueOf(bcUserVO.getIsInstructor()) == Boolean.TRUE){
			criteria.add(Restrictions.eq("role.id", 2));
		}else{
			criteria.add(Restrictions.eq("role.id", 1));
		}
		List<BridgeUser> result = executeCriteira(criteria);
		return null!=result && result.size() > 0? result.get(0) : null;
	}

	@Override
	public List<BridgeUser> getIntegratedBridgeUserByBridgeId(Integer bridgeId) throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.isNotNull("tenantUserId"));
		return executeCriteira(criteria);
	}

	@Override
	public BridgeUser getBridgeUserByGUID(Integer bridgeId, String guid, Integer role_id) throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("guid", guid));
		List<BridgeUser> result = executeCriteira(criteria);
		return null!=result && result.size() > 0? result.get(0) : null;
	}

	@Override
	public Integer deleteAllUsers(Integer adminId, Bridge bridge) {
		Session session = getCrntSession();
		String hqlUpdate = "update BridgeUser bu set bu.deletedBy = :deletedBy, bu.deleted = :deleted where bu.bridge = :bridge";
		int updatedEntities = session.createQuery(hqlUpdate)
				.setInteger("deletedBy", adminId)
				.setDate("deleted", new Date())
				.setEntity("bridge", bridge)
				.executeUpdate();
		return updatedEntities;
	}

	@Override
	public BridgeUser getBridgeUserBySourceId(Integer bridgeId, String userSourceId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("sourceId",userSourceId));
		criteria.add(Restrictions.isNull("deleted"));
		List<BridgeUser> results = executeCriteira(criteria);
		return null != results && results.size() > 0 ? results.get(0) : null;
	}
}
