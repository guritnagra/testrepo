package com.vst.bridge.rest.response.vo.user;

public class UserDetailsVO {
	private String email;
	private String password;
	private String firstName;
	private String lastName;
	private Integer questionId;
	private String questionResponse;
	private Boolean promotionSubscription;
	private Boolean surveySubscription;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Integer getQuestionId() {
		return questionId;
	}
	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}
	public String getQuestionResponse() {
		return questionResponse;
	}
	public void setQuestionResponse(String questionResponse) {
		this.questionResponse = questionResponse;
	}
	public Boolean getPromotionSubscription() {
		return promotionSubscription;
	}
	public void setPromotionSubscription(Boolean promotionSubscription) {
		this.promotionSubscription = promotionSubscription;
	}
	public Boolean getSurveySubscription() {
		return surveySubscription;
	}
	public void setSurveySubscription(Boolean surveySubscription) {
		this.surveySubscription = surveySubscription;
	}
}
