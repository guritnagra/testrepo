package com.vst.bridge.service.book;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookCacheDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.bridge.BridgeBooksVO;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;

@Service("bookServiceAncillary")
public class BookAncillaryServiceImpl implements IBookAncillaryService {

	@Autowired
	private BookServiceUtil bookServiceUtil;
	@Autowired
	private IBridgeDAO bridgeDAO;
	@Autowired
	private IBridgeBookCacheDAO bridgeBookCacheDAO;

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse updateBridgeBookAncillaryTitle(Integer bridgeId, BridgeBooksVO bridgeBooksVO,
			String vbid, HttpServletRequest httpRequest) throws BridgeException {
		RestResponse response = bookServiceUtil.getDefaultRestResponse();
		
		if(null == bridgeBooksVO || null == vbid){
			throw new BridgeException(ApplicationCode.BOOK_NOT_FOUND);
		}
		
		Bridge bridge = bridgeDAO.get(bridgeId);
		
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.NO_SUCH_WEBSITE);
		}
		
		BridgeBookCache bridgeBookCache = checkAndUpdateAncillary(vbid,bridgeId);
		updateAncillaryBookCache(bridgeBookCache, bridgeBooksVO);
		response.setData(bridgeBooksVO);
		return response;
	}

	private BridgeBookCache checkAndUpdateAncillary(String vbid, Integer bridgeId) {
		BridgeBookCache bridgeBookCache = bridgeBookCacheDAO.getBookForVbid(bridgeId, vbid);
		if(null == bridgeBookCache.getAncillary()){
			throw new BridgeException("Not an ancillary", ApplicationCode.DATA_VALIDATION_ERROR);
		}
		return bridgeBookCache;
	}
	private void updateAncillaryBookCache(BridgeBookCache bridgeBookCache, BridgeBooksVO bridgeBooksVO){
		if(null != bridgeBooksVO){
			String param = null;
			if(null != (param = bridgeBooksVO.getTitle())){
				bridgeBookCache.setTitle(param);
				bridgeBookCache.getAncillary().setTitle(param);
			}
			if(null != (param = bridgeBooksVO.getDescription())){
				bridgeBookCache.setDescription(param);
			}
			bridgeBookCacheDAO.update(bridgeBookCache);
		}
	}

}
