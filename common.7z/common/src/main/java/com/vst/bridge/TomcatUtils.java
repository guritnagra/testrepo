package com.vst.bridge;

import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class TomcatUtils {
	private static Logger log = LogManager.getLogger(TomcatUtils.class);

	public static MimeMessage getMimeMessage() throws NamingException {
		Context initContext = new InitialContext();
		Context envContext  = (Context)initContext.lookup("java:/comp/env");

		Session session= (Session)envContext.lookup("mail/Session");
		MimeMessage message = new MimeMessage(session);
		return message;
	}
	
	public static String getParam(String name, String defaultStr) {
		final String foundStr= getParam(name);
		if(null == foundStr) {
			return defaultStr;
		}
		return foundStr;
	}
	
	public static String getParam(String name)
	{
		try {
			return (String)((new InitialContext()).lookup("java:comp/env/"+name));
		} catch (NamingException e) {
			log.error("getParam {} not found", name);
			return null;
		}
	}

}
