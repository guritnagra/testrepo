package com.vst.bridge.dao.admin;

import java.util.List;
import java.util.Set;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.company.AdminCompany;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.company.Company;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminCompanyDAO extends IGenericDAO<AdminCompany, Integer>{
	List<Company> getCompaniesForAdminId(final Integer adminId)throws BridgeException;

	List<AdminCompany> getAdminCompaniesForAdminId(Integer id, Boolean isDeleted)throws BridgeException;

	AdminCompany getAdminCompanyByAdminAndCompanyId(Integer adminId, Integer companyId) throws BridgeException;

	Set<AdminUser> getUsersForCompanyIds(List<Integer> companyIds, Integer startIndex, BridgePaginationVo paginationVo)
			throws BridgeException;

	Integer getUsersCount(List<Integer> companyIds, BridgePaginationVo paginationVo) throws BridgeException;

	

	
}
