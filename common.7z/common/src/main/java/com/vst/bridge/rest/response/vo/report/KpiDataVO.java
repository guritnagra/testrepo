package com.vst.bridge.rest.response.vo.report;

public class KpiDataVO {

	private Integer bridgeSites;

	private Integer bridgeUsers;

	private Integer bridgeAdmins;

	private Integer uniqueAssets;

	private Integer activations;
	
	public KpiDataVO(Integer... values){
		if(null != values && values.length > 0){
			this.bridgeSites = values[0];
			this.bridgeUsers = values[1];
			this.bridgeAdmins = values[2];
			this.uniqueAssets = values[3];
			this.activations = values[4];
		}
	}

	public Integer getBridgeSites() {
		return bridgeSites;
	}

	public void setBridgeSites(Integer bridgeSites) {
		this.bridgeSites = bridgeSites;
	}

	public Integer getBridgeUsers() {
		return bridgeUsers;
	}

	public void setBridgeUsers(Integer bridgeUsers) {
		this.bridgeUsers = bridgeUsers;
	}

	public Integer getBridgeAdmins() {
		return bridgeAdmins;
	}

	public void setBridgeAdmins(Integer bridgeAdmins) {
		this.bridgeAdmins = bridgeAdmins;
	}

	public Integer getUniqueAssets() {
		return uniqueAssets;
	}

	public void setUniqueAssets(Integer uniqueAssets) {
		this.uniqueAssets = uniqueAssets;
	}

	public Integer getActivations() {
		return activations;
	}

	public void setActivations(Integer activations) {
		this.activations = activations;
	}
	
	
}
