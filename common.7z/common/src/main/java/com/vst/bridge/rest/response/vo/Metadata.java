package com.vst.bridge.rest.response.vo;

public class Metadata {
	private Integer count;

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}
}
