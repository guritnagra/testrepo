package com.vst.bridge.rest.central;

import com.vst.bridge.entity.admin.session.AdminSession;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.session.BridgeUserSession;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeAuthonticator {
	SessionStatusVO getAdminSessionVO(AdminSession adminSession)throws BridgeException;
	AdminSession getAdminSession(final String sessionId)throws BridgeException;
	void updateLastAccess(AdminSession adminSession,String sessionId)throws BridgeException;
	BridgeUserSession getBridgeUserSession(String sessionId)throws BridgeException;
	void updateLastAccess(BridgeUserSession userSession, String sessionId)throws BridgeException;
	SessionStatusVO getBridgeUserSessionVO(BridgeUserSession userSession)throws BridgeException;
	void checkAdminAccessForBridgeById(SessionStatusVO sessionStatusVO, Integer bridgeId) throws BridgeException;
	AdminUser getAdminUserForSession(SessionStatusVO sessionStatusVO) throws BridgeException;
}
