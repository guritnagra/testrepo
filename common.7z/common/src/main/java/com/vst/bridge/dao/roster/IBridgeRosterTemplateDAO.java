package com.vst.bridge.dao.roster;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.roster.BridgeRosterTemplate;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeRosterTemplateDAO extends IGenericDAO<BridgeRosterTemplate,Integer> {
	BridgeRosterTemplate getByFileType(String name) throws BridgeException;	
}
