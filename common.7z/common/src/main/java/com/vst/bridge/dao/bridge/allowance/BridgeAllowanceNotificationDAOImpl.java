package com.vst.bridge.dao.bridge.allowance;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.allowance.BridgeAllowanceNotification;

@Repository("bridgeAllowanceNotificationDAO")
public class BridgeAllowanceNotificationDAOImpl extends GenericDAO<BridgeAllowanceNotification, Integer> implements IBridgeAllowanceNotificationDAO {

	public BridgeAllowanceNotificationDAOImpl() {
		super(BridgeAllowanceNotification.class);
	}


	public List<BridgeAllowanceNotification> getLastBridgeAllowanceNotifications(final Integer bridgeId){
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		List<BridgeAllowanceNotification> result =  executeCriteira(criteria);
		return result;
	}
	
}
