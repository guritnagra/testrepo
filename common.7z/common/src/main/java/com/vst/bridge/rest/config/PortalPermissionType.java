package com.vst.bridge.rest.config;

public enum PortalPermissionType {
	admin,
	user;
}
