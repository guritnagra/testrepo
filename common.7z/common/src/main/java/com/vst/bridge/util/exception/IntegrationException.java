package com.vst.bridge.util.exception;

import java.net.URL;

public class IntegrationException extends Throwable{
	private static final long serialVersionUID = 3652384923481397831L;
	
	private String message;
	private ApplicationCode errorCode;
	private URL requestUrl; 
	
	public IntegrationException(final ApplicationCode code, URL requestUrl) {
		this("A integration exception occurred",code, requestUrl);
	}
	
	public IntegrationException(final String message, final ApplicationCode code, URL requestUrl) {
		super(message);
		this.setMessage(message);
		this.errorCode = code;
		this.requestUrl = requestUrl;
	}

	public IntegrationException(final String message, final ApplicationCode code,URL requestUrl, final Throwable throwable) {
		super(message,throwable);
		this.errorCode = code;
		this.setMessage(message);
		this.requestUrl = requestUrl;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public ApplicationCode getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(ApplicationCode errorCode) {
		this.errorCode = errorCode;
	}

	public URL getRequestUrl() {
		return requestUrl;
	}

	public void setRequestUrl(URL requestUrl) {
		this.requestUrl = requestUrl;
	} 
	
	
}
