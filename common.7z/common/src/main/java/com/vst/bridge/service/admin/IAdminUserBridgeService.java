package com.vst.bridge.service.admin;

import java.io.IOException;
import java.net.MalformedURLException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.VstException;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.bridge.BridgeInfoWithFavoriteVO;
import com.vst.bridge.rest.response.vo.bridge.IntigrationVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;

public interface IAdminUserBridgeService {
	RestResponse uploadLogo(SessionStatusVO sessionStatusVO, Object param,HttpServletRequest httpRequest, UriInfo uriInfo)throws BridgeException, MalformedURLException, IOException;
	RestResponse getBridgesList(SessionStatusVO sessionStatusVO,final BridgePaginationVo bridgePaginationVo,
			HttpServletRequest httpRequest, UriInfo uriInfo)throws BridgeException;
	RestResponse getBridgeForId(SessionStatusVO sessionStatusVO,final Integer bridgeid,
			HttpServletRequest httpRequest, UriInfo uriInfo)throws BridgeException;
	RestResponse getBridgeConfigForId(SessionStatusVO sessionStatusVO, Integer id, HttpServletRequest httpRequest,
			UriInfo uriInfo)throws BridgeException;
	RestResponse getBridgeIntigrationForBridgeId(SessionStatusVO sessionStatusVO, Integer id,
			HttpServletRequest httpRequest, UriInfo uriInfo)throws BridgeException;
	RestResponse updateBridgeIntigrationForBridgeId(SessionStatusVO sessionStatusVO, IntigrationVO intigrationVO,
			Integer id, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException;
	RestResponse deleteBridge(SessionStatusVO sessionStatusVO, Integer id, HttpServletRequest httpRequest,
			UriInfo uriInfo)throws BridgeException;
	RestResponse getBridgeTypes() throws BridgeException;
	RestResponse createOrUpdateBridges(BridgeInfoWithFavoriteVO bridgeInfoWithFavoriteVO,
			SessionStatusVO sessionStatusVO, Integer id, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException, ConnectApiException, ConnectApiXmlException, ConnectApiHttpException, VstException;
	RestResponse updateBridgeConfigForId(SessionStatusVO sessionStatusVO, Integer id, Map<String, String> requestMap,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException, IOException;
	RestResponse deleteBridgeUsers(SessionStatusVO sessionStatusVO, Integer bridgeId, List<Integer> usersToRemove,Boolean deleteAll, String search, Boolean isUngrouped)throws BridgeException, ParseException;
	RestResponse getAdminLabels(HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException;
}
