package com.vst.bridge.service.book;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Element;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.util.constant.DataType;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ApiKeys;
import com.vst.connectapi.ConnectApiWrapper;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;
import com.vst.connectapi.ConnectBook;
import com.vst.connectapi.ConnectBookCallUtil;

@Service("BookRefreshService")
public class BookRefreshWorker {

	@Autowired
	private BookServiceUtil bookServiceUtil;
	private ExecutorCompletionService<Document> connectCallWorker;
	private ExecutorService threadPool = Executors.newFixedThreadPool(16);
	private Logger log = LogManager.getLogger(BookRefreshWorker.class);

	@Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.READ_COMMITTED, readOnly=false)
	public void refreshBridges(Bridge bridge, ApiKeys key) {
		
		try {
			Integer totalPages = initalConnectCall(key);
			List<Future<Document>> futureList = getRemainingConnectBooks(totalPages, key);
			
			Map<DataType, Map<String, ConnectBook>> connectBookMap = processAdditionalConnectBooks(futureList, bridge);
			
			if(null != connectBookMap && !connectBookMap.isEmpty()){
				bookServiceUtil.addOrRefreshBridgeBookCacheFromConnectBooks(connectBookMap, bridge.getApiKey(), bridge);
			}   
			log.info("Book refresh completed for bridge id: "+bridge.getId());
		} catch (ConnectApiException | ConnectApiXmlException | ConnectApiHttpException e) {
			throw new BridgeException("There was an error refreshing the assets on bridge id: "+bridge.getId(),
					ApplicationCode.CONNECT_API_ERROR,
					e);
		}

	}

	private Integer initalConnectCall(final ApiKeys key)
			throws ConnectApiException, ConnectApiXmlException, ConnectApiHttpException {
		int initialItemsPerPage = 1;
		int itemsPerPage = 1000;
		int currentPage = 0;
		Integer totalPages = 0;
		Document catalogs = ConnectApiWrapper.getBooksFromCatalog(key, currentPage, initialItemsPerPage);
		if (null != catalogs) {
			Element rootElement = catalogs.getRootElement();
			if (rootElement.getName().equals("catalog")) {
				totalPages = Integer.parseInt(rootElement.getAttributeValue("total-pages"));
				Integer totalItems = Integer.parseInt(rootElement.getAttributeValue("items"));
				int newTotalPages = (int) Math.ceil((totalPages / (double) itemsPerPage));
				totalPages = newTotalPages;
				log.info("total pages: " + totalPages + " total items: " + totalItems);
			} else {
				throw new BridgeException(ApplicationCode.CONNECT_API_ERROR);
			}
		} else {
			throw new BridgeException(ApplicationCode.CONNECT_API_ERROR);
		}
		return totalPages;
	}

	private List<Future<Document>> getRemainingConnectBooks(int totalPages, ApiKeys apiKey) {
		connectCallWorker = new ExecutorCompletionService<>(threadPool);
		List<Future<Document>> futureList = new ArrayList<>();
		for (int i = 0; i < totalPages; i++) {
			ConnectBookCallUtil connectCaller = new ConnectBookCallUtil(apiKey, i, 1000);
			try {
				TimeUnit.MILLISECONDS.sleep(100);
			} catch (InterruptedException e) {
				log.error("There was problem throttling thread " + Thread.currentThread().getName());
				log.error(Thread.currentThread().getStackTrace());
			}
			futureList.add(connectCallWorker.submit(connectCaller));
		}
		return futureList;
	}

	private Map<DataType, Map<String, ConnectBook>> processAdditionalConnectBooks(List<Future<Document>> futureList,
			Bridge bridge) {
		Map<DataType, Map<String, ConnectBook>> connectBookMap = new HashMap<>();
		Map<String, ConnectBook> rentalMap = new HashMap<>();
		Map<String, ConnectBook> standardMap = new HashMap<>();
		connectBookMap.put(DataType.CONNECT_RENTAL_MAP, rentalMap);
		connectBookMap.put(DataType.CONNECT_STANDARD_MAP, standardMap);
		try {
			log.info("Connect book creation started for bridge id: "+bridge.getId());
			for (Future<Document> connectBookResult:futureList) {;
				try{

					Document catalog = connectBookResult.get(90, TimeUnit.SECONDS);
					if (null != catalog) {
						createConnectBooksFromCatalog(catalog, connectBookMap);
					}
				}catch(TimeoutException te){
					log.error("Callback timeout for bridge id: "+bridge.getId());
					continue;
				}
			}
			log.info("Connect book creation complete for bridge id: " + bridge.getId());

		} catch (InterruptedException | ExecutionException e) {
			throw new BridgeException("There was an error fetching Connect books", ApplicationCode.CONNECT_API_ERROR,
					e);
		}
		return connectBookMap;
	}

	private void createConnectBooksFromCatalog(Document catalogs,
			Map<DataType, Map<String, ConnectBook>> connectBookMap) {
		Element rootElement = catalogs.getRootElement();
		if (rootElement.getName().equals("catalog")) {
			Map<String, ConnectBook> rentalMap = connectBookMap.get(DataType.CONNECT_RENTAL_MAP);
			Map<String, ConnectBook> standardMap = connectBookMap.get(DataType.CONNECT_STANDARD_MAP);
			
			List<Element> products_children = rootElement.getChildren();
			for (Element item : products_children) {
				if (!item.getName().equals("item")) {
					continue;
				}

				String description = null, name = null, authorname = null, vbid = null, printisbn = null, isbn = null,
						coverimageurl = null, edition = null, subject = null, sku = null, publisherPrice = null,
						digitalPrice = null, distributable = null, type = null;
				List<Element> assetsDetails = item.getChildren();
				for (Element asset : assetsDetails) {

					switch (asset.getName()) {
					case "title":
						name = asset.getValue();
						break;
					case "author":
						authorname = asset.getValue();
						break;
					case "edition":
						edition = asset.getValue();
						break;
					case "vbid":
						vbid = asset.getValue();
						break;
					case "sku":
						sku = asset.getValue();
						break;
					case "description":
						description = asset.getValue();
						break;
					case "aliases":
						List<Element> aliases = asset.getChildren();
						for (Element aliase : aliases) {
							switch (aliase.getName()) {
							case "isbn-canonical":
								isbn = aliase.getValue();
								break;
							case "print-isbn-canonical":
								printisbn = aliase.getValue();
								break;
							default:
							}
						}
						break;
					case "pricelist":
						List<Element> pricelist = asset.getChildren();
						for (Element price : pricelist) {
							switch (price.getName()) {
							case "publisher-list-price":
								publisherPrice = price.getValue();
								break;
							case "digital-list-price":
								digitalPrice = price.getValue();
								break;
							default:
							}
						}
						break;
					case "icon-url":
						coverimageurl = asset.getValue();
						break;

					case "distributable":
						distributable = asset.getValue();
						break;

					case "type":
						type = asset.getValue();
						break;

					}

				}

				if ((StringUtils.isNotEmpty(distributable) && StringUtils.equals("true", distributable)
						&& !StringUtils.equals("Demo", type))) {
					final ConnectBook b = new ConnectBook(vbid, name, printisbn, isbn, authorname, description,
							coverimageurl, edition, subject, sku, publisherPrice, digitalPrice, type);
					if ("Rental".equals(type)) {
						rentalMap.put(sku, b);
					} else {
						standardMap.put(sku, b);
					}
				}

			}
		}
	}

}
