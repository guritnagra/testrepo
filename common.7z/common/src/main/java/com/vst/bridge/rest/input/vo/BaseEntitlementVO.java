package com.vst.bridge.rest.input.vo;

import com.vst.bridge.annotation.custom.InputRequired;

public class BaseEntitlementVO {

	@InputRequired(required=false)
	//private Integer id;
	private String entitlementName;
	private String entitlementType;
	private Integer credit;
	private Integer onlineDays;
	private Long onlineExpires;
	private Integer offlineDays;
	private Long offlineExpires;
	private Boolean isCopyfromOnline=Boolean.FALSE;
	
	/*public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}*/
	public String getEntitlementName() {
		return entitlementName;
	}
	public void setEntitlementName(String entitlementName) {
		this.entitlementName = entitlementName;
	}
	public String getEntitlementType() {
		return entitlementType;
	}
	public void setEntitlementType(String entitlementType) {
		this.entitlementType = entitlementType;
	}
	public Integer getCredit() {
		return credit;
	}
	public void setCredit(Integer credit) {
		this.credit = credit;
	}
	public Integer getOnlineDays() {
		return onlineDays;
	}
	public void setOnlineDays(Integer onlineDays) {
		this.onlineDays = onlineDays;
	}
	public Long getOnlineExpires() {
		return onlineExpires;
	}
	public void setOnlineExpires(Long onlineExpires) {
		this.onlineExpires = onlineExpires;
	}
	public Integer getOfflineDays() {
		return offlineDays;
	}
	public void setOfflineDays(Integer offlineDays) {
		this.offlineDays = offlineDays;
	}
	public Long getOfflineExpires() {
		return offlineExpires;
	}
	public void setOfflineExpires(Long offlineExpires) {
		this.offlineExpires = offlineExpires;
	}
	public Boolean getIsCopyfromOnline() {
		return isCopyfromOnline;
	}
	public void setIsCopyfromOnline(Boolean isCopyfromOnline) {
		this.isCopyfromOnline = isCopyfromOnline;
	}
	
	
}
