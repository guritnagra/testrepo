package com.vst.bridge.util.constant;

public enum DataType {
	CONNECT_STANDARD_MAP, CONNECT_RENTAL_MAP
}
