package com.vst.bridge.util.constant;

import java.util.List;
import java.util.Vector;

import org.apache.commons.lang.StringUtils;

import com.vst.bridge.TomcatUtils;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ApiKeys;
import com.vst.connectapi.ApiKeys.API_MODE;

public class ApplicationConstants {
	
	public static List<String> validBookOrderByValues = new Vector<String>();
	public static List<String> validBridgesOrderByValues = new Vector<String>();
	public static List<String> validUsersOrderByValues = new Vector<String>();
	static{
		validBookOrderByValues.add("vbid");
		validBookOrderByValues.add("ebookIsbn");
		validBookOrderByValues.add("textbookIsbn");
		validBookOrderByValues.add("title");
		validBookOrderByValues.add("author");
		validBookOrderByValues.add("description");
		validBookOrderByValues.add("recent");
		validBookOrderByValues.add("title");
		validBookOrderByValues.add("lastModifiedDate");
		validBookOrderByValues.add("edition");
		validBookOrderByValues.add("concurrencyLimit");
		validBookOrderByValues.add("fileType");
		
		validBridgesOrderByValues.add("name");
		validBridgesOrderByValues.add("contactName");
		validBridgesOrderByValues.add("email");
		validBridgesOrderByValues.add("code");
		validBridgesOrderByValues.add("language");
		
		validUsersOrderByValues.add("firstName");
		validUsersOrderByValues.add("lastName");
		validUsersOrderByValues.add("email");
	}
	
	public static final String RESPONSE_MESSAGE_ID_OK="messageid.ok";
	public static final String FIELD_VALIDATION_ERROR = "fielderror";
	public static final String BRIDGE_SESSIONID = "bridgesessionId";
	public static final String USER_ROLE_ADMIN="admin";
	public static final String USER_ROLE_SUPER_ADMIN="superAdmin";
	public static final String USER_ROLE_VIEW_ONLY="viewOnly";
	public static final String REST_PARAM_ID = "id";
	public static final String RESET_PASSWORD_TO = "emailTo";
	public static final String RESET_PASSWORD_USER_NAME = "fullName";
	public static final String RESET_PASSWORD_URL = "resetURL";
	public static final String TOKEN 	= "token";			
	public static final String UPLOAD_LOGO_INPUT_STREAM	= "logo.input.stream";		
	public static final String UPLOAD_LOGO_FILE_DETAILS	= "logo.input.file";
	public static final String FAVORITES   = "favorites";
	public static final String PAGINATION_PAGE  = "page";
	public static final String PAGINATION_LICENSED  = "licensed";
	public static final String PAGINATION_LIMIT = "limit";
	public static final String PAGINATION_OFFSET  = "offset";
	public static final String PAGINATION_ORDERBY  = "orderby";
	public static final String PAGINATION_ORDER  = "order";
	public static final String PAGINATION_SEARCH = "search";
	public static final String PAGINATION_REFRESH = "refresh";
	public static final String IS_GROUPED = "isgrouped";
	public static final String IS_UNGROUPED = "isungrouped";
	public static final String SORTING_ORDER_ASC = "ASC";
	public static final String SORTING_ORDER_DSC = "DESC";
	public static final String BRIDGE_ID = "bridgeId";
	public static final String BRIDGE_BOOK_VBID_ID = "vbid";
	public static final String KEY_BATCH_ID="keybatchid";
	public static final String BRIDGE_PURCHASE_ID="purchaseid";
	
	public static final String BRIDGE_CONFIG_LOGIN_WELCOME="loginWelcome";
	public static final String BRIDGE_CONFIG_PRIMARY_LOGO="primaryLogo";
	public static final String BRIDGE_CONFIG_PRIMARY_COLOR="primaryColor";
	public static final String BRIDGE_CONFIG_ETEXT_ENABLED="purchasing.eText.enabled";
	public static final String BRIDGE_CONFIG_ETEXT_PROMO_CODE="purchasing.eText.promoCode";
	public static final String BRIDGE_CONFIG_ETEXT_URL="purchasing.eText.url";
	public static final String BRIDGE_CONFIG_RENTAL_ENABLED="purchasing.rental.enabled";
	public static final String BRIDGE_CONFIG_RENTAL_PROMO_CODE="purchasing.rental.promoCode";
	public static final String BRIDGE_CONFIG_RENTAL_URL="purchasing.rental.url";
	public static final String BRIDGE_CONFIG_TEXT_BOOK_ENABLED="purchasing.textBook.enabled";
	public static final String BRIDGE_CONFIG_TEXT_BOOK_PROMO_CODE="purchasing.textBook.promoCode";
	public static final String BRIDGE_CONFIG_TEXT_BOOK_URL="purchasing.textBook.url";
	public static final String BRIDGE_CONFIG_RANDOM_KEY="randomKey";
	public static final String BRIDGE_CONFIG_SECONDARY_COLOR="secondaryColor";
	public static final String BRIDGE_CONFIG_SECONDARY_LOGO="secondaryLogo";
	public static final String BRIDGE_CONFIG_FORGOT_PASSWORD_URL="forgotPasswordURL";
	
	public static final String BRIDGE_DOMAIN_POST_FIX_SEPERATOR=",";
	public static final String BRIDGE_DOMAIN_NAME_PERIOD = ".";
	public static final Integer DEFAULT_GET_BOOK_PAGE_VALUE=1;
	public static final Integer DEFAULT_GET_BOOK_LIMIT_VALUE = 25;
	public static final String DEFAULT_GET_BOOK_ORDER_BY_VALUE = "title";
	public static final String DEFAULT_GET_BOOK_ORDER_VALUE = "ASC";
	
	public static final String DEFAULT_GET_BRIDGE_ORDER_BY_VALUE = "name";
	public static final String DEFAULT_GET_BRIDGE_ORDER_VALUE = "ASC";
	
	public static final String DEFAULT_GET_USER_ORDER_BY_VALUE = "firstName";
	
	public static final String GET_BRIDGE_BATCH_ID				 = "batchid";
	public static final String GET_BATCHES_FILE_EXTENSION = ".txt";
	
	public static final String KEYCODE               = "keycode";
	public static final String USER_ID				 = "userid";
	
	public static final String BOOK_LICENSE_CODE_PROMOTINAL="promotional";
	public static final String BOOK_LICENSE_CODE_API="code-api";
	public static final String BOOK_LICENSES_RENTAL_KEY_CHECK_REGREX="(([A-Z][0-9]+R[0-9])|([A-Z0-9]?-[0-9]+R[0-9])|([0-9]+R[0-9]))\\w+";
	public static final String BOOK_LICENSE_RENTAL_KEY = "R";
	public static final String STRING_PLACEHOLDER = "{0}";
	public static final String STRING_PLACEHOLDER_1 = "{1}";
	public static final String BOOK_LICENSE_LAUNCH = "/books/"+STRING_PLACEHOLDER+"/launch";
	public static final String BOOK_LICENSE_TRIAL = "/books/"+STRING_PLACEHOLDER+"/try";
	public static final String BOOK_LICENSE_RENTAL = "/books/"+STRING_PLACEHOLDER+"/rent";
	public static final String BOOK_LICENSE_FULL = "/books/"+STRING_PLACEHOLDER+"/full";
	public static final String BOOK_LICENSE_PRINT = "/books/"+STRING_PLACEHOLDER+"/print";
	public static final String BOOK_LICENSE_CONCURRENT = "/books/"+STRING_PLACEHOLDER+"/concurrent";
	public static final String BOOK_LICENSE_RETURN = "/books/"+STRING_PLACEHOLDER+"/return";
	public static final String BOOK_LICENSE_ENTITLEMENT="/books/"+STRING_PLACEHOLDER+"/"+STRING_PLACEHOLDER_1;
	public static final String BOOK_LICENSE_CONCURRENT_ENTITLEMENT="/books/"+STRING_PLACEHOLDER+"/concurrent/"+STRING_PLACEHOLDER_1;
	public static final String BOOK_LICENSE_STATE_ACTIVE="active";
	public static final String BOOK_LICENSE_STATE_EXPIRED="expired";
	public static final String BOOK_LICENSE_STATE_CREDIT="credit";
	public static final String BOOK_LICENSE_STATE_PURCHASE="purchase";
	
	public static final String BOOK_KEY_USED_TYPE_PURCHASE="purchase";
	public static final String BOOK_KEY_USED_TYPE_TRIAL="trial";
	public static final String BOOK_KEY_USED_TYPE_RENTAL="rental";
	public static final String BOOK_KEY_USED_TYPE_FULL="full";
	public static final String BOOK_KEY_USED_TYPE_PRINT="print";
	public static final String BOOK_KEY_USED_TYPE_CONCURRENT="concurrent";
	
	public static final String BOOK_URL = "/#/books/";
	
	public static final String PURCHASE_PRINT="printpurchase";
	
	public static final String PURCHASE_FULL="fullpurchase";
	
	public static final String PURCHASE_RENT="rentpurchase";
	
	
	public static final String BOOK_PURCHASE_PRINT = "/books/"+STRING_PLACEHOLDER+"/printpurchase";
	
	public static final String BOOK_PURCHASE_RENT = "/books/"+STRING_PLACEHOLDER+"/rentpurchase";
	
	public static final String BOOK_PURCHASE_FULL= "/books/"+STRING_PLACEHOLDER+"/fullpurchase";
	
	public static final String BOOK_PURCHASE= "/books/"+STRING_PLACEHOLDER+"/purchase/"+STRING_PLACEHOLDER_1;
	
	public static final String BOOKSHELF_URL_DEV = "https://bookshelf-dev.vitalsource.com/#/books/";
	
//	public static final String BOOKSHELF_URL_DEV = "https://bookshelf-dev.vitalsource.com/books/#/";
	
	public static final String BOOKSHELF_URL_STAGE = "https://bookshelf-staging.vitalsource.com/#/books/";
	
//	public static final String BOOKSHELF_URL_STAGE = "https://bookshelf-staging.vitalsource.com/books/#/";
	
	public static final String BOOKSHELF_URL_PROD = "https://bookshelf.vitalsource.com/#/books/";
	
//	public static final String BOOKSHELF_URL_PROD = "https://bookshelf.vitalsource.com/books/#/";
	
	public static final String BOOK_HAS_VALID_LICENSE = "valideLicense";
	public static final String BOOK_LICENSE_LAUNCH_WRAPPER = "launchLicense";
	
	public static final String BOOK_USER_ORDER_BY_RECENT = "recent"; 
	
	public static final String BOOLEAN_VALUE_TRUE_LOWERCASE = "true";
	public static final String BOOLEAN_VALUE_TRUE_UPPERCASE = "TRUE";
	
	public static final String BOOLEAN_VALUE_FALSE_LOWERCASE = "false";
	public static final String BOOLEAN_VALUE_FALSE_UPPERCASE = "FALSE";
	
	
	public static final String BRIDGE_CODE_ALLOWDED_PATTERN= "^[a-zA-Z0-9-]*$";
	
	public static final String BRIDGE_CONFIG_COMPANY_TYPE="companyType";
	
	public static final String BRIDGE_COMPANY_TYPE_PUBLISHER="PUBLISHER";
	
	public static final String SELECT_ALL_BOOKS="selectAllBooks";
	
	public static final String BATCH_ID				 = "batchid";
	public static final String REDIRECT = "redirect";
	public static final String DESTINATION = "destination";
	public static final String URL_GETREDIRECTS = "/v3/redirects.xml";
	public static final String APIKEY_HEADER = "X-VitalSource-API-Key";
	public static final String ACCESSSTOKEN_HEADER = "X-VitalSource-Access-Token";
	public static final String URL_CREATEUSER = "/v3/users.xml";
	public static final String URL_GETUSER = "/v3/users.xml/";
	public static final String URL_GETCREDENTIALS = "/v3/credentials.xml";
	public static final String URL_GETLICENSE = "/v3/licenses.xml";
	public static final String URL_CREATECODES = "/v3/codes.xml";
	public static final String URL_REDEMPTIONS = "/v3/redemptions.xml";
	public static final String URL_COMPANY = "/v3/company.xml";	
	public static final String XML_EXTN=".xml";
	public static final String ISBN = "isbn";
	public static final String KEY = "key";
	public static final String TYPE = "type";
	public static final String ONLINE = "online";
	public static final String CODES = "codes";
	public static final String NUMDAYS = "numdays";
	public static final String LICENSE_TYPE = "license-type";
	public static final String ONLINE_LICENSE_TYPE = "online-license-type";
	public static final String ONLINE_NUM_DAYS = "online-num-days";
	public static final String CODE_TYPE = "code-type";
	public static final String SKU = "sku";
	public static final String NUM_CODES = "num-codes";
	public static final String NUM_DAYS = "num-days";
	public static final String CODE = "code";
	public static final String REDEMPTION = "redemption";
	public static final String PARAM_KEY = "key";
	public static final String PARAM_VBID = "vbid";
	public static final String PARAM_TIMESTAMP = "timestamp";
	public static final String PARAM_LOGS = "logs";
	public static final String PRICE = "price";
	public static final String TAG = "tag";
	
	public static final boolean	COOKIE_SECURE = false;
	
	public static final String BRIDGE_USER_ROLE_TEACHER = "teacher";
	public static final String BRIDGE_USER_ROLE_STUDENT = "student";

	public static final String PISBN10 = "${PISBN10}";
	public static final String PISBN13 = "${PISBN13}";
	public static final String EISBN10 = "${EISBN10}";
	public static final String EISBN13 = "${EISBN13}";
	public static final String BRIDGE_URL_REGREX_PISBN10 = "(?i)\\$\\{PISBN10\\}";
	public static final String BRIDGE_URL_REGREX_PISBN13 = "(?i)\\$\\{PISBN13\\}";
	public static final String BRIDGE_URL_REGREX_EISBN10 = "(?i)\\$\\{EISBN10\\}";
	public static final String BRIDGE_URL_REGREX_EISBN13 = "(?i)\\$\\{EISBN13\\}";
	public static final String BRIDGE_URL_REGREX_VBID = "(?i)\\$\\{vbid\\}";
	
	public static final String CheckDigits = new String("0123456789X0");
	
	
	public static final String REPORT_PARAM_START_DATE = "startDate";
	public static final String REPORT_PARAM_END_DATE = "endDate";
	private static ApiKeys.API_MODE apiMode;
	public static final String NEW_BRIDGE_TO = "mailTo";
	public static final String NEW_BRIDGE_TO_NAME = "mailToName";
	public static final String NEW_BRIDGE_NAME = "name";
	public static final String NEW_BRIDGE_CONTACT_NAME = "contactName";
	public static final String NEW_BRIDGE_CONTACT_MAIL = "contactEmail";
	public static final String NEW_BRIDGE_CONTACT_PHONE = "contactPhone";
	public static final String NEW_BRIDGE_DOMAIN = "domain";
	public static final String NEW_BRIDGE_COMPANY_NAME = "companyName";
	public static final String NEW_BRIDGE_TYPE = "bridgeType";
	public static final String BRIDGE_CONFIG_PROTECTED_PASSWORD = "isPasswordProtected";
	public static final String BRIDGE_TYPE_SAMPLER="SAMPLER";
	public static final String DUMMY_EMAIL_SUFFIX="@vstbridge.com";
	public static final String ABSDATE="absdate";
	public static final String EXP_YEAR = "exp-year";
	public static final String EXP_MONTH = "exp-month";
	public static final String EXP_DAY = "exp-day";
	public static final String ONLINE_EXP_YEAR = "online-exp-year";
	public static final String ONLINE_EXP_MONTH = "online-exp-month";
	public static final String ONLINE_EXP_DAY ="online-exp-day";
	public static final String AUTO_GENERATED="AUTO-GENERATED";
	public static final String BRIDGE_TYPE_INSTITUTIONAL="INSTITUTIONAL";
	public static final String PUT_REQUEST_ID="PUT_REQUEST_ID";
	public static final String PUT_REQUEST_OBJECT="PUT_REQUEST_OBJECT";
	public static final String BRIDGE_CONFIG_ENTITLEMENT_TYPE="entitlementType";
	public static final String DEFAULT_BRIDGE_CREATE_RECEIVER="default-notification-receiver"; 
	public static final String BRIDGE_GROUP_ID="groupid";
	
	public static final String GROUP_ASSET_USERS="groupAssetUsers";
	
	public static final String SWAGGER_DOCUMENT_APPLICATION_BASE_URL="http://localhost:8080";
	
	
	public static final String BRIDGE_DEFAULT_GROUP_UNIVERSAL="Universal Assets";
	public static final String EXISTS_JSON="/exists.json";
	public static final String UPLOAD_INPUT_STREAM	= "input.stream";
	public static final String ROSTER_URL = "rosterURL";
	
	public static final String DELETE_ALL="deleteAll";
	public static final String STATUS_ACTIVE="active";
	public static final String STATUS_INACTIVE="inactive";
	public static final String STATUS_TOBEDELETED="tobedeleted";
	public static final String ROSTER_ID="rosterid";
	public static final String ROSTER_LOG_ID="rosterlogid";
	
	public static final String EMAIL_ACTIVATION_LINK="activationURL";
	
	public static final String EMAIL_BRIDGE_NAME="bridgeName";
	public static final String PUBLISHER_PRICE_TYPE="PUBLISHER";
	public static final String DIGITAL_PRICE_TYPE="DIGITAL";
	public static final String REDEEM_TYPE_COMP="comp";	
	public static final String REDEEM_TYPE_STANDARD="standard";
	public static final String REFUND_CODE_URL="/v4/codes/";
	public static final String NO_ACCESS="noaccess";
	public static final String PERPETUAL="perpetual";
	public static final String TENANT_ID="tenantid";
	public static final String COURSE_ID="courseid";
	public static final String BC_USER_ID="id";
	public static final String COURSES="bc/tenants/{"+TENANT_ID+"}/courses";
	public static final String USERS="bc/tenants/{"+TENANT_ID+"}/users";
	public static final String USER="bc/tenants/{"+TENANT_ID+"}/users/{"+BC_USER_ID+"}";
	public static final String TENANT="bc/tenants/{"+TENANT_ID+"}";
	public static final String CONTEXT_TOKEN="/contexts/{contexttoken}.json";	
	public static final String BC_USERS = "bc/tenants/{"+TENANT_ID+"}/courses/{"+COURSE_ID+"}/users";
	public static final String BC_COURSE = "bc/tenants/{"+TENANT_ID+"}/courses/{"+COURSE_ID+"}";
	public static final String REST_CONTEXT_TOKEN = "contexttoken";
	public static final String REST_BC_CONTEXT_TOKEN="context_token";
	public static final String PASSWORD_REGEX = "^(?=.*[`~!@#$%\\^&\\*-\\+_=\\[\\]\\{\\};':\"<,>\\.\\?/])(?=.*[a-z])(?=.*[A-Z]).{8,}$";
	public static final String OLD_SECURITY_QUESTION_REGEX="[1-5]";
	public static final String EMAIL_JIGSAW = "forgot[email]";
	public static final String DOMAIN_JIGSAW = "forgot[domain]";
	public static final String UPDATEURL_JIGSAW = "forgot[update_url]";
	public static final String USER_TOKEN_JIGSAW = "user[token]";
	public static final String USER_PASSWORD_JIGSAW = "user[password]";
	public static final String ANCILLARY_UPLOAD_TOKEN_URL = "/v1/api_tokens";
	public static final String PAGINATION_VO = "paginationVO";
	public static final String ANCILLARY_STATUS_URL = "/v1/ancillaries/{"+SKU+"}/upload_status";
	
	public static final String BRIDGE_COLLECTION = "/#/collection/";
	public static final String BRIDGE_BOOK_DETAILS = "/#/book-details/";
	public static final String DEEPLINK_LOCATION = "link_location";
	public static final String CONCURRENCY_ENTITLEMENT_NAME = "label.concCredit";
	
	public static final String KPI_BRIDGE_SITE_COUNT="bridgeSites";
	public static final String KPI_BRIDGE_USER_COUNT="bridgeUsers";
	public static final String KPI_BRIDGE_ADMIN_COUNT="bridgeAdmins";
	public static final String KPI_UNIQUE_ASSET_COUNT="uniqueAssets";
	public static final String KPI_ACTIVATION_COUNT="activations";
	public static final String KPI_DATA_EMAIL_RECIPIENTS_DEV = "vstbridgedev@gmail.com";
	public static final String KPI_DATA_EMAIL_RECIPIENTS = "andrew.romear@ingramcontent.com,clay.salit@ingramcontent.com,Gurit.Nagra@ingramcontent.com";
	public static final String ENTITLEMENT_ID="entitlementid";
	public static final String CONCURRENCY_ENTITLEMENT_ID="concurrencyentitlementid";
	public static final String RE_CAPTCHA_RESPONSE = "g-recaptcha-response";
	public static final String RE_CAPTCHA_VERIFY_URL = "https://www.google.com/recaptcha/api/siteverify?secret=%s&response=%s&remoteip=%s";
	public static final String ANCILLARY_DOWNLOAD_LINK =  "/v1/ancillaries/{"+SKU+"}?title={"+DEFAULT_GET_BOOK_ORDER_BY_VALUE+"}";
	public static final String DEFAULT_ANCILLARY_COVER = "https://storage.googleapis.com/bridge_dev_storage/default_ancillary_cover.jpeg";
	public static final String ANCILLARY_DOWNLOAD = "/books/"+STRING_PLACEHOLDER+"/download";
	public static final String USER_ERROR_PAGE = "/#/error";
	public static final String USER_READER_PAGE = "/#/reader/";
	public static final String CATEGORY_FILTER = "category";
	public static final String AUTHORIZATION_HEADER = "Authorization";
	
	
	public static ApiKeys.API_MODE getApiMode() {
		if(null == apiMode) {
			apiMode= ApiKeys.API_MODE.valueOf(TomcatUtils.getParam("connect-api-mode"));
		}
		return apiMode;
	}
	
	public static String createBookUrl(String vbid,API_MODE mode,String bookshelfUrl) //bookId, String sectionId)
	{
		StringBuilder sb = new StringBuilder();
		if(StringUtils.isNotBlank(bookshelfUrl)){
			bookshelfUrl= bookshelfUrl.endsWith(BOOK_URL) ? bookshelfUrl : bookshelfUrl.concat(BOOK_URL);
			sb.append(bookshelfUrl).append(vbid);
		}
		else{
			switch(mode){
				case dev:
					sb.append(BOOKSHELF_URL_DEV).append(vbid);
					break;
				case stage:
					sb.append(BOOKSHELF_URL_STAGE).append(vbid);
					break;
				case prod:
					sb.append(BOOKSHELF_URL_PROD).append(vbid);
					break;
				default:
					throw new BridgeException(ApplicationCode.INVALID_BRIDGE_ACTION);
			}
		}
	
		return sb.toString();
	}
	
	public static String getBookCacheRefreshPassword(){
		return TomcatUtils.getParam("bridge-book-refresh-cache-password");
	}
	
	public interface AWS {
		public static final String accessKey  = "AKIAIPW766HZHNTUZ3CQ";
		public static final String secretKey  = "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";
		public static final String bucketName = "vst-stack-dev"; //"vbsportaldata";
	}
	
	public static enum CodeType{TRIAL, RENTAL, FULL, CONCURRENCY};
	
	public static enum FileStatus{LOADED,COMPLETED,ERROR,WARNING};
	
	public static enum JobStatus{STARTED,COMPLETED,ERROR,COMPLETE_WITH_ERROR};
	
	public static enum JobType{USERCOURSEJOB};
	
	public static enum JobRecordType{USERS,COURSES,COURSEUSERS};
	
	

}
