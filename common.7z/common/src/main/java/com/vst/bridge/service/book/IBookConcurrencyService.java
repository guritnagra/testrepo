package com.vst.bridge.service.book;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import org.jdom2.JDOMException;

import com.vst.bridge.VstException;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.rest.input.vo.BookConcurrencyLimitVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.user.ConcurrentBookLicenseInfoVO;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;

public interface IBookConcurrencyService {
	RestResponse updateConcurrencyForBooks(SessionStatusVO sessionStatusVO, Integer bridgeId,
			BookConcurrencyLimitVO bookConcurrencyLimitVO, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException;

	RestResponse concurrentBook(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException;

	ConcurrentBookLicenseInfoVO checkConcurrentFunctinalityForVbid(String vbid, BridgeUser user, Bridge bridge);

	Integer getconcurrencyLimitForVbid(String vbid, Bridge bridge);

	RestResponse returnBook(SessionStatusVO sessionStatusVO, String vbid, String code, HttpServletRequest httpRequest,
			UriInfo uriInfo) throws BridgeException, VstException, ConnectApiException, ParseException;

	RestResponse redeemConcurrencyVbid(SessionStatusVO sessionStatusVO, String vbid, Integer entitlementId, String code)
			throws BridgeException, VstException, ConnectApiException, IOException, JDOMException, ParseException;

}
