package com.vst.bridge.rest.response.vo.report;

public class ReportCountDetails {
	private Integer total;
	private Integer rental;
	private Integer full;
	private Integer print;
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}

	public Integer getRental() {
		return rental;
	}
	public void setRental(Integer rental) {
		this.rental = rental;
	}
	public Integer getFull() {
		return full;
	}
	public void setFull(Integer full) {
		this.full = full;
	}
	public Integer getPrint() {
		return print;
	}
	public void setPrint(Integer print) {
		this.print = print;
	}
}
