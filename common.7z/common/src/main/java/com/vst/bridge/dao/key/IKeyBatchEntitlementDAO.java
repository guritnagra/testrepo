package com.vst.bridge.dao.key;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.keys.KeyBatchEntitlement;
import com.vst.bridge.util.exception.BridgeException;

public interface IKeyBatchEntitlementDAO extends IGenericDAO<KeyBatchEntitlement, Integer>{

	
	List<KeyBatchEntitlement> getAllEntitlementsForKeyBatch(Integer keyBatch) throws BridgeException;
	List<KeyBatchEntitlement> getEntitlementsByKeyBatches(Integer keyBatch) throws BridgeException;
}
