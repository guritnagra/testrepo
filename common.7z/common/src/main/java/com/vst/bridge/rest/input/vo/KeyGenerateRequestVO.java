package com.vst.bridge.rest.input.vo;

import java.util.List;

import com.vst.bridge.annotation.custom.InputRequired;

public class KeyGenerateRequestVO {

	@InputRequired(required=false)
	private List<EntitlementVO> entitlements;
	@InputRequired(required=false)
	private List<ConcurrencyEntitlementVO> concurrencyEntitlements;
	@InputRequired(required=false)
	private String role;
	@InputRequired(required=false)
	private String notes;
	@InputRequired(required=false)
	private Long expires;
	@InputRequired(required=false)
	private Integer numUsersPerKey;
	@InputRequired(required=false)
	private Integer count;
	
	public List<EntitlementVO> getEntitlements() {
		return entitlements;
	}
	public void setEntitlements(List<EntitlementVO> entitlements) {
		this.entitlements = entitlements;
	}
	
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public Integer getNumUsersPerKey() {
		return numUsersPerKey;
	}
	public void setNumUsersPerKey(Integer numUsersPerKey) {
		this.numUsersPerKey = numUsersPerKey;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Long getExpires() {
		return expires;
	}
	public void setExpires(Long expires) {
		this.expires = expires;
	}
	public List<ConcurrencyEntitlementVO> getConcurrencyEntitlements() {
		return concurrencyEntitlements;
	}
	public void setConcurrencyEntitlements(List<ConcurrencyEntitlementVO> concurrencyEntitlements) {
		this.concurrencyEntitlements = concurrencyEntitlements;
	}
	
	
	
}
