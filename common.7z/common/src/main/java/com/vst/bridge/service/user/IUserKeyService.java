package com.vst.bridge.service.user;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.user.CreateKeysVO;
import com.vst.bridge.util.exception.BridgeException;

public interface IUserKeyService {
	RestResponse postKeysForUser(SessionStatusVO sessionStatusVO, CreateKeysVO createKeys, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo)throws BridgeException, ParseException, IOException;
	RestResponse getKeysForUser(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo)throws BridgeException, ParseException, IOException;
	
}
