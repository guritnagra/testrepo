package com.vst.bridge.dao.user.key;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.user.BridgeUserKey;
import com.vst.bridge.entity.keys.Keys;
import com.vst.bridge.rest.response.vo.report.ReportKeyUserVO;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeUserKeyDAO")
public class BridgeUserKeyDAOImpl extends GenericDAO<BridgeUserKey,Integer> implements IBridgeUserKeyDAO{

	public BridgeUserKeyDAOImpl() {
		super(BridgeUserKey.class);
	}

	@Override
	public List<Keys> getListOfKeysForBridgeUser(Integer userId) throws BridgeException {
		Criteria criteria = getCriteria(BridgeUserKey.class);
		criteria.createAlias("key", "keyAlias");
		criteria.add(Restrictions.eq("user.id", userId));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.gt("keyAlias.expireDate", new Date()));
		List<BridgeUserKey> result = executeCriteira(criteria);
		List<Keys> keys = null;
		if(null != result && result.size() > 0 ){
			keys = new ArrayList<Keys>();
			for(BridgeUserKey userKey : result){
				keys.add(userKey.getKey());
			}
		}
		return keys;
	}

	@Override
	public BridgeUserKey getUserForCode(Integer userId, Integer keyId,Boolean excludeDeleted) throws BridgeException {
		Criteria criteria = getCriteria();
		
		if(!excludeDeleted){
			criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		}
		
		criteria.add(Restrictions.eq("user.id", userId));
		criteria.add(Restrictions.eq("key.id", keyId));
		List<BridgeUserKey> result = executeCriteira(criteria);
		return null !=result &&  result.size() > 0 ? result.get(0) : null;
	}

	@Override
	public List<BridgeUserKey> getListOfKeysAssigedForUser(Integer userId) throws BridgeException {
		Criteria criteria = getCriteria(BridgeUserKey.class);
		criteria.createAlias("key", "keyAlias");
		criteria.add(Restrictions.eq("user.id", userId));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		//criteria.add(Restrictions.gt("keyAlias.expireDate", new Date()));
		criteria.add(Restrictions.or(Restrictions.isNull("keyAlias.expireDate"),Restrictions.gt("keyAlias.expireDate", new Date())));
		//TODO Add condition for expire days & expire months 
		criteria.addOrder(Order.asc("keyAlias.expireDate"));
		List<BridgeUserKey> result = executeCriteira(criteria);
		return result;
	}

	@Override
	public BridgeUserKey getUserKeyForKeyId(Integer keyId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.eq("key.id", keyId));
		List<BridgeUserKey> result = executeCriteira(criteria);
		return null !=result &&  result.size() > 0 ? result.get(0) : null;
	}	
	
	@Override
	public Integer getKeyCodeUsedCount(Integer keyId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.eq("key.id", keyId));
		List<BridgeUserKey> result = executeCriteira(criteria);
		return null !=result &&  result.size() > 0 ? result.size() : 0;
	}

	@Override
	public List<BridgeUserKey> getListOfUsersAssigedForKey(Integer keyId) throws BridgeException {
		Criteria criteria = getCriteria(BridgeUserKey.class);
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.eq("key.id", keyId));
		return executeCriteira(criteria);
	}

	@Override
	public List<ReportKeyUserVO> getKeysAssigedToUsers(List<Integer> userIds, Date startDate, Date endDate) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.in("user.id", userIds));
		if(null != startDate && endDate != null){
			criteria.add(Restrictions.between("activationDate", startDate, endDate));
		}
		criteria.setProjection(Projections.projectionList()
				.add(Projections.property("key.id").as("keyId"))
				.add(Projections.property("user.id").as("userId")))
				.setResultTransformer(new AliasToBeanResultTransformer(ReportKeyUserVO.class));;
		return executeCriteira(criteria);
	}

	@Override
	public List<Integer> getUserkeyAssignedIds(Integer userId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.eq("user.id", userId));
		criteria.setProjection(Projections.property("id"));
		return executeCriteira(criteria);
	}	
}
