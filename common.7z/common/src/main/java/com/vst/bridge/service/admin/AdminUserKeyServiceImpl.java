package com.vst.bridge.service.admin;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.JsonUtils;
import com.vst.bridge.VstUtils;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.type.ICodeTypesDAO;
import com.vst.bridge.dao.key.IKeyBatchDAO;
import com.vst.bridge.dao.key.IKeyBatchEntitlementDAO;
import com.vst.bridge.dao.key.IKeyDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.dao.user.key.IBridgeUserKeyDAO;
import com.vst.bridge.dao.user.role.IBridgeUserRoleDAO;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.BridgeUserKey;
import com.vst.bridge.entity.keys.KeyBatch;
import com.vst.bridge.entity.keys.KeyBatchEntitlement;
import com.vst.bridge.entity.keys.Keys;
import com.vst.bridge.rest.input.vo.ConcurrencyEntitlementVO;
import com.vst.bridge.rest.input.vo.EntitlementVO;
import com.vst.bridge.rest.input.vo.KeyBatchesVO;
import com.vst.bridge.rest.input.vo.KeyGenerateRequestVO;
import com.vst.bridge.rest.response.vo.Metadata;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.bridge.KeyBatchEntitlementResponseVO;
import com.vst.bridge.rest.response.vo.bridge.KeyBatchResponseVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.date.DateUtility;
import com.vst.bridge.util.error.ErrorHandlerUtil;
import com.vst.bridge.util.error.ResponseError;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.bridge.util.message.TemplateBasedMessageGenerator;

@Service("adminUserKeyService")
public class AdminUserKeyServiceImpl implements IAdminUserKeyService {
	@Autowired
	private IAdminUserDAO adminUserDAO;

	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private ErrorHandlerUtil errorHandlerUtility;

	@Autowired
	private IBridgeDAO bridgeDAO;

	@Autowired
	private IBridgeUserRoleDAO bridgeUserRoleDAO;

	@Autowired
	private IKeyBatchDAO keyBatchDAO;

	@Autowired
	private IKeyDAO keyDAO;

	@Autowired
	private TemplateBasedMessageGenerator messageGenerator;

	@Autowired
	private IBridgeUserKeyDAO bridgeUserKeyDAO;

	@Autowired
	private IBridgeUserDAO bridgeUserDAO;
	
	@Autowired 
	private ICodeTypesDAO codeTypeDAO;

	@Autowired 
	private IKeyBatchEntitlementDAO keyBatchEntitlementDAO;
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse createOrUpdateKeyBatchesForBridgeId(SessionStatusVO sessionStatusVO, KeyBatchesVO keyBatchesVO,
			Integer bridgeId, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		// final String inputJson = JsonUtils.requestToString(httpRequest);
		if (null != keyBatchesVO) {
			// KeyBatchesVO keyBatchesVO= (new Genson()).deserialize(inputJson,
			// KeyBatchesVO.class);
			// ResponseError responseError = bridgeId==null ?
			// errorHandlerUtility.validateKeyBatchesVOParameters(inputJson) :
			// null;
			ResponseError responseError = errorHandlerUtility
					.validateKeyBatchesVOParameters(JsonUtils.getJsonString(keyBatchesVO));
			if (responseError == null) {
				Bridge bridge = bridgeDAO.get(bridgeId);
				if (bridge == null || bridge.getDeleted()) {
					throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
				}
				Date date = new Date(keyBatchesVO.getExpires());
				KeyBatch keyBatch = new KeyBatch();
				keyBatch.setBridge(bridgeDAO.load(bridgeId));
				keyBatch.setCreatedBy(adminUserDAO.load(sessionStatusVO.getAdminId()));
				keyBatch.setNote(keyBatchesVO.getNotes());
				String role = keyBatchesVO.getRole();
				keyBatch.setRole(bridgeUserRoleDAO.getForName(role));
				keyBatch.setExpireDate(date);
				keyBatch.setNoOfUsers(keyBatchesVO.getNumUsersPerKey());
				Integer fullCredits = keyBatchesVO.getFullCredits();
				if (StringUtils.equals(bridge.getBridgeType().getType(),
						ApplicationConstants.BRIDGE_COMPANY_TYPE_PUBLISHER)) {
					if (role != null && StringUtils.equals(role, ApplicationConstants.BRIDGE_USER_ROLE_TEACHER)) {
						if (null != fullCredits && fullCredits > 0) {
							throw new BridgeException(ApplicationCode.INVALID_FULL_CREDITS_VALUE);
						} else {
							fullCredits = -1;
						}
					} else {
						if (null != fullCredits && fullCredits < 0) {
							// throw new
							// BridgeExcepation(ApplicationCode.INVALID_FULL_CREDITS_VALUE);
						} else if (fullCredits == null) {
							fullCredits = 0;
						}
					}
				} else {
					if (role != null && StringUtils.equals(role, ApplicationConstants.BRIDGE_USER_ROLE_TEACHER)) {
						if (fullCredits == null) {
							fullCredits = -1;
						}
					} else {
						if (fullCredits == null) {
							fullCredits = 0;
						}
					}
				}
				keyBatch.setFullCredits(fullCredits);

				Integer trialCredits = keyBatchesVO.getTrialCredits();
				if (null != trialCredits) {
					keyBatch.setTrialCredits(keyBatchesVO.getTrialCredits());
				}

				keyBatch.setCreatedDate(new Date());

				Integer rentalCredits = keyBatchesVO.getRentalCredits();
				if (null != rentalCredits) {
					keyBatch.setRentalCredits(rentalCredits);
				}
				Integer rentalDays = keyBatchesVO.getRentalDays();
				if (null != rentalDays && rentalDays > 0) {
					keyBatch.setRentalDays(rentalDays);
				}
				Integer concurrencyCredits = keyBatchesVO.getConcurrencyCredits();
				if (bridge.getConcurrencyEnabled() && null != concurrencyCredits) {
					keyBatch.setConcurrencyCredits(concurrencyCredits);
				}
				List<String> codes = VstUtils.getKeyCodeValues(keyBatchesVO.getCount());
				if (null != codes && codes.size() > 0) {
					List<Keys> keys = new ArrayList<Keys>();
					// Integer daysDiff = DateUtility.expireDaysRemaing(date);
					// Integer monthsDiff =
					// DateUtility.expireMonthsRemaing(date);
					for (String code : codes) {
						Keys key = new Keys();
						if (null != rentalCredits) {
							key.setRentalCredits(rentalCredits);
						}
						if (bridge.getConcurrencyEnabled() && null != concurrencyCredits) {
							key.setConcurrencyCredits(concurrencyCredits);
						}
						if (null != rentalDays && rentalDays > 0) {
							key.setRentalDays(rentalDays);
						}
						key.setKeyBatch(keyBatch);
						key.setKeyCode(code);
						key.setExpireDate(date);
						key.setNoOfUsers(keyBatchesVO.getNumUsersPerKey());
						key.setFullCredits(fullCredits);
						if (null != trialCredits) {
							key.setTrialCredits(keyBatchesVO.getTrialCredits());
						}
						key.setExpireInDays(keyBatchesVO.getExpireInDays());
						key.setExpireInMonth(keyBatchesVO.getExpireInMonths());
						keys.add(key);
					}
					keyBatch.setKeys(keys);
				}
				keyBatchDAO.create(keyBatch);
				KeyBatchResponseVO data = populateKeyBatchResponseVOFromKetBatch(keyBatch);
				response.setData(data);
			} else {
				response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
				response.setMessage(localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_INPUT.getCodeId()));
				response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
				response.setError(responseError);
			}
		}
		return response;
	}

	private KeyBatchResponseVO populateKeyBatchResponseVOFromKetBatch(KeyBatch keyBatch) {
		KeyBatchResponseVO response = new KeyBatchResponseVO();
		Bridge bridge = keyBatch.getBridge();
		response.setId(keyBatch.getId());
		response.setContactEmail(bridge.getEmail());
		AdminUser adminUser = keyBatch.getCreatedBy();
		response.setContactName(
				com.vst.bridge.StringUtils.getFullName(adminUser.getFirstName(), adminUser.getLastName()));
		// response.setContactName(bridge.getContactName());
		response.setContactPhone(bridge.getContactNo());
		response.setCount(keyBatch.getKeys().size());
		response.setCreated(keyBatch.getCreatedDate().getTime());
		response.setCreatedDate(keyBatch.getCreatedDate());
		response.setExpires(keyBatch.getExpireDate().getTime());
		response.setExpiresDate(keyBatch.getExpireDate());
		response.setNotes(keyBatch.getNote());
		response.setNumUsersPerKey(keyBatch.getNoOfUsers());
		response.setFullCredits(keyBatch.getFullCredits());
		response.setRole(keyBatch.getRole().getName());
		response.setTrialCredits(keyBatch.getTrialCredits());
		response.setRentalCredits(keyBatch.getRentalCredits());
		response.setRentalDays(keyBatch.getRentalDays());
		response.setConcurrencyCredits(keyBatch.getConcurrencyCredits());
		return response;
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse deleteUserKeyCode(SessionStatusVO sessionStatusVO, Object param, HttpServletRequest httpRequest,
			UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if (param instanceof HashMap) {
			HashMap<String, Object> params = (HashMap<String, Object>) param;

			String keyCode = (String) params.get(ApplicationConstants.KEYCODE);
			Keys key = keyDAO.getKeyForCode(keyCode, null);
			if (null == key) {
				throw new BridgeException(ApplicationCode.KEY_CODE_NOT_FOUND);
			}
			Integer userId = (Integer) params.get(ApplicationConstants.USER_ID);
			BridgeUser user = bridgeUserDAO.get(userId);
			if (null == user) {
				throw new BridgeException(ApplicationCode.BRIDGE_USER_NOT_FOUND);
			}
			BridgeUserKey userKey = bridgeUserKeyDAO.getUserForCode(userId, key.getId(), Boolean.FALSE);
			if (userKey == null) {
				throw new BridgeException(ApplicationCode.USE_KEY_ASSOCIATION_NOT_FOUND);
			}
			userKey.setDeleted(Boolean.TRUE);
			bridgeUserKeyDAO.update(userKey);
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getKeyBatchesForBridgeId(SessionStatusVO sessionStatusVO, Integer id,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {

		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Bridge bridge = bridgeDAO.get(id);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		List<KeyBatch> keyBatches = keyBatchDAO.getAllKeyBatches(id);
		if (null != keyBatches && keyBatches.size() > 0) {
			List<KeyBatchResponseVO> data = new ArrayList<KeyBatchResponseVO>();
			for (KeyBatch keyBatch : keyBatches) {
				data.add(populateKeyBatchResponseVOFromKetBatch(keyBatch));
			}
			response.setData(data);
			Metadata metadata = new Metadata();
			metadata.setCount(data.size());
			response.setMetadata(metadata);
		}
		return response;
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public void getKeyBatchFile(SessionStatusVO sessionStatusVO, Object params, HttpServletRequest httpRequest,
			HttpServletResponse httpServletResponse, UriInfo uriInfo) {

		String msg = null;
		if (params instanceof HashMap) {
			Map<String, Integer> param = (Map<String, Integer>) params;
			Integer bridgeId = param.get(ApplicationConstants.BRIDGE_ID);
			Integer batchId = param.get(ApplicationConstants.GET_BRIDGE_BATCH_ID);
			Bridge bridge = bridgeDAO.get(bridgeId);
			if (bridge == null || bridge.getDeleted()) {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			KeyBatch keyBatch = keyBatchDAO.get(batchId);
			if (keyBatch == null) {
				throw new BridgeException(ApplicationCode.KEY_BATCH_NOT_FOUND);
			}
			
			Map<String, Object> batchValues = getbatchValuesFromKeyBatch(keyBatch, sessionStatusVO.getAdminId(),bridge);
			String fileName = (String) batchValues.get("fileName");
			String batchFile = (String)batchValues.get("file");
			httpServletResponse.setHeader("Content-Disposition", "attachment; filename=" + fileName);
			httpServletResponse.setContentType("application/plain");
			httpServletResponse.setContentLength(batchFile.length());
			try {
				PrintWriter writer = httpServletResponse.getWriter();
				writer.write(batchFile);
				httpServletResponse.flushBuffer();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}

	private Map<String, Object> getbatchValuesFromKeyBatch(KeyBatch keyBatch, Integer adminId, Bridge bridge) {
		Map<String,Object> batchValueFile = new HashMap<String,Object>();
		StringBuffer batchValueString = new StringBuffer();
		batchValueString.append("User Type : "+keyBatch.getRole().getName()+"\n\n");
		List<KeyBatchEntitlement> keyBatchEntitlementList = keyBatchEntitlementDAO.getAllEntitlementsForKeyBatch(keyBatch.getId());
		if(keyBatchEntitlementList!=null){
			for(KeyBatchEntitlement keyBatchEntitlement: keyBatchEntitlementList){
				batchValueString.append(keyBatchEntitlement.getEntName()+" : "+keyBatchEntitlement.getEntCredits()+"\n\n");
			}
		}
		batchValueString.append("Concurrency Credits : "+keyBatch.getConcurrencyCredits()+"\n\n");
		batchValueString.append("Notes : "+keyBatch.getNote()+"\n\n");
		batchValueString.append("Expires : "+DateUtility.getBridgeFormatedDate(keyBatch.getExpireDate())+"\n\n");
		AdminUser adminUser = adminUserDAO.get(adminId);
		batchValueString.append("Requested By : "+com.vst.bridge.StringUtils.getFullName(adminUser.getFirstName(), adminUser.getLastName())+"\n\n");
		List<Keys> keys = keyBatch.getKeys();
		if (null != keys && keys.size() > 0) {
			batchValueString.append("# of Keys : "+keys.size()+"\n\n");
		}
		batchValueString.append("User Per Key : "+keyBatch.getNoOfUsers()+"\n\n");
		
		batchValueString.append("Key Codes: "+"\n\n");
		batchValueString.append(getKeyCodesList(keys));
		batchValueString.append("\r\n");
		String fileName = String
				.format("%d_%s_keys_%s", keys.size(), keyBatch.getRole().getName(),
						com.vst.bridge.StringUtils.MMddyyyy.format(new Date()))
				.replaceAll("[^a-zA-Z0-9]+", "_") + ApplicationConstants.GET_BATCHES_FILE_EXTENSION;
		
		batchValueFile.put("fileName",fileName);
		batchValueFile.put("file", batchValueString.toString());
		return batchValueFile;
	}

	private String getKeyCodesList(List<Keys> keys) {
		StringBuilder builder = new StringBuilder();
		if (null != keys && keys.size() > 0) {
			for (Keys key : keys) {
				builder.append(" " + key.getKeyCode() + " \r\n");
			}
		}
		return builder.toString();
	}
	

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse generateKeysForBridgeId(SessionStatusVO sessionStatusVO,
			KeyGenerateRequestVO keyGenerateRequestVO, Integer bridgeId, HttpServletRequest httpRequest,
			UriInfo uriInfo) throws BridgeException, ParseException, IOException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if(null!=keyGenerateRequestVO){
			ResponseError responseError = errorHandlerUtility
					.validateKeyGenerateRequestVOParameters(JsonUtils.getJsonString(keyGenerateRequestVO));
			if(responseError == null){
				Bridge bridge = bridgeDAO.get(bridgeId);
				if (bridge == null || bridge.getDeleted()) {
					throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
				}
				Date date = new Date(keyGenerateRequestVO.getExpires());
				KeyBatch keyBatch = new KeyBatch();
				keyBatch.setCreatedDate(new Date());
				keyBatch.setCount(keyGenerateRequestVO.getCount());
				keyBatch.setBridge(bridgeDAO.load(bridgeId));
				keyBatch.setCreatedBy(adminUserDAO.load(sessionStatusVO.getAdminId()));
				keyBatch.setNote(keyGenerateRequestVO.getNotes());
				String role = keyGenerateRequestVO.getRole();
				keyBatch.setRole(bridgeUserRoleDAO.getForName(role));
				keyBatch.setExpireDate(date);
				keyBatch.setNoOfUsers(keyGenerateRequestVO.getNumUsersPerKey());
				if(bridge.getConcurrencyEnabled()!=null && bridge.getConcurrencyEnabled()){
					List<ConcurrencyEntitlementVO> concurrencyEntitlementVOList=keyGenerateRequestVO.getConcurrencyEntitlements();
					if(concurrencyEntitlementVOList.size()>0){
						ConcurrencyEntitlementVO concEntitlementVO =concurrencyEntitlementVOList.get(0);
						keyBatch.setConcurrencyCredits(concEntitlementVO.getCredit());
						keyBatch.setConcurrencyDays(concEntitlementVO.getOnlineDays());
						keyBatch.setConcurrencyEntitlementName(concEntitlementVO.getEntitlementName());
						Boolean isReturn =concEntitlementVO.getIsReturn()!=null ?concEntitlementVO.getIsReturn():Boolean.FALSE;
						keyBatch.setIsReturn(isReturn);
						keyBatch.setConcCodeType(codeTypeDAO.getCodeForType(concEntitlementVO.getEntitlementType()));
						if(concEntitlementVO.getOnlineExpires()!=null)
							keyBatch.setConcurrencyExpires(new Date(concEntitlementVO.getOnlineExpires()));
						if(concEntitlementVO.getIsCopyfromOnline()){
							keyBatch.setOfflineConcurrencyDays(concEntitlementVO.getOnlineDays());
							if(concEntitlementVO.getOnlineExpires()!=null)
								keyBatch.setOfflineConcurrencyExpires(new Date(concEntitlementVO.getOnlineExpires()));
						}else{
							keyBatch.setOfflineConcurrencyDays(concEntitlementVO.getOfflineDays());
						if(concEntitlementVO.getOfflineExpires()!=null)
							keyBatch.setOfflineConcurrencyExpires(new Date(concEntitlementVO.getOfflineExpires()));
						}
					}
				}
				List<String> codes = VstUtils.getKeyCodeValues(keyGenerateRequestVO.getCount());
				if (null != codes && codes.size() > 0) {
					List<Keys> keys = new ArrayList<Keys>();
					for (String code : codes) {
						Keys key = new Keys();
						key.setKeyBatch(keyBatch);
						key.setKeyCode(code);
						key.setExpireDate(date);
						key.setNoOfUsers(keyGenerateRequestVO.getNumUsersPerKey());
						keys.add(key);
					}
					keyBatch.setKeys(keys);
				}
				
				
				if(null!=keyBatch){
					List<EntitlementVO> entitlementVOList = keyGenerateRequestVO.getEntitlements();
					if(entitlementVOList!=null && !entitlementVOList.isEmpty()){
						List<KeyBatchEntitlement> entitlements = new ArrayList<KeyBatchEntitlement>();
						for(EntitlementVO entitlementVO:entitlementVOList){
							KeyBatchEntitlement keyBatchEntitlement = new KeyBatchEntitlement();
							keyBatchEntitlement.setKeyBatch(keyBatch);
							keyBatchEntitlement.setEntName(entitlementVO.getEntitlementName());
							keyBatchEntitlement.setEntType(codeTypeDAO.getCodeForType(entitlementVO.getEntitlementType()));
							keyBatchEntitlement.setEntCredits(entitlementVO.getCredit());
							keyBatchEntitlement.setEntIsCopyFromOnline(entitlementVO.getIsCopyfromOnline());
							keyBatchEntitlement.setEntOnlineDays(entitlementVO.getOnlineDays());
							if(entitlementVO.getOnlineExpires()!=null)
								keyBatchEntitlement.setEntOnlineExpires(new Date(entitlementVO.getOnlineExpires()));
							if(entitlementVO.getIsCopyfromOnline()){
								keyBatchEntitlement.setEntOfflineDays(entitlementVO.getOnlineDays());
								if(entitlementVO.getOnlineExpires()!=null)
									keyBatchEntitlement.setEntOfflineExpires(new Date(entitlementVO.getOnlineExpires()));
							}else{
							keyBatchEntitlement.setEntOfflineDays(entitlementVO.getOfflineDays());
							if(entitlementVO.getOfflineExpires()!=null)
								keyBatchEntitlement.setEntOfflineExpires(new Date(entitlementVO.getOfflineExpires()));
							}
							keyBatchEntitlement.setEntIsReusableCredit(entitlementVO.getIsReusableCredit());
							entitlements.add(keyBatchEntitlement);	
						}
						keyBatch.setEntitlements(entitlements);
					}
				}
				keyBatchDAO.create(keyBatch);
				KeyBatchEntitlementResponseVO data = populatekeyBatchEntitlementResponseVOFromKeyBatch(bridge,keyBatch);
				response.setData(data);
				
			}else {
				response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
				response.setMessage(localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_INPUT.getCodeId()));
				response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
				response.setError(responseError);
			}
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse updateGeneratedKeysForBridgeId(SessionStatusVO sessionStatusVO,
			KeyGenerateRequestVO keyGenerateRequestVO, Object param, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Integer bridgeId=null;
		Integer keyBatchId=null;
		if (param instanceof HashMap) {
			HashMap<String, Object> params = (HashMap<String, Object>) param;
			bridgeId =(Integer) params.get(ApplicationConstants.BRIDGE_ID);
			keyBatchId = (Integer)params.get(ApplicationConstants.KEY_BATCH_ID);
		}
		
		Bridge bridge = bridgeDAO.get(bridgeId);
		if (bridge == null || bridge.getDeleted()) {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		
		KeyBatch keyBatch = keyBatchDAO.get(keyBatchId);
		if (keyBatch == null) {
			throw new BridgeException(ApplicationCode.KEY_BATCH_NOT_FOUND);
		}
		
		if(null!=keyGenerateRequestVO){
			ResponseError responseError = errorHandlerUtility
					.validateKeyGenerateRequestVOParameters(JsonUtils.getJsonString(keyGenerateRequestVO));
			if(responseError == null){
				if(null!=keyBatch){
					List<ConcurrencyEntitlementVO> concEntitlementVOList = keyGenerateRequestVO.getConcurrencyEntitlements();
					if(!concEntitlementVOList.isEmpty()){
						for(ConcurrencyEntitlementVO concEntitlementVO: concEntitlementVOList){
							keyBatch.setConcCodeType(codeTypeDAO.getCodeForType(concEntitlementVO.getEntitlementType()));
							keyBatch.setConcurrencyCredits(concEntitlementVO.getCredit());
							keyBatch.setConcurrencyDays(concEntitlementVO.getOnlineDays());
							keyBatch.setConcurrencyExpires(concEntitlementVO.getOnlineExpires()!=null?new Date(concEntitlementVO.getOnlineExpires()):null);
							if(concEntitlementVO.getIsCopyfromOnline()){
								keyBatch.setOfflineConcurrencyDays(concEntitlementVO.getOnlineDays());
								keyBatch.setOfflineConcurrencyExpires(concEntitlementVO.getOnlineExpires()!=null?new Date(concEntitlementVO.getOnlineExpires()):null);
							}else{
								keyBatch.setOfflineConcurrencyDays(concEntitlementVO.getOfflineDays());
								keyBatch.setOfflineConcurrencyExpires(concEntitlementVO.getOfflineExpires()!=null?new Date(concEntitlementVO.getOfflineExpires()):null);
							}
							keyBatch.setConcurrencyEntitlementName(concEntitlementVO.getEntitlementName());
							keyBatch.setIsReturn(concEntitlementVO.getIsReturn());
						}
					}
					List<EntitlementVO> requestEntitlementList = keyGenerateRequestVO.getEntitlements();
					
						List<KeyBatchEntitlement> updatedKeyBatchEntitlementList = new ArrayList<KeyBatchEntitlement>();
						List<KeyBatchEntitlement> dBkeyBatchEntitlementList = keyBatchEntitlementDAO.getAllEntitlementsForKeyBatch(keyBatch.getId());
						if(!requestEntitlementList.isEmpty()&& requestEntitlementList!=null){
						Iterator<EntitlementVO> requestEntitlementIterator=requestEntitlementList.iterator();
						while(requestEntitlementIterator.hasNext()){
							EntitlementVO requestEntitlement=requestEntitlementIterator.next();
							if(requestEntitlement.getId()==null)
								continue;
							if(!dBkeyBatchEntitlementList.isEmpty()){
								Iterator<KeyBatchEntitlement> dBkeyBatchEntitlementIterator=dBkeyBatchEntitlementList.iterator();
								while(dBkeyBatchEntitlementIterator.hasNext()){
									KeyBatchEntitlement dBkeyBatchEntitlement=dBkeyBatchEntitlementIterator.next();
									if(requestEntitlement.getId().equals(dBkeyBatchEntitlement.getId())){
										updatedKeyBatchEntitlementList.add(populateKeyBatchEntitlementByRequestEntitlement(dBkeyBatchEntitlement, requestEntitlement, keyBatch));
										requestEntitlementIterator.remove();
										dBkeyBatchEntitlementIterator.remove();
										break;
									}
								}
							}else{
								KeyBatchEntitlement keyBatchEntitlement = new KeyBatchEntitlement();
								updatedKeyBatchEntitlementList.add(populateKeyBatchEntitlementByRequestEntitlement(keyBatchEntitlement, requestEntitlement, keyBatch));
								requestEntitlementIterator.remove();
							}
						}

						if(updatedKeyBatchEntitlementList.size()>0){
							keyBatchEntitlementDAO.saveOrUpdateAll(updatedKeyBatchEntitlementList);
						}

						if(requestEntitlementList.size()>0){  //New entitlements
							List<KeyBatchEntitlement> newKeyBatchEntitlementList = new ArrayList<KeyBatchEntitlement>();
							for(EntitlementVO entitlementVO:requestEntitlementList){
								KeyBatchEntitlement keyBatchEntitlement = new KeyBatchEntitlement();
								newKeyBatchEntitlementList.add(populateKeyBatchEntitlementByRequestEntitlement(keyBatchEntitlement, entitlementVO, keyBatch));							
							}
							keyBatchEntitlementDAO.saveOrUpdateAll(newKeyBatchEntitlementList);
						}
				}
					if(dBkeyBatchEntitlementList.size()>0){
						for(KeyBatchEntitlement keyBatchEntitlement: dBkeyBatchEntitlementList){
							keyBatchEntitlement.setDeleted(Boolean.TRUE);
						}
						keyBatchEntitlementDAO.saveOrUpdateAll(dBkeyBatchEntitlementList);
					}
				}
				KeyBatchEntitlementResponseVO data = populatekeyBatchEntitlementResponseVOFromKeyBatch(bridge,keyBatch);
				response.setData(data);

			}else {
				response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
				response.setMessage(localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_INPUT.getCodeId()));
				response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
				response.setError(responseError);
			}
		}
		return response;
	}

	private KeyBatchEntitlement populateKeyBatchEntitlementByRequestEntitlement(KeyBatchEntitlement keyBatchEntitlement, EntitlementVO requestEntitlement, KeyBatch keyBatch){
		keyBatchEntitlement.setKeyBatch(keyBatch);
		keyBatchEntitlement.setEntName(requestEntitlement.getEntitlementName());
		String compType = requestEntitlement.getEntitlementType();
		if(null != compType && !StringUtils.isEmpty(compType)){
			keyBatchEntitlement.setEntType(codeTypeDAO.getCodeForType(compType));
		}
		keyBatchEntitlement.setEntCredits(requestEntitlement.getCredit());
		keyBatchEntitlement.setEntOnlineDays(requestEntitlement.getOnlineDays());
		keyBatchEntitlement.setEntOnlineExpires(requestEntitlement.getOnlineExpires()!=null?new Date(requestEntitlement.getOnlineExpires()):null);
		Date onlineExpires=requestEntitlement.getOnlineExpires()!=null ? new Date(requestEntitlement.getOnlineExpires()): null;
		if(requestEntitlement.getIsCopyfromOnline()){
			keyBatchEntitlement.setEntOfflineExpires(onlineExpires);
			keyBatchEntitlement.setEntOfflineDays(requestEntitlement.getOnlineDays());
		}
		else{
			Date offlineExpires=requestEntitlement.getOfflineExpires()!=null ? new Date(requestEntitlement.getOfflineExpires()): null;
			keyBatchEntitlement.setEntOfflineExpires(offlineExpires);
			keyBatchEntitlement.setEntOfflineDays(requestEntitlement.getOfflineDays());
		}
		keyBatchEntitlement.setEntIsReusableCredit(requestEntitlement.getIsReusableCredit());
		keyBatchEntitlement.setEntIsCopyFromOnline(Boolean.FALSE);
		if((keyBatchEntitlement.getEntOnlineDays()!= null && keyBatchEntitlement.getEntOfflineDays()!=null) && (keyBatchEntitlement.getEntOnlineDays().equals(keyBatchEntitlement.getEntOfflineDays()))||((keyBatchEntitlement.getEntOnlineExpires()!=null && keyBatchEntitlement.getEntOfflineExpires()!=null)&&(keyBatchEntitlement.getEntOnlineExpires().equals(keyBatchEntitlement.getEntOfflineExpires())))){
			keyBatchEntitlement.setEntIsCopyFromOnline(Boolean.TRUE);
		}
		keyBatchEntitlement.setEntIsReusableCredit(requestEntitlement.getIsReusableCredit());
		
		return keyBatchEntitlement;
	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getEntitlementForKeybatch(SessionStatusVO sessionStatusVO, Integer bridgeId, Integer keyBatchId,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException, IOException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Bridge bridge = bridgeDAO.get(bridgeId);
		if (bridge == null) {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		KeyBatch keyBatch = keyBatchDAO.get(keyBatchId);
		if(keyBatch == null){
			throw new BridgeException(ApplicationCode.KEY_BATCH_NOT_FOUND);
		}
		
		KeyBatchEntitlementResponseVO keyBatchEntitlementResponseVO = populatekeyBatchEntitlementResponseVOFromKeyBatch(bridge, keyBatch);
		response.setData(keyBatchEntitlementResponseVO);
		return response;
	}
	
	private KeyBatchEntitlementResponseVO populatekeyBatchEntitlementResponseVOFromKeyBatch(Bridge bridge,KeyBatch keyBatch){
		AdminUser adminUser = keyBatch.getCreatedBy();
		KeyBatchEntitlementResponseVO keyBatchEntitlementResponseVO = new KeyBatchEntitlementResponseVO();
		keyBatchEntitlementResponseVO.setId(keyBatch.getId());
		keyBatchEntitlementResponseVO.setNumUsersPerKey(keyBatch.getNoOfUsers());
		keyBatchEntitlementResponseVO.setCount(keyBatch.getCount());
		keyBatchEntitlementResponseVO.setNotes(keyBatch.getNote());
		keyBatchEntitlementResponseVO.setRole(keyBatch.getRole().getName());
		keyBatchEntitlementResponseVO.setExpiresDate(keyBatch.getExpireDate().getTime());
		keyBatchEntitlementResponseVO.setCreatedDate(keyBatch.getCreatedDate().getTime());
		keyBatchEntitlementResponseVO.setContactEmail(adminUser.getEmail());
		if(bridge.getConcurrencyEnabled()!=null && bridge.getConcurrencyEnabled())
			keyBatchEntitlementResponseVO.setConcurrencyEntitlements(this.populateConcurrencyEntitlmentVO(keyBatch));
		
		List<KeyBatchEntitlement> keyBatchentitlements = keyBatchEntitlementDAO.getAllEntitlementsForKeyBatch(keyBatch.getId());
		List<EntitlementVO> entitlements = new ArrayList<EntitlementVO>();
		if(keyBatchentitlements != null){
			for(KeyBatchEntitlement keyBatchEntitlement:keyBatchentitlements){
				EntitlementVO entitlementVO = populateEntitlementVO(keyBatchEntitlement);
				entitlements.add(entitlementVO);
			}
		}
		keyBatchEntitlementResponseVO.setEntitlements(entitlements);
		
		return keyBatchEntitlementResponseVO;
		
	}
	
	private List<ConcurrencyEntitlementVO> populateConcurrencyEntitlmentVO(KeyBatch keyBatch){
		List<ConcurrencyEntitlementVO> entitlementVOList = new ArrayList<ConcurrencyEntitlementVO>();
		if(keyBatch.getConcurrencyEntitlementName()!=null && keyBatch.getConcCodeType()!=null){
			ConcurrencyEntitlementVO entitlementVO = new ConcurrencyEntitlementVO();
			//entitlementVO.setId(keyBatch.getId());
			entitlementVO.setEntitlementName(keyBatch.getConcurrencyEntitlementName());
			entitlementVO.setIsReturn(keyBatch.getIsReturn());
			entitlementVO.setEntitlementType(keyBatch.getConcCodeType().getType());
			entitlementVO.setCredit(keyBatch.getConcurrencyCredits());
			entitlementVO.setOnlineDays(keyBatch.getConcurrencyDays());
			entitlementVO.setOfflineDays(keyBatch.getOfflineConcurrencyDays());
			if(keyBatch.getConcurrencyExpires()!=null)
				entitlementVO.setOnlineExpires(keyBatch.getConcurrencyExpires().getTime());
			if(keyBatch.getOfflineConcurrencyExpires()!=null)
				entitlementVO.setOfflineExpires(keyBatch.getOfflineConcurrencyExpires().getTime());
			if(((entitlementVO.getOnlineDays()!= null && entitlementVO.getOfflineDays()!=null) && (entitlementVO.getOnlineDays().equals(entitlementVO.getOfflineDays())))||((entitlementVO.getOnlineExpires()!=null && entitlementVO.getOfflineExpires()!=null) && (entitlementVO.getOnlineExpires().equals(entitlementVO.getOfflineExpires())))){
				entitlementVO.setIsCopyfromOnline(Boolean.TRUE);
			}
			entitlementVOList.add(entitlementVO);
		}
		
		return entitlementVOList;
		
	}
	
	
	private EntitlementVO populateEntitlementVO(KeyBatchEntitlement keyBatchEntitlement){
		EntitlementVO entitlementVO = new EntitlementVO();
		if(keyBatchEntitlement!=null){
			entitlementVO.setId(keyBatchEntitlement.getId());
			entitlementVO.setEntitlementName(keyBatchEntitlement.getEntName());
			entitlementVO.setEntitlementType(keyBatchEntitlement.getEntType().getType());
			entitlementVO.setCredit(keyBatchEntitlement.getEntCredits());
			entitlementVO.setIsReusableCredit(keyBatchEntitlement.getEntIsReusableCredit());
			entitlementVO.setIsCopyfromOnline(keyBatchEntitlement.getEntIsCopyFromOnline());
			entitlementVO.setOnlineDays(keyBatchEntitlement.getEntOnlineDays());
			entitlementVO.setOfflineDays(keyBatchEntitlement.getEntOfflineDays());
			if(keyBatchEntitlement.getEntOnlineExpires()!=null)
			entitlementVO.setOnlineExpires(keyBatchEntitlement.getEntOnlineExpires().getTime());
			if(keyBatchEntitlement.getEntOfflineExpires()!=null)
			entitlementVO.setOfflineExpires(keyBatchEntitlement.getEntOfflineExpires().getTime());
			if(((entitlementVO.getOnlineDays()!= null && entitlementVO.getOfflineDays()!=null) && (entitlementVO.getOnlineDays().equals(entitlementVO.getOfflineDays())))||((entitlementVO.getOnlineExpires()!=null && entitlementVO.getOfflineExpires()!=null)&& (entitlementVO.getOnlineExpires().equals(entitlementVO.getOfflineExpires())))){
				entitlementVO.setIsCopyfromOnline(Boolean.TRUE);
			}
		}
		return entitlementVO;
	}
}
