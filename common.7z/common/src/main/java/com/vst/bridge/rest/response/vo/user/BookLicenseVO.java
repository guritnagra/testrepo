package com.vst.bridge.rest.response.vo.user;

import java.util.List;

public class BookLicenseVO {
	private BookLaunchActionVO launch = new BookLaunchActionVO();
	private BookLicenseInfoVO trial = new BookLicenseInfoVO();
	private BookLicenseInfoVO rental = new BookLicenseInfoVO();
	private BookLicenseInfoVO full = new BookLicenseInfoVO();
	private ConcurrentBookLicenseInfoVO concurrency = new ConcurrentBookLicenseInfoVO();
	private List<BookLicenseInfoVO> entitlements;
	private List<ConcurrentBookLicenseInfoVO> concurrencyEntitlements;
	private AncillaryDownloadActionVO download = new AncillaryDownloadActionVO();
	
//	private BookLicenseInfoVO print	= new BookLicenseInfoVO();
//	private BookLicenseInfoVO text = new BookLicenseInfoVO();
	public BookLicenseInfoVO getTrial() {
		return trial;
	}
	public void setTrial(BookLicenseInfoVO trial) {
		this.trial = trial;
	}
	public BookLicenseInfoVO getRental() {
		return rental;
	}
	public void setRental(BookLicenseInfoVO rental) {
		this.rental = rental;
	}
	public BookLicenseInfoVO getFull() {
		return full;
	}
	public void setFull(BookLicenseInfoVO full) {
		this.full = full;
	}
/*	public BookLicenseInfoVO getPrint() {
		return print;
	}
	public void setPrint(BookLicenseInfoVO print) {
		this.print = print;
	}*/
/*	public BookLicenseInfoVO getText() {
		return text;
	}
	public void setText(BookLicenseInfoVO text) {
		this.text = text;
	}*/
	public BookLaunchActionVO getLaunch() {
		return launch;
	}
	public void setLaunch(BookLaunchActionVO launch) {
		this.launch = launch;
	}
	public ConcurrentBookLicenseInfoVO getConcurrency() {
		return concurrency;
	}
	public void setConcurrency(ConcurrentBookLicenseInfoVO concurrency) {
		this.concurrency = concurrency;
	}
	public List<BookLicenseInfoVO> getEntitlements() {
		return entitlements;
	}
	public void setEntitlements(List<BookLicenseInfoVO> entitlements) {
		this.entitlements = entitlements;
	}
	public List<ConcurrentBookLicenseInfoVO> getConcurrencyEntitlements() {
		return concurrencyEntitlements;
	}
	public void setConcurrencyEntitlements(List<ConcurrentBookLicenseInfoVO> concurrencyEntitlements) {
		this.concurrencyEntitlements = concurrencyEntitlements;
	}
	public AncillaryDownloadActionVO getDownload() {
		return download;
	}
	public void setDownload(AncillaryDownloadActionVO download) {
		this.download = download;
	}
	
	
}
