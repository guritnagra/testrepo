package com.vst.bridge.service.report;


import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.util.exception.BridgeException;

public interface IKpiDataReportService {
	 void generateKpiDataReport();
	 RestResponse getKpiDataReportJson() throws BridgeException;
}
