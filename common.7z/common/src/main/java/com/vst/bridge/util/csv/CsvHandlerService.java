package com.vst.bridge.util.csv;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ParseBool;
import org.supercsv.cellprocessor.constraint.NotNull;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.ICsvBeanReader;

import com.vst.bridge.rest.response.vo.roster.UploadRosterVO;
import com.vst.bridge.util.bean.BridgeGroupBean;
import com.vst.bridge.util.bean.BridgeGroupUserBean;
import com.vst.bridge.util.bean.BridgeUserBean;
import com.vst.bridge.util.exception.InvalidActionException;

@Component("csvHandlerService")
public class CsvHandlerService {

	private static CellProcessor[] getBridgeUserProcessors() {

		//final String emailRegex = "[a-z0-9\\._]+@[a-z0-9\\.]+";
		//StrRegEx.registerMessage(emailRegex, "must be a valid email address");  //new StrRegEx(emailRegex)

		final CellProcessor[] getBridgeUserProcessors = new CellProcessor[] {

				//new UniqueHashCode(), // sourcedId
				new Optional(),// sourcedId
				new Optional(), // status
				new Optional(), // dateLastModified //new ParseDate("yyyy-MM-dd")
				new Optional(), // orgSourcedIds
				new Optional(), // role
				new Optional(), // username
				new Optional(), // userId
				new Optional(), // givenName
				new Optional(), // familyName
				new Optional(), // identifier
				new Optional(), // email
				new Optional(), // sms
				new Optional(), // phone
				new Optional() // agents
		};

		return getBridgeUserProcessors;
	}

	public List<Object> getRosterBean(UploadRosterVO uploadRosterVO, ICsvBeanReader beanReader, String[] header)
			throws IOException, InvalidActionException {

		List<Object> beanList = new ArrayList<>();
		try {
			final CellProcessor[] processors;
			switch (uploadRosterVO.getFileType()) {

			case BRIDGEUSER:
				BridgeUserBean bridgeUserBean = null;
				processors = getBridgeUserProcessors();
				while ((bridgeUserBean = beanReader.read(BridgeUserBean.class, header, processors)) != null) {
					beanList.add(bridgeUserBean);
				}
				break;

			case BRIDGEGROUP:
				BridgeGroupBean bridgeGroupBean = null;
				processors = getBridgeGroupProcessors();
				while ((bridgeGroupBean = beanReader.read(BridgeGroupBean.class, header, processors)) != null) {
					beanList.add(bridgeGroupBean);
				}
				break;

			case BRIDGEGROUPUSER:
				BridgeGroupUserBean bridgeGroupUserBean=null;
				processors = getBridgeGroupUserProcessors();
				while ((bridgeGroupUserBean = beanReader.read(BridgeGroupUserBean.class, header, processors)) != null) {
					beanList.add(bridgeGroupUserBean);
				}
				break;

			default:
				throw new InvalidActionException();

			}

		} finally {
			if (beanReader != null) {
				beanReader.close();
			}
		}
		return beanList;
	}

	private CellProcessor[] getBridgeGroupUserProcessors() {
		//sourcedId,classSourcedId,schoolSourcedId,userSourcedId,role,status,dateLastModified,primary
		final CellProcessor[] getBridgeGroupProcessors = new CellProcessor[] {

				new Optional(), // sourcedId
				new Optional(), // classSourcedId
				new Optional(),//schoolSourcedId
				new Optional(), //userSourcedId
				new Optional(),//role
				new Optional(), // status
				new Optional(), // dateLastModified
				new Optional(new ParseBool())  // primary
				
		};

		return getBridgeGroupProcessors;
	}

	private CellProcessor[] getBridgeGroupProcessors() {
		// sourcedId,status,dateLastModified,title,grade,courseSourcedId,classCode,classType,location,schoolSourcedId,termSourcedId,subjects
		final CellProcessor[] getBridgeGroupProcessors = new CellProcessor[] {

				new NotNull(), // sourcedId
				new Optional(), // status
				new Optional(), // dateLastModified
				new Optional(), // title
				new Optional(), // grade
				new Optional(), // courseSourcedId
				new Optional(), // classCode
				new Optional(), // classType
				new Optional(), // location
				new Optional(), // schoolSourcedId
				new Optional(), // termSourcedId
				new Optional() // subjects
				
		};

		return getBridgeGroupProcessors;
	}
	
	private CellProcessor[] getBridgeGroupBooksMappingProcessor() {
		// sourcedId,status,dateLastModified,title,grade,courseSourcedId,classCode,classType,location,schoolSourcedId,termSourcedId,subjects
		final CellProcessor[] getBridgeGroupBooksMappingProcessor = new CellProcessor[] {
				new Optional(), // vbid
				new Optional(), // Group Name
		};

		return getBridgeGroupBooksMappingProcessor;
	}

}
