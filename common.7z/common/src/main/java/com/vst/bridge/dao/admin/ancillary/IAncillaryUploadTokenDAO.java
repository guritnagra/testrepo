package com.vst.bridge.dao.admin.ancillary;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.ancillary.AncillaryUploadToken;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.Bridge;

public interface IAncillaryUploadTokenDAO extends IGenericDAO<AncillaryUploadToken, Integer>{
	AncillaryUploadToken getAncillaryTokenByTokenString(String token, Bridge bridge);
	List<AncillaryUploadToken> getAncillaryTokensForAdmin(AdminUser admin, Bridge bridge);
}
