package com.vst.bridge.rest.input.vo;

import java.util.List;

public class BridgeGroupBookVO {
	
	private List<String> books;

	public List<String> getBooks() {
		return books;
	}

	public void setBooks(List<String> books) {
		this.books = books;
	}

	

}
