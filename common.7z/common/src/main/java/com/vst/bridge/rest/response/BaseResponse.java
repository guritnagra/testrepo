package com.vst.bridge.rest.response;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.owlike.genson.Genson;

@XmlRootElement
public class BaseResponse {
	private static Logger log = LogManager.getLogger(BaseResponse.class);
	
	final private float version= 1.0F;
	protected List<String> texts= null;
	protected Response.Status code;
	protected String text;
	private Object data;

	
	public BaseResponse(Response.Status code, Exception ex) {
		this(code, ex.getMessage());//MESSAGES.get(MESSAGE.GENERIC_UNEXPECTED_ERROR)
		log.catching(ex);
	}
	
	public BaseResponse(Response.Status code, String text) {
		this.code= code;
		this.text= text;
	}
	
	public BaseResponse(Response.Status code, String text, Object data) {
		this(code,text);
		this.data= data;
	}
	
	public BaseResponse(RestStatus status, Object data) {
		this(status.getCode(), status.getText(), data);
	}
	
	public BaseResponse(BaseResponse status, Object data) {
		this(status.getCode(), status.getText(), data);
	}
	public Object getData()
	{
		return data;
	}
	public void setData(Object data)
	{
		this.data= data;
	}
	public Response.Status getCode()
	{
		return code;
	}
	public void setCode(Response.Status code)
	{
		this.code= code;
	}
	
	public String getText()
	{
		if(texts != null && !texts.isEmpty()) {
			StringBuilder allTexts= new StringBuilder();
			for(String txt : texts) {
				allTexts.append(txt).append(";");
			}
			return allTexts.toString().substring(0,allTexts.length()-1);
		}
		
		return text;
	}
	public void setText(String txt) {
		this.text= txt;
		
	}
	public void addText(String txt) {
		if(null == texts)	{
			texts= new ArrayList<>();
			if(!StringUtils.isBlank(text)) {
				texts.add(text);
			}
		}
		texts.add(txt);
	}
	public void addText(Throwable ex) {
		addText(ex.getMessage());
		log.catching(ex);
	}
	public void addText(Response.Status code, String txt) {
		this.code= code;
		addText(txt);
	}
	public void addText(String param, String txt) {
		addText(String.format("%s: %s", param, txt));
	}
	
	public Response buildResponseWithCookies(NewCookie...cookies) {
		final String responseJson= (new Genson()).serialize(this);
		log.info("ws::reponse: {}", responseJson);
		ResponseBuilder rb = Response.status(this.getCode()).entity(responseJson);//this); //data);
		for(NewCookie cookie : cookies) {
			rb.cookie(cookie);
		}
		return rb.build();
	}
	
	public float getVersion() {
		return version;
	}
}
