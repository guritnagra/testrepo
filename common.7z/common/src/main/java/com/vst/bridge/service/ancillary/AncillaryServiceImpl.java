package com.vst.bridge.service.ancillary;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vst.bridge.VstUtils;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.admin.ancillary.IAncillaryDAO;
import com.vst.bridge.dao.admin.ancillary.IAncillaryUploadTokenDAO;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookCacheDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.entity.admin.ancillary.Ancillary;
import com.vst.bridge.entity.admin.ancillary.AncillaryUploadToken;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.ancillary.AncillaryAdminVO;
import com.vst.bridge.rest.response.vo.ancillary.AncillaryDownloadResponseVO;
import com.vst.bridge.rest.response.vo.ancillary.AncillaryDownloadVO;
import com.vst.bridge.rest.response.vo.ancillary.AncillaryStatusVO;
import com.vst.bridge.rest.response.vo.ancillary.AncillaryUploadTokenVO;
import com.vst.bridge.rest.response.vo.ancillary.AncillaryVO;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.service.admin.AdminUserServiceUtil;
import com.vst.bridge.service.user.UserServiceUtil;
import com.vst.bridge.util.constant.ApplicationAction;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.constant.MimeType;
import com.vst.bridge.util.constant.UploadType;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.connectapi.ApiKeys;

@Service("ancillaryService")
public class AncillaryServiceImpl implements IAncillaryServices {

	@Autowired
	private IBridgeDAO bridgeDAO;
	@Autowired
	private IAncillaryUploadTokenDAO ancillaryUploadTokenDAO;
	@Autowired
	private IAncillaryDAO ancillaryDAO;
	@Autowired
	private LocaleMessageUtility localeMessageUtility;
	@Autowired
	private ObjectMapper objectMapper;
	@Autowired
	private IBridgeBookCacheDAO bridgeBookCacheDAO;
	@Autowired
	private IAdminUserDAO adminUserDAO;
	@Autowired
	private IBridgeUserDAO bridgeUserDAO;
	@Autowired
	private AdminUserServiceUtil adminUserServiceUtil;
	@Autowired
	private UserServiceUtil userServiceUtil;


	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_UNCOMMITTED)
	public RestResponse getAncillaryUploadToken(SessionStatusVO sessionStatusVO, Integer bridgeId,
			UploadType uploadType, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws JsonParseException, JsonMappingException, IOException {
		RestResponse response = getDefaultResponse();
		Bridge bridge = checkBridge(bridgeId);
		Integer adminId = sessionStatusVO.getAdminId();
		AdminUser adminUser = checkUser(adminId, AdminUser.class);
		String apiKey = getApiKey();
		ResponseEntity<String> ancillaryUploadResponse = getUploadTokens(apiKey, uploadType);
		if (ancillaryUploadResponse.getStatusCode() != HttpStatus.CREATED) {
			throw new BridgeException(ApplicationCode.UNEXPECTED_ERROR);
		}
		AncillaryUploadTokenVO uploadToken = getJsonResponse(ancillaryUploadResponse, AncillaryUploadTokenVO.class);

		AncillaryUploadToken token = createAncillaryUploadTokenFromUploadTokenVO(uploadToken, bridge, adminUser);
		ancillaryUploadTokenDAO.saveOrUpdate(token);
		StringBuilder callBackUrl = new StringBuilder();
		callBackUrl.append(VstUtils.getUrlWithProtocol(httpRequest, VstUtils.getDomain(uriInfo, httpRequest)))
				.append("/api").append("/bridges/").append(bridgeId).append("/files");
		uploadToken.setCallBackUrl(callBackUrl.toString());
		response.setData(uploadToken);
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_UNCOMMITTED)
	public RestResponse getAllAncillaries(SessionStatusVO sessionStatusVO, Integer bridgeId, PaginationVO paginationVO,
			HttpServletRequest httpRequest) {
		RestResponse response = getDefaultResponse();
		checkBridge(bridgeId);
		List<AncillaryAdminVO> ancillaryVOList = null;
		if (null == paginationVO) {
			ancillaryVOList = populateAncillaryVOList(bridgeId);
		} else {
			ancillaryVOList = populateAncillaryVOList(bridgeId, paginationVO);
		}
		response.setData(ancillaryVOList);
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_UNCOMMITTED)
	public RestResponse getAncillaryStatus(SessionStatusVO sessionStatusVO, Integer bridgeId, Integer id,
			HttpServletRequest httpRequest) throws JsonParseException, JsonMappingException, IOException {
		RestResponse response = getDefaultResponse();
		Bridge bridge = checkBridge(bridgeId);
		Ancillary ancillary = ancillaryDAO.getAncillaryById(bridge, id);
		if (null != ancillary) {
			String apiKey = getApiKey();
			String sku = ancillary.getGcpSku();
			ResponseEntity<String> ancillaryUploadStatusResponse = getUploadStatus(apiKey, sku);
			if (ancillaryUploadStatusResponse.getStatusCode() != HttpStatus.OK) {
				throw new BridgeException(ApplicationCode.UNEXPECTED_ERROR);
			}
			AncillaryStatusVO ancillaryStatusVO = getJsonResponse(ancillaryUploadStatusResponse,
					AncillaryStatusVO.class);
			response.setData(ancillaryStatusVO);
		} else {
			response.setCode(HttpStatus.NOT_FOUND.value());
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getAncillary(SessionStatusVO sessionStatusVO, Integer bridgeId, Integer id,
			HttpServletRequest httpRequest) {
		RestResponse response = getDefaultResponse();
		Bridge bridge = checkBridge(bridgeId);
		Ancillary ancillary = ancillaryDAO.getAncillaryById(bridge, id);
		if (null != ancillary) {
			response.setData(new AncillaryAdminVO(ancillary));
		} else {
			response.setCode(HttpStatus.NOT_FOUND.value());
		}

		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_UNCOMMITTED)
	public RestResponse createAncillary(Integer bridgeId, AncillaryVO ancillaryVO, HttpServletRequest httpRequest) {
		RestResponse response = getDefaultResponse();
		Bridge bridge = checkBridge(bridgeId);
		if (null != ancillaryDAO.getAncillaryBySku(bridge.getId(), ancillaryVO.getGcpSku())) {
			response.setCode(HttpStatus.UNPROCESSABLE_ENTITY.value());
			response.setMessageid(ApplicationCode.UNEXPECTED_ERROR.getCodeId());
			response.setMessage("Ancillary already exists");
			return response;
		}
		try {
			createAncillaryFromAncillaryVO(ancillaryVO, bridge);
			if (MimeType.checkMimeExists(ancillaryVO.getMimeType())) {
				publishInBookshelf(ancillaryVO, bridge);
			}
			addToBookList(ancillaryVO, bridge);
		} catch (BridgeException | MalformedURLException e) {
			throw new BridgeException("There was an error adding the Ancillary", ApplicationCode.DATA_VALIDATION_ERROR,
					e);
		}
		return response;
	}

	private AdminUser getAdminFromUploadToken(AncillaryVO ancillaryVO, Bridge bridge) {
		AncillaryUploadToken uploadToken = ancillaryUploadTokenDAO.getAncillaryTokenByTokenString(ancillaryVO.getUploadToken().getToken(), bridge);
		if(null == uploadToken){
			throw new BridgeException("There was an error with the ancillary upload, no upload token found", ApplicationCode.DATA_VALIDATION_ERROR);
		}
		return uploadToken.getAdmin();
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_UNCOMMITTED)
	public RestResponse updateAncillary(Integer bridgeId, AncillaryAdminVO ancillaryVO, Integer ancillaryId, SessionStatusVO sessionStatusVO,
			HttpServletRequest httpRequest) {
		RestResponse response = getDefaultResponse();
		Bridge bridge = checkBridge(bridgeId);
		Integer adminId = sessionStatusVO.getAdminId();
		AdminUser admin = checkUser(adminId, AdminUser.class);
		Ancillary ancillary = ancillaryDAO.getAncillaryById(bridge, ancillaryId);
		if (null != ancillary) {
			BridgeBookCache bridgeBookCache = bridgeBookCacheDAO.getBookForVbid(bridgeId, ancillary.getVbid());
			if (null == bridgeBookCache) {
				throw new BridgeException("No asset in book cache matches ancillary",
						ApplicationCode.DATA_VALIDATION_ERROR);
			}
			bridgeBookCache.setTitle(ancillary.getTitle());
			bridgeBookCache.setLastModifiedDate(new Date());
			ancillary.setTitle(ancillaryVO.getTitle());
			ancillary.setCompleted(Boolean.TRUE);
			ancillary.setUpdatedBy(admin);
			AncillaryAdminVO ancillaryVOReturn = new AncillaryAdminVO(ancillary);
			response.setData(ancillaryVOReturn);
		} else {
			throw new BridgeException("Ancillary was not found", ApplicationCode.BOOK_NOT_FOUND);
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_UNCOMMITTED)
	public RestResponse updateAncillary(Integer bridgeId, List<AncillaryAdminVO> ancillaryVOList, SessionStatusVO sessionStatusVO,
			HttpServletRequest httpRequest) {
		RestResponse response = getDefaultResponse();
		Bridge bridge = checkBridge(bridgeId);
		Integer adminId = sessionStatusVO.getAdminId();
		AdminUser admin = checkUser(adminId, AdminUser.class);
		List<AncillaryAdminVO> ancillaryVOReturnList = new LinkedList<>();
		for (AncillaryAdminVO ancillaryAdminVO : ancillaryVOList) {
			Ancillary ancillary = ancillaryDAO.getAncillaryBySku(bridge.getId(), ancillaryAdminVO.getGcpSku());
			if (null != ancillary) {
				BridgeBookCache bridgeBookCache = bridgeBookCacheDAO.getBookForVbid(bridgeId, ancillary.getVbid());
				if (null == bridgeBookCache) {
					throw new BridgeException("No asset in book cache matches ancillary",
							ApplicationCode.DATA_VALIDATION_ERROR);
				}
				bridgeBookCache.setTitle(ancillaryAdminVO.getTitle());
				bridgeBookCache.setLastModifiedDate(new Date());
				bridgeBookCacheDAO.update(bridgeBookCache);
				ancillary.setTitle(ancillaryAdminVO.getTitle());
				ancillary.setUpdatedAt(new Date());
				ancillary.setUpdatedBy(admin);
				ancillary.setCompleted(Boolean.TRUE);
				ancillary.setUpdatedAt(new Date());
				ancillaryDAO.update(ancillary);
				AncillaryAdminVO ancillaryAdminVOReturn = new AncillaryAdminVO(ancillary);
				ancillaryVOReturnList.add(ancillaryAdminVOReturn);
			}
		}

		response.setData(ancillaryVOReturnList);
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_UNCOMMITTED)
	public RestResponse dowloadAncillary(String vbid, HttpServletRequest httpRequest, String code, SessionStatusVO sessionStatusVO)
			throws JsonParseException, JsonMappingException, IOException {
		RestResponse response = getDefaultResponse();
		Bridge bridge = checkBridge(code);
		Ancillary ancillary = ancillaryDAO.getAncillaryByVbid(bridge.getId(), vbid);
		if (null != ancillary && ancillary.getDeleted() != Boolean.TRUE) {
			String apiKey = getApiKey();
			ResponseEntity<String> ancillaryDownloadResponse = getAncillaryDownload(apiKey, ancillary);
			if (ancillaryDownloadResponse.getStatusCode() != HttpStatus.OK) {
				throw new BridgeException(ApplicationCode.UNEXPECTED_ERROR);
			}
			Integer userId = sessionStatusVO.getAdminId(); 
			userServiceUtil.createBridgeLog(userId, bridge, ApplicationAction.ANCILLARY_DOWNLOAD, ancillary.getVbid());
			AncillaryDownloadResponseVO ancillaryResponse = getJsonResponse(ancillaryDownloadResponse,
					AncillaryDownloadResponseVO.class);
			AncillaryDownloadVO ancillaryDownloadVO = new AncillaryDownloadVO(ancillary);
			ancillaryDownloadVO.setLink(ancillaryResponse.getLink());
			response.setData(ancillaryDownloadVO);
		} else {
			throw new BridgeException("Ancillary was not found", ApplicationCode.BOOK_NOT_FOUND);
		}

		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_UNCOMMITTED)
	public RestResponse deleteAncillary(Integer bridgeId, List<AncillaryAdminVO> ancillaryAdminVOList,
			HttpServletRequest httpRequest) {
		RestResponse response = getDefaultResponse();
		Bridge bridge = checkBridge(bridgeId);
		if (null != bridge) {
			for (AncillaryAdminVO ancillaryAdminVO : ancillaryAdminVOList) {
				Ancillary ancillary = ancillaryDAO.getAncillaryBySku(bridge.getId(), ancillaryAdminVO.getGcpSku());
				ancillary.setDeleted(Boolean.TRUE);
				ancillary.setDeletedAt(new Date());
				BridgeBookCache bookCache = bridgeBookCacheDAO.getCacheBooksForVbid(ancillary.getVbid());
				if (null != bookCache) {
					bookCache.setDeleted(Boolean.TRUE);
					bookCache.setLastModifiedDate(new Date());
				}
			}
			ancillaryDAO.flushAndClear();
		}
		List<AncillaryAdminVO> ancillaryVOList = populateAncillaryVOList(bridgeId);
		response.setData(ancillaryVOList);
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_UNCOMMITTED)
	public RestResponse deleteAncillary(Integer bridgeId, AncillaryAdminVO ancillaryAdminVO, Integer ancillaryId,
			HttpServletRequest httpRequest) {
		RestResponse response = getDefaultResponse();
		Bridge bridge = checkBridge(bridgeId);
		if (null != bridge) {
			Ancillary ancillary = ancillaryDAO.getAncillaryById(bridge, ancillaryId);
			if (null != ancillary) {
				ancillary.setDeleted(Boolean.TRUE);
				ancillary.setDeletedAt(new Date());
				BridgeBookCache bookCache = bridgeBookCacheDAO.getCacheBooksForVbid(ancillary.getVbid());
				if (null != bookCache) {
					bookCache.setDeleted(Boolean.TRUE);
					bookCache.setLastModifiedDate(new Date());
				}
			} else {
				throw new BridgeException("Ancillary was not found", ApplicationCode.BOOK_NOT_FOUND);
			}
			ancillaryDAO.flushAndClear();
		}
		List<AncillaryAdminVO> ancillaryVOList = populateAncillaryVOList(bridgeId);
		response.setData(ancillaryVOList);
		return response;
	}

	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED)
	public RestResponse refreshBookCacheAncillaries(Integer bridgeId, HttpServletRequest httpRequest) {
		RestResponse response = getDefaultResponse();
		//Bridge bridge = checkBridge(bridgeId);
		// TODO create a way to update the bridge book cache from ancillary
		// table
		return response;
	}

	private void createAncillaryFromAncillaryVO(AncillaryVO ancillaryVO, Bridge bridge) throws BridgeException {
		if (null == ancillaryVO || null == ancillaryVO.getUploadToken()) {
			throw new BridgeException(ApplicationCode.INVALID_INPUT);
		}
		Ancillary ancillary = new Ancillary();
		ancillary.setBridge(bridge);
		ancillary.setCreatedAt(ancillaryVO.getCreatedAt());
		ancillary.setDeleted(null == ancillaryVO.getDeletedAt() ? Boolean.FALSE : Boolean.TRUE);
		ancillary.setDeletedAt(ancillaryVO.getDeletedAt());
		ancillary.setFileName(ancillaryVO.getFileName());
		ancillary.setTitle(ancillaryVO.getFileName());
		ancillary.setGcpSku(ancillaryVO.getGcpSku());
		ancillary.setMimeType(
				null == ancillaryVO.getMimeType() ? MimeType.BIN.getMimeType() : ancillaryVO.getMimeType());
		ancillary.setVbid("ANC-" + ancillary.getGcpSku().substring(12));
		ancillary.setUpdatedAt(ancillary.getUpdatedAt());
		ancillary.setFileSize(ancillaryVO.getFileSize());
		ancillary.setCompleted(Boolean.FALSE);
		AncillaryUploadToken uploadToken = ancillaryUploadTokenDAO.getAncillaryTokenByTokenString(ancillaryVO.getUploadToken().getToken(), bridge);
		
		if(null != uploadToken && null != uploadToken.getAdmin()) {
			ancillary.setUploadToken(uploadToken);
			ancillary.setUpdatedBy(uploadToken.getAdmin());
			ancillaryDAO.create(ancillary);
			AdminUser admin = getAdminFromUploadToken(ancillaryVO, bridge);
			adminUserServiceUtil.createBridgeAdminLog(admin.getId(), bridge, ApplicationAction.ANCILLARY_UPLOAD, ancillary.getVbid());
		}else {
			throw new BridgeException( "No admin or upload token found",ApplicationCode.USER_AUTHENTICATION_FAILED);
			
		}
	}

	private AncillaryUploadToken createAncillaryUploadTokenFromUploadTokenVO(AncillaryUploadTokenVO uploadToken,
			Bridge bridge, AdminUser admin) {

		return new AncillaryUploadToken(uploadToken.getToken(), uploadToken.getExpiresOn(), bridge, admin);
	}

	private ResponseEntity<String> getUploadTokens(String apiKey, UploadType uploadType) {
		String url = ApiKeys.getAncillaryServiceUrl(ApplicationConstants.getApiMode())
				+ ApplicationConstants.ANCILLARY_UPLOAD_TOKEN_URL;
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = getHeaders(apiKey);
		MultiValueMap<String, String> paramMap = new LinkedMultiValueMap<String, String>();
		paramMap.add("upload_type", uploadType.toString());
		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<MultiValueMap<String, String>>(paramMap,
				headers);
		return restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
	}

	private ResponseEntity<String> getUploadStatus(String apiKey, String sku) {
		String url = ApiKeys.getAncillaryServiceUrl(ApplicationConstants.getApiMode())
				+ ApplicationConstants.ANCILLARY_STATUS_URL;
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = getHeaders(apiKey);
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put(ApplicationConstants.SKU, sku);
		ResponseEntity<String> ancillaryStatusResponse = restTemplate.exchange(url, HttpMethod.GET, entity,
				String.class, paramMap);
		return ancillaryStatusResponse;
	}

	private ResponseEntity<String> getAncillaryDownload(String apiKey, Ancillary ancillary) {
		String url = ApiKeys.getAncillaryServiceUrl(ApplicationConstants.getApiMode())
				+ ApplicationConstants.ANCILLARY_DOWNLOAD_LINK;
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = getHeaders(apiKey);
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put(ApplicationConstants.SKU, ancillary.getGcpSku());
		//title
		paramMap.put(ApplicationConstants.DEFAULT_GET_BOOK_ORDER_BY_VALUE, ancillary.getTitle());
		ResponseEntity<String> ancillaryStatusResponse = restTemplate.exchange(url, HttpMethod.GET, entity,
				String.class, paramMap);

		return ancillaryStatusResponse;
	}

	private HttpHeaders getHeaders(String apiKey) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add(ApplicationConstants.APIKEY_HEADER, apiKey);
		return headers;
	}

	private RestResponse getDefaultResponse() {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		return response;
	}

	private String getApiKey() {
		AncillaryApiKey ancillaryApiKey = AncillaryApiKey
				.valueOf(ApplicationConstants.getApiMode().name().toUpperCase());
		String apiKey = ancillaryApiKey.getApiKey();
		if (null == apiKey) {
			throw new BridgeException("Ancillary API Key Error", ApplicationCode.UNEXPECTED_ERROR);
		}
		return apiKey;
	}

	private Bridge checkBridge(Integer bridgeId) throws BridgeException {
		Bridge bridge = null;
		if (null != bridgeId) {
			bridge = bridgeDAO.get(bridgeId);
			if (bridge == null) {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
		}
		return bridge;
	}

	private Bridge checkBridge(String code) {
		Bridge bridge = null;
		if (null != code) {
			bridge = bridgeDAO.getBridgeForCode(code);
			if (bridge == null) {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
		}
		return bridge;
	}

	private <T> T getJsonResponse(ResponseEntity<String> responseEntity, Class<T> classType)
			throws JsonParseException, JsonMappingException, IOException {
		String responseBody = responseEntity.getBody();
		JsonNode node;
		node = objectMapper.readValue(responseBody, JsonNode.class);
		T ancillaryStatusVO = objectMapper.readValue(node.toString(),
				objectMapper.getTypeFactory().constructType(classType));
		return ancillaryStatusVO;
	}

	private List<AncillaryAdminVO> populateAncillaryVOList(Integer bridgeId, PaginationVO paginationVO) {
		List<Ancillary> ancillaryList = ancillaryDAO.getAllAncillaries(bridgeId, paginationVO);
		List<AncillaryAdminVO> ancillaryVOList = new LinkedList<>();
		for (Ancillary ancillary : ancillaryList) {
			ancillaryVOList.add(new AncillaryAdminVO(ancillary));
		}
		return ancillaryVOList;
	}

	private List<AncillaryAdminVO> populateAncillaryVOList(Integer bridgeId) {
		List<Ancillary> ancillaryList = ancillaryDAO.getAllAncillaries(bridgeId);
		List<AncillaryAdminVO> ancillaryVOList = new LinkedList<>();
		for (Ancillary ancillary : ancillaryList) {
			ancillaryVOList.add(new AncillaryAdminVO(ancillary));
		}
		return ancillaryVOList;
	}

	private void addToBookList(AncillaryVO ancillaryVO, Bridge bridge) throws MalformedURLException {
		BridgeBookCache bookCache = new BridgeBookCache();
		Ancillary ancillary = ancillaryDAO.getAncillaryBySku(bridge.getId(), ancillaryVO.getGcpSku());
		if (null != ancillary) {
			bookCache.setAncillary(ancillary);
			bookCache.setBridge(bridge);
			bookCache.setDeleted(Boolean.FALSE);
			bookCache.setLastModifiedDate(new Date());
			bookCache.setTitle(ancillary.getTitle());
			bookCache.setVbid(ancillary.getVbid());
			bookCache.setAuthor("N/A");
			bookCache.setDescription("");
			bookCache.setEdition("0");
			bookCache.setTextbookIsbn("");
			bookCache.setEbookIsbn("");
			bookCache.setCoverImageUrl(new URL(ApplicationConstants.DEFAULT_ANCILLARY_COVER));
			String fileType = getFileType(ancillary);
			bookCache.setFileType(fileType.toUpperCase());
			bookCache.setCategory(getCategory(fileType.toUpperCase()));
			bridgeBookCacheDAO.create(bookCache);
		}
	}

	private String getCategory(String upperCase) {
		if(MimeType.Category.ETEXT.toString().equals(upperCase)){
			return upperCase;
		}
		MimeType extension = MimeType.findExtenstionByString(upperCase);
		MimeType.Category category = MimeType.getMimeTypeCategory(extension);
		return category.toString();
	}

	private String getFileType(Ancillary ancillary) {
		String fileType = "-";
		String ancillaryMime = ancillary.getMimeType();

		if (null != ancillaryMime) {
			MimeType mimeType = MimeType.findExtensionByMimeType(ancillaryMime);
			if (mimeType.equals(MimeType.BIN)) {
				if (null != ancillary.getFileName()) {
					String[] result = ancillary.getFileName().trim().split("\\.");
					if (null != result && result.length > 1) {
						fileType = result[result.length - 1];
					}
				}

			}else{
				fileType = mimeType.toString();	
			}
		}
		return fileType;
	}
	

	private <T> T checkUser(Integer userId, Class<T> classType) {
		
		if(null != classType){ 
			if(classType == AdminUser.class){
				AdminUser adminUser = adminUserDAO.get(userId);
				if(null == adminUser){
					throw new BridgeException("There was an error with the admin user, no user found", ApplicationCode.DATA_VALIDATION_ERROR);
				}
				return classType.cast(adminUser);
				
			}else if(classType == BridgeUser.class){
				BridgeUser bridgeUser = bridgeUserDAO.get(userId);
				if(null == bridgeUser){
					throw new BridgeException("There was an error with the bridge user, no user found", ApplicationCode.DATA_VALIDATION_ERROR);
				}
				return classType.cast(bridgeUser);
			}
		}
		return null;
	}

	private void publishInBookshelf(AncillaryVO ancillaryVO, Bridge bridge) {
		// TODO Auto-generated method stub

	}

}
