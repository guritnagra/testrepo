package com.vst.bridge.rest.response.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class BCCourseVO {
	
	private String tenantId;
	private String termId;
	private String identifier;
	private String id;
	private String title;
	private String label;
	private String friendlyName;
	private String active;
	private String startDate;
	private String endDate;
	private String censusDate;
	private String createdAt;
	private String updatedAt;
	
	public String getTenantId() {
		return tenantId;
	}
	@JsonProperty("tenant_id")
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	public String getTermId() {
		return termId;
	}
	@JsonProperty("term_id")
	public void setTermId(String termId) {
		this.termId = termId;
	}
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getFriendlyName() {
		return friendlyName;
	}
	@JsonProperty("friendly_name")
	public void setFriendlyName(String friendlyName) {
		this.friendlyName = friendlyName;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getStartDate() {
		return startDate;
	}
	@JsonProperty("start_date")
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	@JsonProperty("end_date")
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getCensusDate() {
		return censusDate;
	}
	@JsonProperty("census_date")
	public void setCensusDate(String censusDate) {
		this.censusDate = censusDate;
	}
	public String getCreatedAt() {
		return createdAt;
	}
	@JsonProperty("created_at")
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
	public String getUpdatedAt() {
		return updatedAt;
	}
	@JsonProperty("updated_at")
	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((tenantId == null) ? 0 : tenantId.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BCCourseVO other = (BCCourseVO) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (tenantId == null) {
			if (other.tenantId != null)
				return false;
		} else if (!tenantId.equals(other.tenantId))
			return false;
		return true;
	}
	
}

