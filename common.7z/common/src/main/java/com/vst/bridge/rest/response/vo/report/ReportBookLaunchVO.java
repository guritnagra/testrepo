package com.vst.bridge.rest.response.vo.report;

public class ReportBookLaunchVO extends ReportBooksVO{
	private Integer totalCount;

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
	
}
