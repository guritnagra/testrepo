package com.vst.bridge.service.report;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;

import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.dao.kpi.IKpiDAO;
import com.vst.bridge.entity.admin.kpi.KpiData;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.report.KpiDataVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.email.EmailHandlerService;
import com.vst.bridge.util.email.ExecutorUtility;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.bridge.util.message.TemplateLocationConstants;
import com.vst.connectapi.ApiKeys.API_MODE;

@Service("kpiDataReportService")
public class KpiDataReportServiceImpl implements IKpiDataReportService {
	@Autowired
	private IKpiDAO kpiDataDAO;

	private Executor executor = ExecutorUtility.getExecutorInstance();

	@Autowired
	private EmailHandlerService emailHandler;
	
	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Override
	public void generateKpiDataReport() {
		KpiDataVO kpiDataVO = getReportDataVO();
		sendKpiDataReportEmail(kpiDataVO);
	}

	private KpiDataVO getReportDataVO() {
		KpiData kpiData = kpiDataDAO.getKpiData();
		KpiDataVO kpiVO = new KpiDataVO(kpiData.getBridgeSites(), kpiData.getBridgeUsers(), kpiData.getBridgeAdmins(),
				kpiData.getUniqueAssets(), kpiData.getActivations());
		return kpiVO;
	}

	private void sendKpiDataReportEmail(final KpiDataVO kpiDataVO) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yy");
		final String date = sdf.format(new Date());

		final Runnable runnable = new Runnable() {

			@Override
			public void run() {
				Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put(ApplicationConstants.NEW_BRIDGE_TO_NAME, getReportRecipient());
				paramMap.put(ApplicationConstants.NEW_BRIDGE_TO, getKpiReportEmailContacts());
				paramMap.put(ApplicationConstants.NEW_BRIDGE_CONTACT_NAME, "Bridge Team");
				paramMap.put("currentDate", date);
				paramMap.put(ApplicationConstants.KPI_BRIDGE_SITE_COUNT, kpiDataVO.getBridgeSites());
				paramMap.put(ApplicationConstants.KPI_BRIDGE_USER_COUNT, kpiDataVO.getBridgeUsers());
				paramMap.put(ApplicationConstants.KPI_BRIDGE_ADMIN_COUNT, kpiDataVO.getBridgeAdmins());
				paramMap.put(ApplicationConstants.KPI_UNIQUE_ASSET_COUNT, kpiDataVO.getUniqueAssets());
				paramMap.put(ApplicationConstants.KPI_ACTIVATION_COUNT, kpiDataVO.getActivations());
				emailHandler.sendEmail(TemplateLocationConstants.KPI_DATA_REPORT_TEMPLATE, paramMap);
			}

		};
		this.executor.execute(runnable);

	}

	private String getKpiReportEmailContacts() {
		if(ApplicationConstants.getApiMode() == API_MODE.prod){
			return ApplicationConstants.KPI_DATA_EMAIL_RECIPIENTS;
		}else{
			return ApplicationConstants.KPI_DATA_EMAIL_RECIPIENTS_DEV;
		}
		
	}

	private String getReportRecipient() {
		return "Clay";
	}

	@Override
	@Transactional(readOnly=true, isolation=Isolation.READ_UNCOMMITTED)
	public RestResponse getKpiDataReportJson() throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		SimpleDateFormat sdf = new SimpleDateFormat("EEEE, MMMMM dd, yyyy hh:mm:ss aa zzz");
		final String date = sdf.format(new Date());
		response.setMetadata(date);
		KpiDataVO kpiDataVO = getReportDataVO();
		response.setData(kpiDataVO);
		return response;
	}

}
