package com.vst.bridge.dao.key;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.keys.KeyBatchEntitlement;
import com.vst.bridge.util.exception.BridgeException;

@Repository("keyBatchEntitlementDAO")
public class KeyBatchEntitlementDAOImpl extends GenericDAO<KeyBatchEntitlement, Integer> implements IKeyBatchEntitlementDAO {

	public KeyBatchEntitlementDAOImpl() {
		super(KeyBatchEntitlement.class);
	}

	@Override
	public List<KeyBatchEntitlement> getEntitlementsByKeyBatches(Integer keyBatch) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.eq("keyBatch.id", keyBatch));
		List<KeyBatchEntitlement> KeyBatchEntitlementList = executeCriteira(criteria);
		return null != KeyBatchEntitlementList && KeyBatchEntitlementList.size() > 0 ? KeyBatchEntitlementList : null;
	}

	@Override
	public List<KeyBatchEntitlement> getAllEntitlementsForKeyBatch(Integer keyBatch) throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("keyBatch.id", keyBatch));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		List<KeyBatchEntitlement> keyBatchEntitlements = executeCriteira(criteria);
		return keyBatchEntitlements;
	}

}
