package com.vst.bridge.rest.central;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.admin.group.company.IAdminGroupCompanyDAO;
import com.vst.bridge.dao.admin.session.IAdminSessionDAO;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.user.session.IBridgeUserSessionDAO;
import com.vst.bridge.entity.admin.company.AdminCompany;
import com.vst.bridge.entity.admin.session.AdminSession;
import com.vst.bridge.entity.admin.user.AdminGroup;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.session.BridgeUserSession;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.company.Company;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;

@Service("bridgeAuthonticator")
public class BridgeAuthonticator implements IBridgeAuthonticator{

	@Autowired
	private IAdminSessionDAO adminSessionDAO;
		
	@Autowired
	private IBridgeUserSessionDAO bridgeUserSessionDAO;
	
	@Autowired
	private IBridgeDAO bridgeDAO;
    
    @Autowired
	private IAdminUserDAO adminUserDAO;
    
    @Autowired
	private IAdminGroupCompanyDAO adminGroupCompanyDAO;
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true,isolation=Isolation.READ_COMMITTED)
	public synchronized SessionStatusVO getAdminSessionVO(AdminSession adminSession) throws BridgeException {
		AdminUser adminUser = null;
		SessionStatusVO sessionStatusVO = new SessionStatusVO(ApplicationCode.STATUS_OK);
		if(null != adminSession ){
			adminUser = adminSession.getAdmin();
			sessionStatusVO.setAdminId(adminUser.getId());
			sessionStatusVO.setRoleName(adminUser.getRole().getName());
		}
		return sessionStatusVO;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true,isolation=Isolation.READ_COMMITTED)
	public AdminSession getAdminSession(String sessionId) throws BridgeException {
		AdminSession adminSession = null;
		if(null != sessionId && !StringUtils.isEmpty(sessionId)){
			Calendar calendar = Calendar.getInstance();
			calendar.add(Calendar.MINUTE, -30);
			Date lastAcessDate = calendar.getTime();
			adminSession = adminSessionDAO.getForSessionId(sessionId,Boolean.TRUE,lastAcessDate);
		}
		return adminSession;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false,isolation=Isolation.REPEATABLE_READ)
	public void updateLastAccess(AdminSession adminSession,String sessionId) throws BridgeException {
		if(null != adminSession){
			adminSession.setLastAccessDate(new Date());
			adminSessionDAO.update(adminSession);
		}else{
			adminSession = adminSessionDAO.getForSessionId(sessionId,Boolean.FALSE,null);
			if(null != adminSession){
				if(!adminSession.getDeleted()){
					adminSession.setDeleted(Boolean.TRUE);
					adminSessionDAO.update(adminSession);
				}
			}
		}
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false,isolation=Isolation.READ_COMMITTED)
	public BridgeUserSession getBridgeUserSession(String sessionId) throws BridgeException {
		BridgeUserSession userSession = null;
		if(null != sessionId && !StringUtils.isEmpty(sessionId)){
			Calendar calendar = Calendar.getInstance();
			calendar.add(Calendar.MINUTE, -30);
			Date lastAcessDate = calendar.getTime();
			userSession = bridgeUserSessionDAO.getForSessionId(sessionId,Boolean.TRUE,lastAcessDate);
		}
		return userSession;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false,isolation=Isolation.REPEATABLE_READ)
	public void updateLastAccess(BridgeUserSession userSession, String sessionId) throws BridgeException {
		if(null != userSession){
			userSession.setLastAccess(new Date());
			bridgeUserSessionDAO.update(userSession);
		}else{
			userSession = bridgeUserSessionDAO.getForSessionId(sessionId,Boolean.FALSE,null);
			if(null != userSession){
				if(!userSession.getDeleted()){
					userSession.setDeleted(Boolean.TRUE);
					bridgeUserSessionDAO.update(userSession);
				}
			}
		}
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true,isolation=Isolation.READ_COMMITTED)
	public SessionStatusVO getBridgeUserSessionVO(BridgeUserSession userSession) throws BridgeException {
		BridgeUser bridgeUser = null;
		SessionStatusVO sessionStatusVO = new SessionStatusVO(ApplicationCode.STATUS_OK);
		if(null != userSession ){
			bridgeUser = userSession.getUser();
			sessionStatusVO.setAdminId(bridgeUser.getId());
		}
		return sessionStatusVO;
	}
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true,isolation=Isolation.READ_COMMITTED)
	public void checkAdminAccessForBridgeById(SessionStatusVO sessionStatusVO, Integer bridgeId) throws BridgeException {
		String role = sessionStatusVO.getRoleName();
		if (StringUtils.equals(role, ApplicationConstants.USER_ROLE_SUPER_ADMIN)) {
			return;
		}
		List<Integer> companyIds = new ArrayList<Integer>();
		AdminUser adminUser = adminUserDAO.get(sessionStatusVO.getAdminId());
		List<AdminCompany> adminCompanies = adminUser.getCompanies();
		if (null != adminCompanies && adminCompanies.size() > 0) {
			for (AdminCompany adminCompany : adminCompanies) {
				companyIds.add(adminCompany.getCompany().getId());
			}
		}
		List<AdminGroup> adminGroups = adminUser.getGroups();
		if (null != adminGroups && adminGroups.size() > 0) {
			List<Integer> groupIds = new ArrayList<Integer>();
			for (AdminGroup adminGroup : adminGroups) {
				groupIds.add(adminGroup.getGroup().getId());
			}
			List<Company> groupCompanies = adminGroupCompanyDAO.getListOfCompaniesForGroupIds(groupIds);
			if (null != groupCompanies && groupCompanies.size() > 0) {
				List<Integer> comapniesFromGroupList = new ArrayList<Integer>();
				for (Company company : groupCompanies) {
					comapniesFromGroupList.add(company.getId());
				}
				Set<Integer> unionCopanyIds = new HashSet<Integer>();
				unionCopanyIds.addAll(comapniesFromGroupList);
				unionCopanyIds.addAll(companyIds);
				companyIds = new ArrayList<Integer>(unionCopanyIds);
			}
		}
		List<Bridge> bridges = bridgeDAO.getBrigesList(companyIds, Boolean.FALSE, null, null, Boolean.FALSE);
		if(bridgeId!=null && bridges!=null){
			if(!bridges.contains(bridgeDAO.load(bridgeId))){
				throw new BridgeException(ApplicationCode.INSUFFICIENT_PRIVILEGE);
			}
		}
		
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true,isolation=Isolation.READ_COMMITTED)
	public AdminUser getAdminUserForSession(SessionStatusVO sessionStatusVO) throws BridgeException {
		if(sessionStatusVO!=null){
			return adminUserDAO.get(sessionStatusVO.getAdminId());
		}
		return null;
		
	}
}
