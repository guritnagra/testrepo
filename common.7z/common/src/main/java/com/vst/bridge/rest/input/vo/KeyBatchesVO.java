package com.vst.bridge.rest.input.vo;

import com.vst.bridge.annotation.custom.InputRequired;

public class KeyBatchesVO {
	
	private String notes;
	private String role;
	private Long expires;
	private Integer count;
	private Integer numUsersPerKey;
	@InputRequired(required=false)
	private Integer fullCredits;
	@InputRequired(required=false)
	private Integer trialCredits;
	@InputRequired(required=false)
	private Integer rentalCredits;
	@InputRequired(required=false)
	private Integer rentalDays;
	@InputRequired(required=false)
	private Integer expireInMonths;
	@InputRequired(required=false)
	private Integer expireInDays;
	@InputRequired(required=false)
	private Integer concurrencyCredits;
	
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Long getExpires() {
		return expires;
	}
	public void setExpires(Long expires) {
		this.expires = expires;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public Integer getNumUsersPerKey() {
		return numUsersPerKey;
	}
	public void setNumUsersPerKey(Integer numUsersPerKey) {
		this.numUsersPerKey = numUsersPerKey;
	}

	public Integer getTrialCredits() {
		return trialCredits;
	}
	public void setTrialCredits(Integer trialCredits) {
		this.trialCredits = trialCredits;
	}
	public Integer getExpireInMonths() {
		return expireInMonths;
	}
	public Integer getFullCredits() {
		return fullCredits;
	}
	public void setFullCredits(Integer fullCredits) {
		this.fullCredits = fullCredits;
	}
	public Integer getRentalCredits() {
		return rentalCredits;
	}
	public void setRentalCredits(Integer rentalCredits) {
		this.rentalCredits = rentalCredits;
	}
	public Integer getRentalDays() {
		return rentalDays;
	}
	public void setRentalDays(Integer rentalDays) {
		this.rentalDays = rentalDays;
	}
	public void setExpireInMonths(Integer expireInMonths) {
		this.expireInMonths = expireInMonths;
	}
	public Integer getExpireInDays() {
		return expireInDays;
	}
	public void setExpireInDays(Integer expireInDays) {
		this.expireInDays = expireInDays;
	}
	public Integer getConcurrencyCredits() {
		return concurrencyCredits;
	}
	public void setConcurrencyCredits(Integer concurrencyCredits) {
		this.concurrencyCredits = concurrencyCredits;
	}
	
}
