package com.vst.bridge.service.admin;

public interface IAdminUserServices extends IAdminUserPasswordService, IAdminUserGroupService, IAdminUserAccessService,
		IAdminUserEntityService, IAdminUserBridgeService, IAdminUserBookService, IAdminUserCompaniesService,
		IAdminUserKeyService, IAdminUserConnectivityService, IAdminUserRosteringService,IAdminUserEntitlementService {

}
