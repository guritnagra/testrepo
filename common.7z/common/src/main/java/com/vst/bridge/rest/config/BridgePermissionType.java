package com.vst.bridge.rest.config;

public enum BridgePermissionType {
	admin,
	user;
}
