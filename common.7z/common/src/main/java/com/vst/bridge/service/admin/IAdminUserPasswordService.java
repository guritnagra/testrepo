package com.vst.bridge.service.admin;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.rest.input.vo.LoginInfoVO;
import com.vst.bridge.rest.response.vo.AdminResetPasswordVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminUserPasswordService {
	RestResponse resetPassword(AdminResetPasswordVO adminResetPasswordVO, HttpServletRequest httpRequest,UriInfo uriInfo)throws BridgeException, ParseException, IOException;
	RestResponse updateResetPassword(LoginInfoVO loginInfoVO,final String token,HttpServletRequest httpRequest,UriInfo uriInfo)throws BridgeException, ParseException, IOException;
}
