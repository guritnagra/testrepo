package com.vst.bridge.rest.response.vo.books;

import com.vst.bridge.rest.response.vo.page.PaginationVO;

public class SelectAllBooksMetadataVO extends PaginationVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7148875420260307824L;
	
	private Boolean selectAllBooks;	
	

	public Boolean getSelectAllBooks() {
		return selectAllBooks;
	}

	public void setSelectAllBooks(Boolean selectAllBooks) {
		this.selectAllBooks = selectAllBooks;
	}
	public SelectAllBooksMetadataVO() {}
	
	public SelectAllBooksMetadataVO(Boolean selectAllBooks,Integer page,Integer limit,Integer totalPages,String orderBy,String order,String serach,Integer count,Integer offset) {
		super(page,limit,totalPages,orderBy,order,serach,count,offset);
		this.selectAllBooks = selectAllBooks;		
	}

	
	
}
