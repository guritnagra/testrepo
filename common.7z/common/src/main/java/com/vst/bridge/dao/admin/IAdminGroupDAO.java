package com.vst.bridge.dao.admin;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.user.AdminGroup;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminGroupDAO extends IGenericDAO<AdminGroup, Integer>{
	List<Integer> getGropIdsForAdminUser(AdminUser adminUser)throws BridgeException;

	List<AdminUser> getUsersForGroupIds(List<Integer> groupIds, Integer startIndex, BridgePaginationVo bridgePaginationVo)throws BridgeException;

	Integer getUserCount(List<Integer> groupIds, BridgePaginationVo paginationVo)throws BridgeException;

	List<AdminGroup> getGroupsForAdminId(Integer id)throws BridgeException;
}
