package com.vst.bridge.rest.response.vo.user;

import java.util.HashMap;
import java.util.Map;

public class BridgeUserConfigVO {
	private String name;
	private String language;
	private String code;
	private Boolean isPending;
	private Map<String,String> config = new HashMap<String,String>(0);
	
	private Map<String,String> labels = new HashMap<String,String>(0);
	
	private Boolean isDefered;

	private Boolean keysRequired;
	
	private Boolean isIntegrated;
	
	private Boolean isRostered;
	
	private Boolean isBCIntegrated;
	
	private Boolean isSampler;
	
	private Boolean isEmbeddedEnabled;
	
	private String brandedUrl;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Map<String, String> getConfig() {
		return config;
	}
	public void setConfig(Map<String, String> config) {
		this.config = config;
	}
	public Boolean getIsPending() {
		return isPending;
	}
	public void setIsPending(Boolean isPending) {
		this.isPending = isPending;
	}
	public Map<String, String> getLabels() {
		return labels;
	}
	public void setLabels(Map<String, String> labels) {
		this.labels = labels;
	}
	public Boolean getIsDefered() {
		return isDefered;
	}
	public void setIsDefered(Boolean isDefered) {
		this.isDefered = isDefered;
	}
	public Boolean getKeysRequired() {
		return keysRequired;
	}
	public void setKeysRequired(Boolean keysRequired) {
		this.keysRequired = keysRequired;
	}
	public Boolean getIsIntegrated() {
		return isIntegrated;
	}
	public void setIsIntegrated(Boolean isIntegrated) {
		this.isIntegrated = isIntegrated;
	}
	public Boolean getIsRostered() {
		return isRostered;
	}
	public void setIsRostered(Boolean isRostered) {
		this.isRostered = isRostered;
	}
	public Boolean getIsBCIntegrated() {
		return isBCIntegrated;
	}
	public void setIsBCIntegrated(Boolean isBCIntegrated) {
		this.isBCIntegrated = isBCIntegrated;
	}
	public Boolean getIsSampler() {
		return isSampler;
	}
	public void setIsSampler(Boolean isSampler) {
		this.isSampler = isSampler;
	}
	public Boolean getIsEmbeddedEnabled() {
		return isEmbeddedEnabled;
	}
	public void setIsEmbeddedEnabled(Boolean isEmbeddedEnabled) {
		this.isEmbeddedEnabled = isEmbeddedEnabled;
	}
	public String getBrandedUrl() {
		return brandedUrl;
	}
	public void setBrandedUrl(String brandedUrl) {
		this.brandedUrl = brandedUrl;
	}
	
	
}
