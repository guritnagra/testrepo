package com.vst.bridge.rest.response.vo.user;

public class BookLaunchActionVO extends BaseLicenseInfoVO {
	private String activeCredit;
	private Boolean allowReturn = Boolean.TRUE;

	public String getActiveCredit() {
		return activeCredit;
	}

	public void setActiveCredit(String activeCredit) {
		this.activeCredit = activeCredit;
	}

	public Boolean getAllowReturn() {
		return allowReturn;
	}

	public void setAllowReturn(Boolean allowReturn) {
		this.allowReturn = allowReturn;
	}

}
