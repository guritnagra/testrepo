package com.vst.bridge.dao.bridge.purchase;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.purchase.BridgePurchase;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgePurchaseDAO")
public class BridgePurchaseDAOImpl extends GenericDAO<BridgePurchase, Integer> implements IBridgePurchaseDAO{
	public BridgePurchaseDAOImpl() {
		super(BridgePurchase.class);
	}

	@Override
	public List<BridgePurchase> getBridgePurchases(Integer bridgeId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		List<BridgePurchase> result =  executeCriteira(criteria);
		return result;
	}

}
