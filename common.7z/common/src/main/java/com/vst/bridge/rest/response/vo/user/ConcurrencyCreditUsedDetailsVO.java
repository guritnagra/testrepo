package com.vst.bridge.rest.response.vo.user;

public class ConcurrencyCreditUsedDetailsVO {
	
	private Integer total;
	private Integer used = 0;
	private Integer unused;
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}
	public Integer getUsed() {
		return used;
	}
	public void setUsed(Integer used) {
		this.used = used;
	}
	public Integer getUnused() {
		return unused;
	}
	public void setUnused(Integer unused) {
		this.unused = unused;
	}
}
