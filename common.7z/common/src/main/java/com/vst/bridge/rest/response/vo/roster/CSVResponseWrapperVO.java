package com.vst.bridge.rest.response.vo.roster;

import org.supercsv.io.ICsvBeanReader;

import com.vst.bridge.rest.response.vo.RestResponse;

public class CSVResponseWrapperVO {
	private RestResponse response;
	
	private UploadRosterVO uploadRosterVO;
	
	private ICsvBeanReader beanReader;
	
	private String[] header;

	public RestResponse getResponse() {
		return response;
	}

	public void setResponse(RestResponse response) {
		this.response = response;
	}

	public UploadRosterVO getUploadRosterVO() {
		return uploadRosterVO;
	}

	public void setUploadRosterVO(UploadRosterVO uploadRosterVO) {
		this.uploadRosterVO = uploadRosterVO;
	}

	public ICsvBeanReader getBeanReader() {
		return beanReader;
	}

	public void setBeanReader(ICsvBeanReader beanReader) {
		this.beanReader = beanReader;
	}

	public String[] getHeader() {
		return header;
	}

	public void setHeader(String[] header) {
		this.header = header;
	}
	
	
	
}
