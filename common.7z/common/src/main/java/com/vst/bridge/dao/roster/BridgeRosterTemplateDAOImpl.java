package com.vst.bridge.dao.roster;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.roster.BridgeRosterTemplate;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeRosterTemplateDAO")
public class BridgeRosterTemplateDAOImpl extends GenericDAO<BridgeRosterTemplate, Integer> implements IBridgeRosterTemplateDAO {

	public BridgeRosterTemplateDAOImpl() {
		super(BridgeRosterTemplate.class);
	}
	
	@Override
	public BridgeRosterTemplate getByFileType(String name) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("name",name));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		List<BridgeRosterTemplate> result = executeCriteira(criteria);
		return null!=result && result.size() > 0? result.get(0) : null;
	}
}
