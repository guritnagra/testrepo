package com.vst.bridge.rest.input.vo;

import com.vst.bridge.annotation.custom.InputRequired;

/*
 * 			"entitlementName": "Get Book",
			"entitlementType": "Standard",
			"credit": "5",
			"isResuableCredit": true,
			"onlineDays": "",
			"onlineExpires": "12/25/16",
			"offlineDays": "",
			"offlineExpires": "12/25/16",
			"copyfromOnline":false
 */


public class EntitlementVO extends BaseEntitlementVO{
	@InputRequired(required=false)
	private Integer id;
	/*private String entitlementName;
	private String entitlementType;
	private Integer credit;*/
	private Boolean isReusableCredit=Boolean.FALSE;;
	/*private Integer onlineDays;
	private Long onlineExpires;
	private Integer offlineDays;
	private Long offlineExpires;
	private Boolean isCopyfromOnline=Boolean.FALSE;*/
	//private Boolean isConcurrencyCredit;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	/*public String getEntitlementName() {
		return entitlementName;
	}
	public void setEntitlementName(String entitlementName) {
		this.entitlementName = entitlementName;
	}
	public String getEntitlementType() {
		return entitlementType;
	}
	public void setEntitlementType(String entitlementType) {
		this.entitlementType = entitlementType;
	}
	public Integer getCredit() {
		return credit;
	}
	public void setCredit(Integer credit) {
		this.credit = credit;
	}*/
	
	public Boolean getIsReusableCredit() {
		return isReusableCredit;
	}
	public void setIsReusableCredit(Boolean isReusableCredit) {
		this.isReusableCredit = isReusableCredit;
	}
	/*public Integer getOnlineDays() {
		return onlineDays;
	}
	public void setOnlineDays(Integer onlineDays) {
		this.onlineDays = onlineDays;
	}
	public Long getOnlineExpires() {
		return onlineExpires;
	}
	public void setOnlineExpires(Long onlineExpires) {
		this.onlineExpires = onlineExpires;
	}
	public Integer getOfflineDays() {
		return offlineDays;
	}
	public void setOfflineDays(Integer offlineDays) {
		this.offlineDays = offlineDays;
	}
	public Long getOfflineExpires() {
		return offlineExpires;
	}
	public void setOfflineExpires(Long offlineExpires) {
		this.offlineExpires = offlineExpires;
	}
	
	public Boolean getIsCopyfromOnline() {
		return isCopyfromOnline;
	}
	public void setIsCopyfromOnline(Boolean isCopyfromOnline) {
		this.isCopyfromOnline = isCopyfromOnline;
	}*/
	/*public Boolean getIsConcurrencyCredit() {
		return isConcurrencyCredit;
	}
	public void setIsConcurrencyCredit(Boolean isConcurrencyCredit) {
		this.isConcurrencyCredit = isConcurrencyCredit;
	}*/
	
	
}
