package com.vst.bridge.dao.bridge.book;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.entity.bridge.books.BridgeBooks;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeBooksDAO")
public class BridgeBookDAOImpl extends GenericDAO<BridgeBooks,Integer> implements IBridgeBookDAO{
	public BridgeBookDAOImpl() {
		super(BridgeBooks.class);
	}

	@Override
	public List<String> getBookIdsForBridge(Integer bridgeId,boolean showAllBooks,boolean orderbyRecent)
			throws BridgeException {
		Criteria criteria = null;
		if(showAllBooks){
			criteria = getCriteria(BridgeBookCache.class);
		}else{
			criteria = getCriteria();
			criteria.add(Restrictions.eq("seleted", Boolean.TRUE));
		}
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		
		if(orderbyRecent){
			criteria.addOrder(Order.desc("lastModifiedDate"));
		}
		List<String> selectedBooks = new ArrayList<String>(0);
		if(showAllBooks){
			List<BridgeBookCache> result = executeCriteira(criteria);
			if(null != result && result.size() > 0){
				for(BridgeBookCache books : result){
					selectedBooks.add(books.getVbid());
				}
			}
		}else{
			List<BridgeBooks> result = executeCriteira(criteria);
			if(null != result && result.size() > 0){
				for(BridgeBooks books : result){
					selectedBooks.add(books.getBookVbid());
				}
			}
		}
		return selectedBooks;
	}

	@Override
	public List<BridgeBooks> getAllBooksForBridge(Integer bridgeId)
			throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.addOrder(Order.desc("lastModifiedDate"));
		return executeCriteira(criteria);
	}
}
