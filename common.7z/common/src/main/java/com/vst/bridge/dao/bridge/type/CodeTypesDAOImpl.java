package com.vst.bridge.dao.bridge.type;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.CodeTypes;
import com.vst.bridge.util.exception.BridgeException;

@Repository("codeTypesDAO")
public class CodeTypesDAOImpl extends GenericDAO<CodeTypes, Integer> implements ICodeTypesDAO {

	public CodeTypesDAOImpl() {
		super(CodeTypes.class);
		// TODO Auto-generated constructor stub
	}

	@Override
	public CodeTypes getCodeForType(String type) throws BridgeException {
		Criteria criteria = getCriteria();
		if(null != type){
			criteria.add(Restrictions.like("type", type));
		}
		List<CodeTypes> result =  executeCriteira(criteria);
		return result != null && result.size() > 0 ? result.get(0) : null ;
	}

}
