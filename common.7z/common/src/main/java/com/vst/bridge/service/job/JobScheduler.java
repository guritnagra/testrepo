package com.vst.bridge.service.job;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;



@Service("jobScheduler")
public class JobScheduler {
	
	private static Logger logger = LogManager.getLogger(JobScheduler.class);
	
	@Autowired
	protected IJobSchedulerServices jobSchedulerServices;

    @Scheduled(cron = "${cron_courseuser.expression}")
	public void executeCoursesAndUsersJobScheduler() {
    	logger.info("--------------Job STARTED--------------");    	
		jobSchedulerServices.populateUsersFromBC();
		logger.info("--------------Job FINISHED--------------");
	}
    
    @Scheduled(cron = "${kpi_data.expression}")
	public void executeKpiDataReportJobScheduler() {
    	logger.info("--------------KPI Report Job STARTED--------------");    	
		jobSchedulerServices.generateKpiDataReport();
		logger.info("--------------KPI Report Job FINISHED--------------");
	}

   
  
}
