package com.vst.bridge.service.user;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.user.UserDetailsVO;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiFieldException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;

public interface IUserEntityService {
	RestResponse createOrUpdateUser(SessionStatusVO sessionStatusVO, HttpServletRequest httpRequest,
			UserDetailsVO userDetailsVO, UriInfo uriInfo, String code, Boolean isNew, UserDetailsVO newDummyUser,
			Boolean isReferenceUser) throws BridgeException, ParseException, IOException, ConnectApiException,
			ConnectApiXmlException, ConnectApiFieldException, ConnectApiHttpException;
	
	RestResponse getGroups(SessionStatusVO sessionStatusVO,String code) throws BridgeException;
	
}
