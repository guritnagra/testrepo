package com.vst.bridge.rest.response.vo;

public class BridgeAccessTypeResponseVO {

	private Boolean pendingApproved = Boolean.TRUE;
	private Boolean derefedSignIn;
	private Boolean keysRequired;
	private Boolean isRostered=Boolean.FALSE;
	private Boolean isIntegrated;
	private Boolean isSampler;
	
	public Boolean getPendingApproved() {
		return pendingApproved;
	}
	public void setPendingApproved(Boolean pendingApproved) {
		this.pendingApproved = pendingApproved;
	}
	public Boolean getDerefedSignIn() {
		return derefedSignIn;
	}
	public void setDerefedSignIn(Boolean derefedSignIn) {
		this.derefedSignIn = derefedSignIn;
	}
	public Boolean getKeysRequired() {
		return keysRequired;
	}
	public void setKeysRequired(Boolean keysRequired) {
		this.keysRequired = keysRequired;
	}
	public Boolean getIsRostered() {
		return isRostered;
	}
	public void setIsRostered(Boolean isRostered) {
		this.isRostered = isRostered;
	}
	public Boolean getIsIntegrated() {
		return isIntegrated;
	}
	public void setIsIntegrated(Boolean isIntegrated) {
		this.isIntegrated = isIntegrated;
	}
	public Boolean getIsSampler() {
		return isSampler;
	}
	public void setIsSampler(Boolean isSampler) {
		this.isSampler = isSampler;
	}
	
}
