package com.vst.bridge.dao.admin.ancillary;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.admin.ancillary.Ancillary;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.rest.response.vo.page.PaginationVO;

public interface IAncillaryDAO extends IGenericDAO<Ancillary, Integer>{

	List<Ancillary> getAllAncillaries(Integer bridgeId, PaginationVO paginationVO);

	Ancillary getAncillaryByVbid(Integer bridgeId, String vbid);

	Ancillary getAncillaryById(Bridge bridge, Integer ancillaryId);

	Ancillary getAncillaryBySku(Integer bridgeId, String sku);

	List<Ancillary> getAllAncillaries(Integer bridgeId);

}
