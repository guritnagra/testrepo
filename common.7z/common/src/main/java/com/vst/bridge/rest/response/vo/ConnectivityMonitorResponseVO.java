package com.vst.bridge.rest.response.vo;

public class ConnectivityMonitorResponseVO {
	
	private Boolean success;
	private Boolean dbStatus=Boolean.FALSE;

	public Boolean getSuccess() {
		return success;
	}

	public void setSuccess(Boolean success) {
		this.success = success;
	}

	public Boolean getDbStatus() {
		return dbStatus;
	}

	public void setDbStatus(Boolean dbStatus) {
		this.dbStatus = dbStatus;
	}

}
