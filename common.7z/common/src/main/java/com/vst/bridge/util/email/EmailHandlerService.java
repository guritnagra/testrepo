package com.vst.bridge.util.email;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.vst.bridge.TomcatUtils;
import com.vst.bridge.entity.admin.allowance.BridgeAllowanceNotification;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.rest.response.vo.bridge.BridgeAdminResponseVO;
import com.vst.bridge.rest.response.vo.user.AdminInfoVo;
import com.vst.bridge.service.user.IUserAccessService;
import com.vst.bridge.util.bean.HipChatAttribute;
import com.vst.bridge.util.bean.HipChatCard;
import com.vst.bridge.util.bean.HipChatThumbnail;
import com.vst.bridge.util.bean.HipChatValue;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.bridge.util.message.TemplateBasedMessageGenerator;
import com.vst.bridge.util.message.TemplateLocationConstants;
import com.vst.connectapi.ApiKeys;
import com.vst.connectapi.ApiKeys.API_MODE;

@Component("emailHandlerService")
public class EmailHandlerService {

	@Autowired
	private TemplateBasedMessageGenerator messageGenerator;

	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private MailManager mailManager;

	private Executor executor = ExecutorUtility.getExecutorInstance();

	private List<String> bridgeDomainPostfix;

	@Autowired
	private IUserAccessService userLoginService;

	public EmailHandlerService() {
		String postfix = TomcatUtils.getParam("bridge-domain-postfix");
		if (null != postfix) {
			bridgeDomainPostfix = new ArrayList<String>();
			String[] postfixs = postfix.split(ApplicationConstants.BRIDGE_DOMAIN_POST_FIX_SEPERATOR);
			for (String string : postfixs) {
				bridgeDomainPostfix.add(string);
			}
		}
	}

	public void sendEmail(String templateName, Map<String, Object> paramMap) throws BridgeException {
		final String mailContent = this.messageGenerator.getMessage(templateName, paramMap);
		final MailMessage message = new MailMessage();
		message.setContent(mailContent);
		message.setMimeType(EMailType.HTML);
		final MailHeader mailHeader = new MailHeader();
		// Gurit-change 1 start //only if
		if (TemplateLocationConstants.RESET_PASSWORD_TEMPLATE.equals(templateName)) {
			// mailHeader.setFrom(TomcatUtils.getParam("resetpassword_from_email"));
			String to = (String) paramMap.get(ApplicationConstants.RESET_PASSWORD_TO);
			mailHeader.setTo(to);
			mailHeader.setSubject(
					localeMessageUtility.getMessage(ApplicationCode.EMAIL_RESET_PASSWORD_SUBJECT.getCodeId()));
			String from = TomcatUtils.getParam("resetpassword_from_email");
			mailHeader.setFrom(from);
		} else if (TemplateLocationConstants.NEW_BRIDGE_NOTIFICATION_TEMPLATE.equals(templateName)) { // Gurit-change 2
																										// added below
																										// condition
			// mailHeader.setFrom("dev-noreply@bridge.com");
			String from = TomcatUtils.getParam("newbridge_from_email");
			mailHeader.setFrom(from);
			String to = (String) paramMap.get(ApplicationConstants.NEW_BRIDGE_TO);
			mailHeader.setTo(to);
			mailHeader
					.setSubject(localeMessageUtility.getMessage(ApplicationCode.EMAIL_NEW_BRIDGE_SUBJECT.getCodeId()));

		} else if (TemplateLocationConstants.USER_ACCTIVATION_NOTIFICATION_TEMPLATE.equals(templateName)) {
			String from = TomcatUtils.getParam("newbridge_from_email");
			mailHeader.setFrom(from);
			String to = (String) paramMap.get(ApplicationConstants.RESET_PASSWORD_TO);
			mailHeader.setTo(to);
			mailHeader.setSubject(
					localeMessageUtility.getMessage(ApplicationCode.ROSTER_USER_ACTIVATION_MAIL_SUB.getCodeId()));
		} else if (TemplateLocationConstants.BRIDGE_ACCTIVATION_NOTIFICATION_TEMPLATE.equals(templateName)) {
			String from = TomcatUtils.getParam("newbridge_from_email");
			mailHeader.setFrom(from);
			String to = (String) paramMap.get(ApplicationConstants.NEW_BRIDGE_TO);
			mailHeader.setTo(to);
			mailHeader.setSubject(
					localeMessageUtility.getMessage(ApplicationCode.EMAIL_BRIDGE_ACTIVATION_SUBJECT.getCodeId()));

		} else if (TemplateLocationConstants.KPI_DATA_REPORT_TEMPLATE.equals(templateName)) {
			String from = TomcatUtils.getParam("newbridge_from_email");
			mailHeader.setFrom(from);
			String to = (String) paramMap.get(ApplicationConstants.NEW_BRIDGE_TO);
			mailHeader.setTo(to);
			String subject = ApplicationConstants.getApiMode() == API_MODE.prod
					? localeMessageUtility.getMessage(ApplicationCode.KPI_DATA_REPORT_SUBJECT_PROD.getCodeId())
					: ApplicationConstants.getApiMode() == API_MODE.stage
							? localeMessageUtility.getMessage(ApplicationCode.KPI_DATA_REPORT_SUBJECT_STAGE.getCodeId())
							: localeMessageUtility.getMessage(ApplicationCode.KPI_DATA_REPORT_SUBJECT_DEV.getCodeId());
			mailHeader.setSubject(subject);
		} else if (TemplateLocationConstants.BRIDGE_ALLOWANCE_NOTIFICATION_TEMPLATE.equals(templateName)) {
			String from = TomcatUtils.getParam("newbridge_from_email");
			mailHeader.setFrom(from);
			String to = (String) paramMap.get(ApplicationConstants.NEW_BRIDGE_TO);
			mailHeader.setTo(to);
			mailHeader.setSubject(localeMessageUtility
					.getMessage(ApplicationCode.EMAIL_BRIDGE_SETUP_NOTIFICATION_SUBJECT.getCodeId()));
		}

		final Mail mail = new Mail();
		mail.setMailMessage(message);
		mail.setMailHeader(mailHeader);
		mailManager.sendMail(mail);
	}

	/**** Email Notification method *******/
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void sendBridgeAllowanceNotificationEmail(final Bridge bridge, final List<AdminInfoVo> superAdmins,
			final BridgeAllowanceNotification lastBridgeAllowanceNotification) {

		final Runnable runnable = new Runnable() {

			@Override
			public void run() {
				userLoginService.sendNotificationMail(bridge, superAdmins, lastBridgeAllowanceNotification);
			}
		};
		this.executor.execute(runnable);
	}

	public void sendHipChatNotification(String templateName, Map<String, Object> paramMap) {
		final String mailContent = this.messageGenerator.getMessage(templateName, paramMap);
		String url = ApiKeys.getHipChatToken(ApplicationConstants.getApiMode());
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = getHeaders(getToken());
		JsonObject requestBody = new JsonObject();
		JsonElement  hipChatCard = getJsonHipChatNotification(paramMap);
		String notify = getHipChatNotify();
		requestBody.addProperty("color", "purple");
		requestBody.addProperty("message", mailContent);
		requestBody.addProperty("notify", notify);
		requestBody.addProperty("message_format", "text");
		requestBody.add("card",hipChatCard);

		HttpEntity<String> entity = new HttpEntity<String>(requestBody.toString(),
				headers);
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
	}

	private String getHipChatNotify() {
		String notify = "false";
		if ("PROD".equals(ApplicationConstants.getApiMode().name().toUpperCase()) || "STAGE".equals(ApplicationConstants.getApiMode().name().toUpperCase())) {
			notify = "true";
		}
		return notify;
	}

	private HttpHeaders getHeaders(String apiKey) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add(ApplicationConstants.AUTHORIZATION_HEADER, "Bearer " + apiKey);
		return headers;
	}

	private String getToken() {
		HipChatToken hipChatToken = HipChatToken.valueOf(ApplicationConstants.getApiMode().name().toUpperCase());
		String token = hipChatToken.getToken();
		if (null == token) {
			throw new BridgeException("Ancillary API Key Error", ApplicationCode.UNEXPECTED_ERROR);
		}
		return token;
	}

	public JsonElement getJsonHipChatNotification(Map<String, Object> paramMap) {
		String adminEmail = (String) paramMap.get(ApplicationConstants.NEW_BRIDGE_CONTACT_MAIL);
		String bridgeName = (String) paramMap.get(ApplicationConstants.NEW_BRIDGE_NAME);
		BridgeAdminResponseVO bridgeResponseVo = (BridgeAdminResponseVO) paramMap.get(ApplicationConstants.CODE);
		String url = (String) paramMap.get(ApplicationConstants.URL_COMPANY);
		HipChatCard hipChatCard = setHipChatCard(bridgeName, bridgeResponseVo, url);
		setHipChatThumbnail(hipChatCard);
		hipChatCard.setAttributes(setHipChatAttributes(adminEmail, bridgeName));
		Gson gson = new Gson();
		
	
		return gson.toJsonTree(hipChatCard);
	}

	private List<HipChatAttribute> setHipChatAttributes(String adminEmail, String bridgeName) {
		List<HipChatAttribute> attributes = new ArrayList<>();
		HipChatAttribute hipChatAtt1 = new HipChatAttribute();
		hipChatAtt1.setLabel("contact");
		HipChatValue hipChatValue = hipChatAtt1.getValue();
		hipChatValue.setLabel(adminEmail);
		hipChatValue.setStyle("lozenge-complete");

		HipChatAttribute hipChatAtt2 = new HipChatAttribute();
		hipChatValue = hipChatAtt2.getValue();
		hipChatAtt2.setLabel("bridge name");
		hipChatValue.setLabel(bridgeName);
		hipChatValue.setStyle("lozenge-complete");

		attributes.add(hipChatAtt1);
		attributes.add(hipChatAtt2);
		return attributes;
	}

	private void setHipChatThumbnail(HipChatCard hipChatCard) {
		HipChatThumbnail thubmnail = hipChatCard.getThumbnail();
		thubmnail.setUrl("http://bit.ly/2ubIKOF");
		thubmnail.setUrl2("http://bit.ly/2ubIKOF");
		thubmnail.setHeight(564);
		thubmnail.setWidth(1193);
	}

	private HipChatCard setHipChatCard(String bridgeName, BridgeAdminResponseVO bridgeResponseVo, String url) {
		HipChatCard hipChatCard = new HipChatCard();
		hipChatCard.setDescription(bridgeName + " is ready for activation");
		hipChatCard.setStyle("application");
		url = url.replaceAll("\\.local", "\\.com");
		url = url + "/#/bridge-details/"+bridgeResponseVo.getId()+"/basic-info";
		hipChatCard.setUrl(url);
		hipChatCard.setTitle("Bridge Activation Required");
		hipChatCard.getIcon().setUrl("http://bit.ly/2trD9VA");
		return hipChatCard;
	}

}
