package com.vst.bridge.util;

import org.apache.commons.lang.StringUtils;


public class DisplayPricing {
	
	private String eTextPriceType;
	private String rentalPriceType;
	private String textBookPriceType;
	public String geteTextPriceType() {
		return eTextPriceType;
	}
	public void seteTextPriceType(String eTextPriceType) {
		if(StringUtils.isNotEmpty(eTextPriceType))
			this.eTextPriceType = eTextPriceType.toUpperCase();
		/*else
			this.eTextPriceType=ApplicationConstants.DIGITAL_PRICE_TYPE;*/
	}
	public String getRentalPriceType() {
		return rentalPriceType;
	}
	public void setRentalPriceType(String rentalPriceType) {
		if(StringUtils.isNotEmpty(rentalPriceType))
			this.rentalPriceType = rentalPriceType.toUpperCase();
		/*else
			this.rentalPriceType=ApplicationConstants.DIGITAL_PRICE_TYPE;*/
		
	}
	public String getTextBookPriceType() {
		return textBookPriceType;
	}
	public void setTextBookPriceType(String textBookPriceType) {
		if(StringUtils.isNotEmpty(textBookPriceType))
			this.textBookPriceType = textBookPriceType.toUpperCase();
		/*else
			this.textBookPriceType=ApplicationConstants.PUBLISHER_PRICE_TYPE;*/
		
	}
	
	
	

}
