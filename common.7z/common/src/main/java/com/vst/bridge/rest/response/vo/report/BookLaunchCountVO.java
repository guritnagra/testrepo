package com.vst.bridge.rest.response.vo.report;

public class BookLaunchCountVO {
	private Long count;
	private String vbid;
	public Long getCount() {
		return count;
	}
	public void setCount(Long count) {
		this.count = count;
	}
	public String getVbid() {
		return vbid;
	}
	public void setVbid(String vbid) {
		this.vbid = vbid;
	}
	
}
