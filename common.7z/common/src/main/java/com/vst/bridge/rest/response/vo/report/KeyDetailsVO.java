package com.vst.bridge.rest.response.vo.report;

import java.util.Date;

public class KeyDetailsVO {
	private Integer totalUsed;
	private Integer numUsersPerKey;
	private String code;
	private String role;
	private Date createdDate;
	private Long created;
	private Long expires;
	private Date expiresDate;
	
	public Integer getTotalUsed() {
		return totalUsed;
	}
	public void setTotalUsed(Integer totalUsed) {
		this.totalUsed = totalUsed;
	}
	public Integer getNumUsersPerKey() {
		return numUsersPerKey;
	}
	public void setNumUsersPerKey(Integer numUsersPerKey) {
		this.numUsersPerKey = numUsersPerKey;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Long getCreated() {
		return created;
	}
	public void setCreated(Long created) {
		this.created = created;
	}
	public Long getExpires() {
		return expires;
	}
	public void setExpires(Long expires) {
		this.expires = expires;
	}
	public Date getExpiresDate() {
		return expiresDate;
	}
	public void setExpiresDate(Date expiresDate) {
		this.expiresDate = expiresDate;
	}
	
}
