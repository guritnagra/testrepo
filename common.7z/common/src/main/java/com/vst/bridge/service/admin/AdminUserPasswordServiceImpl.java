package com.vst.bridge.service.admin;

import java.io.IOException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.JsonUtils;
import com.vst.bridge.VstUtils;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.admin.password.IAdminUserPasswordDAO;
import com.vst.bridge.entity.admin.password.ResetPassword;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.rest.input.vo.LoginInfoVO;
import com.vst.bridge.rest.response.vo.AdminResetPasswordVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.date.DateUtility;
import com.vst.bridge.util.email.EmailHandlerService;
import com.vst.bridge.util.error.ErrorHandlerUtil;
import com.vst.bridge.util.error.ResponseError;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.bridge.util.message.TemplateLocationConstants;

@Service("adminUserPasswordService")
public class AdminUserPasswordServiceImpl implements IAdminUserPasswordService {
	@Autowired
	private IAdminUserDAO adminUserDAO;

	@Autowired
	private IAdminUserPasswordDAO resetPasswordDAO;

	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private ErrorHandlerUtil errorHandlerUtility;

	@Autowired
	private EmailHandlerService emailHandler;

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse resetPassword(AdminResetPasswordVO resetPasswordVO, HttpServletRequest httpRequest,
			UriInfo uriInfo) throws BridgeException, ParseException, IOException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if (null != resetPasswordVO) {
			String email = resetPasswordVO.getEmail();
			final String domain = VstUtils.getDomain(uriInfo, httpRequest);
			String resetUrl = httpRequest.getRequestURL().toString();
			resetUrl = resetUrl.substring(0, resetUrl.indexOf("//")) + "//" + domain + "/#/admin/resetPassword?token=";
			if (null != email && !StringUtils.isEmpty(email) && adminUserDAO.checkEmailExistInDb(email)) {
				if (StringUtils.isBlank(resetUrl)) {
					response = new RestResponse(Response.Status.BAD_REQUEST.getStatusCode(),
							ApplicationCode.NO_SUCH_WEBSITE.getCodeId(),
							localeMessageUtility.getMessage(ApplicationCode.NO_SUCH_WEBSITE.getCodeId()));
				} else {
					/*
					 * String fullurl = uri.resolve(resetUrl.replace("${token}",
					 * "@@TOKEN@@")).toURL() .toString().replace("@@TOKEN@@",
					 * "${token}");
					 */
					AdminUser adminUser = adminUserDAO.getForEmail(email);
					if (null != adminUser) {

						List<ResetPassword> oldResetRequestList = resetPasswordDAO.getListByAdminId(adminUser.getId(),
								Boolean.FALSE);
						if (null != oldResetRequestList && oldResetRequestList.size() > 0) {
							for (ResetPassword emailToken : oldResetRequestList) {
								emailToken.setDeleted(Boolean.TRUE);
							}
						}
						String token = UUID.randomUUID().toString();
						ResetPassword resetPassword = new ResetPassword();
						resetPassword.setAdmin(adminUser);
						resetPassword.setToken(token);
						resetPasswordDAO.create(resetPassword);

						final Map<String, Object> paramMap = new HashMap<String, Object>();
						paramMap.put(ApplicationConstants.RESET_PASSWORD_TO, email);
						paramMap.put(ApplicationConstants.RESET_PASSWORD_USER_NAME, com.vst.bridge.StringUtils
								.getFullName(adminUser.getFirstName(), adminUser.getLastName()));
						paramMap.put(ApplicationConstants.RESET_PASSWORD_URL, resetUrl + token);
						emailHandler.sendEmail(TemplateLocationConstants.RESET_PASSWORD_TEMPLATE, paramMap);
						response = new RestResponse(Response.Status.CREATED.getStatusCode(),
								ApplicationCode.STATUS_OK.getCodeId(),
								localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
						response.setData(resetPasswordVO);
					}
				}
			} else {
				response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(),
						ApplicationCode.USER_NOT_FOUND.getCodeId(),
						localeMessageUtility.getMessage(ApplicationCode.USER_NOT_FOUND.getCodeId()));
			}
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse updateResetPassword(LoginInfoVO loginInfoVO, String token, HttpServletRequest httpRequest,
			UriInfo uriInfo) throws BridgeException, ParseException, IOException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if (null != loginInfoVO) {
			ResponseError responseError = errorHandlerUtility
					.validateAdminLoginInputParameters(JsonUtils.getJsonString(loginInfoVO));
			if (null == responseError) {
				String email = loginInfoVO.getEmail();
				AdminUser user = null;
				if (null != email && !StringUtils.isEmpty(email)) {
					user = adminUserDAO.getForEmail(email);
				}
				if (null != user) {
					ResetPassword resetPassword = resetPasswordDAO.getPasswordForAdminId(user.getId(), token,
							Boolean.FALSE);
					if (null != resetPassword) {
						Date resetTime = resetPassword.getCreatedDate();
						Calendar calendar = DateUtility.DateToCalendar(resetTime);
						calendar.add(Calendar.DATE, 1);
						if (resetTime.getTime() < calendar.getTime().getTime()) {
							resetPassword.setUsed(Boolean.TRUE);
							resetPasswordDAO.update(resetPassword);
							user.setPassword(com.vst.bridge.StringUtils.hash(loginInfoVO.getPassword()));
							adminUserDAO.update(user);
						} else {
							response = new RestResponse(Response.Status.EXPECTATION_FAILED.getStatusCode(),
									ApplicationCode.RESET_PASSWORD_TOKEN_EXPIRE.getCodeId(), localeMessageUtility
											.getMessage(ApplicationCode.RESET_PASSWORD_TOKEN_EXPIRE.getCodeId()));
						}
					} else {
						response = new RestResponse(Response.Status.EXPECTATION_FAILED.getStatusCode(),
								ApplicationCode.RESET_PASSWORD_TOKEN_EXPIRE.getCodeId(), localeMessageUtility
										.getMessage(ApplicationCode.RESET_PASSWORD_TOKEN_EXPIRE.getCodeId()));
					}
				}
			} else {
				response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
				response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
				response.setError(responseError);
			}
		}
		return response;
	}
}
