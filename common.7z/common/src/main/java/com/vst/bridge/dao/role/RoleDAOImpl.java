package com.vst.bridge.dao.role;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.user.Role;
import com.vst.bridge.util.exception.BridgeException;

@Repository("roleDAO")
public class RoleDAOImpl extends GenericDAO<Role, Integer> implements IRoleDAO{

	public RoleDAOImpl() {
		super(Role.class);
	}

	@Override
	public Role getRoleByName(String name) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("name",name));
		List<Role> result = executeCriteira(criteria);
		return null!=result && result.size() > 0? result.get(0) : null;
	}

}
