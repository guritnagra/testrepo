package com.vst.bridge.dao.log;

import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.log.BridgeRosterLog;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeRosterLogDAO extends IGenericDAO<BridgeRosterLog, Integer>{
	public BridgeRosterLog getRosterLogByURL(String fileURL) throws BridgeException;

	public List<BridgeRosterLog> getAllBridgeRosterLog(Integer bridgeId)throws BridgeException;
}
