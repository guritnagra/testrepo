package com.vst.bridge.rest.response.vo.bridge.user;

import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.vst.bridge.annotation.custom.CustomDateSerializer;
import com.vst.bridge.rest.response.vo.group.user.BridgeGroupUserResponseVO;

public class BridgeUserResponseVO extends BridgeGroupUserResponseVO {
	
    private Boolean isGroupMember=false;
	private Date activationDate;
	private long activationTime;
	private String tenantUserId;
	public Boolean getIsGroupMember() {
		return isGroupMember;
	}

	public void setIsGroupMember(Boolean isGroupMember) {
		this.isGroupMember = isGroupMember;
	}
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getActivationDate() {
		return activationDate;
	}

	public void setActivationDate(Date activationDate) {
		this.activationDate = activationDate;
	}

	public long getActivationTime() {
		return activationTime;
	}

	public void setActivationTime(long activationTime) {
		this.activationTime = activationTime;
	}

	public String getTenantUserId() {
		return tenantUserId;
	}

	public void setTenantUserId(String tenantUserId) {
		this.tenantUserId = tenantUserId;
	}

	

	

	

}
