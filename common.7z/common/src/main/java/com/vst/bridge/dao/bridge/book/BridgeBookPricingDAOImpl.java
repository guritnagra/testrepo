package com.vst.bridge.dao.bridge.book;

import java.util.Collection;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.entity.bridge.books.BridgeBookPricing;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeBookPricingDAO")
public class BridgeBookPricingDAOImpl extends GenericDAO<BridgeBookPricing,Integer> implements IBridgeBookPricingDAO{

	public BridgeBookPricingDAOImpl() {
		super(BridgeBookPricing.class);
	}

	@Override
	public BridgeBookPricing getBookPricingbySku(Integer cacheId, String sku) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bookCache.id", cacheId));
		criteria.add(Restrictions.like("sku", sku));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		List<BridgeBookPricing> result =  executeCriteira(criteria);
		return null!=result && result.size() >0 ? result.get(0) : null;
	}

	@Override
	public List<BridgeBookPricing> getBookPricingByCacheId(Integer cacheId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bookCache.id", cacheId));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));		
		return executeCriteira(criteria);
	}

	@Override
	public BridgeBookPricing getBookPricingByRentalType(Integer cacheId, String rentalType) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bookCache.id", cacheId));
		if(rentalType!=null)
			criteria.add(Restrictions.like("priceType",rentalType));
		else
			criteria.add(Restrictions.isNull("priceType"));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		List<BridgeBookPricing> result =  executeCriteira(criteria);
		return null!=result && result.size() >0 ? result.get(0) : null;
	}
	
	@Override
	public List<BridgeBookPricing> getBookPricingByCacheIds(List<Integer> cacheIdList) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.in("bookCache.id", cacheIdList));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));		
		return executeCriteira(criteria);
	}
	
	@Override
	public List<BridgeBookPricing> getBookPricingBySkus(Collection<String> skuList) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.in("sku", skuList));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));		
		return executeCriteira(criteria);
	}

	@Override
	public List<BridgeBookPricing> getBookPricingByCacheCollection(Collection<BridgeBookCache> bookCacheCollection) {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.in("bookCache", bookCacheCollection));
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));		
		return executeCriteira(criteria);
	}
	
}
