package com.vst.bridge.dao.group;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.group.Group;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;

@Repository("groupDAO")
public class GroupDAOImpl extends GenericDAO<Group, Integer> implements IGroupDAO{

	public GroupDAOImpl() {
		super(Group.class);
	}

	@Override
	public List<Group> getAllGroups() throws BridgeException {
		Criteria criteria = getCriteria();
		return executeCriteira(criteria);
	}

	@Override
	public Group getGroupForName(String name) throws BridgeException {
		Criteria criteria = getCriteria();
		if(null != name){
			criteria.add(Restrictions.like("name", name));
		}
		List<Group> result =  executeCriteira(criteria);
		return result != null && result.size() > 0 ? result.get(0) : null ;
	}

	@Override
	public void checkGroupNameExist(String name) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.like("name", name.trim()));
		List<Bridge> result = executeCriteira(criteria);
		 if(null != result && result.size() > 0){
			 throw new BridgeException(ApplicationCode.DUPLICATE_GROUP_NAME);
		 }
	}
}
