package com.vst.bridge.service.book;

import javax.servlet.http.HttpServletRequest;

import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.bridge.BridgeBooksVO;
import com.vst.bridge.util.exception.BridgeException;

public interface IBookAncillaryService {
	RestResponse updateBridgeBookAncillaryTitle(Integer bridgeId, BridgeBooksVO bridgeBooksVO,
			String vbid, HttpServletRequest httpRequest) throws BridgeException;
}
