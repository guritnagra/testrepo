package com.vst.bridge.service.bc;

import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.JDOMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vst.bridge.VstUtils;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.bc.IContextTokenDAO;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupUserDAO;
import com.vst.bridge.dao.job.IJobTaskDAO;
import com.vst.bridge.dao.role.IRoleDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bc.ContextToken;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.Role;
import com.vst.bridge.entity.group.BridgeGroup;
import com.vst.bridge.entity.group.GroupUser;
import com.vst.bridge.entity.job.JobTask;
import com.vst.bridge.rest.response.vo.BCCourseVO;
import com.vst.bridge.rest.response.vo.BCUserVO;
import com.vst.bridge.rest.response.vo.ContextVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.TenantVO;
import com.vst.bridge.rest.response.vo.user.IntegratedBridgeUserResponseVO;
import com.vst.bridge.service.admin.AdminUserServiceUtil;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.constant.PermissionAction;
import com.vst.bridge.util.constant.ApplicationConstants.JobStatus;
import com.vst.bridge.util.date.DateUtility;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.exception.BusinessCenterException;
import com.vst.bridge.util.exception.IntegrationException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.connectapi.ApiKeys;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;

@Service("businessCenterServices")
public class BusinessCenterServicesImpl implements IBusinessCenterServices {

	private static Logger logger = LogManager.getLogger(BusinessCenterServicesImpl.class);

	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private IBridgeDAO bridgeDAO;

	@Autowired
	protected ObjectMapper objectMapper;

	@Autowired
	private IBridgeGroupDAO bridgeGroupDAO;

	@Autowired
	private IAdminUserDAO adminUserDAO;

	@Autowired
	private IContextTokenDAO contextTokenDAO;

	@Autowired
	private IBridgeUserDAO bridgeUserDAO;

	@Autowired
	private IBridgeGroupUserDAO bridgeGroupUserDAO;

	@Autowired
	private IRoleDAO roleDAO;

	@Autowired
	private IJobTaskDAO jobTaskDAO;
	
	@Autowired
	private AdminUserServiceUtil adminUserServiceUtil;

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, isolation = Isolation.READ_COMMITTED, readOnly = false)
	public RestResponse createOrUpdateCoursesForTenantId(SessionStatusVO sessionStatusVO, Integer bridgeId,
			Integer tenantId, HttpServletRequest httpRequest, UriInfo uriInfo, JobTask jobTask, Boolean isJobScheduler)
			throws IOException, BridgeException, BusinessCenterException, ConnectApiException, JDOMException,
			ParseException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		AdminUser adminUser = adminUserDAO.get(sessionStatusVO.getAdminId());
		adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_MANAGE, adminUser);
		if (null != bridgeId) {
			Bridge bridge = bridgeDAO.get(bridgeId);
			if (bridge == null) {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			if (null != tenantId) {
				if (bridge.getBcTenantId() != null && tenantId.equals(bridge.getBcTenantId())) {

					try {

						String url = ApiKeys.getBusinessCenterUrl(ApplicationConstants.getApiMode())
								+ ApplicationConstants.COURSES;
						Map<String, String> paramMap = new HashMap<String, String>();
						paramMap.put(ApplicationConstants.TENANT_ID, tenantId.toString());
						ResponseEntity<String> bcCoursesResponse = callBcApi(bridge, paramMap, url, HttpMethod.GET);
						String responseBody = bcCoursesResponse.getBody();
						JsonNode node;
						List<BCCourseVO> courseList;

						if (bcCoursesResponse.getStatusCode() != HttpStatus.OK) {
							throw new BusinessCenterException("Status returned " + bcCoursesResponse.getStatusCode(),
									ApplicationCode.UNEXPECTED_ERROR);
						} else {

							node = objectMapper.readValue(responseBody, JsonNode.class);
							courseList = objectMapper.readValue(node.get("courses").toString(), objectMapper
									.getTypeFactory().constructCollectionType(List.class, BCCourseVO.class));

						}

						refreshBridgeGroupsAndUsers(tenantId, adminUser, bridge, courseList);

					} catch (HttpClientErrorException e) {
						if (isJobScheduler) {
							jobTask.setJobStatus(JobStatus.ERROR.name());
							jobTaskDAO.saveOrUpdate(jobTask);
						} else {
							throw new BusinessCenterException(ApplicationCode.UNEXPECTED_ERROR);
						}
					}
				} else {
					throw new BridgeException(ApplicationCode.TENANT_NOT_VALID);
				}
			} else {
				throw new BridgeException(ApplicationCode.TENANT_NOT_VALID);
			}
		} else {
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		return response;
	}

	private void refreshBridgeGroupsAndUsers(Integer tenantId, AdminUser adminUser, Bridge bridge,
			List<BCCourseVO> courseList) throws JsonParseException, JsonMappingException, IOException {
		refreshCoursesForTenantId(courseList, adminUser, bridge);
		List<BCUserVO> bcUserList = refreshUsersForTenantId(adminUser, bridge, tenantId);
		refreshGroupUsersForTenantId(bcUserList, bridge);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false)
	public List<BCUserVO> refreshUsersForTenantId(AdminUser adminUser, Bridge bridge, Integer tenantId)
			throws JsonParseException, JsonMappingException, IOException {
		List<BCUserVO> bcUserList = getUsersForTenantFromBc(tenantId, bridge);
		updateBridgeUsersFromBCUsers(adminUser.getId(), bridge, bcUserList);
		return bcUserList;
	}

	private void refreshGroupUsersForTenantId(List<BCUserVO> bcUserList, Bridge bridge) {
		int batchSize = 0;
		int deletedGroupUsers = bridgeGroupUserDAO.deleteAllGroupUsersForBridge(bridge);
		logger.info(deletedGroupUsers + " user groups marked deleted for " + bridge);
		for (int i = 0; i < bcUserList.size(); i++) {
			BCUserVO bcUserVO = bcUserList.get(i);
			List<String> bcCourseIdList = bcUserVO.getCourseIds();
			logger.info(
					"Courses for BC user with tenant user id: " + bcUserVO.getId() + " | " + bcUserVO.getCourseIds());
			if (null == bcCourseIdList || bcCourseIdList.isEmpty()) {
				logger.info("No courses for BC user with tenant user id: " + bcUserVO.getId());
				continue;
			}

			BridgeUser bridgeUser = bridgeUserDAO.getBridgeUserByTenantUser(bcUserVO, bridge.getId());
			if (bridgeUser != null) {

				for (String bcCourseId : bcCourseIdList) {
					BridgeGroup bridgeGroup = bridgeGroupDAO.getGroupByCourseId(bridge.getId(), bcCourseId);
					if (null != bridgeGroup) {
						updateGroupUserFromBcUser(bridge, bridgeGroup, bcUserVO);

					} else {
						logger.warn("There was no bridge group found for BC course with id: " + bcCourseId);
					}
				}

			} else {
				logger.warn("No bridge user for BC user with tenant id: " + bcUserVO.getTenantId());
			}
			if (++batchSize % 50 == 0) {
				bridgeGroupUserDAO.flushAndClear();
				logger.info("Batch clear and flush " + batchSize + " for updating bridge user groups on bridge id: "
						+ bridge.getId());
			}
		}
		logger.info("User groups refresh completed for bridge with id: " + bridge.getId());

	}

	@Deprecated
	@SuppressWarnings("unused")
	private void refreshGroupUsersForTenantId(Set<BCCourseVO> courseSet, Bridge bridge)
			throws JsonParseException, JsonMappingException, IOException {

		for (BCCourseVO bcCourse : courseSet) {
			String courseId = bcCourse.getId();
			BridgeGroup bridgeGroup = bridgeGroupDAO.getGroupByCourseId(bridge.getId(), courseId);

			if (null != bridgeGroup) {
				int deletedGroupUserNum = bridgeGroupUserDAO.deleteGroupUsersForGroup(bridgeGroup.getId());
				logger.info(deletedGroupUserNum + " group users marked deleted");
				Map<String, String> paramMap = new HashMap<String, String>();
				paramMap.put(ApplicationConstants.TENANT_ID, bridge.getBcTenantId().toString());
				paramMap.put(ApplicationConstants.COURSE_ID, bridgeGroup.getCourseId());

				String usersUrl = ApiKeys.getBusinessCenterUrl(ApplicationConstants.getApiMode())
						+ ApplicationConstants.BC_USERS;
				ResponseEntity<String> bcUsersResponse = callBcApi(bridge, paramMap, usersUrl, HttpMethod.GET);
				String bcUsersResponseBody = bcUsersResponse.getBody();
				JsonNode userNode;
				List<BCUserVO> userList;

				if (bcUsersResponse.getStatusCode() != HttpStatus.OK) {
					throw new BusinessCenterException(ApplicationCode.UNEXPECTED_ERROR);
				} else {
					userNode = objectMapper.readValue(bcUsersResponseBody, JsonNode.class);
					userList = objectMapper.readValue(userNode.get("users").toString(),
							objectMapper.getTypeFactory().constructCollectionType(List.class, BCUserVO.class));
				}

				if (null != userList) {
					for (BCUserVO bcUserVO : userList) {
						if (StringUtils.equals(bridge.getBcTenantId().toString(), bcUserVO.getTenantId())) {
							updateGroupUserFromBcUser(bridge, bridgeGroup, bcUserVO);
						}
					}
				}
			}
		}
	}

	private void refreshCoursesForTenantId(List<BCCourseVO> bcCourseList, AdminUser adminUser, Bridge bridge) {
		int deletedCourses = bridgeGroupDAO.deleteAllGroupsForBridge(bridge, adminUser);
		logger.info("Number of courses marked deleted: " + deletedCourses + " for " + bridge);
		Calendar cal = Calendar.getInstance();
		cal.set(2016, Calendar.AUGUST, 20);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
		int batchSize = 0;
		if (bridge.getId().intValue() == 239 && bridge.getBcTenantId().intValue() == 10059) {
			logger.warn("Refreshing groups for bridge id: " + bridge.getId() + " with tenant id: "
					+ bridge.getBcTenantId() + " from " + cal.getTime());
			for (int i = 0; i < bcCourseList.size(); i++) {
				try {
					BCCourseVO bcCourseVO = bcCourseList.get(i);
					Date cutoffDate = formatter.parse(bcCourseVO.getUpdatedAt().replaceAll("Z$", "+0000"));
					if (Boolean.valueOf(bcCourseVO.getActive()) && cutoffDate.after(cal.getTime())) {
						try {
							createOrUpdateBridgeGroupsFromBcCourseRefresh(bcCourseVO, bridge, adminUser);

							if (++batchSize % 50 == 0) {
								bridgeGroupDAO.flushAndClear();
								logger.info("Batch clear and flush " + batchSize + " for updating groups on bridge id: "
										+ bridge.getId());
							}
						} catch (BridgeException e) {
							logger.error("There was an issue refreshing a course for for bridge id: " + bridge.getId()
									+ " with tenant id: " + bridge.getBcTenantId(), e);
						}
					} else {
						logger.info("BC course with id:" + bcCourseVO.getId() + "with modified date before cutoff date "
								+ cal.getTime() + " ignored for bridge id: " + bridge.getId() + " with tenant id: "
								+ bridge.getBcTenantId());
						continue;
					}
				} catch (ParseException e) {
					logger.info("There was an error parsing cutoff date for course refresh on bridge id:"
							+ bridge.getId() + " with tenant id: " + bridge.getBcTenantId());
				}
			}
		} else {
			// plain for loop may provide a performance improvement over enhance
			// for loop
			for (int i = 0; i < bcCourseList.size(); i++) {
				try {
					BCCourseVO course = bcCourseList.get(i);
					createOrUpdateBridgeGroupsFromBcCourseRefresh(course, bridge, adminUser);
					if (++batchSize % 50 == 0) {
						bridgeGroupDAO.flushAndClear();
						logger.info("Batch clear and flush " + batchSize + " for updating groups on bridge id: "
								+ bridge.getId());
					}
				} catch (BridgeException e) {
					logger.error("There was an issue refreshing a course for for bridge id: " + bridge.getId()
							+ " with tenant id: " + bridge.getBcTenantId(), e);
				}

			}
		}
		logger.info("Courses refresh complete for bridge with id: " + bridge.getId());
	}

	@Deprecated
	@SuppressWarnings("unused")
	private void refreshCoursesForTenantId(Set<BCCourseVO> bcCourseSet, AdminUser adminUser, Bridge bridge)
			throws JsonParseException, JsonMappingException, IOException {
		int deletedCourses = bridgeGroupDAO.deleteAllGroupsForBridge(bridge, adminUser);
		logger.info("Number of courses marked deleted: " + deletedCourses + " for Bridge with id: " + bridge.getId());
		Calendar cal = Calendar.getInstance();
		cal.set(2016, Calendar.AUGUST, 20);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
		int batchSize = 0;
		if (bridge.getId().intValue() == 239 && bridge.getBcTenantId().intValue() == 100059) {

			logger.warn("Refreshing groups for bridge id: " + bridge.getId() + " with tenant id: "
					+ bridge.getBcTenantId() + " from " + cal.getTime());
			for (Iterator<BCCourseVO> bcCourseIt = bcCourseSet.iterator(); bcCourseIt.hasNext();) {
				BCCourseVO course = bcCourseIt.next();
				try {
					Date cutoffDate = formatter.parse(course.getUpdatedAt().replaceAll("Z$", "+0000"));
					if (Boolean.valueOf(course.getActive()) && cutoffDate.after(cal.getTime())) {
						try {
							createOrUpdateBridgeGroupsFromBcCourseRefresh(course, bridge, adminUser);
							if (++batchSize % 50 == 0) {
								bridgeGroupDAO.flushAndClear();
								logger.info("Batch clear and flush " + batchSize + " for updating groups on bridge id: "
										+ bridge.getId());
							}
						} catch (BridgeException e) {
							logger.error("There was an issue refreshing a course for for bridge id: " + bridge.getId()
									+ " with tenant id: " + bridge.getBcTenantId(), e);
						}
					} else {
						bcCourseIt.remove();
						logger.info("BC course with id:" + course.getId() + "with modified date before cutoff date "
								+ cal.getTime() + " ignored for bridge id: " + bridge.getId() + " with tenant id: "
								+ bridge.getBcTenantId());
						continue;
					}
				} catch (ParseException e) {
					logger.info("There was an error parsing cutoff date for course refresh on bridge id:"
							+ bridge.getId() + " with tenant id: " + bridge.getBcTenantId());
				}

			}
		} else {
			for (BCCourseVO course : bcCourseSet) {
				try {
					createOrUpdateBridgeGroupsFromBcCourseRefresh(course, bridge, adminUser);
					if (++batchSize % 50 == 0) {
						bridgeGroupDAO.flushAndClear();
						logger.info("Batch clear and flush " + batchSize + " for updating groups on bridge id: "
								+ bridge.getId());
					}
				} catch (BridgeException e) {
					logger.error("There was an issue refreshing a course for for bridge id: " + bridge.getId()
							+ " with tenant id: " + bridge.getBcTenantId(), e);
				}

			}
		}
	}

	private void createOrUpdateBridgeGroupsFromBcCourseRefresh(BCCourseVO bcCourseVO, Bridge bridge,
			AdminUser adminUser) {
		BridgeGroup bridgeGroup = bridgeGroupDAO.getGroupByCourseId(bridge.getId(), bcCourseVO.getId());
		bridgeGroup = bridgeGroup != null ? bridgeGroup : new BridgeGroup();
		if (bridgeGroup.getId() == null) {
			bridgeGroup.setCreatedBy(adminUser);
			bridgeGroup.setCreatedDate(new Date());
			bridgeGroup.setModifiedBy(adminUser);
			bridgeGroup.setModifiedDate(bridgeGroup.getCreatedDate());
		} else {
			bridgeGroup.setModifiedBy(adminUser);
			bridgeGroup.setModifiedDate(new Date());
		}
		bridgeGroup.setBridge(bridge);
		this.populateBCGroupVO(bcCourseVO, bridgeGroup, bridge);
		try {
			if (null == bridgeGroup.getId()) {
				bridgeGroupDAO.saveOrUpdate(bridgeGroup);
			}
			logger.info(null == bridgeGroup.getId() ? "Group created from BC with courseId: "
					: "Group restored from BC with courseId: " + bridgeGroup.getCourseId() + " for Bridge with Id: "
							+ bridge.getId());
		} catch (BridgeException e) {
			logger.error("There was an error adding bridge group with id: " + bridgeGroup.getId(), e);
		}
	}

	private void populateBCGroupVO(BCCourseVO bcCourse, BridgeGroup bridgeGroup, Bridge bridge) {
		bridgeGroup.setCourseId(bcCourse.getId());
		if (StringUtils.isNotEmpty(bcCourse.getFriendlyName())) {
			bridgeGroup.setName(bcCourse.getFriendlyName());
		} else if (StringUtils.isNotEmpty(bcCourse.getTitle())) {
			bridgeGroup.setName(bcCourse.getTitle());
		} else if (StringUtils.isNotEmpty(bcCourse.getLabel())) {
			bridgeGroup.setName(bcCourse.getLabel());
		} else if (!StringUtils.isNotEmpty(bcCourse.getIdentifier())) {
			bridgeGroup.setName(bcCourse.getIdentifier());
		} else {

			bridgeGroup.setName(bcCourse.getId());
		}
		if (bcCourse.getStartDate() != null) {
			Date startDate = DateUtility.getDateStartOfDay(DateUtility.convertStringToDate(bcCourse.getStartDate()));
			bridgeGroup.setStartDate(startDate);
		}
		if (bcCourse.getEndDate() != null) {
			Date endDate = DateUtility.getDateEndOfDay(DateUtility.convertStringToDate(bcCourse.getEndDate()));
			bridgeGroup.setExpiredDate(endDate);
		}
		if (bcCourse.getActive() != null) {
			if (bcCourse.getActive().equalsIgnoreCase("true")) {
				bridgeGroup.setIsActive(Boolean.TRUE);
			} else {
				bridgeGroup.setIsActive(Boolean.FALSE);
			}
		}
		bridgeGroup.setBridge(bridge);
		bridgeGroup.setDeleted(Boolean.FALSE);
		bridgeGroup.setDeletedBy(null);
		bridgeGroup.setDeletedDate(null);
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public RestResponse getTenant(Integer tenantId, String apiKey)
			throws BusinessCenterException, JsonParseException, JsonMappingException, IOException {

		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		String url = ApiKeys.getBusinessCenterUrl(ApplicationConstants.getApiMode()) + ApplicationConstants.TENANT;
		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders headers = getHeaders(apiKey);
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

		Map<String, Integer> paramMap = new HashMap<String, Integer>();
		paramMap.put(ApplicationConstants.TENANT_ID, tenantId);

		try {
			ResponseEntity<String> bcResponse = restTemplate.exchange(url, HttpMethod.GET, entity, String.class,
					paramMap);
			if (bcResponse.getStatusCode() != HttpStatus.OK) {
				throw new BusinessCenterException(ApplicationCode.UNEXPECTED_ERROR);
			}
			String responseBody = bcResponse.getBody();
			JsonNode node;
			TenantVO tenantVO = null;
			node = objectMapper.readValue(responseBody, JsonNode.class);
			tenantVO = objectMapper.readValue(node.get("tenant").toString(), TenantVO.class);
			if (tenantVO != null) {
				response.setData(tenantVO);
			}

		} catch (HttpClientErrorException e) {
			throw new BusinessCenterException(ApplicationCode.UNEXPECTED_ERROR);
		}

		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false)
	public RestResponse createOrUpdateBridgeUserFromContextToken(HttpServletRequest httpRequest,
			HttpServletResponse httpResponse, String code, String contextToken, UriInfo uriInfo)
			throws JsonParseException, JsonMappingException, IOException, IntegrationException {
		String requestString = VstUtils.getUrlWithProtocol(httpRequest, VstUtils.getDomain(uriInfo, httpRequest));
		URL requestUrl = new URL(requestString+ApplicationConstants.USER_ERROR_PAGE);
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Bridge bridge = bridgeDAO.getBridgeForCode(code);
		if (bridge == null) {
			throw new IntegrationException(ApplicationCode.BRIDGE_NOT_FOUND,requestUrl);
		} else if (bridge.getIsIntegrated() && bridge.getBcTenantId() != null) {

			if (!StringUtils.isEmpty(contextToken)) {
				ContextToken tokenFromDb = checkTokenExpiration(contextToken);
				try {
					ResponseEntity<String> bcTokenResponse = getTokenDataFromBC(contextToken, bridge);
					switch (bcTokenResponse.getStatusCode()) {
					case OK:
						addBCResponseData(bcTokenResponse, response, bridge, requestUrl);
						if (tokenFromDb == null) {
							ContextToken ct = new ContextToken();
							ct.setContextToken(contextToken);
							contextTokenDAO.create(ct);
						}
						break;
					case NOT_FOUND:
						throw new IntegrationException(
								"Missing context token " + contextToken + " Status: " + bcTokenResponse.getStatusCode(),
								ApplicationCode.TOKEN_NOT_FOUND,requestUrl);
					case UNAUTHORIZED:
						throw new IntegrationException("Unothorized for context " + contextToken + " Status: "
								+ bcTokenResponse.getStatusCode(), ApplicationCode.UNATHORISED_REQUEST,requestUrl);
					default:
						throw new IntegrationException("There was an error with context " + contextToken
								+ " Status: " + bcTokenResponse.getStatusCode(), ApplicationCode.UNEXPECTED_ERROR,requestUrl);
					}
				} catch (HttpClientErrorException e) {
					throw new IntegrationException("Client error for context: " + contextToken,
							ApplicationCode.TOKEN_NOT_FOUND,requestUrl);
				}

			} else {
				throw new IntegrationException("There was an error with context " + contextToken,
						ApplicationCode.INVALID_CONTEXT_TOKEN,requestUrl);
			}
		} else {
			throw new IntegrationException("There was an error with context " + contextToken,
					ApplicationCode.TENANT_NOT_VALID,requestUrl);
		}

		return response;
	}

	private void addBCResponseData(ResponseEntity<String> bcTokenResponse, RestResponse response, Bridge bridge, URL requestUrl)
			throws IntegrationException {
		IntegratedBridgeUserResponseVO integratedBridgeUserResponseVO = null;
		String responseBody = bcTokenResponse.getBody();
		try {
			JsonNode node = objectMapper.readValue(responseBody, JsonNode.class);
			ContextVO contextVO = objectMapper.readValue(node.get("data").toString(), ContextVO.class);
			if (contextVO != null) {
				String tenant_id = contextVO.getTenantId();
				if (StringUtils.equals(tenant_id, bridge.getBcTenantId().toString())) {
					BCUserVO bcUserVO = refreshGroupFromBcUser(bridge, contextVO);
					BridgeUser bridgeUser = bridgeUserDAO.getBridgeUserByTenantUser(bcUserVO, bridge.getId());
					bridgeUser.setAccessToken(contextVO.getTenantUserAccessToken());
					integratedBridgeUserResponseVO = populateIntegratedBridgeUserInfoFromBridgeUser(bridgeUser);
					addContextToIntegratedBridgeUser(contextVO, integratedBridgeUserResponseVO);
					response.setData(integratedBridgeUserResponseVO);

				} else {
					throw new IntegrationException("Tenant Id:" + tenant_id + " Expected Id: " + bridge.getBcTenantId(),
							ApplicationCode.TENANT_NOT_VALID, requestUrl);
				}
			}

		} catch (IOException e) {
			throw new IntegrationException("There was an error adding BC response data", ApplicationCode.UNEXPECTED_ERROR, requestUrl,e);
		}catch (BridgeException bc){
			
		}
	}
	

	private BCUserVO refreshGroupFromBcUser(Bridge bridge, ContextVO contextVO)
			throws JsonParseException, JsonMappingException, IOException {
		String url = ApiKeys.getBusinessCenterUrl(ApplicationConstants.getApiMode()) + ApplicationConstants.USER;
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put(ApplicationConstants.TENANT_ID, contextVO.getTenantId());
		paramMap.put(ApplicationConstants.BC_USER_ID, contextVO.getTenantUserId());
		ResponseEntity<String> bcUserResponse = callBcApi(bridge, paramMap, url, HttpMethod.GET);
		String responseBody = bcUserResponse.getBody();
		JsonNode node;
		BCUserVO bcUser;
		if (bcUserResponse.getStatusCode() != HttpStatus.OK) {
			throw new BusinessCenterException(ApplicationCode.UNEXPECTED_ERROR);
		} else {
			node = objectMapper.readValue(responseBody, JsonNode.class);
			bcUser = objectMapper.readValue(node.get("user").toString(),
					objectMapper.getTypeFactory().constructType(BCUserVO.class));
		}

		if (bcUser != null && (null != bcUser.getCourseIds() && !bcUser.getCourseIds().isEmpty())) {

			List<Integer> bridgeGroupIdList = bridgeGroupDAO.getCourseIds(bridge.getId(), bcUser.getCourseIds(), false);

			for (String courseId : bcUser.getCourseIds()) {

				try {
					if ((StringUtils.isNotEmpty(courseId) && null != bridgeGroupIdList)
							&& !bridgeGroupIdList.contains(Integer.valueOf(courseId))) {
						BridgeGroup bridgeGroup = bridgeGroupDAO.getGroupByCourseId(bridge.getId(), courseId);
						if (null == bridgeGroup) {
							bridgeGroup = new BridgeGroup();
							BCCourseVO bcCourseVO = getBcGroup(bridge, courseId);
							if (null == bcCourseVO)
								continue;
							bridgeGroup.setCreatedBy(adminUserDAO.get(1));
							bridgeGroup.setCreatedDate(new Date());
							bridgeGroup.setModifiedBy(adminUserDAO.get(1));
							bridgeGroup.setModifiedDate(bridgeGroup.getCreatedDate());
							populateBCGroupVO(bcCourseVO, bridgeGroup, bridge);
							try {
								bridgeGroupDAO.saveOrUpdate(bridgeGroup);
							} catch (BridgeException e) {
								logger.error(
										"There was an issue refreshing a course for for bridge id: " + bridge.getId()
												+ " with tenant id: " + bridge.getBcTenantId() + " for BC user id: "
												+ bcUser.getId() + " from context " + contextVO.getLtiSequenceIdent(),
										e);
							}
						}
						updateGroupUserFromBcUser(bridge, bridgeGroup, bcUser);
					}
				} catch (BridgeException e) {
					logger.error("There was an issue refreshing groups for user " + bcUser.getId() + " ond bridge "
							+ bridge + " with context " + contextVO.getLtiSequenceIdent(), e);
				}
			}

		}else {
			BridgeUser bridgeUser = bridgeUserDAO.getBridgeUserByTenantUser(bcUser, bridge.getId());
			if (bridgeUser == null) {
				bridgeUser = new BridgeUser();
				populateBridgeUserFromBcUserVO(bcUser, bridgeUser, bridge);
				bridgeUserDAO.saveOrUpdate(bridgeUser);
			}
			
		}
  return bcUser;
	}

	private void updateGroupUserFromBcUser(Bridge bridge, BridgeGroup bridgeGroup, BCUserVO bcUserVO) {

		BridgeUser bridgeUser = bridgeUserDAO.getBridgeUserByTenantUser(bcUserVO, bridge.getId());
		if (bridgeUser == null) {
			bridgeUser = new BridgeUser();
		}
		populateBridgeUserFromBcUserVO(bcUserVO, bridgeUser, bridge);
		bridgeUser.setDeleted(null);
		bridgeUser.setDeletedBy(null);
		if(null == bridgeUser.getId()){
			bridgeUserDAO.saveOrUpdate(bridgeUser);
		}
		GroupUser groupUser = bridgeGroupUserDAO.getGroupUser(bridgeGroup.getId(), bridgeUser.getId(), Boolean.FALSE,
				Boolean.FALSE, Boolean.FALSE);
		if (groupUser == null) {
			groupUser = new GroupUser();
			groupUser.setGroup(bridgeGroup);
			groupUser.setUser(bridgeUser);
		}
		groupUser.setSelected(Boolean.TRUE);
		try {
			if (null == groupUser.getId()) {
				bridgeGroupUserDAO.saveOrUpdate(groupUser);
				logger.info("User group created with id: " + groupUser.getId() + " for bridge user with id:"
						+ groupUser.getUser().getId() + " and bridge group with id: " + groupUser.getGroup().getId());
			} else {
				logger.info("User group updated with id: " + groupUser.getId() + " for bridge user with id:"
						+ groupUser.getUser().getId() + " and bridge group with id: " + groupUser.getGroup().getId());
			}
		} catch (BridgeException e) {
			logger.error("There was an error adding bridge user with id: " + bridgeUser.getId()
					+ " to bridge group with id: " + bridgeGroup.getId(), e);
		}
	}

	private BCCourseVO getBcGroup(Bridge bridge, String courseId)
			throws JsonParseException, JsonMappingException, IOException {
		String url = ApiKeys.getBusinessCenterUrl(ApplicationConstants.getApiMode()) + ApplicationConstants.BC_COURSE;
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = getHeaders(bridge.getApiKey());
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put(ApplicationConstants.TENANT_ID, bridge.getBcTenantId().toString());
		paramMap.put(ApplicationConstants.COURSE_ID, courseId);
		ResponseEntity<String> bcUsersResponse = restTemplate.exchange(url, HttpMethod.GET, entity, String.class,
				paramMap);
		String bcUsersResponseBody = bcUsersResponse.getBody();
		JsonNode courseNode;
		BCCourseVO bcCourseVO;
		if (bcUsersResponse.getStatusCode() != HttpStatus.OK) {
			throw new BusinessCenterException(ApplicationCode.UNEXPECTED_ERROR);
		} else {
			courseNode = objectMapper.readValue(bcUsersResponseBody, JsonNode.class);
			bcCourseVO = objectMapper.readValue(courseNode.get("course").toString(),
					objectMapper.getTypeFactory().constructType(BCCourseVO.class));
		}
		if (null == bcCourseVO) {
			logger.error("BC course with course id: " + courseId + " not found for bridge with id: " + bridge.getId());
		}
		return bcCourseVO;

	}

	private ResponseEntity<String> getTokenDataFromBC(String contextToken, Bridge bridge) {
		String url = ApiKeys.getBusinessCenterUrl(ApplicationConstants.getApiMode())
				+ ApplicationConstants.CONTEXT_TOKEN;
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = getHeaders(bridge.getApiKey());
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("contexttoken", contextToken);
		logger.info("BC API call for token " + contextToken);
		return restTemplate.exchange(url, HttpMethod.GET, entity, String.class, paramMap);
	}

	private ContextToken checkTokenExpiration(String contextToken) throws BridgeException {
		ContextToken contextTokenDb = contextTokenDAO.getByContextToken(contextToken);
		if (contextTokenDb != null) {
			Date creationDate = contextTokenDb.getCreatedDate();
			long diffInSeconds = DateUtility.secondsBetweenTime(creationDate);
			if (diffInSeconds > 1800) {
				throw new BridgeException("The context token " + contextTokenDb.getContextToken() + " has expired",
						ApplicationCode.EXPIRED_TOKEN);
			}
		}
		return contextTokenDb;
	}

	private void addContextToIntegratedBridgeUser(ContextVO contextVO,
			IntegratedBridgeUserResponseVO integratedBridgeUserResponseVO) {
		if (contextVO != null && integratedBridgeUserResponseVO != null) {
			integratedBridgeUserResponseVO.setContextVO(contextVO);
		}
	}

	private IntegratedBridgeUserResponseVO populateIntegratedBridgeUserInfoFromBridgeUser(BridgeUser bridgeUser) {
		IntegratedBridgeUserResponseVO bridgeUserResponseVO = new IntegratedBridgeUserResponseVO();
		bridgeUserResponseVO.setId(bridgeUser.getId());
		bridgeUserResponseVO.setFirstName(bridgeUser.getFirstName());
		bridgeUserResponseVO.setLastName(bridgeUser.getLastName());
		bridgeUserResponseVO.setEmail(bridgeUser.getEmail());
		bridgeUserResponseVO.setBridgeId(bridgeUser.getBridge().getId());
		bridgeUserResponseVO.setTenantUserId(bridgeUser.getTenantUserId());
		bridgeUserResponseVO.setAccessToken(bridgeUser.getAccessToken());
		bridgeUserResponseVO.setGuid(bridgeUser.getGuid());
		return bridgeUserResponseVO;
	}

	private void populateBridgeUserFromContextVO(BridgeUser bridgeUser, ContextVO contextVO, Bridge bridge) {
		bridgeUser.setBridge(bridge);
		bridgeUser.setTenantUserId(contextVO.getTenantUserId());
		bridgeUser.setEmail(contextVO.getEmailAddress());
		bridgeUser.setGuid(contextVO.getTenantUserGuid());
		bridgeUser.setAccessToken(contextVO.getTenantUserAccessToken());
		getBridgeUserRoleFromContext(contextVO, bridgeUser);
		getNameFromContext(contextVO, bridgeUser);
	}

	private void getBridgeUserRoleFromContext(ContextVO contextVO, BridgeUser bridgeUser) {
		String roleFromBc = contextVO.getRoles();
		if (null != roleFromBc) {
			if (roleFromBc.contains("instructor") || roleFromBc.contains("teacher")) {
				Role role = roleDAO.getRoleByName("teacher");
				bridgeUser.setRole(role);
			} else {
				Role role = roleDAO.getRoleByName("student");
				bridgeUser.setRole(role);
			}
		}
	}

	private void getNameFromContext(ContextVO contextVO, BridgeUser bridgeUser) {
		String firstName = null == contextVO.getFirstName() ? contextVO.getLisPersonNameGiven()
				: contextVO.getFirstName();
		String lastName = StringUtils.isEmpty(contextVO.getLastName()) ? contextVO.getLisPersonNameFamily()
				: contextVO.getLastName();
		String email = StringUtils.isEmpty(contextVO.getEmailAddress())
				? contextVO.getToolConsumerInstanceContactEmail() : contextVO.getEmailAddress();
		;

		if (StringUtils.isEmpty(firstName) || "NoFirstNameProvided".equals(firstName)
				|| "NoLastNameProvided".equals(lastName) || "NoFirstNameProvided".equals(firstName)) {

			if (StringUtils.isEmpty(email) || email.contains("@placeholder")) {
				bridgeUser.setFirstName("Reference");
				bridgeUser.setLastName("User");
			} else {
				bridgeUser.setFirstName(email);
			}

		} else {
			bridgeUser.setFirstName(firstName);
			bridgeUser.setLastName(lastName);
		}

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse getUsersForTenantId(SessionStatusVO sessionStatusVO, Integer bridgeId, Integer tenantId,
			HttpServletRequest httpRequest, UriInfo uriInfo, JobTask jobTask, Boolean isJobScheduler)
			throws BridgeException, BusinessCenterException, JsonParseException, JsonMappingException, IOException,
			ConnectApiException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if (null != bridgeId) {
			Bridge bridge = bridgeDAO.get(bridgeId);
			if (bridge == null) {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			if (null != tenantId) {
				if (bridge.getBcTenantId() != null && tenantId.equals(bridge.getBcTenantId())) {
					try {

						List<BCUserVO> bcUserList = getUsersForTenantFromBc(tenantId, bridge);
						updateBridgeUsersFromBCUsers(sessionStatusVO.getAdminId(), bridge, bcUserList);

					} catch (HttpClientErrorException e) {
						if (isJobScheduler) {
							logger.error("Job task error for job " + jobTask.getJobType(), e);
							jobTask.setJobStatus(JobStatus.ERROR.name());
							jobTaskDAO.saveOrUpdate(jobTask);
						} else {
							throw new BusinessCenterException(ApplicationCode.UNEXPECTED_ERROR);
						}
					}
				} else {
					logger.error("Tenant with id " + tenantId + " not valid");
					throw new BridgeException(ApplicationCode.TENANT_NOT_VALID);
				}

			} else {
				logger.error("Tenant with id " + tenantId + " not valid");
				throw new BridgeException(ApplicationCode.TENANT_NOT_VALID);
			}
		} else {
			logger.error("Bridge " + bridgeId + " not valid");
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		return response;
	}

	private List<BCUserVO> getUsersForTenantFromBc(Integer tenantId, Bridge bridge)
			throws IOException, JsonParseException, JsonMappingException {
		String url = ApiKeys.getBusinessCenterUrl(ApplicationConstants.getApiMode()) + ApplicationConstants.USERS;
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = getHeaders(bridge.getApiKey());
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put(ApplicationConstants.TENANT_ID, tenantId.toString());
		ResponseEntity<String> bcCoursesResponse = restTemplate.exchange(url, HttpMethod.GET, entity, String.class,
				paramMap);
		String responseBody = bcCoursesResponse.getBody();
		JsonNode node;
		List<BCUserVO> bcUserList;
		if (bcCoursesResponse.getStatusCode() != HttpStatus.OK) {
			throw new BusinessCenterException(ApplicationCode.UNEXPECTED_ERROR);
		} else {
			node = objectMapper.readValue(responseBody, JsonNode.class);
			bcUserList = objectMapper.readValue(node.get("users").toString(),
					objectMapper.getTypeFactory().constructCollectionType(List.class, BCUserVO.class));
		}
		return bcUserList;
	}

	private void updateBridgeUsersFromBCUsers(Integer adminId, Bridge bridge, List<BCUserVO> bcUserList) {
		int deletedUsers = bridgeUserDAO.deleteAllUsers(adminId, bridge);
		int batchSize = 0;
		logger.info(deletedUsers + " users marked deleted for " + bridge);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
		Calendar cal = Calendar.getInstance();
		cal.set(2016, Calendar.AUGUST, 20);

		for (int i = 0; i < bcUserList.size(); i++) {
			BCUserVO bcUser = bcUserList.get(i);
			if (bridge.getId().intValue() == 239 && bridge.getBcTenantId().intValue() == 100059) {
				try {
					logger.warn("Refreshing groups for bridge id: " + bridge.getId() + " with tenant id: "
							+ bridge.getBcTenantId() + " from " + cal.getTime());

					Date cutoffDate = formatter.parse(bcUser.getUpdatedAt().replaceAll("Z$", "+0000"));
					if (cutoffDate.before(cal.getTime())) {
						logger.warn("User with tenant id " + bcUser.getTenantId() + " last updated on " + cutoffDate
								+ " and will be ignored");
						continue;
					}
				} catch (ParseException e) {
					logger.error("There was an issue parsing the cutoff date for bridge id: " + bridge.getId());
					e.printStackTrace();
				}
			}

			BridgeUser bridgeUser = bridgeUserDAO.getBridgeUserByTenantUser(bcUser, bridge.getId());
			if (null == bridgeUser) {
				bridgeUser = new BridgeUser();
				logger.info("New user created with tenant user id: " + bcUser.getId());
			}
			bridgeUser.setDeleted(null);
			bridgeUser.setDeletedBy(null);
			populateBridgeUserFromBcUserVO(bcUser, bridgeUser, bridge);
			try {
				if (null == bridgeUser.getId())
					bridgeUserDAO.saveOrUpdate(bridgeUser);
				else {
					logger.info("User refreshed on bridge with id: " + bridge.getId() + " with tenant user id: "
							+ bridgeUser.getId());
				}
				if (++batchSize % 50 == 0) {
					bridgeUserDAO.flushAndClear();
					logger.info("Batch clear and flush " + batchSize + " for updating bridge users on bridge id: "
							+ bridge.getId());
				}

			} catch (BridgeException e) {
				logger.error("There was an error adding a user to the database: with bc user id: "
						+ bridgeUser.getTenantUserId(), e);
			}

		}
		logger.info("Users refresh complete for bridge with id: " + bridge.getId());
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse getCourseForGroupId(SessionStatusVO sessionStatusVO, Integer bridgeId, Integer courseId,
			HttpServletRequest httpRequest, UriInfo uriInfo, Boolean isJobScheduler) throws BridgeException,
			BusinessCenterException, JsonParseException, JsonMappingException, IOException, ConnectApiException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if (null != bridgeId) {
			Bridge bridge = bridgeDAO.get(bridgeId);
			if (bridge == null) {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			if (!bridge.getIsIntegrated()) {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_INTEGRATED);
			}
			Integer tenantId = bridge.getBcTenantId();
			if (tenantId == null) {
				throw new BridgeException(ApplicationCode.TENANT_NOT_VALID);
			}

			BridgeGroup bridgeGroup = bridgeGroupDAO.get(courseId);
			if (bridgeGroup == null) {
				throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
			}
			AdminUser adminUser = adminUserDAO.get(sessionStatusVO.getAdminId());
			adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_MANAGE, adminUser);
			String groupCourseId = bridgeGroup.getCourseId();

			String url = ApiKeys.getBusinessCenterUrl(ApplicationConstants.getApiMode())
					+ ApplicationConstants.BC_USERS;
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = getHeaders(bridge.getApiKey());
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

			Map<String, String> paramMap = new HashMap<String, String>();
			paramMap.put(ApplicationConstants.TENANT_ID, tenantId.toString());
			paramMap.put(ApplicationConstants.COURSE_ID, groupCourseId);
			ResponseEntity<String> bcUsersResponse = restTemplate.exchange(url, HttpMethod.GET, entity, String.class,
					paramMap);
			String bcUsersResponseBody = bcUsersResponse.getBody();
			JsonNode userNode;
			List<BCUserVO> userList;
			if (bcUsersResponse.getStatusCode() != HttpStatus.OK) {
				throw new BusinessCenterException(ApplicationCode.UNEXPECTED_ERROR);
			} else {
				userNode = objectMapper.readValue(bcUsersResponseBody, JsonNode.class);
				userList = objectMapper.readValue(userNode.get("users").toString(),
						objectMapper.getTypeFactory().constructCollectionType(List.class, BCUserVO.class));
			}

			if (null != userList && !userList.isEmpty()) {
				int batchSize = 0;
				for (BCUserVO bcUserVO : userList) {
					if (StringUtils.equals(bridge.getBcTenantId().toString(), bcUserVO.getTenantId())) {
						BridgeUser bridgeUser = bridgeUserDAO.getBridgeUserByTenantUser(bcUserVO, bridgeId);
						if (bridgeUser != null) {
							Boolean isUserDeleted = bridgeUser.getDeleted() != null ? Boolean.TRUE : Boolean.FALSE;
							GroupUser groupUser = bridgeGroupUserDAO.getGroupUser(bridgeGroup.getId(),
									bridgeUser.getId(), Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
							if (groupUser == null && !isUserDeleted) {
								GroupUser createGroupUser = new GroupUser();
								createGroupUser.setGroup(bridgeGroup);
								createGroupUser.setUser(bridgeUser);
								createGroupUser.setSelected(Boolean.TRUE);
								bridgeGroupUserDAO.saveOrUpdate(createGroupUser);
								logger.info("Group User created for bridge user id: " + bridgeUser.getId()
										+ " and bridge group id: " + bridgeGroup.getId());
							}
							if (isUserDeleted) {
								groupUser.setSelected(Boolean.FALSE);
								logger.info("User with bridge user id: " + bridgeUser.getId()
										+ " has been removed from group id: " + bridgeGroup.getId());
							} else {
								groupUser.setSelected(Boolean.TRUE);
								logger.info("User with bridge user id: " + bridgeUser.getId()
										+ " has been added to group id: " + bridgeGroup.getId());
							}
							try {
								if (null == groupUser.getId())
									bridgeGroupUserDAO.saveOrUpdate(groupUser);
								if (++batchSize % 50 == 0) {
									bridgeGroupUserDAO.flushAndClear();
									bridgeUserDAO.flushAndClear();
								}
								;
							} catch (BridgeException e) {
								logger.error("There was an error adding user with id: " + groupUser.getUser().getId()
										+ " to group with id: " + groupUser.getGroup().getId());
							}

						}
					}
				}
			}
		}

		return response;
	}

	private void populateBridgeUserFromBcUserVO(BCUserVO bcUserVO, BridgeUser bridgeUser, Bridge bridge) {
		String firstName = bcUserVO.getFirstName();
		String lastName = bcUserVO.getLastName();

		if (StringUtils.isEmpty(firstName) || "NoFirstNameProvided".equals(firstName)
				|| "NoLastNameProvided".equals(lastName)) {
			if (StringUtils.isEmpty(bcUserVO.getEmail()) || bcUserVO.getEmail().contains("@placeholder")) {
				bridgeUser.setFirstName("Reference");
				bridgeUser.setLastName("User");
			} else {
				bridgeUser.setFirstName(bcUserVO.getEmail());
			}

		} else {
			bridgeUser.setFirstName(firstName);
			bridgeUser.setLastName(lastName);
		}
		bridgeUser.setEmail(bcUserVO.getEmail());
		bridgeUser.setBridge(bridge);
		bridgeUser.setTenantUserId(bcUserVO.getId());
		bridgeUser.setGuid(bcUserVO.getGuid());
		if (null != bcUserVO.getIsInstructor() && Boolean.valueOf(bcUserVO.getIsInstructor()) == Boolean.TRUE) {
			Role role = roleDAO.getRoleByName("teacher");
			bridgeUser.setRole(role);
		} else {
			Role role = roleDAO.getRoleByName("student");
			bridgeUser.setRole(role);
		}

	}

	private HttpHeaders getHeaders(String apiKey) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add(ApplicationConstants.APIKEY_HEADER, apiKey);
		headers.add("Content-Type", "application/json; charset=utf-8");
		return headers;
	}

	private ResponseEntity<String> callBcApi(Bridge bridge, Map<String, String> paramMap, String url,
			HttpMethod httpMethod) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = getHeaders(bridge.getApiKey());
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		return restTemplate.exchange(url, httpMethod, entity, String.class, paramMap);
	}
}
