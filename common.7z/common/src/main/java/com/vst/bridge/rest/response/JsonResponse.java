package com.vst.bridge.rest.response;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import com.owlike.genson.Genson;

//@XmlRootElement
public class JsonResponse extends RestResponse 
{
	private Object data;
	private Object metadata;
	private List<ResponseError> errors = new ArrayList<>();
	
	public static JsonResponse instance(RestStatus status)
	{
		return new JsonResponse(status.getCode(),status.getText());
	}
	public static JsonResponse instance(RestStatus status, Object data)
	{
		return new JsonResponse(status.getCode(),status.getText(), data);
	}
	public static JsonResponse instance(Response.Status code, String message)
	{
		return new JsonResponse(code,message);
	}
	public static JsonResponse instance(Response.Status code, String message, Object data)
	{
		return new JsonResponse(code,message, data);
	}
	public static JsonResponse instance(Response.Status code, String message, Object data, Object metadata)
	{
		return new JsonResponse(code,message, data,metadata);
	}
	
	private JsonResponse(Response.Status code, String message)
	{
		this.code = code;
		this.text = message;
	}
	private JsonResponse(Response.Status code, String message, Object data)
	{
		this.code = code;
		this.text = message;
		this.data = data;
	}
	private JsonResponse(Response.Status code, String message, Object data, Object metadata)
	{
		this.code = code;
		this.text = message;
		this.data = data;
		this.metadata = metadata;
	}
	//@XmlElement
	public String getData() {
		return new Genson().serialize(data);
	}

	public void setData(Object data) {
		this.data = data;
	}
	public Object getMetaData()
	{
		return metadata;
	}
	public void addFieldError(String field,String message)
	{
		errors.add(new FieldError(field,message));
	}
	public List<ResponseError> getErrors()
	{
		return errors;
	}
	
	public abstract class ResponseError
	{
		public abstract String getType();
		public abstract Object getData();
	}
	
	public class FieldError extends ResponseError
	{
		//private String message;
		//private String field; 
		private String type = "fielderror";
		private HashMap<String,String> data = new HashMap<String,String>();
		
		public FieldError(String field, String message)
		{
			data.put("field",field);
			data.put("message",message);
		}
		public String getType()
		{
			return type;
		}
		public Object getData()
		{
			return data;
		}
		public String getField()
		{
			return data.get("field");
		}
		public String getMessage()
		{
			return data.get("message");
		}
	}

	public void cookie(NewCookie newCookie) 
	{
		this.cookies.add(newCookie);
		
	}
	public Response build(HttpServletRequest hsr) 
	{
		
		ResponseBuilder rb = Response.status(this.getCode()).entity((new Genson()).serialize(this));//this); //data);
		//return Response.ok(FromDatabaseToBean.getDefaultAndPortalConfigValues(2).toString(), MediaType.APPLICATION_JSON).build(); //JsonResponse.instance(Response.Status.OK, "session.authorized", Constants.DEBUG.CONFIG).build(request);	//TODO: fix

		
		for(NewCookie cookie : this.cookies) {
			rb.cookie(cookie);
		}
		
		//rb.header("Access-Control-Allow-Origin","*");
	    //rb.header("Access-Control-Allow-Methods","GET, PUT, DELETE, POST, OPTIONS");
	    //rb.header("Access-Control-Allow-Headers","*");
	    //rb.header("Access-Control-Allow-Credentials","true");
		
		return rb.build();
	}
}
