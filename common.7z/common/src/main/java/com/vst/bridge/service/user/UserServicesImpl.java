package com.vst.bridge.service.user;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.UriInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vst.bridge.VstException;
import com.vst.bridge.entity.admin.allowance.BridgeAllowanceNotification;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.rest.input.vo.LoginInfoVO;
import com.vst.bridge.rest.input.vo.OldPolicyPasswordVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.rest.response.vo.user.AdminInfoVo;
import com.vst.bridge.rest.response.vo.user.CreateKeysVO;
import com.vst.bridge.rest.response.vo.user.IntegratedBridgeUserResponseVO;
import com.vst.bridge.rest.response.vo.user.UpdatePasswordVO;
import com.vst.bridge.rest.response.vo.user.UserDetailsVO;
import com.vst.bridge.rest.response.vo.user.UserEmailVO;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.exception.BusinessCenterException;
import com.vst.bridge.util.exception.IntegrationException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiFieldException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;

@Service("userServices")
public class UserServicesImpl implements IUserServices{
	
	@Autowired
	IUserBookService userBookService;
	
	@Autowired
	IUserBridgeService userBridgeService;
	
	@Autowired
	IUserEntityService userEntityService;
	
	@Autowired
	IUserKeyService userKeyService;
	
	@Autowired
	IUserAccessService userAccessService;
	
	@Autowired
	IUserPasswordService userPasswordService;
	
	@Autowired
	IUserValidationService userValidationService;

	@Override
	public RestResponse login(LoginInfoVO loginInfoVO, HttpServletRequest request,
			HttpServletResponse httpServletResponse, UriInfo uriInfo, String code, Integer bridgeUserId)
			throws BridgeException, ParseException, IOException, ConnectApiException, ConnectApiHttpException,
			ConnectApiXmlException, ConnectApiFieldException, VstException {

		return userAccessService.login(loginInfoVO, request, httpServletResponse, uriInfo, code, bridgeUserId);
	}

	@Override
	public RestResponse logout(String sessionId, String code, HttpServletRequest request, UriInfo uriInfo)
			throws BridgeException {

		return userAccessService.logout(sessionId, code, request, uriInfo);
	}

	@Override
	public RestResponse createOrUpdateUser(SessionStatusVO sessionStatusVO, HttpServletRequest httpRequest,
			UserDetailsVO userDetailsVO, UriInfo uriInfo, String code, Boolean isNew, UserDetailsVO newDummyUser,
			Boolean isReferenceUser) throws BridgeException, ParseException, IOException, ConnectApiException,
			ConnectApiXmlException, ConnectApiFieldException, ConnectApiHttpException {

		return userEntityService.createOrUpdateUser(sessionStatusVO, httpRequest, userDetailsVO, uriInfo, code, isNew, newDummyUser, isReferenceUser);
	}

	@Override
	public RestResponse getGroups(SessionStatusVO sessionStatusVO, String code) throws BridgeException {
		
		return userEntityService.getGroups(sessionStatusVO, code);
	}

	@Override
	public RestResponse getBridgeUserInfo(String sessionId, UriInfo uriInfo, String code)
			throws BridgeException, ConnectApiException {
		
		return userBridgeService.getBridgeUserInfo(sessionId, uriInfo, code);
	}

	@Override
	public RestResponse getBridgeConfig(HttpServletRequest httpRequest, UriInfo uriInfo, String code, String domain)
			throws BridgeException {
		
		return userBridgeService.getBridgeConfig(httpRequest, uriInfo, code, domain);
	}

	@Override
	public RestResponse checkBridgeCode(String code, String domain) throws BridgeException {
		
		return userBridgeService.checkBridgeCode(code, domain);
	}

	@Override
	public RestResponse getBooks(SessionStatusVO sessionStatusVO, Integer groupId, String vbid, String code,
			BridgePaginationVo bridgePaginationVo,String category, Boolean isDefered) throws BridgeException, ConnectApiException {
		
		return userBookService.getBooks(sessionStatusVO, groupId, vbid, code, bridgePaginationVo, category, isDefered);
	}

	@Override
	public RestResponse getBooksForDeferSignIn(HttpServletRequest httpRequest, UriInfo uriInfo, String code,
			String domain, BridgePaginationVo bridgePaginationVo) throws BridgeException, ConnectApiException {
		
		return userBookService.getBooksForDeferSignIn(httpRequest, uriInfo, code, domain, bridgePaginationVo);
	}

	@Override
	public RestResponse resetPasswordRequest(HttpServletRequest httpRequest, UserEmailVO userEmailVO, String domain,
			String code) throws BridgeException, ConnectApiException, VstException {
		
		return userPasswordService.resetPasswordRequest(httpRequest, userEmailVO, domain, code);
	}

	@Override
	public RestResponse updatePassword(UpdatePasswordVO updatePasswordVO, String domain) throws BridgeException {
		
		return userPasswordService.updatePassword(updatePasswordVO, domain);
	}

	@Override
	public RestResponse updateOldPolicyPassword(OldPolicyPasswordVO oldPolicyPasswordVO, String code)
			throws BridgeException, ParseException, IOException, ConnectApiException, ConnectApiHttpException,
			ConnectApiXmlException, ConnectApiFieldException, VstException {
		
		return userPasswordService.updateOldPolicyPassword(oldPolicyPasswordVO, code);
	}

	@Override
	public RestResponse checkUserEmail(String domain, UserEmailVO userEmailVO, String code,
			HttpServletRequest httpRequest) throws BridgeException, ConnectApiException, VstException {
		
		return userPasswordService.checkUserEmail(domain, userEmailVO, code, httpRequest);
	}

	@Override
	public RestResponse getQuestions(HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		
		return userPasswordService.getQuestions(httpRequest, uriInfo);
	}

	@Override
	public RestResponse postKeysForUser(SessionStatusVO sessionStatusVO, CreateKeysVO createKeys, String vbid,
			String code, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException {
		
		return userKeyService.postKeysForUser(sessionStatusVO, createKeys, vbid, code, httpRequest, uriInfo);
	}

	@Override
	public RestResponse getKeysForUser(SessionStatusVO sessionStatusVO, String vbid, String code,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException, IOException {
		
		return userKeyService.getKeysForUser(sessionStatusVO, vbid, code, httpRequest, uriInfo);
	}

	@Override
	public RestResponse validateToken(String code, String token) throws BridgeException {
		
		return userValidationService.validateToken(code, token);
	}

	@Override
	public RestResponse ssoLoginForIntegratedUser(IntegratedBridgeUserResponseVO integratedBridgeUserResponseVO,
			String code, HttpServletResponse httpResponse, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException, BusinessCenterException, VstException,
			IntegrationException {
		
		return userValidationService.ssoLoginForIntegratedUser(integratedBridgeUserResponseVO, code, httpResponse, httpRequest, uriInfo);
	}

	@Override
	public void sendNotificationMail(Bridge bridge, List<AdminInfoVo> superAdmins,
			BridgeAllowanceNotification lastBridgeAllowanceNotification) {
		
		sendNotificationMail(bridge, superAdmins,lastBridgeAllowanceNotification);
	}

}
