package com.vst.bridge.dao.admin.password;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.password.ResetPassword;
import com.vst.bridge.util.exception.BridgeException;

@Repository("resetPasswordDAO")
public class AdminUserPasswordDAO extends GenericDAO<ResetPassword,Integer> implements IAdminUserPasswordDAO{

	public AdminUserPasswordDAO() {
		super(ResetPassword.class);
	}

	@Override
	public ResetPassword getPasswordForAdminId(Integer adminId,final String tokanId,final Boolean used)
			throws BridgeException {
		Criteria  criteria = getCriteria();
		criteria.add(Restrictions.eq("admin.id", adminId));
		if(null != tokanId && !StringUtils.isEmpty(tokanId)){
			criteria.add(Restrictions.like("token", tokanId));
		}
		criteria.add(Restrictions.eq("used", used));
		criteria.addOrder(Order.desc("createdDate"));
		List<ResetPassword> result = executeCriteira(criteria);
		return null != result && result.size() > 0 ? result.get(0) : null;
	}
	
	@Override
	public List<ResetPassword> getListByAdminId(Integer adminId,Boolean used) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.eq("used", used));
		return executeCriteira(criteria);
	}
}
