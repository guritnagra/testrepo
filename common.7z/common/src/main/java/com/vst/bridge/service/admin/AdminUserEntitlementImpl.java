package com.vst.bridge.service.admin;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.allowance.IBridgeEntitlementDAO;
import com.vst.bridge.dao.bridge.config.IBridgeConfigDAO;
import com.vst.bridge.dao.bridge.purchase.IBridgePurchaseDAO;
import com.vst.bridge.dao.bridge.type.ICodeTypesDAO;
import com.vst.bridge.dao.key.IKeyBatchDAO;
import com.vst.bridge.dao.key.IKeyBatchEntitlementDAO;
import com.vst.bridge.dao.log.IBridgeRosterLogDAO;
import com.vst.bridge.dao.user.role.IBridgeUserRoleDAO;
import com.vst.bridge.entity.admin.allowance.BridgeEntitlement;
import com.vst.bridge.entity.admin.purchase.BridgePurchase;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.BridgeConfig;
import com.vst.bridge.entity.bridge.log.BridgeRosterLog;
import com.vst.bridge.entity.keys.KeyBatch;
import com.vst.bridge.entity.keys.KeyBatchEntitlement;
import com.vst.bridge.rest.input.vo.AllowanceRequestVO;
import com.vst.bridge.rest.input.vo.ConcurrencyEntitlementVO;
import com.vst.bridge.rest.input.vo.EntitlementVO;
import com.vst.bridge.rest.input.vo.PurchaseRequestVO;
import com.vst.bridge.rest.input.vo.PurchaseVO;
import com.vst.bridge.rest.response.vo.BridgeAccessTypeResponseVO;
import com.vst.bridge.rest.response.vo.BridgeAllowanceResponseVO;
import com.vst.bridge.rest.response.vo.BridgePurchaseResponseVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;

@Service("adminUserEntitlementService")
public class AdminUserEntitlementImpl implements IAdminUserEntitlementService {
	
	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private IBridgeDAO bridgeDAO;

	@Autowired
	private ICodeTypesDAO codeTypesDAO;
	
	@Autowired
	private IBridgeEntitlementDAO bridgeEntitlementDAO;
	
	@Autowired
	private IBridgePurchaseDAO bridgePurchaseDAO;
	
	@Autowired
	private IBridgeRosterLogDAO bridgeRosterLogDAO;
	
	@Autowired
	private IBridgeConfigDAO bridgeConfigDAO;
	
	@Autowired 
	private IKeyBatchDAO keyBatchDAO;
	
	@Autowired
	private IKeyBatchEntitlementDAO keyBatchEntitlementDAO;
	
	@Autowired
	private IAdminUserDAO adminUserDAO;

	@Autowired
	private IBridgeUserRoleDAO bridgeUserRoleDAO;
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public RestResponse updateBridgeAllowanceForBridgeId(SessionStatusVO sessionStatusVO, AllowanceRequestVO allowanceRequestVO,
			Integer bridgeId, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Bridge bridge = bridgeDAO.get(bridgeId);
		
		if(bridge==null){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		KeyBatch keyBatch = keyBatchDAO.getKeyBatchForAutoRedeem(bridge.getId());
		if(keyBatch==null){
			keyBatch = this.createNewKeyBatchforAutoRedeem(bridge);
			keyBatchDAO.saveOrUpdate(keyBatch);
		}
		if(allowanceRequestVO!=null){
			if(bridge.getConcurrencyEnabled()){
				List<ConcurrencyEntitlementVO> concurrencyEntitlement=allowanceRequestVO.getConcurrencyEntitlements();  //Only 1 concurrency entitlement permited
				if(concurrencyEntitlement!=null){					
					//this.populateConcurrencyEntitlementVO(concurrencyEntitlement,bridge);
					if(bridge.getConcurrencyEnabled()!=null && bridge.getConcurrencyEnabled()){
						this.populateKeyBatchConcurrencyEntitlement(concurrencyEntitlement,keyBatch);
						keyBatchDAO.saveOrUpdate(keyBatch);
					}					
				}
			}
			if(allowanceRequestVO.getEntitlements()!=null){				
				List<KeyBatchEntitlement> updatedKeyBatchEntitlementList = new ArrayList<KeyBatchEntitlement>();
				List<EntitlementVO> requestEntitlementList = allowanceRequestVO.getEntitlements();
				if(keyBatch!=null){
					List<KeyBatchEntitlement> dBkeyBatchEntitlementList = keyBatchEntitlementDAO.getAllEntitlementsForKeyBatch(keyBatch.getId());
					
					Iterator<EntitlementVO> requestEntitlementIterator=requestEntitlementList.iterator();
					while(requestEntitlementIterator.hasNext()){
						EntitlementVO requestEntitlement=requestEntitlementIterator.next();
						if(requestEntitlement.getId()==null)
							continue;
						if(!dBkeyBatchEntitlementList.isEmpty()){
							Iterator<KeyBatchEntitlement> dBkeyBatchEntitlementIterator=dBkeyBatchEntitlementList.iterator();
							while(dBkeyBatchEntitlementIterator.hasNext()){
								KeyBatchEntitlement dBkeyBatchEntitlement=dBkeyBatchEntitlementIterator.next();
								if(requestEntitlement.getId().equals(dBkeyBatchEntitlement.getId())){
									updatedKeyBatchEntitlementList.add(populateKeyBatchEntitlementByRequestEntitlement(dBkeyBatchEntitlement, requestEntitlement, keyBatch));
									requestEntitlementIterator.remove();
									dBkeyBatchEntitlementIterator.remove();
									break;
								}/*else{
									KeyBatchEntitlement keyBatchEntitlement = new KeyBatchEntitlement();
									updatedKeyBatchEntitlementList.add(populateKeyBatchEntitlementByBridgeEntitlement(keyBatchEntitlement, requestEntitlement, keyBatch));
									requestEntitlementIterator.remove();
									break;
								}*/
							}
						}else{
							KeyBatchEntitlement keyBatchEntitlement = new KeyBatchEntitlement();
							updatedKeyBatchEntitlementList.add(populateKeyBatchEntitlementByRequestEntitlement(keyBatchEntitlement, requestEntitlement, keyBatch));
							requestEntitlementIterator.remove();
						}
					}
					if(updatedKeyBatchEntitlementList.size()>0){
						keyBatchEntitlementDAO.saveOrUpdateAll(updatedKeyBatchEntitlementList);
					}
					if(dBkeyBatchEntitlementList.size()>0){
						for(KeyBatchEntitlement keyBatchEntitlement: dBkeyBatchEntitlementList){
							keyBatchEntitlement.setDeleted(Boolean.TRUE);
						}
						keyBatchEntitlementDAO.saveOrUpdateAll(dBkeyBatchEntitlementList);
					}
					if(requestEntitlementList.size()>0){  //New entitlements
						List<KeyBatchEntitlement> newKeyBatchEntitlementList = new ArrayList<KeyBatchEntitlement>();
						for(EntitlementVO entitlementVO:requestEntitlementList){
							KeyBatchEntitlement keyBatchEntitlement = new KeyBatchEntitlement();
							newKeyBatchEntitlementList.add(populateKeyBatchEntitlementByRequestEntitlement(keyBatchEntitlement, entitlementVO, keyBatch));							
						}
						bridgeEntitlementDAO.saveOrUpdateAll(newKeyBatchEntitlementList);
					}
				}
			}			
		}
		BridgeAllowanceResponseVO  data = this.populateBridgeAllowanceResponseVO(bridge);
		response.setData(data);
		return response;
	}

	private void populateConcurrencyEntitlementVO(List<ConcurrencyEntitlementVO> concurrencyEntitlement, Bridge bridge) {
		ConcurrencyEntitlementVO concurrencyEntitlementVO=concurrencyEntitlement.get(0);
		BridgeConfig concBridgeConfig=bridgeConfigDAO.getBridgeConfigByKeyName(bridge.getId(),ApplicationConstants.CONCURRENCY_ENTITLEMENT_NAME);
		if(concBridgeConfig!=null){
			concBridgeConfig.setKeyValue(concurrencyEntitlementVO.getEntitlementName());
			concBridgeConfig.setDeleted(Boolean.FALSE);
		}
		else{
			concBridgeConfig = new BridgeConfig();
			concBridgeConfig.setBridge(bridge);
			concBridgeConfig.setKeyName(ApplicationConstants.CONCURRENCY_ENTITLEMENT_NAME);
			concBridgeConfig.setKeyValue(concurrencyEntitlementVO.getEntitlementName());
		}		
		bridgeConfigDAO.saveOrUpdate(concBridgeConfig);
		bridge.setConcurrencyCredits(concurrencyEntitlementVO.getCredit());
		bridge.setCodeType(codeTypesDAO.getCodeForType(concurrencyEntitlementVO.getEntitlementType()));
		Long concDate = concurrencyEntitlementVO.getOnlineExpires();
		if (null != concDate && concDate > 0) {
			bridge.setConcurrencyExpires(new Date(concDate));
		} else {
			bridge.setConcurrencyExpires(null);
		}
		bridge.setConcurrencyDays(concurrencyEntitlementVO.getOnlineDays());
		if(concurrencyEntitlementVO.getIsCopyfromOnline()!=null && concurrencyEntitlementVO.getIsCopyfromOnline()){
			bridge.setOfflineConcurrencyDays(bridge.getConcurrencyDays());
			bridge.setOfflineConcurrencyExpires(bridge.getOfflineConcurrencyExpires());
		}
		else{
			bridge.setOfflineConcurrencyDays(concurrencyEntitlementVO.getOfflineDays());
			Long offlineConcDate = concurrencyEntitlementVO.getOfflineExpires();
			if (null != offlineConcDate && offlineConcDate > 0) {
				bridge.setOfflineConcurrencyExpires(new Date(offlineConcDate));
			} else {
				bridge.setOfflineConcurrencyExpires(null);
			}
		}
		
	}
	
	private KeyBatch populateKeyBatchConcurrencyEntitlement(List<ConcurrencyEntitlementVO> concurrencyEntitlement, KeyBatch keyBatch){
		ConcurrencyEntitlementVO concurrencyEntitlementVO=concurrencyEntitlement.get(0);
		keyBatch.setConcurrencyEntitlementName(concurrencyEntitlementVO.getEntitlementName());
		String compType = concurrencyEntitlementVO.getEntitlementType();
		Boolean isReturn =concurrencyEntitlementVO.getIsReturn()!=null ? concurrencyEntitlementVO.getIsReturn():Boolean.TRUE;
		keyBatch.setIsReturn(isReturn);
		if(null != compType && !StringUtils.isEmpty(compType)){
			keyBatch.setConcCodeType(codeTypesDAO.getCodeForType(compType));
		}
		Long concDate = concurrencyEntitlementVO.getOnlineExpires();
		if (null != concDate && concDate > 0) {
			keyBatch.setConcurrencyExpires(new Date(concDate));
		} else {
			keyBatch.setConcurrencyExpires(null);
		}
		keyBatch.setConcurrencyDays(concurrencyEntitlementVO.getOnlineDays());
		keyBatch.setConcurrencyCredits(concurrencyEntitlementVO.getCredit());
		if(concurrencyEntitlementVO.getIsCopyfromOnline()!=null && concurrencyEntitlementVO.getIsCopyfromOnline()){
			keyBatch.setOfflineConcurrencyDays(concurrencyEntitlementVO.getOnlineDays());
			if (null != concDate && concDate > 0) {
				keyBatch.setOfflineConcurrencyExpires(new Date(concDate));
			} else {
				keyBatch.setOfflineConcurrencyExpires(null);
			}
		}
		else{
			keyBatch.setOfflineConcurrencyDays(concurrencyEntitlementVO.getOfflineDays());
			Long offlineConcDate = concurrencyEntitlementVO.getOfflineExpires();
			if (null != offlineConcDate && offlineConcDate > 0) {
				keyBatch.setOfflineConcurrencyExpires(new Date(offlineConcDate));
			} else {
				keyBatch.setOfflineConcurrencyExpires(null);
			}
		}
		return keyBatch;
	}
	
	protected KeyBatch createNewKeyBatchforAutoRedeem(Bridge bridge) {
			KeyBatch keyBatch = new KeyBatch();
			keyBatch.setBridge(bridge);
			keyBatch.setNote(ApplicationConstants.AUTO_GENERATED);
			keyBatch.setRole(bridgeUserRoleDAO.getForName(ApplicationConstants.BRIDGE_USER_ROLE_STUDENT));
			keyBatch.setNoOfUsers(1);
			String createdByEmail = adminUserDAO.getSuperAdmins().get(0).getEmail();
			keyBatch.setCreatedBy(adminUserDAO.getForEmail(createdByEmail));

			return keyBatch;
	}
		
	private KeyBatchEntitlement populateKeyBatchEntitlementByRequestEntitlement(KeyBatchEntitlement keyBatchEntitlement, EntitlementVO requestEntitlement, KeyBatch keyBatch){
		keyBatchEntitlement.setKeyBatch(keyBatch);
		keyBatchEntitlement.setEntName(requestEntitlement.getEntitlementName());
		String compType = requestEntitlement.getEntitlementType();
		if(null != compType && !StringUtils.isEmpty(compType)){
			keyBatchEntitlement.setEntType(codeTypesDAO.getCodeForType(compType));
		}
		keyBatchEntitlement.setEntCredits(requestEntitlement.getCredit());
		keyBatchEntitlement.setEntOnlineDays(requestEntitlement.getOnlineDays());
		keyBatchEntitlement.setEntOnlineExpires(requestEntitlement.getOnlineExpires()!=null?new Date(requestEntitlement.getOnlineExpires()):null);
		Date onlineExpires=requestEntitlement.getOnlineExpires()!=null ? new Date(requestEntitlement.getOnlineExpires()): null;
		if(requestEntitlement.getIsCopyfromOnline()){
			keyBatchEntitlement.setEntOfflineExpires(onlineExpires);
			keyBatchEntitlement.setEntOfflineDays(requestEntitlement.getOnlineDays());
		}
		else{
			Date offlineExpires=requestEntitlement.getOfflineExpires()!=null ? new Date(requestEntitlement.getOfflineExpires()): null;
			keyBatchEntitlement.setEntOfflineExpires(offlineExpires);
			keyBatchEntitlement.setEntOfflineDays(requestEntitlement.getOfflineDays());
		}
		keyBatchEntitlement.setEntIsReusableCredit(requestEntitlement.getIsReusableCredit());
		keyBatchEntitlement.setEntIsCopyFromOnline(Boolean.FALSE);
		if((keyBatchEntitlement.getEntOnlineDays()!= null && keyBatchEntitlement.getEntOfflineDays()!=null) && (keyBatchEntitlement.getEntOnlineDays().equals(keyBatchEntitlement.getEntOfflineDays()))||((keyBatchEntitlement.getEntOnlineExpires()!=null && keyBatchEntitlement.getEntOfflineExpires()!=null)&&(keyBatchEntitlement.getEntOnlineExpires().equals(keyBatchEntitlement.getEntOfflineExpires())))){
			keyBatchEntitlement.setEntIsCopyFromOnline(Boolean.TRUE);
		}
		keyBatchEntitlement.setEntIsReusableCredit(requestEntitlement.getIsReusableCredit());
		
		return keyBatchEntitlement;
	}

	private BridgePurchase populateBridgePurchase(PurchaseVO purchaseVO, BridgePurchase bridgePurchase, Bridge bridge) {
		bridgePurchase.setBridge(bridge);
		bridgePurchase.setPurchaseName(purchaseVO.getPurchaseName());
		bridgePurchase.setDisplayPricing(purchaseVO.getDisplayPricing());
		bridgePurchase.setPurchaseUrl(purchaseVO.getPurchaseUrl());
		if(bridgePurchase.getLastModifiedDate()!=null)
			bridgePurchase.setLastModifiedDate(new Date());
		return bridgePurchase;
	}

	private BridgeAllowanceResponseVO populateBridgeAllowanceResponseVO(Bridge bridge) {
		BridgeAllowanceResponseVO data = new BridgeAllowanceResponseVO();	
		//List<EntitlementVO> entitlementVOList= this.populateEntitlementVO(bridgeEntitlementDAO.getBridgeEntitlements(bridge.getId()));
		KeyBatch keyBatch = keyBatchDAO.getKeyBatchForAutoRedeem(bridge.getId());
		if(keyBatch!=null){
		List<EntitlementVO> entitlementVOList= this.populateEntitlementVO(keyBatchEntitlementDAO.getAllEntitlementsForKeyBatch(keyBatch.getId()));
		if(bridge.getConcurrencyEnabled()){
			List<ConcurrencyEntitlementVO> concurrencyEntitlementVOList = this.populateConcurrencyEntitlementResponseVO(keyBatch);
			data.setConcurrencyEntitlements(concurrencyEntitlementVOList);
		}
			
		//List<PurchaseVO> purchaseVOList=this.populatePurchaseVO(bridgePurchaseDAO.getBridgePurchases(bridge.getId()));
		data.setEntitlements(entitlementVOList);		
		data.setBridgeId(bridge.getId());
		data.setIsConcurrencyEnabled(bridge.getConcurrencyEnabled());
		}
		
		return data;
	}

	private List<ConcurrencyEntitlementVO> populateConcurrencyEntitlementResponseVO(KeyBatch keyBatch) {
		List<ConcurrencyEntitlementVO> entitlementVOList = new ArrayList<ConcurrencyEntitlementVO>();
		ConcurrencyEntitlementVO concEntitlementVO = new ConcurrencyEntitlementVO();		
		concEntitlementVO.setCredit(keyBatch.getConcurrencyCredits());		
		concEntitlementVO.setEntitlementName(keyBatch.getConcurrencyEntitlementName());
		concEntitlementVO.setIsReturn(keyBatch.getIsReturn());
		if(keyBatch.getConcCodeType()!=null)
			concEntitlementVO.setEntitlementType(keyBatch.getConcCodeType().getType());
		concEntitlementVO.setOfflineDays(keyBatch.getOfflineConcurrencyDays());
		if(keyBatch.getOfflineConcurrencyExpires()!=null){
			concEntitlementVO.setOfflineExpires(keyBatch.getOfflineConcurrencyExpires().getTime());
			if(keyBatch.getOfflineConcurrencyExpires().equals(keyBatch.getConcurrencyExpires())){
				concEntitlementVO.setIsCopyfromOnline(Boolean.TRUE);
			}
		}
		concEntitlementVO.setOnlineDays(keyBatch.getConcurrencyDays());
		if(keyBatch.getConcurrencyExpires()!=null)
			concEntitlementVO.setOnlineExpires(keyBatch.getConcurrencyExpires().getTime());
		if(keyBatch.getOfflineConcurrencyDays()!=null && keyBatch.getOfflineConcurrencyDays().equals(keyBatch.getConcurrencyDays())){
			concEntitlementVO.setIsCopyfromOnline(Boolean.TRUE);
		}		
		entitlementVOList.add(concEntitlementVO);
		return entitlementVOList;
	}

	private List<PurchaseVO> populatePurchaseVO(List<BridgePurchase> bridgePurchases) {
		List<PurchaseVO> purchaseVOList = new ArrayList<PurchaseVO>();
		for(BridgePurchase bridgePurchase: bridgePurchases){
			PurchaseVO purchaseVO = new PurchaseVO();
			purchaseVO.setId(bridgePurchase.getId());
			purchaseVO.setPurchaseName(bridgePurchase.getPurchaseName());
			purchaseVO.setDisplayPricing(bridgePurchase.getDisplayPricing());
			purchaseVO.setPurchaseUrl(bridgePurchase.getPurchaseUrl());
			purchaseVOList.add(purchaseVO);
		}
		return purchaseVOList;
	}
	
	private BridgePurchaseResponseVO populateBridgePurchaseResponseVO(Bridge bridge) {
		BridgePurchaseResponseVO data = new BridgePurchaseResponseVO();		
		//List<EntitlementVO> entitlementVOList= this.populateEntitlementVO(bridgeEntitlementDAO.getBridgeEntitlements(bridge.getId()));
		List<PurchaseVO> purchaseVOList=this.populatePurchaseVO(bridgePurchaseDAO.getBridgePurchases(bridge.getId()));
		data.setPurchases(purchaseVOList);
		data.setBridgeId(bridge.getId());
		data.setIsPurchaseEnabled(bridge.getIsPurchasesEnabled());
		return data;
	}

	private List<EntitlementVO> populateEntitlementVO(List<KeyBatchEntitlement> keyBatchEntitlements) {
		List<EntitlementVO> entitlementVOList = new ArrayList<EntitlementVO>();
		for(KeyBatchEntitlement keyBatchEntitlement: keyBatchEntitlements){
			EntitlementVO entitlementVO = new EntitlementVO();
			/*entitlementVO.setCredit(bridgeEntitlement.getCredits());
			entitlementVO.setEntitlementName(bridgeEntitlement.getEntitlementName());
			String entitlementType= bridgeEntitlement.getEntitlementType()!=null ?bridgeEntitlement.getEntitlementType().getType() : null;
			entitlementVO.setEntitlementType(entitlementType);
			entitlementVO.setId(bridgeEntitlement.getId());
			//entitlementVO.setIsConcurrencyCredit(bridgeEntitlement.getIsConcurrencyCredit());
			entitlementVO.setIsReusableCredit(bridgeEntitlement.getIsReusableCredit());
			entitlementVO.setOfflineDays(bridgeEntitlement.getOfflineDays());
			entitlementVO.setOnlineDays(bridgeEntitlement.getOnlineDays());
			if(bridgeEntitlement.getOfflineDays()!=null && bridgeEntitlement.getOfflineDays().equals(bridgeEntitlement.getOnlineDays())){
				entitlementVO.setIsCopyfromOnline(Boolean.TRUE);
			}
			if(bridgeEntitlement.getOfflineExpires()!=null){
				entitlementVO.setOfflineExpires(bridgeEntitlement.getOfflineExpires().getTime());
				if(bridgeEntitlement.getOfflineExpires().equals(bridgeEntitlement.getOnlineExpires())){
					entitlementVO.setIsCopyfromOnline(Boolean.TRUE);
				}
			}				
			if(bridgeEntitlement.getOnlineExpires()!=null)
				entitlementVO.setOnlineExpires(bridgeEntitlement.getOnlineExpires().getTime());*/
			entitlementVO.setId(keyBatchEntitlement.getId());
			entitlementVO.setEntitlementName(keyBatchEntitlement.getEntName());
			entitlementVO.setEntitlementType(keyBatchEntitlement.getEntType().getType());
			entitlementVO.setCredit(keyBatchEntitlement.getEntCredits());
			entitlementVO.setIsReusableCredit(keyBatchEntitlement.getEntIsReusableCredit());
			entitlementVO.setIsCopyfromOnline(keyBatchEntitlement.getEntIsCopyFromOnline());
			entitlementVO.setOnlineDays(keyBatchEntitlement.getEntOnlineDays());
			entitlementVO.setOfflineDays(keyBatchEntitlement.getEntOfflineDays());
			if(keyBatchEntitlement.getEntOnlineExpires()!=null)
			entitlementVO.setOnlineExpires(keyBatchEntitlement.getEntOnlineExpires().getTime());
			if(keyBatchEntitlement.getEntOfflineExpires()!=null)
			entitlementVO.setOfflineExpires(keyBatchEntitlement.getEntOfflineExpires().getTime());
			keyBatchEntitlement.setEntIsCopyFromOnline(Boolean.FALSE);
			if((keyBatchEntitlement.getEntOnlineDays()!= null && keyBatchEntitlement.getEntOfflineDays()!=null) && (keyBatchEntitlement.getEntOnlineDays().equals(keyBatchEntitlement.getEntOfflineDays()))||((keyBatchEntitlement.getEntOnlineExpires()!=null && keyBatchEntitlement.getEntOfflineExpires()!=null)&&(keyBatchEntitlement.getEntOnlineExpires().equals(keyBatchEntitlement.getEntOfflineExpires())))){
				keyBatchEntitlement.setEntIsCopyFromOnline(Boolean.TRUE);
			}
			
			entitlementVOList.add(entitlementVO);
			
		}
		return entitlementVOList;
	}

	private BridgeEntitlement populateBridgeEntitlement(EntitlementVO entitlementVO, BridgeEntitlement bridgeEntitlement,Bridge bridge) {
		bridgeEntitlement.setBridge(bridge);
		bridgeEntitlement.setCredits(entitlementVO.getCredit());
		bridgeEntitlement.setEntitlementName(entitlementVO.getEntitlementName());
		String compType = entitlementVO.getEntitlementType();
		if(null != compType && !StringUtils.isEmpty(compType)){
			bridgeEntitlement.setEntitlementType(codeTypesDAO.getCodeForType(compType));
		}
		
		//bridgeEntitlement.setIsConcurrencyCredit(entitlementVO.getIsConcurrencyCredit());
		Date onlineExpires=entitlementVO.getOnlineExpires()!=null ? new Date(entitlementVO.getOnlineExpires()): null;
		if(entitlementVO.getIsCopyfromOnline()){
			bridgeEntitlement.setOfflineExpires(onlineExpires);
			bridgeEntitlement.setOfflineDays(entitlementVO.getOnlineDays());
		}
		else{
			Date offlineExpires=entitlementVO.getOfflineExpires()!=null ? new Date(entitlementVO.getOfflineExpires()): null;
			bridgeEntitlement.setOfflineExpires(offlineExpires);
			bridgeEntitlement.setOfflineDays(entitlementVO.getOfflineDays());
		}
		bridgeEntitlement.setOnlineDays(entitlementVO.getOnlineDays());
		bridgeEntitlement.setOnlineExpires(onlineExpires);
		bridgeEntitlement.setIsReusableCredit(entitlementVO.getIsReusableCredit());
		if(bridgeEntitlement.getLastModifiedDate()!=null)
			bridgeEntitlement.setLastModifiedDate(new Date());
		
		return bridgeEntitlement;
		
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getBridgeAllowanceForBridgeId(SessionStatusVO sessionStatusVO, Integer bridgeId,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Bridge bridge = bridgeDAO.get(bridgeId);
		if(bridge==null){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		
		response.setData(populateBridgeAllowanceResponseVO(bridge));
		
		return response;
	}

	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getAccessTypeForBridgeId(SessionStatusVO sessionStatusVO, Integer bridgeId,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Bridge bridge = bridgeDAO.get(bridgeId);
		if(bridge==null){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		
		response.setData(populateBridgeAccessTypeResponseVO(bridge));
		
		return response;
	}
	
	public BridgeAccessTypeResponseVO populateBridgeAccessTypeResponseVO(Bridge bridge){
		BridgeAccessTypeResponseVO bridgeAccessTypeResponseVO = new BridgeAccessTypeResponseVO();
		bridgeAccessTypeResponseVO.setPendingApproved(bridge.getPendingApproved());
		bridgeAccessTypeResponseVO.setDerefedSignIn(bridge.getDerefedSignIn());
		bridgeAccessTypeResponseVO.setIsIntegrated(bridge.getIsIntegrated());
		bridgeAccessTypeResponseVO.setIsRostered(bridge.getIsRostered());
		bridgeAccessTypeResponseVO.setIsSampler(bridge.getIsSampler());
		bridgeAccessTypeResponseVO.setKeysRequired(bridge.getKeysRequired());
		return bridgeAccessTypeResponseVO;
	}
	 
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public void getCsvErrorFile(SessionStatusVO sessionStatusVO, Object params, HttpServletRequest httpRequest,
			HttpServletResponse httpServletResponse, UriInfo uriInfo) {

		String err = null;
		if (params instanceof HashMap) {
			Map<String, Integer> param = (Map<String, Integer>) params;
			Integer bridgeId= param.get(ApplicationConstants.BRIDGE_ID);
			Integer logId = param.get(ApplicationConstants.ROSTER_LOG_ID);

			Bridge bridge = bridgeDAO.get(bridgeId);
			if (bridge == null || bridge.getDeleted()) {
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			
			BridgeRosterLog bridgeRosterLog = bridgeRosterLogDAO.get(logId);
			if (bridgeRosterLog == null) {
				throw new BridgeException(ApplicationCode.KEY_BATCH_NOT_FOUND);
			}
			err=bridgeRosterLog.getErrorDescription();

			httpServletResponse.setHeader("Content-Disposition", "attachment; filename=" + "default.txt");
			httpServletResponse.setContentType("application/plain");
			httpServletResponse.setContentLength(err.length());
			try {
				PrintWriter writer = httpServletResponse.getWriter();
				writer.write(err);
				httpServletResponse.flushBuffer();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse updateBridgePurchaseForBridgeId(SessionStatusVO sessionStatusVO,
			PurchaseRequestVO purchaseRequestVO, Integer bridgeId, HttpServletRequest httpRequest, UriInfo uriInfo)
			throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Bridge bridge = bridgeDAO.get(bridgeId);
		if(bridge==null){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		if(bridge!=null && bridge.getIsPurchasesEnabled()){
			if(purchaseRequestVO.getPurchases()!=null){
				List<BridgePurchase> updatedPurchaseList= new ArrayList<BridgePurchase>();
				List<BridgePurchase> purchaseDbList=bridgePurchaseDAO.getBridgePurchases(bridge.getId());
				List<PurchaseVO> purchaseVOList= purchaseRequestVO.getPurchases();
				Iterator<PurchaseVO> purchaseVOIterator=purchaseVOList.iterator();
				
				while(purchaseVOIterator.hasNext()){
					PurchaseVO purchaseVO=purchaseVOIterator.next();
					if(purchaseVO.getId()==null)
						continue;
					Iterator<BridgePurchase> purchaseDbIterator=purchaseDbList.iterator();
					while(purchaseDbIterator.hasNext()){
						BridgePurchase bridgePurchase=purchaseDbIterator.next();
						if(purchaseVO.getId().equals(bridgePurchase.getId())){
							updatedPurchaseList.add(populateBridgePurchase(purchaseVO,bridgePurchase,bridge));
							purchaseDbIterator.remove();
							purchaseVOIterator.remove();
							break;
						}
					}					
				}
				if(updatedPurchaseList.size()>0){
					bridgePurchaseDAO.saveOrUpdateAll(updatedPurchaseList);
				}
				if(purchaseDbList.size()>0){
					for(BridgePurchase bridgePurchase: purchaseDbList){
						bridgePurchase.setDeleted(Boolean.TRUE);
					}
					bridgePurchaseDAO.saveOrUpdateAll(purchaseDbList);
				}
				if(purchaseVOList.size()>0){  //New Purchase
					List<BridgePurchase> newPurchaseList = new ArrayList<BridgePurchase>();
					for(PurchaseVO purchaseVO:purchaseVOList){
						newPurchaseList.add(populateBridgePurchase(purchaseVO, new BridgePurchase(), bridge));
					}
					bridgePurchaseDAO.saveOrUpdateAll(newPurchaseList);
				}
			}
			response.setData(populateBridgePurchaseResponseVO(bridge));
		}
		else{
			throw new BridgeException(ApplicationCode.PURCHASE_NOT_ENABLED);
		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getBridgePurchaseForBridgeId(SessionStatusVO sessionStatusVO, Integer bridgeId,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Bridge bridge = bridgeDAO.get(bridgeId);
		if(bridge==null){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		if(bridge.getIsPurchasesEnabled())
			response.setData(populateBridgePurchaseResponseVO(bridge));
		
		return response;
	}
}
