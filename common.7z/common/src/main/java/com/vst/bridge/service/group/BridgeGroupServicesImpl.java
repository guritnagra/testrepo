package com.vst.bridge.service.group;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.jboss.logging.Logger;
import org.jdom2.JDOMException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.vst.bridge.JsonUtils;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.bridge.IBridgeDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookCacheDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookPricingDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupAssetDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupUserDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.entity.admin.ancillary.Ancillary;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.books.BridgeBookCache;
import com.vst.bridge.entity.bridge.books.BridgeBookPricing;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.group.BridgeGroup;
import com.vst.bridge.entity.group.GroupAsset;
import com.vst.bridge.entity.group.GroupUser;
import com.vst.bridge.rest.input.vo.BridgeGroupBookVO;
import com.vst.bridge.rest.input.vo.BridgeGroupUserVO;
import com.vst.bridge.rest.input.vo.BridgeGroupVO;
import com.vst.bridge.rest.response.vo.ConcurrencyLimitVO;
import com.vst.bridge.rest.response.vo.IdValueVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.ancillary.AncillaryBookVO;
import com.vst.bridge.rest.response.vo.bridge.BridgeBooksVO;
import com.vst.bridge.rest.response.vo.bridge.user.BridgeUserResponseVO;
import com.vst.bridge.rest.response.vo.group.BridgeGroupAssetUserVO;
import com.vst.bridge.rest.response.vo.group.BridgeGroupResponseVO;
import com.vst.bridge.rest.response.vo.group.book.BridgeGroupBookResponseVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.service.admin.AdminUserServiceUtil;
import com.vst.bridge.service.bc.IBusinessCenterServices;
import com.vst.bridge.util.DisplayPricing;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.constant.PermissionAction;
import com.vst.bridge.util.date.DateUtility;
import com.vst.bridge.util.error.Error;
import com.vst.bridge.util.error.ErrorHandlerUtil;
import com.vst.bridge.util.error.ResponseError;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.exception.BusinessCenterException;
import com.vst.bridge.util.html.HTMLParserUtil;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;

@Service("bridgeGroupServices")
public class BridgeGroupServicesImpl implements IBridgeGroupServices {
	
	@Autowired
	private ErrorHandlerUtil errorHandlerUtility;
	
	@Autowired
	private IBridgeDAO bridgeDAO;
	
	@Autowired
	private IAdminUserDAO adminUserDAO;
	
	@Autowired
	private IBridgeGroupDAO bridgeGroupDAO;
	
	@Autowired
	private LocaleMessageUtility localeMessageUtility;
	
	private Logger log = Logger.getLogger(BridgeGroupServicesImpl.class);
	
	@Autowired
	private IBridgeGroupUserDAO bridgeGroupUserDAO;
	
	@Autowired
	private IBridgeUserDAO bridgeUserDAO;
	
	@Autowired
	private IBridgeGroupAssetDAO bridgeGroupAssetDAO;
	
	@Autowired
	private IBridgeBookCacheDAO bridgeBookCacheDAO;
	
	@Autowired
	private IBridgeBookPricingDAO bridgeBookPricingDAO;
	
	@Autowired IBusinessCenterServices businessCenterServices;
	

	@Autowired
	private AdminUserServiceUtil adminUserServiceUtil;
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public RestResponse createOrUpdateBridgeGroup(SessionStatusVO sessionStatusVO, BridgeGroupVO bridgeGroupVO,
			Integer bridgeId, Integer groupId, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if(null !=bridgeGroupVO){
			ResponseError responseError =   errorHandlerUtility.validateBridgeGroupVOParameters(JsonUtils.getJsonString(bridgeGroupVO)) ;
			AdminUser adminUser = adminUserDAO.get(sessionStatusVO.getAdminId());
			adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_MANAGE, adminUser);
			BridgeGroup bridgeGroup = null;

			if(null == responseError){
				bridgeGroup = null != groupId ? bridgeGroupDAO.get(groupId) : new BridgeGroup();
				if(bridgeGroup==null || bridgeGroup.getDeleted()){
					throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
				}
				Bridge bridge = bridgeDAO.get(bridgeId);
				if(bridge==null || bridge.getDeleted()){
					throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
				}
				if(null!=bridgeGroup.getBridge() && bridgeGroup.getBridge().getId()!=bridge.getId()){
					throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
				}
				Boolean isAutoAssignUser = bridgeGroupVO.getIsAutoAssignUser()!=null ? bridgeGroupVO.getIsAutoAssignUser() : Boolean.FALSE;
				bridgeGroup.setIsAutoAssignUser(isAutoAssignUser);
				Boolean isHidden = bridgeGroupVO.getIsHidden()!=null ? bridgeGroupVO.getIsHidden() : Boolean.FALSE;
				bridgeGroup.setIsHidden(isHidden);
				Boolean isAutoAssignAsset = bridgeGroupVO.getIsAutoAssignAsset()!=null ? bridgeGroupVO.getIsAutoAssignAsset() : Boolean.FALSE;
				bridgeGroup.setIsAutoAssignAsset(isAutoAssignAsset);
				String groupName=bridgeGroupVO.getGroupName();

				if(groupName!=null && ApplicationConstants.BRIDGE_DEFAULT_GROUP_UNIVERSAL.toLowerCase().equals(groupName.toLowerCase())){
					throw new BridgeException(ApplicationCode.INVALID_GROUP_NAME);
				}
				// TODO 	fix for PAU-844 enabled when required duplicate group names
				//List<BridgeGroup> bridgeGroupList = bridgeGroupDAO.getAllGroups(bridgeId, Boolean.FALSE);
				/*for(BridgeGroup bridgeGroupsFromDB:bridgeGroupList){
					if(null==groupId && bridgeGroupsFromDB.getName().equals(groupName)){
						throw new BridgeExcepation(ApplicationCode.DUPLICATE_GROUP_NAME);
					}
					else if(null!=groupId && groupId!=bridgeGroupsFromDB.getId() && bridgeGroupsFromDB.getName().equals(groupName)){
						throw new BridgeExcepation(ApplicationCode.DUPLICATE_GROUP_NAME);
					}
				}*/
				
				long startDate=bridgeGroupVO.getActivationTime();
				long expiredDate=bridgeGroupVO.getExpirationTime();;
				bridgeGroup.setBridge(bridge);
				bridgeGroup.setName(groupName);
				if(expiredDate!=0 && startDate>expiredDate){
					throw new BridgeException(ApplicationCode.INVALID_DATE);
				}
				if(startDate!=0){
					bridgeGroup.setStartDate(DateUtility.getDateStartOfDay(new Date(startDate)));
				}
				else if(startDate==0){
					bridgeGroup.setStartDate(null);
				}
				if(expiredDate!=0){
					bridgeGroup.setExpiredDate(DateUtility.getDateEndOfDay(new Date(expiredDate)));
				}
				else if(expiredDate==0){
					bridgeGroup.setExpiredDate(null);
				}
				if(null==groupId){
					bridgeGroup.setCreatedBy(adminUser);
					bridgeGroup.setCreatedDate(new Date());
				}
				bridgeGroup.setModifiedBy(adminUser);
				bridgeGroup.setModifiedDate(new Date());									
				bridgeGroupDAO.create(bridgeGroup);
				BridgeGroupResponseVO data = populateBridgeGroupResponseVOFromBridgeGroup(bridgeGroup);
				response.setData(data);
			}
			else{
				response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
				response.setMessage(localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_INPUT.getCodeId()));
				response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
				response.setError(responseError);
				}
			}
		return response;
	}

	
	
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public RestResponse duplicateBridgeGroup(SessionStatusVO sessionStatusVO, String duplicateGroupName,
			Integer bridgeId, Integer groupId, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if(null !=duplicateGroupName){
			//ResponseError responseError =   errorHandlerUtility.validateBridgeGroupVOParameters(JsonUtils.getJsonString(bridgeGroupVO)) ;
			AdminUser adminUser = adminUserDAO.get(sessionStatusVO.getAdminId());
			adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_MANAGE, adminUser);
			BridgeGroup bridgeGroup = null;
			BridgeGroup duplicateBridgeGroup=new BridgeGroup();
			long currentDateTime= DateUtility.getDateStartOfDay(new Date()).getTime();
			//if(null == responseError){
				bridgeGroup = null != groupId ? bridgeGroupDAO.get(groupId) : new BridgeGroup();
				if(bridgeGroup==null || bridgeGroup.getDeleted()){
					throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
				}else{
					if(duplicateGroupName!=null && ApplicationConstants.BRIDGE_DEFAULT_GROUP_UNIVERSAL.toLowerCase().equals(duplicateGroupName.toLowerCase())){
						throw new BridgeException(ApplicationCode.INVALID_GROUP_NAME);
					}
					duplicateBridgeGroup.setName(duplicateGroupName);
					duplicateBridgeGroup.setBridge(bridgeGroup.getBridge());
					duplicateBridgeGroup.setCourseId(bridgeGroup.getCourseId());
					duplicateBridgeGroup.setCreatedBy(bridgeGroup.getCreatedBy());
					duplicateBridgeGroup.setCreatedDate(bridgeGroup.getCreatedDate());
					duplicateBridgeGroup.setDeleted(bridgeGroup.getDeleted());
					duplicateBridgeGroup.setDeletedBy(bridgeGroup.getDeletedBy());
					duplicateBridgeGroup.setDeletedDate(bridgeGroup.getDeletedDate());
					duplicateBridgeGroup.setExpiredDate(bridgeGroup.getExpiredDate());
					duplicateBridgeGroup.setIsActive(bridgeGroup.getIsActive());
					duplicateBridgeGroup.setModifiedBy(bridgeGroup.getModifiedBy());
					duplicateBridgeGroup.setModifiedDate(bridgeGroup.getModifiedDate());
					duplicateBridgeGroup.setSourceId(bridgeGroup.getSourceId());
					duplicateBridgeGroup.setStartDate(bridgeGroup.getStartDate());
					duplicateBridgeGroup.setVersion(bridgeGroup.getVersion());
					duplicateBridgeGroup.setIsAutoAssignAsset(bridgeGroup.getIsAutoAssignAsset());
					duplicateBridgeGroup.setIsAutoAssignUser(bridgeGroup.getIsAutoAssignUser());
					duplicateBridgeGroup.setIsHidden(bridgeGroup.getIsHidden());
					
					Integer dupGroupId = bridgeGroupDAO.create(duplicateBridgeGroup);
					if(dupGroupId!=null && dupGroupId!=0){
						List<GroupUser> groupUserList = bridgeGroupUserDAO.getAllUsersForGroup(groupId);
						if(groupUserList != null){
							for(GroupUser groupUser : groupUserList){
								GroupUser dupGroupUser = new GroupUser();
								dupGroupUser.setRole(groupUser.getRole());
								dupGroupUser.setSelected(groupUser.getSelected());
								dupGroupUser.setSourceId(groupUser.getSourceId());
								dupGroupUser.setUser(groupUser.getUser());
								dupGroupUser.setVersion(groupUser.getVersion());
								dupGroupUser.setGroup(duplicateBridgeGroup);
								bridgeGroupUserDAO.create(dupGroupUser);
							}
						}
						
						List<GroupAsset> groupAssetsList = bridgeGroupAssetDAO.getAllBooksForGroup(groupId);
						if(groupAssetsList!=null){
							for(GroupAsset groupAsset : groupAssetsList){
								GroupAsset dupGroupAsset = new GroupAsset();
								dupGroupAsset.setLastUpdated(groupAsset.getLastUpdated());
								dupGroupAsset.setSelected(groupAsset.getSelected());
								dupGroupAsset.setVbid(groupAsset.getVbid());
								dupGroupAsset.setVersion(groupAsset.getVersion());
								dupGroupAsset.setGroup(duplicateBridgeGroup);
								bridgeGroupAssetDAO.create(dupGroupAsset);
							}
						}
					}
					BridgeGroupResponseVO data = populateBridgeGroupResponseVOFromBridgeGroup(duplicateBridgeGroup);
					response.setData(data);
				}
			}else{
				response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
				response.setMessage(localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_INPUT.getCodeId()));
				response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
				ResponseError responseRrror = new ResponseError();
				Error fieldError = new Error();
				fieldError.setName("duplicateGroupName");
				fieldError.setMessage(localeMessageUtility.getErrorMessage(ApplicationCode.MISSING_INPUT_FIELD.getCodeId()));
				responseRrror.setType(ApplicationConstants.FIELD_VALIDATION_ERROR);
				responseRrror.setData(fieldError);
				response.setError(responseRrror);
			}
		return response;
	}
	
	
	
	
	
	private BridgeGroupResponseVO populateBridgeGroupResponseVOFromBridgeGroup(BridgeGroup bridgeGroup) {
		Date currentDate = new Date();
		BridgeGroupResponseVO bridgeGroupResponseVO = new BridgeGroupResponseVO();
		bridgeGroupResponseVO.setId(bridgeGroup.getId());
		bridgeGroupResponseVO.setBridgeId(bridgeGroup.getBridge().getId());
		bridgeGroupResponseVO.setActivationDate(bridgeGroup.getStartDate());
		bridgeGroupResponseVO.setExpirationDate(bridgeGroup.getExpiredDate());
		bridgeGroupResponseVO.setGroupName(bridgeGroup.getName());
		bridgeGroupResponseVO.setCourseId(bridgeGroup.getCourseId());
		bridgeGroupResponseVO.setIsAutoAssignUser(bridgeGroup.getIsAutoAssignUser());
		bridgeGroupResponseVO.setIsHidden(bridgeGroup.getIsHidden());
		bridgeGroupResponseVO.setIsAutoAssignAsset(bridgeGroup.getIsAutoAssignAsset());
		if(null!= bridgeGroup.getStartDate()){
			bridgeGroupResponseVO.setActivationTime(bridgeGroup.getStartDate().getTime());
			bridgeGroupResponseVO.setIsGroupAlive((bridgeGroup.getStartDate().before(currentDate)?Boolean.TRUE:Boolean.FALSE));
			if(null!=bridgeGroup.getExpiredDate())
				bridgeGroupResponseVO.setIsGroupAlive((bridgeGroup.getExpiredDate().after(currentDate) && bridgeGroupResponseVO.getIsGroupAlive())?Boolean.TRUE:Boolean.FALSE);
		}
		if(null!=bridgeGroup.getExpiredDate()){
			long groupExpiredTime=bridgeGroup.getExpiredDate().getTime();
			bridgeGroupResponseVO.setExpirationTime(groupExpiredTime);
			if(groupExpiredTime<new Date().getTime())
				bridgeGroupResponseVO.setIsExpired(Boolean.TRUE);
		}
		if(bridgeGroup.getExpiredDate()== null && bridgeGroup.getStartDate()==null)
			bridgeGroupResponseVO.setIsGroupAlive(Boolean.TRUE);
		
		return bridgeGroupResponseVO;
	}
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public RestResponse getGroupsForBridgeId(SessionStatusVO sessionStatusVO, Integer bridgeId, Boolean refreshGroups,
			Boolean getDeletedGroups,HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, BusinessCenterException, IOException, ConnectApiException, JDOMException, ParseException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		List<BridgeGroupResponseVO> resultVO = null;
		if(null != bridgeId) {
			Bridge bridge = bridgeDAO.get(bridgeId);
 			if(bridge == null || bridge.getDeleted()){
 				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
 			}
 			if(refreshGroups!=null && refreshGroups){
 				businessCenterServices.createOrUpdateCoursesForTenantId(sessionStatusVO,bridgeId,bridge.getBcTenantId(),httpRequest,uriInfo,null,Boolean.FALSE);
 			}
			List<BridgeGroup> bridgeGroups = bridgeGroupDAO.getAllGroups(bridgeId, getDeletedGroups,Boolean.TRUE);
			if(null != bridgeGroups && bridgeGroups.size() > 0){
				resultVO = new ArrayList<BridgeGroupResponseVO>();
				for(BridgeGroup bridgeGroup : bridgeGroups){
					resultVO.add(this.populateBridgeGroupResponseVOFromBridgeGroup(bridgeGroup));
				}
				response.setData(resultVO);
				ConcurrencyLimitVO concurrencyLimitVO = this.populateConcurrencyDetails(new ConcurrencyLimitVO(),bridge);
				response.setMetadata(concurrencyLimitVO);
			}
			
		}
		
		return response;
	}

	private ConcurrencyLimitVO populateConcurrencyDetails(ConcurrencyLimitVO concurrencyLimitVO,Bridge bridge) {
		concurrencyLimitVO.setConcurrencyLimit(bridge.getConcurrencyLimit());
		concurrencyLimitVO.setIsConcurrencyEnabled(bridge.getConcurrencyEnabled());
		return concurrencyLimitVO;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public RestResponse updateBridgeGroupUsers(SessionStatusVO sessionStatusVO, BridgeGroupUserVO bridgeGroupUserVO,
			Integer bridgeId, Integer groupId, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		AdminUser adminUser = adminUserDAO.get(sessionStatusVO.getAdminId());
		adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_MANAGE, adminUser);
		if(null!=bridgeGroupUserVO && bridgeGroupUserVO.getUsers().size()>0){
			ResponseError responseError = errorHandlerUtility.validateBridgeGroupUsersVOParameters(JsonUtils.getJsonString(bridgeGroupUserVO));
			
			if(null==responseError){
				BridgeGroup bridgeGroup =bridgeGroupDAO.get(groupId);
				if(bridgeGroup==null || bridgeGroup.getDeleted()){
					throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
				}
				
				int deletedGroupUsers = bridgeGroupUserDAO.deleteGroupUsersForGroup(groupId);
				log.info("Removed " + deletedGroupUsers + " GroupUsers for Bridge Group " +  groupId);
				
				List<Integer> groupUserList=bridgeGroupUserVO.getUsers();
				
				Set<GroupUser> groupUserSet = new HashSet<>();
				for(Integer userId:groupUserList){
					BridgeUser bridgeUser = bridgeUserDAO.get(userId);
					if(null == bridgeUser){
						throw new BridgeException(ApplicationCode.BRIDGE_USER_NOT_FOUND);
					}else{
						GroupUser groupUser = bridgeGroupUserDAO.getGroupUser(groupId, userId);
						if (null == groupUser){
							groupUser= new GroupUser();
							groupUser.setGroup(bridgeGroup);
							groupUser.setUser(bridgeUser);
						}
						groupUser.setSelected(Boolean.TRUE);
						groupUserSet.add(groupUser);
						log.info("Add group " + groupUser);
					}
				}
				
				bridgeGroupUserDAO.saveOrUpdateAll(groupUserSet);
				log.info("Total Groups Users updated for Group "+groupId+" on Bridge "+bridgeId+": " +groupUserSet.size());
				
				//List<GroupUser> allDbUserList =bridgeGroupUserDAO.getAllUsersForGroup(groupId);
				//Iterator<GroupUser> allDbUserIterator =allDbUserList.iterator();
				//Iterator<Integer> groupUserListIterator=groupUserList.iterator();
				//List<GroupUser> toAddUserList= new ArrayList<GroupUser>();
				//List<Integer> toRemoveForList= new ArrayList<Integer>();
				//while(allDbUserIterator.hasNext()){
//					Boolean isUserFound=Boolean.FALSE;
//					GroupUser groupUser=allDbUserIterator.next();
//					for(Integer inputUser:groupUserList){
//						if(inputUser.equals(groupUser.getUser().getId())){
//							groupUser.setSelected(Boolean.TRUE);  
//							toRemoveForList.add(inputUser);
//							toAddUserList.add(groupUser);
//							isUserFound=Boolean.TRUE;
//							break;
//						}
					//}
//					if(!isUserFound){
//						groupUser.setSelected(Boolean.FALSE);
//						toAddUserList.add(groupUser);
//					}
//				}
//				groupUserList.removeAll(toRemoveForList);
//				for(Integer userId :groupUserList){
//					GroupUser groupUser= new GroupUser();
//					BridgeUser bridgeUser=bridgeUserDAO.get(userId);
//					if(null!=groupUserList && null!=bridgeUser && bridgeId!=bridgeUser.getBridge().getId()){
//						throw new BridgeExcepation(ApplicationCode.BRIDGE_USER_NOT_FOUND);
//					}
//					groupUser.setUser(bridgeUser);
//					groupUser.setGroup(bridgeGroup);
//					groupUser.setSelected(Boolean.TRUE);
//					toAddUserList.add(groupUser);
//				}
//				bridgeGroupUserDAO.saveOrUpdateAll(toAddUserList);
						
			}
			else{
				response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
				response.setMessage(localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_INPUT.getCodeId()));
				response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
				response.setError(responseError);
			}
		}
		return response;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public RestResponse updateBridgeGroupBooks(SessionStatusVO sessionStatusVO, BridgeGroupBookVO bridgeGroupBookVO,
			Integer bridgeId, Integer groupId, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException {
		// TODO Auto-generated method stub
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		AdminUser adminUser = adminUserDAO.get(sessionStatusVO.getAdminId());
		adminUserServiceUtil.validateAdminPermission(PermissionAction.EDIT_MANAGE, adminUser);
		if(null!=bridgeGroupBookVO && bridgeGroupBookVO.getBooks().size()>0){
			ResponseError responseError = errorHandlerUtility.validateBridgeGroupBooksVOParameters(JsonUtils.getJsonString(bridgeGroupBookVO));			
			if(null==responseError){
				BridgeGroup bridgeGroup =bridgeGroupDAO.get(groupId);
				if(bridgeGroup==null || bridgeGroup.getDeleted()){
					throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
				}
				List<String> groupBookList=bridgeGroupBookVO.getBooks();
				List<GroupAsset> allDbAssetList =bridgeGroupAssetDAO.getAllBooksForGroup(groupId);
				Iterator<GroupAsset> allDbAssetIterator=allDbAssetList.iterator();
				List<GroupAsset> toAddBookList= new ArrayList<GroupAsset>();
				List<String> toRemoveForList= new ArrayList<String>();
				while(allDbAssetIterator.hasNext()){
					Boolean isBookFound=Boolean.FALSE;
					GroupAsset groupAsset=allDbAssetIterator.next();
					for(String vbid:groupBookList){
						if(vbid.equals(groupAsset.getVbid())){
							groupAsset.setSelected(Boolean.TRUE);
							toRemoveForList.add(vbid);
							toAddBookList.add(groupAsset);
							isBookFound=Boolean.TRUE;
							break;
						}
					}
					if(!isBookFound){
						groupAsset.setSelected(Boolean.FALSE);
						toAddBookList.add(groupAsset);
					}
				}				
				groupBookList.removeAll(toRemoveForList);
				for(String vbid :groupBookList){
					GroupAsset groupAsset= new GroupAsset();
					groupAsset.setVbid(vbid);
					groupAsset.setGroup(bridgeGroup);
					groupAsset.setSelected(Boolean.TRUE);
					toAddBookList.add(groupAsset);
				}
				bridgeGroupUserDAO.saveOrUpdateAll(toAddBookList);
			}
			else{
				response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
				response.setMessage(localeMessageUtility.getErrorMessage(ApplicationCode.INVALID_INPUT.getCodeId()));
				response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
				response.setError(responseError);
			}
		}
		return response;
	}
	
	private void validateAndRearangePaginationVO(PaginationVO paginationVo,String defaultOrderBy, Boolean forBook) {
		
		Integer page = paginationVo.getPage();
		if(null==page || page==0){
			paginationVo.setPage(ApplicationConstants.DEFAULT_GET_BOOK_PAGE_VALUE);
		}
		
		Integer limit = paginationVo.getLimit();
		if(null==limit || limit==0){
			paginationVo.setLimit(ApplicationConstants.DEFAULT_GET_BOOK_LIMIT_VALUE);
		}
		
		String orderby = paginationVo.getOrderBy();
		if(forBook){
			if(!StringUtils.isEmpty(orderby) && !ApplicationConstants.validBookOrderByValues.contains(orderby)){
				throw new BridgeException(ApplicationCode.INVALID_ORDERBY_FIELD);
			}
		}else{
			if(!StringUtils.isEmpty(orderby) && !ApplicationConstants.validUsersOrderByValues.contains(orderby)){
				throw new BridgeException(ApplicationCode.INVALID_ORDERBY_FIELD);
			}
		}
		
		if(null == orderby || StringUtils.isEmpty(orderby)){
			paginationVo.setOrderBy(defaultOrderBy);
		}
		
		String order = paginationVo.getOrder();
		if(null == order || StringUtils.isEmpty(order)){
			paginationVo.setOrder(ApplicationConstants.DEFAULT_GET_BOOK_ORDER_VALUE);
		}
	}
	
	private Integer calculateStartIndexForUser(final int currentPage, final int totalRowsToFetch) {
		final Integer startIndex = (currentPage * totalRowsToFetch) - totalRowsToFetch;
		return startIndex;
	}
	
	private Integer calculateTotalPageCount(final int totalCount, final int totalRowsToFetch) {
		final Integer pageCount = (int) Math.ceil((double) totalCount / totalRowsToFetch);
		return pageCount;
	}
	/**
	 * Get list of users. Hybrid api , if groupId is sent, then return users for the group. 
	 * If groupId is not provided, then return all users from the bridge.
	 * 
	 * Authenticated: yes
	 * @throws ConnectApiException 
	 * @throws IOException 
	 * @throws BusinessCenterException 
	 * @throws BridgeException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 * @response.representation.200.doc  Returns a summary of all available portals
	 * @response.representation.200.mediaType application/json
	 * @response.representation.200.example {
	 * 
	 * }
	 */

	@Override
	@Transactional(propagation=Propagation.REQUIRES_NEW,readOnly=false)
	public RestResponse getGroupUsersForBridgeId(SessionStatusVO sessionStatusVO,Integer bridgeId, Integer groupId, PaginationVO paginationVo, Boolean isGrouped, Boolean bcRefresh) throws JsonParseException, JsonMappingException, BridgeException, BusinessCenterException, IOException, ConnectApiException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		
		 if(null != bridgeId) {
			Bridge bridge = bridgeDAO.get(bridgeId);
			if(bridge == null || bridge.getDeleted()){
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			bcRefresh= bcRefresh!=null ? bcRefresh : Boolean.FALSE;
			if(bcRefresh){
				businessCenterServices.getUsersForTenantId(sessionStatusVO, bridgeId, bridge.getBcTenantId(), null, null,null, Boolean.FALSE);
			}
			/*BridgeGroup group = bridgeGroupDAO.get(groupId);
			if(group == null || group.getDeleted() || group.getBridge().getId() != bridgeId) {
				throw new BridgeExcepation(ApplicationCode.GROUP_NOT_FOUND);
			}*/
			this.validateAndRearangePaginationVO(paginationVo, ApplicationConstants.DEFAULT_GET_USER_ORDER_BY_VALUE, Boolean.FALSE);
			Integer startIndex = calculateStartIndexForUser(paginationVo.getPage(), paginationVo.getLimit());
			Integer  totalRecords = null;
			BridgeGroup bg=null;
			if(null!=groupId){
				bg = bridgeGroupDAO.get(groupId);
				if(bg == null || bg.getDeleted() || bg.getBridge().getId() != bridgeId) {
					throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
				}				
			}			
			if(null!=groupId && !bg.getIsAutoAssignUser()){
				
				
				List<BridgeUserResponseVO> resultBridgeGroupUserVO = bridgeGroupUserDAO.getUsersForGroup(groupId, startIndex, paginationVo);
				for(BridgeUserResponseVO bridgeUserResponseVO:resultBridgeGroupUserVO)
				{
					bridgeUserResponseVO.setActivationTime(bridgeUserResponseVO.getActivationDate().getTime());
				}
				response.setData(resultBridgeGroupUserVO);
				totalRecords = bridgeGroupUserDAO.getUsersCountForGroup(groupId, paginationVo);				
			}
			else{
				//List<BridgeUserResponseVO> resultBridgeUserVOs = bridgeUserDAO.getUsersForBridge(bridgeId,startIndex,paginationVo);
				List<BridgeUserResponseVO> bridgeUserVOs = bridgeUserDAO.getUsersForBridge(bridgeId, paginationVo);
				List<BridgeUserResponseVO> filteredBridgeUserVOs = new ArrayList<BridgeUserResponseVO>(); 
				List<BridgeUserResponseVO> resultBridgeUserVOs = new ArrayList<BridgeUserResponseVO>();
				List<BridgeGroup> bridgeGroups= bridgeGroupDAO.getAllGroups(bridgeId,Boolean.FALSE,Boolean.FALSE);
				List<Integer> groupIds= new ArrayList<Integer>();
				
				for(BridgeGroup bridgeGroup:bridgeGroups){
					groupIds.add(bridgeGroup.getId());
				}			
				
				List<Integer> groupedUsers=null;

				for(BridgeGroup bridgeGroup:bridgeGroups){
					groupIds.add(bridgeGroup.getId());
				}			

				if(groupIds.size()>0)
					groupedUsers=bridgeGroupUserDAO.getGroupUsersForBridge(groupIds);
				
				for(BridgeUserResponseVO bridgeUserVO:bridgeUserVOs){
					bridgeUserVO.setActivationTime(bridgeUserVO.getActivationDate().getTime());
					Integer userId = bridgeUserVO.getId();
					if(null != groupedUsers){
						bridgeUserVO.setIsGroupMember(groupedUsers.contains(userId));
					}
					if(null != isGrouped && groupedUsers != null) {
						if (isGrouped && bridgeUserVO.getIsGroupMember()) {
							filteredBridgeUserVOs.add(bridgeUserVO);
						} else if (!isGrouped && !bridgeUserVO.getIsGroupMember()) {
							filteredBridgeUserVOs.add(bridgeUserVO);
						}
					} else {
						filteredBridgeUserVOs.add(bridgeUserVO);
					}
				}
				
				Integer totalRecordToFetch = paginationVo.getLimit();
				
				for(int i = startIndex; i < filteredBridgeUserVOs.size() && totalRecordToFetch >= 0; i ++) {
					resultBridgeUserVOs.add(filteredBridgeUserVOs.get(i));
					totalRecordToFetch--;
				}
				
				
				response.setData(resultBridgeUserVOs);
				totalRecords = filteredBridgeUserVOs.size();
				
			}
			Integer totalPages = calculateTotalPageCount(totalRecords,paginationVo.getLimit());		
			Integer offset=this.calculateOffsetValue(paginationVo.getPage(),paginationVo.getLimit());
			PaginationVO paginationVOMetadata = new PaginationVO(paginationVo.getPage(), paginationVo.getLimit(), totalPages, paginationVo.getOrderBy(), paginationVo.getOrder(), paginationVo.getSearch(), totalRecords,offset);
			if(bg!=null){
				paginationVOMetadata.setMetadataName(bg.getName());
			}			
			response.setMetadata(paginationVOMetadata);
		}
		
		return response;
	}
	
	private Integer calculateOffsetValue(Integer page, Integer limit) {
		if(page!=null){
			return (page-1)*limit;
		}
		return 0;
	}
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getGroupBooksForBridgeId(Integer bridgeId, Integer groupId, BridgePaginationVo paginationVo, String category) {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		
		List<GroupAsset> groupAssets = null;
		List<BridgeBookCache> bridgeBookCaches = null;
		List<String> vbids = new ArrayList<String>();
		List<BridgeGroupBookResponseVO> responseVO = null;
		
		if(null != bridgeId && null != groupId) {
			Bridge bridge = bridgeDAO.get(bridgeId);
			if(bridge == null || bridge.getDeleted()){
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			BridgeGroup group = bridgeGroupDAO.get(groupId);
			if(group == null || group.getDeleted() || group.getBridge().getId() != bridgeId) {
				throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
			}
			
			this.validateAndRearangePaginationVO(paginationVo, ApplicationConstants.DEFAULT_GET_BOOK_ORDER_BY_VALUE, Boolean.TRUE);
			Integer startIndex = calculateStartIndexForUser(paginationVo.getPage(), paginationVo.getLimit());
			
			if(!group.getIsAutoAssignAsset()){
				groupAssets = bridgeGroupAssetDAO.getAllBooksForGroup(groupId);
				
				for(GroupAsset groupAsset : groupAssets) {
					vbids.add(groupAsset.getVbid());
				}
				
				bridgeBookCaches = bridgeBookCacheDAO.getCacheBooks(bridgeId, startIndex, paginationVo, vbids, Boolean.FALSE, category);
			}
			else{
				bridgeBookCaches = bridgeBookCacheDAO.getCacheBooks(bridgeId, startIndex, paginationVo, null, Boolean.FALSE, category);
			}
			Integer  totalRecords = bridgeBookCacheDAO.getCacheBookCount(bridgeId, paginationVo, vbids, Boolean.FALSE, category);
			
			Integer totalPages = calculateTotalPageCount(totalRecords,paginationVo.getLimit());
			Integer offset= this.calculateOffsetValue(paginationVo.getPage(), paginationVo.getLimit());
			PaginationVO paginationVOMetadata = new PaginationVO(paginationVo.getPage(), paginationVo.getLimit(), totalPages, paginationVo.getOrderBy(), paginationVo.getOrder(), paginationVo.getSearch(), totalRecords,offset);
			paginationVOMetadata.setMetadataName(group.getName());
			
			if(null != bridgeBookCaches && bridgeBookCaches.size() > 0) {
				responseVO = new ArrayList<BridgeGroupBookResponseVO>();
				for(BridgeBookCache bridgeBookCache: bridgeBookCaches) {
					responseVO.add(this.populateBridgeGroupBookResponseVOFromBridgeBookCache(bridgeBookCache,bridge));
				}
				response.setData(responseVO);			
			}
			response.setMetadata(paginationVOMetadata);
		}
		
		return response;
	}
	
	private BridgeGroupBookResponseVO populateBridgeGroupBookResponseVOFromBridgeBookCache(BridgeBookCache bridgeBookCache,Bridge bridge) {
		
		BridgeGroupBookResponseVO bridgeGroupResponseVO = new BridgeGroupBookResponseVO();
		this.populatePricingforGroupBook(bridgeGroupResponseVO, bridgeBookCache, bridge);
		bridgeGroupResponseVO.setVbid(bridgeBookCache.getVbid());
		bridgeGroupResponseVO.seteBookIsbn(bridgeBookCache.getEbookIsbn());
		bridgeGroupResponseVO.setTextbookIsbn(bridgeBookCache.getTextbookIsbn());
		bridgeGroupResponseVO.setCoverImageUrl(bridgeBookCache.getCoverImageUrl().toString());
		String title = bridgeBookCache.getTitle();
		/*title = StringEscapeUtils.unescapeHtml(title);
		title = StringEscapeUtils.unescapeJava(title);
		title = HTMLParserUtil.parseHTML(title);*/
		bridgeGroupResponseVO.setTitle(title);
		bridgeGroupResponseVO.setFileType(bridgeBookCache.getFileType());
		
		String description = bridgeBookCache.getDescription();
		/*description = StringEscapeUtils.unescapeHtml(description);
		description = StringEscapeUtils.unescapeJava(description);
		description = HTMLParserUtil.parseHTML(description);*/
		bridgeGroupResponseVO.setDescription(description);
		bridgeGroupResponseVO.setAuthor(bridgeBookCache.getAuthor());
		bridgeGroupResponseVO.setEdition(bridgeBookCache.getEdition());
		if(bridge.getConcurrencyEnabled()){
			Integer concurrencyLimit=bridgeBookCache.getConcurrencyLimit()!=null ?bridgeBookCache.getConcurrencyLimit():bridge.getConcurrencyLimit();
			bridgeGroupResponseVO.setConcurrencyLimit(concurrencyLimit);
		}
		if(null != bridgeBookCache.getAncillary()){		
			bridgeGroupResponseVO.setAncillaryMetaData(createAncillaryMetaData(bridgeBookCache.getAncillary()));
		}
			
		
		return bridgeGroupResponseVO;
		
	}
	private AncillaryBookVO createAncillaryMetaData(Ancillary ancillary) {
		AncillaryBookVO metaData = new AncillaryBookVO(ancillary);
		return metaData;
	}
	
	private void populatePricingforGroupBook(BridgeGroupBookResponseVO bridgeGroupResponseVO, BridgeBookCache cacheBook, Bridge bridge) {
		DisplayPricing displayPrice= new DisplayPricing();
		displayPrice.seteTextPriceType(bridge.geteTextPrice());
		displayPrice.setRentalPriceType(bridge.getRentalPrice());
		displayPrice.setTextBookPriceType(bridge.getTextBookPrice());
		BridgeBookPricing baseVbidPricing=bridgeBookPricingDAO.getBookPricingByRentalType(cacheBook.getId(),null);
		if(baseVbidPricing!=null){
			if(StringUtils.equals(ApplicationConstants.PUBLISHER_PRICE_TYPE, displayPrice.geteTextPriceType())){
				bridgeGroupResponseVO.seteTextPrice(baseVbidPricing.getPublisherPrice());
			}
			else{
				bridgeGroupResponseVO.seteTextPrice(baseVbidPricing.getDigitalPrice());
			}
			if(StringUtils.equals(ApplicationConstants.DIGITAL_PRICE_TYPE, displayPrice.getTextBookPriceType())){
				bridgeGroupResponseVO.setTextBookPrice(baseVbidPricing.getDigitalPrice());
			}
			else{
				bridgeGroupResponseVO.setTextBookPrice(baseVbidPricing.getPublisherPrice());
			}
			BridgeBookPricing rentalVbidPricing=bridgeBookPricingDAO.getBookPricingByRentalType(cacheBook.getId(),displayPrice.getRentalPriceType());
			if(rentalVbidPricing!=null){
				if(StringUtils.equals(ApplicationConstants.PUBLISHER_PRICE_TYPE, displayPrice.getRentalPriceType()))
					bridgeGroupResponseVO.setRentalPrice(rentalVbidPricing.getPublisherPrice());
				else
					bridgeGroupResponseVO.setRentalPrice(rentalVbidPricing.getDigitalPrice());
			}
			else{
				bridgeGroupResponseVO.setRentalPrice(baseVbidPricing.getDigitalPrice());
			}
		}	
		
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public RestResponse addBulkGroupAssetUsers(Integer bridgeId, BridgeGroupAssetUserVO groupAssetUsersVO)
			throws BridgeException, ParseException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		
		Bridge bridge = bridgeDAO.get(bridgeId);
		
		if(bridge == null || bridge.getDeleted()){
			throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
		}
		
		if(null != groupAssetUsersVO){
			
			List<Integer> groups = groupAssetUsersVO.getGroups();
			if((groupAssetUsersVO.getAllUsers()!=null && groupAssetUsersVO.getAllUsers()) || (groupAssetUsersVO.getUsers()!=null)){
				BridgeGroup defaultBridgeGroup=bridgeGroupDAO.getDefaultGroup(bridgeId);
				if(defaultBridgeGroup.getId()!=null){
					groups.remove(defaultBridgeGroup.getId());
				}
			}
			if(groups != null && groups.size() > 0){
				
				String searchParam=null;
				Boolean isGrouped=Boolean.FALSE;
				Boolean allEntities=Boolean.FALSE;
				if(groupAssetUsersVO.getSearchParam()!=null){
					if(groupAssetUsersVO.getSearchParam().getIsGrouped()==null || (groupAssetUsersVO.getSearchParam().getIsGrouped()!=null && !groupAssetUsersVO.getSearchParam().getIsGrouped())){
						allEntities = Boolean.TRUE;
					}
					searchParam=groupAssetUsersVO.getSearchParam().getSearchString();
					isGrouped=groupAssetUsersVO.getSearchParam().getIsGrouped()!=null ?groupAssetUsersVO.getSearchParam().getIsGrouped():Boolean.TRUE;
				}
				for(Integer groupId : groups){
					
					BridgeGroup group = bridgeGroupDAO.get(groupId);
					if(group == null || group.getDeleted() || group.getBridge().getId() != bridgeId) {
						throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
					}
					if(group!=null && group.getCourseId()!=null){ //
						continue;
					}
					Boolean addAllUsers = groupAssetUsersVO.getAllUsers();
					List<Integer> users = null;
					List<GroupUser> groupUserList=null;
					if(null != addAllUsers && addAllUsers){	
						if(searchParam==null && allEntities){
							users = bridgeUserDAO.getUserIdsForBridge(bridgeId);	
						}
						else{
							List<BridgeUserResponseVO> userResponseList=this.getFilteredUserResponseVO(searchParam,bridgeId);
							users= new ArrayList<Integer>();
							for(BridgeUserResponseVO userResponseVO:userResponseList){
								List<BridgeGroup> userGroups = bridgeGroupUserDAO.getGroupsForUser(userResponseVO.getId(), Boolean.FALSE, Boolean.TRUE, Boolean.TRUE);
								if(isGrouped){
										users.add(userResponseVO.getId());
								}
								else if(!isGrouped){
									if(userGroups.isEmpty())
									users.add(userResponseVO.getId());
								}
							}
						}
						 	
					}else{
						users = groupAssetUsersVO.getUsers();	
					}
					if(users!=null && users.size()>0)
						groupUserList= bridgeGroupUserDAO.getUsersForGroup(groupId, users);
					HashMap<Integer,GroupUser> groupUserMap= new HashMap<Integer,GroupUser>();
					if(groupUserList!=null){
						for(GroupUser groupUser:groupUserList){
							groupUserMap.put(groupUser.getUser().getId(),groupUser);
						}
					}
					if(null != users && users.size() > 0){
					//	List<GroupUser> groupUsers = new ArrayList<GroupUser>();
						int insertedCount = 0;	
						int batchSize=50;
						//long temp = System.currentTimeMillis();
						for(int i=0; i<users.size();i++){
							Integer userId=users.get(i);
							//BridgeUser user = bridgeUserDAO.get(userId);
							///if(user == null){
							//	throw new BridgeExcepation(ApplicationCode.USER_NOT_FOUND);
							//}
							
							//GroupUser groupUser = bridgeGroupUserDAO.getGroupUser(groupId, userId,Boolean.FALSE,Boolean.TRUE,Boolean.FALSE);
							GroupUser groupUser=null;
							if(groupUserMap!=null){
								groupUser=groupUserMap.get(userId);
							}
													
							groupUser = null!=groupUser ? groupUser : new GroupUser();
							groupUser.setGroup(group);
							groupUser.setUser(bridgeUserDAO.load(userId));
							groupUser.setSelected(Boolean.TRUE);
							//groupUsers.add(groupUser);
							bridgeGroupUserDAO.saveOrUpdate(groupUser);
							insertedCount++;
							if(insertedCount % batchSize==0){
								//System.out.println("before commit"+new Date() + "******** bridgeGroupUserDAO.getGroupUser Time : " + (System.currentTimeMillis() - temp));
								//long before = System.currentTimeMillis();
								bridgeGroupUserDAO.flushAndClear();
								//System.out.println("Flush Time : " + (System.currentTimeMillis() - before));
								//temp = System.currentTimeMillis();
							}
						}
						
						//bridgeGroupUserDAO.saveOrUpdateAll(groupUsers);						
					}
					
					List<String> books = null;
					Boolean addAllAssets = groupAssetUsersVO.getAllAssets();
					if(null != addAllAssets && addAllAssets){
						if(searchParam==null && allEntities){
							books = bridgeBookCacheDAO.getCacheBookVbids(bridgeId);
							books = new ArrayList<String>(books);
						}
						else{
							String category = null; 
							List<BridgeBooksVO> bridgebooksVOList=this.getFilteredBridgeBooksVO(bridgeId,bridge,searchParam,isGrouped, category);							
							books= new ArrayList<String>();
							for(BridgeBooksVO bridgebooksVO: bridgebooksVOList){
								books.add(bridgebooksVO.getVbid());
							}
						}
						
					}else{						
						 books = groupAssetUsersVO.getBooks();
					}
					if(null != books && books.size() > 0){
						List<GroupAsset> groupAssets = new ArrayList<GroupAsset>();
						for(String vbid : books){
							GroupAsset groupAsset = bridgeGroupAssetDAO.getGroupAsset(groupId,vbid);
							groupAsset = null !=	groupAsset ? groupAsset : new GroupAsset();
							groupAsset.setGroup(group);
							groupAsset.setVbid(vbid);
							groupAsset.setSelected(Boolean.TRUE);
							groupAssets.add(groupAsset);
						}
						bridgeGroupAssetDAO.saveOrUpdateAll(groupAssets);
					}
				}								
			}			
		}
		
		return response;
	}
	
	private List<BridgeBooksVO> getFilteredBridgeBooksVO(Integer bridgeId,Bridge bridge, String searchParam, Boolean isGrouped, String category) {
		BridgePaginationVo bridgePaginationVO = new BridgePaginationVo(bridgeId, null,  null, null, null, null, null, searchParam, null,null);
		this.validateAndRearangePaginationVO(bridgePaginationVO);
		List<BridgeBookCache> filterBookList=bridgeBookCacheDAO.getCacheBooks(bridgeId, bridgePaginationVO, null, Boolean.FALSE, category);
		return this.populateBridgeBooksVOFromConnectBook(filterBookList, bridge, bridgePaginationVO, isGrouped);
		
	}

	private List<BridgeUserResponseVO> getFilteredUserResponseVO(String searchParam, Integer bridgeId) {
		PaginationVO paginationVO= new PaginationVO(null, null, null, null, null, searchParam, null,0);
		this.validateAndRearangePaginationVO(paginationVO, ApplicationConstants.DEFAULT_GET_USER_ORDER_BY_VALUE, Boolean.FALSE);
		return bridgeUserDAO.getUsersForBridge(bridgeId, paginationVO);
		
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public RestResponse deleteBridgeGroupUsers(SessionStatusVO sessionStatusVO, List<Integer>userIds,
			Integer bridgeId, Integer groupId,Boolean deleteAll,String search,Boolean isGrouped, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		

		if((null!=userIds && userIds.size()>0)|| (deleteAll!=null && deleteAll)){

				BridgeGroup bridgeGroup =bridgeGroupDAO.get(groupId);
				if(bridgeGroup==null || bridgeGroup.getDeleted()){
					throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
				}
				
				List<GroupUser> allUserList = bridgeGroupUserDAO.getAllUsersForGroup(groupId);	
				List<BridgeUserResponseVO> filterUserList=null;
				if(null != allUserList && allUserList.size() > 0){
					if(null != deleteAll && deleteAll){
						if(StringUtils.isNotBlank(search)){
							filterUserList =this.getFilteredUserResponseVO(search, bridgeId);
							isGrouped=isGrouped!=null ?isGrouped :Boolean.FALSE;
						}
					for(GroupUser allUser:allUserList){
						if(filterUserList!=null && filterUserList.size()>0){
							for(BridgeUserResponseVO filterUserResponseVO:filterUserList){								
								if(filterUserResponseVO.getId().equals(allUser.getUser().getId())){
									if(isGrouped && filterUserResponseVO.getIsGroupMember()){
										allUser.setSelected(Boolean.FALSE);
									}
									else{
										allUser.setSelected(Boolean.FALSE);
									}
									
								}
							}
						}
						else{
							allUser.setSelected(Boolean.FALSE);
						}
						
					}						
					}else{
					//	List<GroupUser> updateUsers = new ArrayList<GroupUser>();					
						for(Integer groupUser:userIds) {
							for(GroupUser allUser:allUserList){
								if(groupUser.equals(allUser.getUser().getId())){
									allUser.setSelected(Boolean.FALSE);
						//			updateUsers.add(allUser);
									break;
								}
							}
						}
					}
				}
				bridgeGroupUserDAO.saveOrUpdateAll(allUserList);
		}
		return response;
	}
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public RestResponse deleteBridgeGroupBooks(SessionStatusVO sessionStatusVO, List<String> vbids,
			Integer bridgeId, Integer groupId, Boolean deleteAll,String search, Boolean isGrouped, String category, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException {
		
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		

				Bridge bridge = bridgeDAO.get(bridgeId);
				isGrouped=isGrouped!=null?isGrouped :Boolean.FALSE;
				BridgeGroup bridgeGroup =bridgeGroupDAO.get(groupId);
				if(bridgeGroup==null || bridgeGroup.getDeleted()){
					throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
				}
				
				List<GroupAsset> allBooksList = bridgeGroupAssetDAO.getAllBooksForGroup(groupId);								
				List<BridgeBooksVO> bridgebooksVOList=null;		
				if(null != deleteAll && deleteAll){
					if(null != allBooksList && allBooksList.size() > 0){
						if(search!=null){
							bridgebooksVOList=this.getFilteredBridgeBooksVO(bridgeId,bridge,search,isGrouped,category);		
						}
						for(GroupAsset groupAsset : allBooksList){							
							if(bridgebooksVOList!=null && bridgebooksVOList.size()>0){
								for(BridgeBooksVO filterBookVO:bridgebooksVOList){									
									if(StringUtils.equals(filterBookVO.getVbid(), groupAsset.getVbid())){
										groupAsset.setSelected(Boolean.FALSE);
									}
								}
							}
							else{
								groupAsset.setSelected(Boolean.FALSE);
							}
							
						}
						bridgeGroupAssetDAO.saveOrUpdateAll(allBooksList);
					}
				}else if(vbids != null && vbids.size() > 0){
					Map<String,GroupAsset> vbidToGroupAssetMap = allBooksList.stream().collect(Collectors.toMap(GroupAsset::getVbid, ga -> ga));
					for(String groupBook:vbids) {
						GroupAsset groupAsset = vbidToGroupAssetMap.get(groupBook);
						if(null != groupAsset) {
							groupAsset.setSelected(Boolean.FALSE);
						}
					}
					bridgeGroupAssetDAO.flushAndClear();
				}
				

		return response;
	}
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public RestResponse deleteBridgeGroup(SessionStatusVO sessionStatusVO,Integer bridgeId, Integer groupId, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));	
				
			if(bridgeId!=null && groupId!=null){
				BridgeGroup bridgeGroup =bridgeGroupDAO.get(groupId);
				if(bridgeGroup==null || bridgeGroup.getDeleted()){
					throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
				}
				if(!bridgeId.equals(bridgeGroup.getBridge().getId())){
					throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
				}
				bridgeGroup.setDeleted(Boolean.TRUE);
				bridgeGroup.setDeletedBy(adminUserDAO.get(sessionStatusVO.getAdminId()));
				bridgeGroup.setDeletedDate(new Date());
				bridgeGroupDAO.saveOrUpdate(bridgeGroup);
			}
			else{
				throw new BridgeException(ApplicationCode.ERROR_VALIDATION_INPUT_FIELD);				
			}
		
		return response;
	}



	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getBridgeGroupForVbid(SessionStatusVO sessionStatusVO, Integer bridgeId, String vbid,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, ParseException {
		
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));	
		if(bridgeId!=null && StringUtils.isNotBlank(vbid)){
			Bridge bridge = bridgeDAO.get(bridgeId);
			if(bridge == null || bridge.getDeleted()){
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			BridgeBookCache bookCache = bridgeBookCacheDAO.getBookForVbid(bridgeId, vbid);
			if(bookCache == null || bookCache.getDeleted()) {
				throw new BridgeException(ApplicationCode.INVALID_INPUT);
			}
			List<IdValueVO> groups = bridgeGroupAssetDAO.getGroupsForVbid(bridgeId, vbid,Boolean.TRUE);
			response.setData(groups);
		}else{
			throw new BridgeException(ApplicationCode.ERROR_VALIDATION_INPUT_FIELD);				
		}
		return response;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getBridgeGroupForUserId(Integer bridgeId, Integer userId) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if(bridgeId!=null){	
			
			Bridge bridge = bridgeDAO.get(bridgeId);
			if(bridge == null || bridge.getDeleted()){
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			
			BridgeUser bridgeUser = bridgeUserDAO.getForUser(bridgeId, userId);
			if(bridgeUser == null) {
				throw new BridgeException(ApplicationCode.INVALID_INPUT);
			}
			
			List<IdValueVO> groups = bridgeGroupUserDAO.getGroupsForUserId(bridgeId, userId);
			response.setData(groups);
		}else{
			throw new BridgeException(ApplicationCode.ERROR_VALIDATION_INPUT_FIELD);				
		}
		return response;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public RestResponse getBridgeGroupById(SessionStatusVO sessionStatusVO, Integer bridgeId, Integer groupId, Boolean bcRefresh,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException, JsonParseException, JsonMappingException, BusinessCenterException, IOException, ConnectApiException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if(bridgeId!=null){
			Bridge bridge = bridgeDAO.get(bridgeId);
			if(bridge == null || bridge.getDeleted()){
				throw new BridgeException(ApplicationCode.BRIDGE_NOT_FOUND);
			}
			if(groupId!=null){
				BridgeGroup bridgeGroup= bridgeGroupDAO.get(groupId);
				if(bridgeGroup == null || bridgeGroup.getDeleted()){
					throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
				}
				if(!bridgeId.equals(bridgeGroup.getBridge().getId())){
					throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
				}
				bcRefresh= bcRefresh!=null ?bcRefresh : Boolean.FALSE;
				if(bcRefresh){
					businessCenterServices.getCourseForGroupId(sessionStatusVO, bridgeId, groupId, httpRequest, uriInfo, null);
				}
				BridgeGroupResponseVO bridgeGroupResponseVO=this.populateBridgeGroupResponseVOFromBridgeGroup(bridgeGroup);
				response.setData(bridgeGroupResponseVO);
			}
		}
		else{
			throw new BridgeException(ApplicationCode.ERROR_VALIDATION_INPUT_FIELD);				
		}
		
		
		return response;
	}
	
	private void validateAndRearangePaginationVO(BridgePaginationVo bridgePaginationVo) {
		
		Integer page = bridgePaginationVo.getPage();
		if(null==page || page==0){
			bridgePaginationVo.setPage(ApplicationConstants.DEFAULT_GET_BOOK_PAGE_VALUE);
		}
		
		Integer limit = bridgePaginationVo.getLimit();
		if(null==limit || limit==0){
			bridgePaginationVo.setLimit(ApplicationConstants.DEFAULT_GET_BOOK_LIMIT_VALUE);
		}
		
		String orderby = bridgePaginationVo.getOrderBy();
		if(!StringUtils.isEmpty(orderby) && !ApplicationConstants.validBookOrderByValues.contains(orderby)){
			throw new BridgeException(ApplicationCode.INVALID_ORDERBY_FIELD);
		}
		if(null == orderby || StringUtils.isEmpty(orderby)){
			bridgePaginationVo.setOrderBy(ApplicationConstants.DEFAULT_GET_BOOK_ORDER_BY_VALUE);
		}
		
		String order = bridgePaginationVo.getOrder();
		if(null == order || StringUtils.isEmpty(order)){
			bridgePaginationVo.setOrder(ApplicationConstants.DEFAULT_GET_BOOK_ORDER_VALUE);
		}
	}
	
	private List<BridgeBooksVO> populateBridgeBooksVOFromConnectBook(List<BridgeBookCache> cacheBooks,Bridge bridge,BridgePaginationVo bridgePaginationVo, Boolean isGrouped) {
		List<BridgeBooksVO> books = new ArrayList<BridgeBooksVO>();
		List<BridgeBooksVO> responceBridgeBooksVO = new ArrayList<BridgeBooksVO>();
		
		List<Integer> bridgeGroupIds = bridgeGroupDAO.getGroupIdsForBridgeId(bridge.getId(), Boolean.TRUE);
		
		List<String> groupVbids = bridgeGroupAssetDAO.getVbidsForGroupIds(bridge.getId(),bridgeGroupIds);
				
		Integer startIndex = calculateStartIndexForReport(bridgePaginationVo.getPage(), bridgePaginationVo.getLimit());
		Integer totalRecordToFetch = bridgePaginationVo.getLimit();
		
		if(null != cacheBooks && cacheBooks.size() >0){
	//		List<String> selectedBooks = bridgeBooksDAO.getBookIdsForBridge(bridge.getId(),bridge.getShowAllBooks(),Boolean.FALSE);
			for(BridgeBookCache cacheBook : cacheBooks){
				String vbid = cacheBook.getVbid();
				BridgeBooksVO bridgeBooksVO = new BridgeBooksVO();
				this.populatePricingforBook(bridgeBooksVO,cacheBook,bridge);
				Integer concurrencyLimit= cacheBook.getConcurrencyLimit()!=null ? cacheBook.getConcurrencyLimit():bridge.getConcurrencyLimit();
				bridgeBooksVO.setConcurrencyLimit(concurrencyLimit);
				if(null != isGrouped && groupVbids != null) {
				//	bridgeBooksVO.setIsGroupMember(groupVbids.contains(vbid));

					
					bridgeBooksVO.setAuthor(cacheBook.getAuthor());
					bridgeBooksVO.setCoverImageUrl(cacheBook.getCoverImageUrl());
					
					String title = cacheBook.getTitle();
					title = StringEscapeUtils.unescapeHtml(title);
					title = StringEscapeUtils.unescapeJava(title);
					title = HTMLParserUtil.parseHTML(title);
					bridgeBooksVO.setTitle(title);
					
					String description = cacheBook.getDescription();
					description = StringEscapeUtils.unescapeHtml(description);
					description = StringEscapeUtils.unescapeJava(description);
					description = HTMLParserUtil.parseHTML(description);
					bridgeBooksVO.setDescription(description);
					
					bridgeBooksVO.setTextbookIsbn(cacheBook.getTextbookIsbn());
					bridgeBooksVO.seteBookIsbn(cacheBook.getEbookIsbn());
					bridgeBooksVO.setFileType(cacheBook.getFileType());
					bridgeBooksVO.setCategory(cacheBook.getCategory());
					
					bridgeBooksVO.setVbid(vbid);
					bridgeBooksVO.setEdition(cacheBook.getEdition());
					
					if( groupVbids != null){
						bridgeBooksVO.setIsGroupMember(groupVbids.contains(vbid));
					}
					
					if (isGrouped) {
					books.add(bridgeBooksVO);
					} else if (!isGrouped && !bridgeBooksVO.getIsGroupMember()) {
						books.add(bridgeBooksVO);
					}

				} else {

					bridgeBooksVO.setAuthor(cacheBook.getAuthor());
					bridgeBooksVO.setCoverImageUrl(cacheBook.getCoverImageUrl());
					
					String title = cacheBook.getTitle();
					title = StringEscapeUtils.unescapeHtml(title);
					title = StringEscapeUtils.unescapeJava(title);
					title = HTMLParserUtil.parseHTML(title);
					bridgeBooksVO.setTitle(title);
					
					String description = cacheBook.getDescription();
					description = StringEscapeUtils.unescapeHtml(description);
					description = StringEscapeUtils.unescapeJava(description);
					description = HTMLParserUtil.parseHTML(description);
					bridgeBooksVO.setDescription(description);
					
					bridgeBooksVO.setTextbookIsbn(cacheBook.getTextbookIsbn());
					bridgeBooksVO.seteBookIsbn(cacheBook.getEbookIsbn());
					
					
					bridgeBooksVO.setVbid(vbid);
					bridgeBooksVO.setEdition(cacheBook.getEdition());
					
					if( groupVbids != null){
						bridgeBooksVO.setIsGroupMember(groupVbids.contains(vbid));
					}
					
					books.add(bridgeBooksVO);
				}
			}
		}
		
		/*bridgePaginationVo.setCount(books.size());
		
		for(int i = startIndex; i < books.size() && totalRecordToFetch >= 0; i ++) {
			responceBridgeBooksVO.add(books.get(i));
			totalRecordToFetch--;
		}*/
		
		return books;
	}
	
	private void populatePricingforBook(BridgeBooksVO bridgeBooksVO, BridgeBookCache cacheBook, Bridge bridge) {
		DisplayPricing displayPrice= new DisplayPricing(); //TODO need to move out
		displayPrice.seteTextPriceType(bridge.geteTextPrice());
		displayPrice.setRentalPriceType(bridge.getRentalPrice());
		displayPrice.setTextBookPriceType(bridge.getTextBookPrice());
		BridgeBookPricing baseVbidPricing=bridgeBookPricingDAO.getBookPricingByRentalType(cacheBook.getId(),null);
		if(baseVbidPricing!=null){
			if(StringUtils.equals(ApplicationConstants.PUBLISHER_PRICE_TYPE, displayPrice.geteTextPriceType())){
				bridgeBooksVO.seteTextPrice(baseVbidPricing.getPublisherPrice());
			}
			else if(StringUtils.equals(ApplicationConstants.DIGITAL_PRICE_TYPE, displayPrice.geteTextPriceType())){
				bridgeBooksVO.seteTextPrice(baseVbidPricing.getDigitalPrice());
			}
			if(StringUtils.equals(ApplicationConstants.DIGITAL_PRICE_TYPE, displayPrice.getTextBookPriceType())){
				bridgeBooksVO.setTextBookPrice(baseVbidPricing.getDigitalPrice());
			}
			else if(StringUtils.equals(ApplicationConstants.PUBLISHER_PRICE_TYPE, displayPrice.getTextBookPriceType())){
				bridgeBooksVO.setTextBookPrice(baseVbidPricing.getPublisherPrice());
			}
			if(StringUtils.isNotEmpty(displayPrice.getRentalPriceType())){
				if(StringUtils.equals(ApplicationConstants.PUBLISHER_PRICE_TYPE, displayPrice.getRentalPriceType()))
					bridgeBooksVO.setRentalPrice(baseVbidPricing.getPublisherPrice());
				else if(StringUtils.equals(ApplicationConstants.DIGITAL_PRICE_TYPE, displayPrice.getRentalPriceType()))
					bridgeBooksVO.setRentalPrice(baseVbidPricing.getDigitalPrice());
				else{
					BridgeBookPricing rentalVbidPricing=bridgeBookPricingDAO.getBookPricingByRentalType(cacheBook.getId(),displayPrice.getRentalPriceType());
					if(rentalVbidPricing!=null){
						bridgeBooksVO.setRentalPrice(rentalVbidPricing.getDigitalPrice());
					}					
				}				
			}			
		}
		
	}
	
	/**
	 * This method is used to calculate start index for report
	 * 
	 * @param currentPage
	 * @param totalRowsToFetch
	 * @return {@link Integer} value
	 */
	private Integer calculateStartIndexForReport(final int currentPage, final int totalRowsToFetch) {
		final Integer startIndex = (currentPage * totalRowsToFetch) - totalRowsToFetch;
		return startIndex;
	}

}
