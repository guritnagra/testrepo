package com.vst.bridge.rest.response.vo;

import com.vst.bridge.annotation.custom.InputRequired;

public class CompanyVO {
	private String name;
	@InputRequired(required=false)
	private String apiKey;	
	@InputRequired(required=false)
	private Integer companyId;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	
}
