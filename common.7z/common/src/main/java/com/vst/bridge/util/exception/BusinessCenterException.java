package com.vst.bridge.util.exception;



public class BusinessCenterException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	private String message;
	private  ApplicationCode errorCode;	
	

	public BusinessCenterException(final ApplicationCode code) {
		this.errorCode = code;
	}
	
	public BusinessCenterException(final String message, final ApplicationCode code) {
		this.setMessage(message);
		this.errorCode = code;
	}

	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public ApplicationCode getErrorCode() {
		return errorCode;
	}
}
