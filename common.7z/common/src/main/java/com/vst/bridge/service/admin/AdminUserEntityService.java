package com.vst.bridge.service.admin;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.vst.bridge.JsonUtils;
import com.vst.bridge.VstException;
import com.vst.bridge.dao.admin.IAdminCompanyDAO;
import com.vst.bridge.dao.admin.IAdminGroupDAO;
import com.vst.bridge.dao.admin.IAdminRoleDAO;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.admin.IAdminUserLabelDAO;
import com.vst.bridge.dao.bridge.book.IBridgeBookCacheDAO;
import com.vst.bridge.dao.bridge.group.IBridgeGroupUserDAO;
import com.vst.bridge.dao.bridge.type.ICodeTypesDAO;
import com.vst.bridge.dao.company.ICompanyDAO;
import com.vst.bridge.dao.group.IGroupDAO;
import com.vst.bridge.dao.role.IRoleDAO;
import com.vst.bridge.entity.admin.company.AdminCompany;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.rest.input.vo.AdminUserProfileVO;
import com.vst.bridge.rest.input.vo.ConnectSystemUserVO;
import com.vst.bridge.rest.input.vo.PermissionLevelVO;
import com.vst.bridge.rest.input.vo.SystemUserInfoVO;
import com.vst.bridge.rest.response.vo.AdminUserVO;
import com.vst.bridge.rest.response.vo.ConnectCompanyVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.SystemUserResponseVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.service.bc.IBusinessCenterServices;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.csv.CsvHandlerService;
import com.vst.bridge.util.error.ErrorHandlerUtil;
import com.vst.bridge.util.error.ResponseError;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.connectapi.ApiKeys;
import com.vst.connectapi.ConnectApiWrapper;
import com.vst.connectapi.ERRORS;

@Service("adminUserEntityService")
public class AdminUserEntityService implements IAdminUserEntityService {
	@Autowired
	private IAdminUserDAO adminUserDAO;

	@Autowired
	private IAdminRoleDAO adminRoleDAO;

	@Autowired
	private IAdminGroupDAO adminGroupDAO;

	@Autowired
	private ICompanyDAO companyDAO;

	@Autowired
	private LocaleMessageUtility localeMessageUtility;

	@Autowired
	private ErrorHandlerUtil errorHandlerUtility;

	@Autowired
	private IGroupDAO groupDAO;

	@Autowired
	CsvHandlerService csvHandlerService;

	@Autowired
	IBridgeGroupUserDAO bridgeGroupUserDAO;

	@Autowired
	IRoleDAO roleDAO;

	@Autowired
	IBridgeBookCacheDAO bridgeBookCacheDAO;

	@Autowired
	ICodeTypesDAO codeTypesDAO;

	@Autowired
	IBusinessCenterServices businessCenterServices;

	@Autowired
	AdminUserServiceUtil adminUserServiceUtil;
	
	@Autowired
	IAdminUserLabelDAO adminUserLabelDAO;
	
	@Autowired
	IAdminCompanyDAO adminCompanyDAO;
	
	private static Logger logger = LogManager.getLogger(AdminUserEntityService.class);

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse getAdminUserInfo(SessionStatusVO sessionStatusVO, final Integer adminId,
			BridgePaginationVo bridgePaginationVo, final Boolean getAllUsers, UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		AdminUser adminUser = null != adminId && adminId > 0 ? adminUserDAO.get(adminId)
				: adminUserDAO.get(sessionStatusVO.getAdminId());
		Integer totalRecords = 0;
		if (null != adminUser) {
			List<AdminUserVO> adminUserVOs = null;
			if (getAllUsers) {
				adminUserServiceUtil.validateAndRearangePaginationVO(bridgePaginationVo,
						ApplicationConstants.DEFAULT_GET_USER_ORDER_BY_VALUE, Boolean.FALSE);
				List<AdminUser> allUsers = new ArrayList<AdminUser>();
				Integer startIndex = adminUserServiceUtil.calculateStartIndex(bridgePaginationVo.getPage(),
						bridgePaginationVo.getLimit());

				String roleName = sessionStatusVO.getRoleName();
				if (StringUtils.equals(roleName, ApplicationConstants.USER_ROLE_ADMIN)) {
					List<AdminCompany> adminCompanies = adminUser.getCompanies();
					if (null != adminCompanies && adminCompanies.size() > 0) {
						List<Integer> companyIds=new ArrayList<Integer>();
						for(AdminCompany adminCompany:adminCompanies)
							companyIds.add(adminCompany.getCompany().getId());
						
						totalRecords = adminCompanyDAO.getUsersCount(companyIds, bridgePaginationVo);
						
						Set<AdminUser> adminUsers= adminCompanyDAO.getUsersForCompanyIds(companyIds, startIndex, bridgePaginationVo);
						if(adminUsers!=null && adminUsers.size()>0){
							for(AdminUser user :adminUsers){
								if(user!=null && !user.getDeleted()){
									allUsers.add(user);
								}
							}
						}						
					}
				} else {
					totalRecords = adminUserDAO.getUserCount(bridgePaginationVo);
					allUsers = adminUserDAO.getAllUsersForAdmin(startIndex, bridgePaginationVo);
				}
				if (null != allUsers && allUsers.size() > 0) {
					adminUserVOs = new ArrayList<AdminUserVO>(0);
					for (AdminUser user : allUsers) {
						adminUserVOs.add(adminUserServiceUtil.populateAdminVoFromAdmin(user));
					}
				}
				if (null != adminUserVOs) {
					Integer totalPages = adminUserServiceUtil.calculateTotalPageCount(totalRecords,
							bridgePaginationVo.getLimit());
					Integer offset=this.calculateOffsetValue(bridgePaginationVo.getPage(), bridgePaginationVo.getLimit());
					PaginationVO paginationVO = new PaginationVO(bridgePaginationVo.getPage(),
							bridgePaginationVo.getLimit(), totalPages, bridgePaginationVo.getOrderBy(),
							bridgePaginationVo.getOrder(), bridgePaginationVo.getSearch(), totalRecords,offset);
					response.setMetadata(paginationVO);
					response.setData(adminUserVOs);
				}
			} else {
				AdminUserVO adminUserVO = adminUserServiceUtil.populateAdminVoFromAdmin(adminUser);
				response.setData(adminUserVO);
			}
		} else {
			response = new RestResponse(Response.Status.NOT_FOUND.getStatusCode(),
					ApplicationCode.USER_NOT_FOUND.getCodeId(),
					localeMessageUtility.getMessage(ApplicationCode.USER_NOT_FOUND.getCodeId()));
		}
		return response;
	}
	
	private Integer calculateOffsetValue(Integer page, Integer limit) {
		if(page!=null){
			return (page-1)*limit;
		}
		return 0;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse createOrUpdateAdminUser(SessionStatusVO sessionStatusVO, AdminUserProfileVO adminUserProfileVO,
			Integer adminId, HttpServletRequest request, Boolean isNew, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException, VstException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		AdminUser newAdminUser = null;
		AdminUser adminUser = adminId != null && adminId > 0 ? adminUserDAO.get(adminId)
				: adminUserDAO.get(sessionStatusVO.getAdminId());
		newAdminUser = isNew ? null : adminUser;
		// final String inputJson = JsonUtils.requestToString(request);
		if (null != adminUserProfileVO) {
			ResponseError responseError = isNew
					? errorHandlerUtility.validateAdminProfileVOParameters(JsonUtils.getJsonString(adminUserProfileVO))
					: null;
			if (null == responseError) {
				// AdminUserProfileVO adminUserProfileVO = (new
				// Genson()).deserialize(inputJson, AdminUserProfileVO.class);
				List<SystemUserInfoVO> systemUserList = adminUserProfileVO.getSystemUserInfo();
				ConnectCompanyVO connectCompanyVO=null;
				if(systemUserList!=null && systemUserList.size()>0){
					
					for(SystemUserInfoVO systemUserVO :systemUserList){													
						try {
							if(isNew){
								String systemApiKey = ApiKeys.getSystemUserKey(ApplicationConstants.getApiMode());
									if(StringUtils.isNotEmpty(systemApiKey)){						
										try {
											connectCompanyVO=ConnectApiWrapper.getV4ConnectCompany(systemApiKey);							
										} catch (VstException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}						
									
								}
								String email=systemUserVO.getEmail();
								if(email!=null){
									AdminUser checkAdminUser=adminUserDAO.getForEmail(email);
									if(checkAdminUser!=null){
										logger.info("createOrUpdateAdminUser : Email {0} already exist",email);
										continue;
									}								
									newAdminUser= new AdminUser();
									newAdminUser.setCreatedBy(adminUser);
									newAdminUser.setCreatedDate(new Date());
									//adminUserDAO.create(newAdminUser);
									response.setCode(Response.Status.CREATED.getStatusCode());
									//Check in system user if user exist or not
								}
								else{
									logger.info("createOrUpdateAdminUser : Email is mandatory field");
									continue;
								}
								newAdminUser=populateNewAdminUserDetails(newAdminUser,systemUserVO,adminUserProfileVO,connectCompanyVO,systemApiKey);
							}
							else{
								fillAdminUserDetails(adminUser, systemUserVO, adminUserProfileVO);
								newAdminUser=adminUser;
							}								
							if(newAdminUser!=null && newAdminUser.getEmail()!=null){
								adminUserDAO.saveOrUpdate(newAdminUser);
							}
						} catch (VstException e) {
							throw new VstException("An error occured",null, ERRORS.ConnectKeyException);
						}
					}
				}	
				

				/*List<AdminGroupVO> groupIds = adminUserProfileVO.getGroups();
				List<AdminGroup> groupList = newUser.getGroups();

				// setting all previous admin group as deleted ( softdelete)
				if (null != groupList && groupList.size() > 0) {
					for (AdminGroup adminGroup : groupList) {
						adminGroup.setDeleted(Boolean.TRUE);
					}
				}

				// setting group as selected which is previously selected and
				// marked as delete
				if (null != groupIds && groupIds.size() > 0) {
					Iterator<AdminGroupVO> adminGroupIterator = groupIds.iterator();
					while (adminGroupIterator.hasNext()) {
						AdminGroupVO groupVO = adminGroupIterator.next();
						for (AdminGroup adminGroup : groupList) {
							if (groupVO.getId() == adminGroup.getGroup().getId()) {
								adminGroup.setDeleted(Boolean.FALSE);
								adminGroupIterator.remove();
							}
						}
					}
				}

				// adding new groups for admin
				if (null != groupIds && groupIds.size() > 0) {
					for (AdminGroupVO groupId : groupIds) {
						AdminGroup adminGroup = new AdminGroup();
						adminGroup.setAdmin(newUser);
						adminGroup.setGroup(groupDAO.load(groupId.getId()));
						groupList.add(adminGroup);
					}
				}

				newUser.setGroups(groupList);*/
			/*	List<AdminCompany> companyList = newUser.getCompanies();

				// setting all previous admin companies as deleted ( softdelete)
				if (null != companyList && companyList.size() > 0) {
					for (AdminCompany adminCompany : companyList) {
						adminCompany.setDeleted(Boolean.TRUE);
					}
				}

				List<AdminCompanyVO> companyIds = adminUserProfileVO.getCompanies();                                                                                                                                                                                                                                                   
				if (null != companyIds && companyIds.size() > 0) {
					Iterator<AdminCompanyVO> adminCompanyIterator = companyIds.iterator();
					while (adminCompanyIterator.hasNext()) {
						AdminCompanyVO companyVO = adminCompanyIterator.next();
						for (AdminCompany adminCompany : companyList) {
							if (companyVO.getId() == adminCompany.getCompany().getId()) {
								adminCompany.setDeleted(Boolean.FALSE);
								adminCompanyIterator.remove();
							}
						}
					}
					if (null != companyIds && companyIds.size() > 0) {
						for (AdminCompanyVO companyid : companyIds) {
							AdminCompany adminCompany = new AdminCompany();
							adminCompany.setAdmin(newUser);
							adminCompany.setCompany(companyDAO.load(companyid.getId()));
							companyList.add(adminCompany);
						}
					}
				}

				newUser.setCompanies(companyList);*/
				
				//AdminUserVO adminUserVO = adminUserServiceUtil.populateAdminVoFromAdmin(newUser);
				//response.setData(adminUserVO);
			} else {
				response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
				response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
				response.setError(responseError);
			}
		}
		return response;
	}

	private AdminUser populateNewAdminUserDetails(AdminUser adminUser, SystemUserInfoVO systemUserVO,
			AdminUserProfileVO adminUserProfileVO, ConnectCompanyVO connectCompanyVO, String systemApiKey) throws VstException {
		//Create Connect User
		String url=ApiKeys.getConnectUrl(ApplicationConstants.getApiMode())+"/v4/system_users";
		ConnectSystemUserVO connectSystemUserVO=this.populateConnectSystemUserDetails(systemUserVO);
		Integer[] companyArray={connectCompanyVO.getId()};
		connectSystemUserVO.setCompanyId(companyArray);
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = getHeaders(systemApiKey);

		HttpEntity<ConnectSystemUserVO> requestObject = new HttpEntity<ConnectSystemUserVO>(connectSystemUserVO, headers);
		ResponseEntity<SystemUserResponseVO> systemUserResponse =	null;
		try{
			systemUserResponse= restTemplate.exchange(url,HttpMethod.POST,requestObject,SystemUserResponseVO.class);
			if(systemUserResponse!=null){
				SystemUserResponseVO systemUserResponseVO=systemUserResponse.getBody();
				adminUser.setSystemUserId(systemUserResponseVO.getId());
				fillAdminUserDetails(adminUser,systemUserVO,adminUserProfileVO);
			}
			else{
				throw new VstException("An error occured",null, ERRORS.ConnectKeyException);
			}
		}
		catch(Exception e){
			e.printStackTrace();
			throw new VstException("An error occured",e, ERRORS.ConnectKeyException);
		}
		
		return adminUser;
	}

	private void fillAdminUserDetails(AdminUser adminUser, SystemUserInfoVO systemUserVO,
			AdminUserProfileVO adminUserProfileVO) {
		List<Integer> companyList=adminUserProfileVO.getCompanies();
		List<AdminCompany> adminCompanyList=new ArrayList<AdminCompany>();
		if(adminUser.getId()!=null){
			List<AdminCompany> existingAdminCompany = adminCompanyDAO.getAdminCompaniesForAdminId(adminUser.getId(), Boolean.FALSE);
			if(existingAdminCompany!=null && existingAdminCompany.size()>0){
				for(AdminCompany ac :existingAdminCompany){
					ac.setDeleted(Boolean.TRUE);
				}
				adminCompanyDAO.saveOrUpdateAll(existingAdminCompany);
			}
		}
		for(Integer companyId:companyList){
			AdminCompany adminCompany=null;
			if(adminUser!=null && adminUser.getId()!=null){
				adminCompany = adminCompanyDAO.getAdminCompanyByAdminAndCompanyId(adminUser.getId(), companyId);
				if(adminCompany!=null)
					adminCompany.setDeleted(Boolean.FALSE);
			}
			adminCompany=adminCompany!=null ? adminCompany : new AdminCompany();			
			adminCompany.setAdmin(adminUser);
			adminCompany.setCompany(companyDAO.load(companyId));
			adminCompanyList.add(adminCompany);
		}
		if(adminCompanyList.size()>0)
			adminUser.setCompanies(adminCompanyList);
		String firstName = systemUserVO.getFirstName();
		if (null != firstName && !StringUtils.isEmpty(firstName.trim())) {
			adminUser.setFirstName(StringUtils.capitalize(firstName.trim().toLowerCase()));
		}
		String lastName = systemUserVO.getLastName();
		if (null != lastName && !StringUtils.isEmpty(lastName.trim())) {
			adminUser.setLastName(StringUtils.capitalize(lastName.trim().toLowerCase()));
		}
		String email = systemUserVO.getEmail();
		if (null != email && !StringUtils.isEmpty(email.trim())
				&& !StringUtils.equals(email, adminUser.getEmail())) {
			if (adminUserDAO.checkEmailExistInDb(email)) {
				return;
			}
			adminUser.setEmail(email.trim().toLowerCase());
		}
		if(systemUserVO.getLabel()!=null && StringUtils.isNotEmpty(systemUserVO.getLabel())){
			adminUser.setLabel(adminUserLabelDAO.getLabelByName(systemUserVO.getLabel()));
		}
		String roleName=adminUserProfileVO.getType();		
		if (null != roleName && !StringUtils.isEmpty(roleName.trim())) {
			adminUser.setRole(adminRoleDAO.getUserForRoleName(roleName));
		}
		else{
			throw new BridgeException("Missing role",ApplicationCode.MISSING_INPUT_FIELD);
		}
		PermissionLevelVO permission=adminUserProfileVO.getPermission();
		if(permission!=null && roleName!=null ){
			if(roleName.equals(ApplicationConstants.USER_ROLE_ADMIN)){
			adminUser.setEditSystemUser(permission.getEditSystemUser());
			adminUser.setEditBridge(permission.getEditBridge());
			adminUser.setEditBasicInfo(permission.getEditBasicInfo());
			adminUser.setEditStyling(permission.getEditStyling());
			adminUser.setEditManage(permission.getEditManage());
			adminUser.setEditUsers(permission.getEditUsers());
			adminUser.setEditUserLimit(permission.getEditUserLimit());
			adminUser.setEditUserConcurrency(permission.getEditUserConcurrency());
			adminUser.setAllowContentUpload(permission.getAllowContentUpload());
			adminUser.setEditAllowance(permission.getEditAllowance());
			adminUser.setEditAccess(permission.getEditAccess());
			adminUser.setIsReadOnly(permission.getIsReadOnly());
			adminUser.setEditKey(permission.getEditKey());
			adminUser.setEditPurchase(permission.getEditPurchase());
			}
			else if(roleName.equals(ApplicationConstants.USER_ROLE_SUPER_ADMIN)){
				adminUser.setEditSystemUser(Boolean.TRUE);
				adminUser.setEditBridge(Boolean.TRUE);
				adminUser.setEditBasicInfo(Boolean.TRUE);
				adminUser.setEditStyling(Boolean.TRUE);
				adminUser.setEditManage(Boolean.TRUE);
				adminUser.setEditUsers(Boolean.TRUE);
				adminUser.setEditUserLimit(Boolean.TRUE);
				adminUser.setEditUserConcurrency(Boolean.TRUE);
				adminUser.setAllowContentUpload(Boolean.TRUE);
				adminUser.setEditAllowance(Boolean.TRUE);
				adminUser.setEditAccess(Boolean.TRUE);
				adminUser.setIsReadOnly(Boolean.FALSE);
				adminUser.setEditKey(Boolean.TRUE);
				adminUser.setEditPurchase(Boolean.TRUE);
			}
		}	
		
	}

	private ConnectSystemUserVO populateConnectSystemUserDetails(SystemUserInfoVO systemUserVO) {
		ConnectSystemUserVO connectSystemUserVO = new ConnectSystemUserVO();
		connectSystemUserVO.setLogin(systemUserVO.getEmail());
		connectSystemUserVO.setPlainTextPassword(systemUserVO.getPassword());
		connectSystemUserVO.setPlainTextPasswordConfirmation(systemUserVO.getPassword());
		connectSystemUserVO.setFirstName(systemUserVO.getFirstName());
		connectSystemUserVO.setLastName(systemUserVO.getLastName());
		connectSystemUserVO.setEmail(systemUserVO.getEmail());
		return connectSystemUserVO;
	}
	
	private HttpHeaders getHeaders(String apiKey) {
        HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add(ApplicationConstants.APIKEY_HEADER, apiKey);
		headers.add("Content-Type", "application/json; charset=utf-8");
		return headers;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public RestResponse getAdminUserInfoForId(Integer adminId, UriInfo uriInfo)
			throws BridgeException, ParseException, IOException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationConstants.RESPONSE_MESSAGE_ID_OK,
				localeMessageUtility.getMessage(ApplicationConstants.RESPONSE_MESSAGE_ID_OK));
		if (null != adminId && adminId > 0) {
			AdminUser adminUser = adminUserDAO.get(adminId);
			if (null != adminUser) {
				AdminUserVO adminUserVO = adminUserServiceUtil.populateAdminVoFromAdmin(adminUser);
				response.setData(adminUserVO);
			}
		}
		return response;
	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestResponse deleteUser(SessionStatusVO sessionStatusVO, Integer adminId, HttpServletRequest httpRequest,
			UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),
				ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));

		if (null != adminId) {
			AdminUser adminUser = adminUserDAO.get(adminId);
			if (adminUser == null || adminUser.getDeleted()) {
				throw new BridgeException(ApplicationCode.USER_NOT_FOUND);
			}
			adminUser.setDeleted(Boolean.TRUE);
			adminUser.setDeletedBy(sessionStatusVO.getAdminId());
			adminUser.setDeletedTime(new Date());
			adminUserDAO.saveOrUpdate(adminUser);

		} else {
			throw new BridgeException(ApplicationCode.USER_NOT_FOUND);
		}

		return response;
	}


}
