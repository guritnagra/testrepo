package com.vst.bridge.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Set;

import org.apache.commons.csv.CSVFormat;


public class CSVUtils {


	public static Set<String> loadFile(InputStream uploadedInputStream) {
		Reader in = new InputStreamReader(uploadedInputStream); 
		Set<String> headerSet = null;
		try {
			headerSet = CSVFormat.EXCEL.withHeader().parse(in).getHeaderMap().keySet();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return headerSet;
	}
}
