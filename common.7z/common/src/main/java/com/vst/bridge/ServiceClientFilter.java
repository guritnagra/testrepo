package com.vst.bridge;
import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
//import org.apache.log4j.Logger;
public class ServiceClientFilter implements Filter
{
	//private static Logger log = Logger.getLogger(ServiceClientFilter.class);
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain filterChain) throws IOException, ServletException
	{
		try
		{
			String url = ((HttpServletRequest) req).getRequestURI();
			//String server = ((HttpServletRequest) req).getServerName().toLowerCase();
			if(req.getDispatcherType()==javax.servlet.DispatcherType.REQUEST)
			{
				((HttpServletRequest) req).getRequestDispatcher("/WEB-INF/tools"+url).forward(req,res);
			}
			else
			{
				filterChain.doFilter(req, res);
			}
		}
		catch(Exception ex)
		{
			//log.error(ex.getMessage(),ex);
			((HttpServletResponse) res).sendError(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(),"An error occured");
		}
	}
	public void init(FilterConfig filterConfig)
	{
	}
	public void destroy()
	{
	}
}