package com.vst.bridge.rest.response.vo.bridge;

public class BatchFileVO {
	private String roleName;
	private Boolean trial;
	private Integer credits;
	private Integer rentals;
	private String note;
	private String expireDate;
	private String requester;
	private Integer keys;
	private Integer userPerKey;
	private String codes;
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public Boolean getTrial() {
		return trial;
	}
	public void setTrial(Boolean trial) {
		this.trial = trial;
	}
	public Integer getCredits() {
		return credits;
	}
	public void setCredits(Integer credits) {
		this.credits = credits;
	}
	public Integer getRentals() {
		return rentals;
	}
	public void setRentals(Integer rentals) {
		this.rentals = rentals;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getExpireDate() {
		return expireDate;
	}
	public void setExpireDate(String expireDate) {
		this.expireDate = expireDate;
	}
	public String getRequester() {
		return requester;
	}
	public void setRequester(String requester) {
		this.requester = requester;
	}
	public Integer getKeys() {
		return keys;
	}
	public void setKeys(Integer keys) {
		this.keys = keys;
	}
	public Integer getUserPerKey() {
		return userPerKey;
	}
	public void setUserPerKey(Integer userPerKey) {
		this.userPerKey = userPerKey;
	}
	public String getCodes() {
		return codes;
	}
	public void setCodes(String codes) {
		this.codes = codes;
	}
}
