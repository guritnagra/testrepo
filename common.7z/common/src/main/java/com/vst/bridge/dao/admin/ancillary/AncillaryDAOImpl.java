package com.vst.bridge.dao.admin.ancillary;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.admin.ancillary.Ancillary;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.util.constant.ApplicationConstants;

@Repository("ancillaryDAO ")
public class AncillaryDAOImpl extends GenericDAO<Ancillary, Integer> implements IAncillaryDAO {

	public AncillaryDAOImpl() {
		super(Ancillary.class);
	}

	@Override
	public List<Ancillary> getAllAncillaries(Integer bridgeId, PaginationVO paginationVO) {
		Criteria criteria = getCriteria();
		if(null != bridgeId){
			criteria.add(Restrictions.eq("bridge.id", bridgeId));
		}
		if(null!=paginationVO){
			Integer totalRecordToFetch = paginationVO.getLimit();
			Integer startIndex = null == paginationVO.getPage() ? 1 : paginationVO.getPage();
			if(null != totalRecordToFetch  && totalRecordToFetch > 0){
				criteria.setFirstResult(startIndex);
				criteria.setMaxResults(totalRecordToFetch);
			}
				
			String search = paginationVO.getSearch();
			if(null!=search && !StringUtils.isEmpty(search)){
				
				Criterion criterion1 = Restrictions.like("vbid", "%"+search+"%");
				Criterion criterion2 = Restrictions.like("fileName", "%"+search+"%");
				Criterion criterion3 = Restrictions.like("sku", "%"+search+"%");
				Criterion criterion4 = Restrictions.like("mimeType", "%"+search+"%");
	
				Criterion completeCriterion = Restrictions.disjunction()
																	.add(criterion1)
																	.add(criterion2)
																	.add(criterion3)
																	.add(criterion4);
				
				criteria.add(completeCriterion);
			}
			
			String orderBy = paginationVO.getOrderBy();
			if(null != orderBy && !StringUtils.isEmpty(orderBy)){
				String order = paginationVO.getOrder();
				if(order.equals(ApplicationConstants.SORTING_ORDER_ASC)){
					criteria.addOrder(Order.asc(orderBy));
				}else{
					criteria.addOrder(Order.desc(orderBy));
				}
			}
		}
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		return executeCriteira(criteria);
	}
	
	@Override
	public List<Ancillary> getAllAncillaries(Integer bridgeId) {
		Criteria criteria = getCriteria();
		if(null != bridgeId){
			criteria.add(Restrictions.eq("bridge.id", bridgeId));
		}
		criteria.add(Restrictions.eq("deleted",Boolean.FALSE));
		return executeCriteira(criteria);
	}

	@Override
	public Ancillary getAncillaryByVbid(Integer bridgeId, String vbid) {
		Criteria criteria = getCriteria();
		if(null != bridgeId){
			criteria.add(Restrictions.eq("bridge.id", bridgeId));
		}
		if(null == vbid){
			return null;
		}
		criteria.add(Restrictions.eq("vbid", vbid.trim()));
		List<Ancillary> result = executeCriteira(criteria);
		return result != null && result.size() > 0 ? result.get(0) : null;
	}
	
	@Override
	public Ancillary getAncillaryById(Bridge  bridge, Integer id) {
		Criteria criteria = getCriteria();
		if(null != bridge){
			criteria.add(Restrictions.eq("bridge", bridge));
		}
		if(null == id){
			return null;
		}
		criteria.add(Restrictions.eq("id", id));
		List<Ancillary> result = executeCriteira(criteria);
		return result != null && result.size() > 0 ? result.get(0) : null;
	}

	@Override
	public Ancillary getAncillaryBySku(Integer bridgeId, String sku) {
		Criteria criteria = getCriteria();
		if(null != bridgeId){
			criteria.add(Restrictions.eq("bridge.id", bridgeId));
		}
		if(null == sku){
			return null;
		}
		criteria.add(Restrictions.eq("gcpSku", sku.trim()));
		List<Ancillary> result = executeCriteira(criteria);
		return result != null && result.size() > 0 ? result.get(0) : null;
	}

}
