package com.vst.bridge.util.bean;

import java.util.Date;

public class BridgeGroupUserBean extends BridgeBean {
	
	private String sourcedId;
	private String classSourcedId;
	private String schoolSourcedId;
	private String userSourcedId;
	private String role;
	private String status;
	private Date dateLastModified;
	private Boolean primary;
	
	public String getSourcedId() {
		return sourcedId;
	}
	public void setSourcedId(String sourcedId) {
		this.sourcedId = sourcedId;
	}
	
	public String getSchoolSourcedId() {
		return schoolSourcedId;
	}
	public void setSchoolSourcedId(String schoolSourcedId) {
		this.schoolSourcedId = schoolSourcedId;
	}
	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getDateLastModified() {
		return dateLastModified;
	}
	public void setDateLastModified(Date dateLastModified) {
		this.dateLastModified = dateLastModified;
	}
	public Boolean getPrimary() {
		return primary;
	}
	public void setPrimary(Boolean primary) {
		this.primary = primary;
	}
	public String getClassSourcedId() {
		return classSourcedId;
	}
	public void setClassSourcedId(String classSourcedId) {
		this.classSourcedId = classSourcedId;
	}
	public String getUserSourcedId() {
		return userSourcedId;
	}
	public void setUserSourcedId(String userSourcedId) {
		this.userSourcedId = userSourcedId;
	}
	

}
