package com.vst.bridge.rest.input.vo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ConnectSystemUserVO {
	
	private String login;
	@JsonProperty("plain_text_password")
	private String plainTextPassword;
	@JsonProperty("plain_text_password_confirmation")
	private String plainTextPasswordConfirmation;
	@JsonProperty("first_name")
	private String firstName;
	@JsonProperty("last_name")
	private String lastName;	
	private String email;
	@JsonProperty("company_ids")
	private Integer[] companyId;
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPlainTextPassword() {
		return plainTextPassword;
	}
	public void setPlainTextPassword(String plainTextPassword) {
		this.plainTextPassword = plainTextPassword;
	}
	public String getPlainTextPasswordConfirmation() {
		return plainTextPasswordConfirmation;
	}
	public void setPlainTextPasswordConfirmation(String plainTextPasswordConfirmation) {
		this.plainTextPasswordConfirmation = plainTextPasswordConfirmation;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer[] getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Integer[] companyId) {
		this.companyId = companyId;
	}

}
