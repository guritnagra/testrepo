package com.vst.bridge.rest.response.vo.report;

import java.util.List;

public class ReportKeysDetailsVO {
	private Integer id;
	private String name;
	private String company;
	private List< KeyDetailsVO> keys;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public List<KeyDetailsVO> getKeys() {
		return keys;
	}
	public void setKeys(List<KeyDetailsVO> keys) {
		this.keys = keys;
	}
	
}
