package com.vst.bridge.rest.response;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

public class TextResponse extends RestResponse
{
	public static TextResponse instance(Response.Status code, String text)
	{
		return new TextResponse(code,text);
	}
	
	public static TextResponse instance(Response.Status code, String text, String filename)
	{
		return new TextResponse(code,text, filename);
	}
	
	
	private TextResponse(Response.Status code, String text)
	{
		this.code = code;
		this.text = text;
	}
	
	private TextResponse(Response.Status code, String text, String filename)
	{
		this.code = code;
		this.text = text;
		this.filename = filename;
	}
	
	public Response build(HttpServletRequest hsr) 
	{
		ResponseBuilder rb = Response.status(this.getCode()).entity(this.getText());
		
		for(NewCookie cookie: this.cookies) {
			rb.cookie(cookie);
		}
		
		//rb.header("Access-Control-Allow-Origin","*");
	    //rb.header("Access-Control-Allow-Methods","GET, PUT, DELETE, POST, OPTIONS");
	    //rb.header("Access-Control-Allow-Headers","*");
	    //rb.header("Access-Control-Allow-Credentials","true");
	    
	    if(filename!=null)
	    {
	    	rb.header("Content-Type", "text/plain");
			rb.header("Content-Disposition","attachment; filename=\"" + filename + "\"");
	    }
		
		return rb.build();
	}
}
