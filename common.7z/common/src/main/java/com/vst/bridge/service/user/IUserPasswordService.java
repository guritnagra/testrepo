package com.vst.bridge.service.user;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.VstException;
import com.vst.bridge.rest.input.vo.OldPolicyPasswordVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.user.UpdatePasswordVO;
import com.vst.bridge.rest.response.vo.user.UserEmailVO;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiFieldException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiHttpException;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiXmlException;

public interface IUserPasswordService {
	RestResponse resetPasswordRequest(HttpServletRequest httpRequest, UserEmailVO userEmailVO, String domain,
			String code) throws BridgeException, ConnectApiException, VstException;
	RestResponse updatePassword(UpdatePasswordVO updatePasswordVO, String domain)	throws BridgeException;
	RestResponse updateOldPolicyPassword(OldPolicyPasswordVO oldPolicyPasswordVO, String code)throws BridgeException, ParseException, IOException, ConnectApiException, ConnectApiHttpException, ConnectApiXmlException, ConnectApiFieldException, VstException;
	RestResponse checkUserEmail(String domain, UserEmailVO userEmailVO, String code, HttpServletRequest httpRequest)
			throws BridgeException, ConnectApiException, VstException;
	RestResponse getQuestions(HttpServletRequest httpRequest, UriInfo uriInfo)throws BridgeException;
	
}
