package com.vst.bridge.service.admin;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.VstException;
import com.vst.bridge.rest.input.vo.LoginInfoVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminUserAccessService {
	RestResponse login(LoginInfoVO loginInfoVO,HttpServletRequest request,HttpServletResponse httpServletResponse,UriInfo uriInfo)throws BridgeException, ParseException, IOException, VstException;
	RestResponse logout(final String sessionId, HttpServletRequest request,UriInfo uriInfo)throws BridgeException;
}
