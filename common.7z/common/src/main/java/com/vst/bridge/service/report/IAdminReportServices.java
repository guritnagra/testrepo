package com.vst.bridge.service.report;

import java.util.Date;

import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminReportServices {

	public RestResponse getBooksForBridgeId(BridgePaginationVo bridgePaginationVo, String category) throws BridgeException;

	public RestResponse getBookForVbid(Integer bridgeId, String vbid)throws BridgeException;

	public RestResponse getKeysForBridgeId(BridgePaginationVo bridgePaginationVo)throws BridgeException;

	public RestResponse getKeyDetailsForCode(Integer bridgeId, String keyCode)throws BridgeException;

	public RestResponse getBridgeLoginSummary(Integer bridgeId, Date startDate, Date endDate)throws BridgeException;
	
	public RestResponse getBridgeKeyRedeemedSummary(Integer bridgeId, Date startDate, Date endDate)throws BridgeException;
	
	public RestResponse getBridgeCreditsSummary(Integer bridgeId, Date startDate, Date endDate)throws BridgeException;

	public RestResponse getBridgeBookLaunchSummary(Integer bridgeId, Integer limit,Date startDate, Date endDate)throws BridgeException;

}
