package com.vst.bridge.dao.key;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.keys.Keys;
import com.vst.bridge.util.exception.BridgeException;

@Repository("keyDAO")
public class KeyDAOImpl extends GenericDAO<Keys, Integer> implements IKeyDAO{

	public KeyDAOImpl() {
		super(Keys.class);
	}

	@Override
	public Keys getKeyForCode(String code,final Integer bridgeId) throws BridgeException {
		Criteria criteria = getCriteria();
		if(null != bridgeId && bridgeId >0){
			criteria.createAlias("keyBatch", "keyBatchAlias");
			criteria.add(Restrictions.eq("keyBatchAlias.bridge.id", bridgeId));
		}
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.like("keyCode", code));
		List<Keys> result = executeCriteira(criteria);
		return null != result && result.size() > 0 ? result.get(0) : null;
	}

	@Override
	public Keys getKeyForCode(String code) throws BridgeException {
		Criteria criteria = getCriteria();
	
		criteria.createAlias("keyBatch", "keyBatchAlias");
		
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.like("keyCode", code));
		List<Keys> result = executeCriteira(criteria);
		return null != result && result.size() > 0 ? result.get(0) : null;
	}

	@Override
	public List<Keys> getKeysForKeyBatches(List<Integer> keyBatcheIds,Integer startIndex,Integer totalRecordToFetch,String search) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.in("keyBatch.id", keyBatcheIds));
		
		if(null != startIndex && null != totalRecordToFetch  && totalRecordToFetch > 0){
			criteria.setFirstResult(startIndex);
			criteria.setMaxResults(totalRecordToFetch);
		}
		
		if(org.apache.commons.lang.StringUtils.isNotBlank(search)){
			criteria.add(Restrictions.ilike("keyCode", search,MatchMode.ANYWHERE));
		}
		return  executeCriteira(criteria);
	}

	@Override
	public List<Integer> getKeysForType(Integer bridgeId,String bridgeUserRole,List<String> keyCodes) throws BridgeException {
		Criteria criteria = getCriteria();

			criteria.createAlias("keyBatch", "keyBatchAlias");
			criteria.createAlias("keyBatch.role", "roleAlias");
			criteria.add(Restrictions.eq("keyBatchAlias.bridge.id", bridgeId));
			criteria.add(Restrictions.like("roleAlias.name", bridgeUserRole));
			criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
			if(null != keyCodes && keyCodes.size() > 0){
				criteria.add(Restrictions.in("keyCode", keyCodes));
			}
			criteria.setProjection(Projections.projectionList()
					.add(Projections.property("id")));
			return executeCriteira(criteria);
	}

	@Override
	public Integer getTotalRecordsCount(List<Integer> keyBatchIds, String search) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.in("keyBatch.id", keyBatchIds));
				
		if(org.apache.commons.lang.StringUtils.isNotBlank(search)){
			criteria.add(Restrictions.ilike("keyCode", search,MatchMode.ANYWHERE));
		}
		criteria.setProjection(Projections.rowCount());
		Long total = (Long) criteria.uniqueResult();
		return null != total && total > 0? total.intValue() : 0;
	}
	
	@Override
	public List<Integer> getKeyIdsForBridge(final Integer bridgeId) throws BridgeException {
		List<Integer>  keyIds = null;
		Criteria criteria = getCriteria();
		if(null != bridgeId && bridgeId >0){
			criteria.createAlias("keyBatch", "keyBatchAlias");
			criteria.add(Restrictions.eq("keyBatchAlias.bridge.id", bridgeId));
		}
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		List<Keys> keys = executeCriteira(criteria);
		if(null != keys && keys.size() > 0){
			keyIds = new ArrayList<Integer>();
			for(Keys key : keys){
				keyIds.add(key.getId());
			}
		}
		return keyIds;
	}
}
