package com.vst.bridge.dao.user.key;

import java.util.Date;
import java.util.List;

import com.vst.bridge.dao.generic.IGenericDAO;
import com.vst.bridge.entity.bridge.user.BridgeUserKey;
import com.vst.bridge.entity.keys.Keys;
import com.vst.bridge.rest.response.vo.report.ReportKeyUserVO;
import com.vst.bridge.util.exception.BridgeException;

public interface IBridgeUserKeyDAO extends IGenericDAO<BridgeUserKey, Integer>{

	List<BridgeUserKey> getListOfKeysAssigedForUser(final Integer userId)throws BridgeException;
	
	
	List<BridgeUserKey> getListOfUsersAssigedForKey(final Integer keyId)throws BridgeException;
	
	List<Keys> getListOfKeysForBridgeUser(final Integer userId)throws BridgeException;

	BridgeUserKey getUserForCode(Integer userId, Integer id, Boolean excludeDeleted)throws BridgeException;

	BridgeUserKey getUserKeyForKeyId(Integer keyId)throws BridgeException;

	Integer getKeyCodeUsedCount(Integer keyId) throws BridgeException;
	
	List<ReportKeyUserVO> getKeysAssigedToUsers(final List<Integer> userIds, Date startDate, Date endDate)throws BridgeException;
	
	List<Integer> getUserkeyAssignedIds(Integer userId)throws BridgeException;
	
}
