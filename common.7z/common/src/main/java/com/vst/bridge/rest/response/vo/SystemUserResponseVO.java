package com.vst.bridge.rest.response.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class SystemUserResponseVO {
	
	private Integer id ;
	private String login;
	private String email;
	@JsonProperty("first_name")
	private String firstName;
	@JsonProperty("last_name")
	private String lastName;
	@JsonProperty("distribution_set_notify")
	private Boolean distributionSetNotify;
	@JsonProperty("wants_asset_distribution_emails")
	private Boolean wantsAssetDistributionEmails;
	@JsonProperty("is_activated")
	private Boolean isActivated;
	@JsonProperty("isApiUser")
	private Boolean is_api_user;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Boolean getDistributionSetNotify() {
		return distributionSetNotify;
	}
	public void setDistributionSetNotify(Boolean distributionSetNotify) {
		this.distributionSetNotify = distributionSetNotify;
	}
	public Boolean getWantsAssetDistributionEmails() {
		return wantsAssetDistributionEmails;
	}
	public void setWantsAssetDistributionEmails(Boolean wantsAssetDistributionEmails) {
		this.wantsAssetDistributionEmails = wantsAssetDistributionEmails;
	}
	public Boolean getIsActivated() {
		return isActivated;
	}
	public void setIsActivated(Boolean isActivated) {
		this.isActivated = isActivated;
	}
	public Boolean getIs_api_user() {
		return is_api_user;
	}
	public void setIs_api_user(Boolean is_api_user) {
		this.is_api_user = is_api_user;
	}
}
