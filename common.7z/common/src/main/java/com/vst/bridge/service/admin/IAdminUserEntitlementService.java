package com.vst.bridge.service.admin;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.UriInfo;

import com.vst.bridge.rest.input.vo.AllowanceRequestVO;
import com.vst.bridge.rest.input.vo.PurchaseRequestVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.util.exception.BridgeException;

public interface IAdminUserEntitlementService {

	RestResponse updateBridgeAllowanceForBridgeId(SessionStatusVO sessionStatusVO, AllowanceRequestVO allowanceRequestVO,
			Integer bridgeId, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException;
	RestResponse getBridgeAllowanceForBridgeId(SessionStatusVO sessionStatusVO, Integer bridgeId,
			HttpServletRequest httpRequest, UriInfo uriInfo)throws BridgeException;
	RestResponse getAccessTypeForBridgeId(SessionStatusVO sessionStatusVO, Integer bridgeId,
			HttpServletRequest httpRequest, UriInfo uriInfo)throws BridgeException;
	void getCsvErrorFile(SessionStatusVO sessionStatusVO, Object params, HttpServletRequest httpRequest,
			HttpServletResponse httpServletResponse, UriInfo uriInfo) throws BridgeException;;
	RestResponse updateBridgePurchaseForBridgeId(SessionStatusVO sessionStatusVO, PurchaseRequestVO purchaseRequestVO,
			Integer bridgeId, HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException;	
	RestResponse getBridgePurchaseForBridgeId(SessionStatusVO sessionStatusVO, Integer bridgeId,
			HttpServletRequest httpRequest, UriInfo uriInfo) throws BridgeException;
}
