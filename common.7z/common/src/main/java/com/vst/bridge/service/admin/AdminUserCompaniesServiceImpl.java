package com.vst.bridge.service.admin;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vst.bridge.JsonUtils;
import com.vst.bridge.VstException;
import com.vst.bridge.dao.admin.IAdminCompanyDAO;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.admin.group.company.IAdminGroupCompanyDAO;
import com.vst.bridge.dao.company.ICompanyDAO;
import com.vst.bridge.dao.group.IGroupDAO;
import com.vst.bridge.entity.admin.group.Group;
import com.vst.bridge.entity.admin.user.AdminUser;
import com.vst.bridge.entity.company.Company;
import com.vst.bridge.rest.response.vo.AdminCompanyVO;
import com.vst.bridge.rest.response.vo.CompanyVO;
import com.vst.bridge.rest.response.vo.ConnectCompanyResponseVO;
import com.vst.bridge.rest.response.vo.ConnectCompanyVO;
import com.vst.bridge.rest.response.vo.RestResponse;
import com.vst.bridge.rest.response.vo.SessionStatusVO;
import com.vst.bridge.rest.response.vo.page.BridgePaginationVo;
import com.vst.bridge.rest.response.vo.page.PaginationVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.error.ErrorHandlerUtil;
import com.vst.bridge.util.error.ResponseError;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.bridge.util.message.LocaleMessageUtility;
import com.vst.connectapi.ConnectApiWrapper;

@Service("adminUserCompaniesService")
public class AdminUserCompaniesServiceImpl implements IAdminUserCompaniesService {

	@Autowired
	private IAdminUserDAO adminUserDAO;
	
	@Autowired
	private IAdminCompanyDAO adminCompanyDAO;
	
	@Autowired
	private ICompanyDAO companyDAO;
	
	
	@Autowired
	private LocaleMessageUtility localeMessageUtility;
	
	@Autowired
	private ErrorHandlerUtil errorHandlerUtility;
	
	@Autowired
	private IGroupDAO groupDAO;
	
	@Autowired
	private IAdminGroupCompanyDAO adminGroupCompanyDAO;	
	
	@Autowired
	private AdminUserServiceUtil adminUserServiceUtil;
	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public RestResponse createOrUpdateCompanies(SessionStatusVO sessionStatusVO,CompanyVO companyVO, Integer companyId,
			UriInfo uriInfo, HttpServletRequest httpRequest)
			throws BridgeException, ParseException, IOException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		
		if(null!=companyVO){
			ResponseError responseError =  companyId==null ? errorHandlerUtility.validateCompanyVOParameters(JsonUtils.getJsonString(companyVO)) : null;
			Company company = null;
			String apiKey=companyVO.getApiKey();
			if(apiKey!=null){
				company=companyDAO.getCompanyByApiKey(apiKey);
				if(company!=null){
					throw new BridgeException(ApplicationCode.COMPANY_ALREADY_EXIST);
				}
			}
			company= companyId==null ? new Company() : companyDAO.get(companyId);
			String name = null;
			if(null==company){
				throw new BridgeException(ApplicationCode.COMPANY_NOT_FOUND);
			}else if(companyId==null){
				company.setCreatedBy(adminUserDAO.load(sessionStatusVO.getAdminId()));
				response.setCode(Response.Status.CREATED.getStatusCode());
			}
			if(null == responseError){
				name = companyVO.getName();
				if(null != name && !StringUtils.isEmpty(name) && !StringUtils.equals(name, company.getName())){
					companyDAO.checkCompanyNameExist(name);
					company.setName(name);
					company.setApiKey(companyVO.getApiKey());
					company.setCompanyId(companyVO.getCompanyId());
				}

				companyDAO.saveOrUpdate(company);
				if(companyId==null){
					company = companyDAO.getForName(name);
				}
				if(null != company){
					AdminCompanyVO compVo = new AdminCompanyVO();
					compVo.setId(company.getId());
					compVo.setName(company.getName());
					compVo.setCompanyId(company.getCompanyId());
					response.setData(compVo);
				}
			}else{
				response.setCode(Response.Status.BAD_REQUEST.getStatusCode());
				response.setMessageid(ApplicationCode.MISSING_INPUT_FIELD.getCodeId());
				response.setError(responseError);
			}
		}
		return response;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getCompaniesForGroupId(SessionStatusVO sessionStatusVO, Integer groupId, String code,
			BridgePaginationVo bridgePaginationVo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		Group group = groupDAO.get(groupId);
		if(group==null){
			throw new BridgeException(ApplicationCode.GROUP_NOT_FOUND);
		}
		List<Company> companies = adminGroupCompanyDAO.getListOfCompaniesForGroupId(groupId);
		List<AdminCompanyVO> companyVOs = adminUserServiceUtil.populateListOfCompanyVOFromCompany(companies);
		response.setData(companyVOs);
		return response;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse getCompanies(SessionStatusVO sessionStatusVO,Integer companyId,PaginationVO paginationVO,UriInfo uriInfo) throws BridgeException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if(null != companyId && companyId > 0){
			Company company = companyDAO.get(companyId);
			if(null==company){
				throw new BridgeException(ApplicationCode.COMPANY_NOT_FOUND);
			}
			AdminCompanyVO companyVO = new AdminCompanyVO();
			companyVO.setId(company.getId());
			companyVO.setName(company.getName());
			response.setData(companyVO);
		}else{
			adminUserServiceUtil.validateAndRearangePaginationVO(paginationVO, ApplicationConstants.DEFAULT_GET_BRIDGE_ORDER_BY_VALUE, Boolean.TRUE);
			Integer startIndex = adminUserServiceUtil.calculateStartIndex(paginationVO.getPage(), paginationVO.getLimit());
			List<Company> companies = null;
			Integer totalCount=null;
			if(StringUtils.equals(sessionStatusVO.getRoleName(), ApplicationConstants.USER_ROLE_SUPER_ADMIN)){
				companies = companyDAO.getAllCompanies(startIndex,paginationVO);
				totalCount=companyDAO.getAllCompaniesCount(paginationVO);
			}else{
				AdminUser user = adminUserDAO.get(sessionStatusVO.getAdminId());
				companies = adminCompanyDAO.getCompaniesForAdminId(user.getId());
				if(companies!=null && companies.size()>0){
					totalCount=companies.size();
				}
				/*List<AdminGroup> adminGroups = user.getGroups();
				if(null != adminGroups && adminGroups.size() > 0){
					List<Integer> groupIds = new ArrayList<Integer>();
					for(AdminGroup adminGroup : adminGroups){
						groupIds.add(adminGroup.getGroup().getId());
					}
					List<Company> groupCompanies = adminGroupCompanyDAO.getListOfCompaniesForGroupIds(groupIds);
					if(null != groupCompanies && groupCompanies.size() > 0){
						Set<Company> unionCopanies = new HashSet<Company>();
						unionCopanies.addAll(companies);
						unionCopanies.addAll(groupCompanies);
						companies = new ArrayList<Company>(unionCopanies);
					}
					totalCount=companies.size();
				}*/
			}
			List<AdminCompanyVO> companyList = new ArrayList<AdminCompanyVO>();
			if(null != companies && companies.size() > 0){
				for(Company company : companies){
					AdminCompanyVO companyVO = this.populateAdminCompanyResponseVO(company);					
					companyList.add(companyVO);
					
				}
				if(companyList!=null && companyList.size()>0){
					Integer totalPages = adminUserServiceUtil.calculateTotalPageCount(totalCount,
							paginationVO.getLimit());
					Integer offset=this.calculateOffsetValue(paginationVO.getPage(), paginationVO.getLimit());
					paginationVO = new PaginationVO(paginationVO.getPage(),paginationVO.getLimit(), totalPages, paginationVO.getOrderBy(),paginationVO.getOrder(), paginationVO.getSearch(), totalCount,offset);
					response.setMetadata(paginationVO);
				}
			}
			response.setData(companyList);
		}
		return response;
	}
	
	private Integer calculateOffsetValue(Integer page, Integer limit) {
		if(page!=null){
			return (page-1)*limit;
		}
		return 0;
	}

	private AdminCompanyVO populateAdminCompanyResponseVO(Company company) {
		AdminCompanyVO companyVO = new AdminCompanyVO();
		companyVO.setId(company.getId());
		companyVO.setName(company.getName());
		companyVO.setCompanyId(company.getCompanyId());
		companyVO.setCreated(company.getCreatedDate().getTime());
		companyVO.setCreatedDate(company.getCreatedDate());
		return companyVO;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public RestResponse checkCompany(SessionStatusVO sessionStatusVO, String apiKey, UriInfo uriInfo,
			HttpServletRequest httpRequest) throws BridgeException, VstException {
		RestResponse response = new RestResponse(Response.Status.OK.getStatusCode(),ApplicationCode.STATUS_OK.getCodeId(),
				localeMessageUtility.getMessage(ApplicationCode.STATUS_OK.getCodeId()));
		if(apiKey!=null){
			Company company=companyDAO.getCompanyByApiKey(apiKey);
			if(company!=null){
				throw new BridgeException("Associated company "+company.getName()+" already exist", ApplicationCode.COMPANY_ALREADY_EXIST);	
			}
			ConnectCompanyVO connectCompanyVO=ConnectApiWrapper.getV4ConnectCompany(apiKey);
			if(connectCompanyVO!=null){
				ConnectCompanyResponseVO companyResponseVO= new ConnectCompanyResponseVO(connectCompanyVO); 
				companyResponseVO.setApiKey(apiKey);
				response.setData(companyResponseVO);
			}
		}
		
		return response;
	}

}
