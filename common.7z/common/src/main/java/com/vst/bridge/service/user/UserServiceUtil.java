package com.vst.bridge.service.user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vst.bridge.VstException;
import com.vst.bridge.dao.admin.IAdminUserDAO;
import com.vst.bridge.dao.key.IKeyBatchDAO;
import com.vst.bridge.dao.key.IKeyBatchEntitlementDAO;
import com.vst.bridge.dao.log.IBridgeLogDAO;
import com.vst.bridge.dao.role.IRoleDAO;
import com.vst.bridge.dao.user.IBridgeUserDAO;
import com.vst.bridge.dao.user.book.IBridgeUserBookAssignDAO;
import com.vst.bridge.dao.user.key.IBridgeUserKeyDAO;
import com.vst.bridge.dao.user.role.IBridgeUserRoleDAO;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.log.BridgeLog;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.entity.bridge.user.BridgeUserKey;
import com.vst.bridge.entity.keys.KeyBatch;
import com.vst.bridge.entity.keys.KeyBatchEntitlement;
import com.vst.bridge.entity.keys.Keys;
import com.vst.bridge.rest.response.vo.user.BridgeUserInfoVO;
import com.vst.bridge.rest.response.vo.user.ConcurrencyCreditUsedDetailsVO;
import com.vst.bridge.rest.response.vo.user.TotalUsedDetailsVO;
import com.vst.bridge.rest.response.vo.user.UserCreditsInfoVO;
import com.vst.bridge.rest.response.vo.user.UserEntitlementVO;
import com.vst.bridge.util.constant.ApplicationAction;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.connectapi.ConnectApiWrapper;
import com.vst.connectapi.ConnectApiWrapper.ConnectApiException;
import com.vst.connectapi.ConnectCredentials;
import com.vst.connectapi.ConnectUser;

@Component("userServiceUtil")
public class UserServiceUtil {

	@Autowired
	private IBridgeUserDAO bridgeUserDAO;

	@Autowired
	private IBridgeUserKeyDAO bridgeUserKeyDAO;

	@Autowired
	private IBridgeUserBookAssignDAO bridgeUserBookAssignDAO;

	@Autowired
	private IBridgeLogDAO bridgeLogDAO;

	@Autowired
	private IBridgeUserRoleDAO bridgeUserRoleDAO;

	@Autowired
	private IAdminUserDAO adminUserDAO;
	
	@Autowired 
	private IKeyBatchEntitlementDAO keyBatchEntitlementDAO;
	
	@Autowired
	private IKeyBatchDAO keyBatchDAO;

	@Autowired
	private IRoleDAO roleDAO;
	
	protected Boolean checkEmailExistInBookshelf(String email) throws VstException, ConnectApiException {
		Boolean result = null;
		String isEmailUsed = ConnectApiWrapper.verifyMail(ApplicationConstants.getApiMode(), email);
		if (isEmailUsed != null) {
			if (isEmailUsed.contains("true")) {
				result = Boolean.TRUE;
			} else {
				result = Boolean.FALSE;
			}
		}

		return result;
	}

	public Integer createBridgeLog(final Integer userId, final Bridge bridge, final ApplicationAction action,
			final String value) {
		BridgeLog bridgeLog = new BridgeLog();
		bridgeLog.setUser(bridgeUserDAO.load(userId));
		bridgeLog.setBridge(bridge);
		bridgeLog.setAction(action.getCodeId());
		bridgeLog.setValue(value);
		return bridgeLogDAO.create(bridgeLog);
	}

	protected void populateBridgeUserDetailsFromConnectUser(BridgeUser bridgeUser, Bridge bridge,
			ConnectUser connectUser, ConnectCredentials credentials) {
		bridgeUser.setCreatedDate(new Date());
		bridgeUser.setBridge(bridge);

		String accessToken = connectUser.getAccessToken();
		accessToken = StringUtils.isNotBlank(accessToken) ? accessToken : credentials.getAccessToken();
		bridgeUser.setAccessToken(accessToken);

		String guid = connectUser.getGuid();
		guid = StringUtils.isNotBlank(guid) ? guid : credentials.getGuid();
		bridgeUser.setGuid(guid);

		bridgeUser.setEmail(connectUser.getEmail().toLowerCase());
		bridgeUser.setFirstName(StringUtils.capitalize(connectUser.getFirstName().toLowerCase()));
		bridgeUser.setLastName(StringUtils.capitalize(connectUser.getLastName().toLowerCase()));
		bridgeUser.setPromotionSubscription(connectUser.getPromotionSubscription());
		bridgeUser.setSurveySubscription(connectUser.getSurveySubscription());
		if(bridgeUser.getRole()==null){
			bridgeUser.setRole(roleDAO.getRoleByName("student"));
		}
	}

	protected BridgeUserInfoVO populateBridgeUserInfoFromBridgeUser(BridgeUser bridgeUser) {
		BridgeUserInfoVO userInfo = new BridgeUserInfoVO();
		userInfo.setId(bridgeUser.getId());
		userInfo.setFirstName(bridgeUser.getFirstName());
		userInfo.setLastName(bridgeUser.getLastName());
		userInfo.setEmail(bridgeUser.getEmail());
		userInfo.setCreated(bridgeUser.getCreatedDate().getTime());
		userInfo.setCreatedDate(bridgeUser.getCreatedDate());
		userInfo.setPromotionSubscription(bridgeUser.getPromotionSubscription());
		userInfo.setSurveySubscription(bridgeUser.getSurveySubscription());
		// List<Keys> keysAssiged =
		// bridgeUserKeyDAO.getListOfKeysForBridgeUser(bridgeUser.getId());
		UserCreditsInfoVO userCreditsInfoVO = this.getUserCredits(bridgeUser);
		TotalUsedDetailsVO trials = new TotalUsedDetailsVO();
		trials.setTotal(userCreditsInfoVO.getTrialCredits());
		trials.setUsed(userCreditsInfoVO.getTrailUsed());
		userInfo.setTrialCredits(trials);
		TotalUsedDetailsVO full = new TotalUsedDetailsVO();
		full.setTotal(userCreditsInfoVO.getFullCredits());
		full.setUsed(userCreditsInfoVO.getFullUsed());
		userInfo.setFullCredits(full);
		TotalUsedDetailsVO rental = new TotalUsedDetailsVO();
		rental.setTotal(userCreditsInfoVO.getRentalCredits());
		rental.setUsed(userCreditsInfoVO.getRentalUsed());
		userInfo.setRentalCredits(rental);
		ConcurrencyCreditUsedDetailsVO concurrencyCredits = new ConcurrencyCreditUsedDetailsVO();
		concurrencyCredits.setTotal(userCreditsInfoVO.getConcurrencyCredits());
		concurrencyCredits.setUsed(userCreditsInfoVO.getConcurrencyUsed());
		if (userCreditsInfoVO.getConcurrencyCredits() != null && userCreditsInfoVO.getConcurrencyUsed() != null)
			concurrencyCredits
					.setUnused(userCreditsInfoVO.getConcurrencyCredits() - userCreditsInfoVO.getConcurrencyUsed());
		userInfo.setConcurrencyCredits(concurrencyCredits);
		userInfo.setEntitlements(userCreditsInfoVO.getEntitlements());
		userInfo.setConcurrencyEntitlements(userCreditsInfoVO.getConcurrencyEntitlements());
		return userInfo;
	}

	/***
	 * Methode to get Bridge user trial or puchase credits details
	 * 
	 * @param bridgeUser
	 * @return
	 */
	protected UserCreditsInfoVO getUserCredits(BridgeUser bridgeUser) {
		UserCreditsInfoVO userCreditsInfoVO = new UserCreditsInfoVO();
		List<BridgeUserKey> userKeysAssigned = bridgeUserKeyDAO.getListOfKeysAssigedForUser(bridgeUser.getId());
		List<Keys> keysAssiged = getUserKeys(userKeysAssigned);
		List<Integer> keyBatchIdList=null;
		Integer trialCredits = 0;
		Integer fullCredits = 0;
		Integer rentalCredits = 0;
		Integer concurrencyCredits = 0;
		if(keysAssiged!=null && keysAssiged.size()>0){
			keyBatchIdList = getKeyBatchList(keysAssiged);
		}
			
		if (null != keysAssiged && keysAssiged.size() > 0) {
			for (Keys key : keysAssiged) {
				if (key.getTrialCredits() != null && key.getTrialCredits() != -1) {
					trialCredits = trialCredits + key.getTrialCredits();
				} else if (key.getTrialCredits() != null && key.getTrialCredits() == -1) {
					trialCredits = -1;
					break;
				}
			}
			for (Keys key : keysAssiged) {
				if (key.getFullCredits() != null && key.getFullCredits() != -1) {
					fullCredits = fullCredits + key.getFullCredits();
				} else if (key.getFullCredits() != null && key.getFullCredits() == -1) {
					fullCredits = -1;
					break;
				}
			}
			for (Keys key : keysAssiged) {
				if (key.getRentalCredits() != null && key.getRentalCredits() != -1) {
					rentalCredits = rentalCredits + key.getRentalCredits();
				} else if (key.getRentalCredits() != null && key.getRentalCredits() == -1) {
					rentalCredits = -1;
					break;
				}
			}
			if(keyBatchIdList!=null && keyBatchIdList.size()>0){
				Collections.sort(keyBatchIdList);
			}
			List<KeyBatch> keyBatchList = new ArrayList<KeyBatch>();
			for(Integer keyBatchId:keyBatchIdList){
				keyBatchList.add(keyBatchDAO.get(keyBatchId));
			}
			List<Integer> keyAssigedIds = getIds(userKeysAssigned);
			if(keyBatchList.size()>0){
				Bridge bridge=keyBatchList.get(0).getBridge();
				Map<String,UserEntitlementVO> concEntitlementMap= new HashMap<>();
				if(bridge!=null && bridge.getConcurrencyEnabled()){
					String mapKey=null;
					UserEntitlementVO concurrencyUserEntitlementVO=null;
					for (KeyBatch keybatch : keyBatchList){
						if(keybatch.getConcurrencyEntitlementName()!=null){
							if(keybatch.getConcurrencyDays()==null && keybatch.getConcurrencyExpires()!=null && new Date().after(keybatch.getConcurrencyExpires())){
								continue;
							}
							mapKey=keybatch.getConcurrencyEntitlementName().toLowerCase();
							concurrencyUserEntitlementVO = concEntitlementMap.get(mapKey);
							if(concurrencyUserEntitlementVO!=null){
								concurrencyUserEntitlementVO.setCredits(this.calculateUserTotalConcurrencyCredits(concurrencyUserEntitlementVO,keybatch));
								concurrencyUserEntitlementVO.setUsed(this.calculateUserUsedConcurrencyCredits(concurrencyUserEntitlementVO,keyAssigedIds,keybatch));
								if(concurrencyUserEntitlementVO.getCredits()!=null){
									this.calculateUserConcurrencyEntitlementId(concurrencyUserEntitlementVO, keybatch);
								}
								//concurrencyUserEntitlementVO.setId(keybatch.getId());							
							}
							else{
								concurrencyUserEntitlementVO = new UserEntitlementVO();
								mapKey=keybatch.getConcurrencyEntitlementName().toLowerCase();
								concurrencyUserEntitlementVO.setEntitlementName(mapKey);
								concurrencyUserEntitlementVO.setCredits(keybatch.getConcurrencyCredits());
								concurrencyUserEntitlementVO.setId(keybatch.getId());
								concurrencyUserEntitlementVO.setUsed(bridgeUserBookAssignDAO.getConcurrencyCountForUsedEntitlementType(keyAssigedIds,keybatch.getId()));							
							}
							concEntitlementMap.put(mapKey, concurrencyUserEntitlementVO);
						}
					}
					userCreditsInfoVO.setConcurrencyEntitlements(this.populateEntitlements(concEntitlementMap));
				}
			}			
			
			
			Integer trailUsed = bridgeUserBookAssignDAO.getCountForUsedType(keyAssigedIds,
					ApplicationConstants.BOOK_KEY_USED_TYPE_TRIAL);
			Integer fullUsed = bridgeUserBookAssignDAO.getCountForUsedType(keyAssigedIds,
					ApplicationConstants.BOOK_KEY_USED_TYPE_FULL);
			Integer rentalUsed = bridgeUserBookAssignDAO.getCountForUsedType(keyAssigedIds,
					ApplicationConstants.BOOK_KEY_USED_TYPE_RENTAL);
			Integer concurrencyUsed = bridgeUserBookAssignDAO.getCountForUsedType(keyAssigedIds,
					ApplicationConstants.BOOK_KEY_USED_TYPE_CONCURRENT);
			userCreditsInfoVO.setFullCredits(fullCredits);
			userCreditsInfoVO.setTrialCredits(trialCredits);
			userCreditsInfoVO.setFullUsed(fullUsed);
			userCreditsInfoVO.setTrailUsed(trailUsed);
			userCreditsInfoVO.setRentalCredits(rentalCredits);
			userCreditsInfoVO.setRentalUsed(rentalUsed);
			userCreditsInfoVO.setConcurrencyCredits(concurrencyCredits);
			userCreditsInfoVO.setConcurrencyUsed(concurrencyUsed);
			
			//New allowance with standard and comp
			//List<Integer> keyBatchList = getKeyBatchList(keysAssiged);
			List<KeyBatchEntitlement> keyBatchEntitlementList=new ArrayList<>();
			for(Integer keyBatchId: keyBatchIdList){
				List<KeyBatchEntitlement> keyBatchEntitlements=keyBatchEntitlementDAO.getEntitlementsByKeyBatches(keyBatchId);
				if(keyBatchEntitlements!=null)
					keyBatchEntitlementList.addAll(keyBatchEntitlements);
			}
				
			List<UserEntitlementVO> UserEntitlementVOList=this.populateUserEntitlements(keyBatchEntitlementList,keyAssigedIds);
			userCreditsInfoVO.setEntitlements(UserEntitlementVOList);
		}
		return userCreditsInfoVO;
	}

	private void calculateUserConcurrencyEntitlementId(UserEntitlementVO userEntitlementVO,KeyBatch keybatch) {
		if(userEntitlementVO.getCredits()==-1)
			return;
		if(userEntitlementVO.getUsed()!=null && userEntitlementVO.getUsed()>=userEntitlementVO.getCredits()){
			userEntitlementVO.setId(keybatch.getId());
		}
		
	}
	
	private void calculateUserEntitlementId(UserEntitlementVO userEntitlementVO,KeyBatchEntitlement keyBatchEntitlement) {
		if(userEntitlementVO.getCredits()==-1)
			return;
		if(userEntitlementVO.getUsed()!=null && userEntitlementVO.getUsed()>=userEntitlementVO.getCredits()){
			userEntitlementVO.setId(keyBatchEntitlement.getId());
		}
		
	}
	
	private Integer calculateUserUsedConcurrencyCredits(UserEntitlementVO concurrencyUserEntitlementVO, List<Integer> keyAssigedIds, KeyBatch keybatch) {
		Integer credits=concurrencyUserEntitlementVO.getCredits()!=null ? concurrencyUserEntitlementVO.getCredits() :0;
		if(credits==-1){
			return credits;
		}
		Integer usedCredits=concurrencyUserEntitlementVO.getUsed()!=null ? concurrencyUserEntitlementVO.getUsed() :0;
		if(concurrencyUserEntitlementVO.getId()!=null && keybatch.getId()!=null && concurrencyUserEntitlementVO.getId()!=keybatch.getId())
			usedCredits= usedCredits + bridgeUserBookAssignDAO.getConcurrencyCountForUsedEntitlementType(keyAssigedIds,keybatch.getId());
		return usedCredits;
	}

	private Integer calculateUserTotalConcurrencyCredits(UserEntitlementVO concurrencyUserEntitlementVO, KeyBatch keybatch) {		
		Integer credits=concurrencyUserEntitlementVO.getCredits()!=null ? concurrencyUserEntitlementVO.getCredits() :0;
		if(credits==-1){
			credits = -1;	
		}
		else if(keybatch.getConcurrencyCredits() != null && keybatch.getConcurrencyCredits() != -1) {
			credits = credits + keybatch.getConcurrencyCredits();
		} else if (keybatch.getConcurrencyCredits() != null && keybatch.getConcurrencyCredits() == -1) {
			credits = -1;			
		}
		
		return credits;
	}

	private List<UserEntitlementVO> populateUserEntitlements(List<KeyBatchEntitlement> keyBatchEntitlementList,List<Integer> keyAssigedIds) {		
		if(keyBatchEntitlementList!=null && keyBatchEntitlementList.size()>0){
			Map<String,UserEntitlementVO> entitlementMap= new HashMap<>();
			//List<UserEntitlementVO> UserEntitlementVOList = new ArrayList<UserEntitlementVO>();
			String mapKey=null;
			UserEntitlementVO userEntitlementVO=null;
			for(KeyBatchEntitlement keyBatchEntitlement: keyBatchEntitlementList){
				if(keyBatchEntitlement.getEntOnlineDays()==null && keyBatchEntitlement.getEntOnlineExpires()!=null && new Date().after(keyBatchEntitlement.getEntOnlineExpires())){
					continue;
				}
				mapKey=keyBatchEntitlement.getEntName().toLowerCase();
				userEntitlementVO = entitlementMap.get(mapKey);
				if(userEntitlementVO!=null){
					userEntitlementVO.setCredits(this.calculateUserTotalCredits(userEntitlementVO, keyBatchEntitlement));
					userEntitlementVO.setUsed(this.calculateUserUsedCredits(userEntitlementVO, keyAssigedIds,keyBatchEntitlement));
					if(userEntitlementVO.getCredits()!=null){
						calculateUserEntitlementId(userEntitlementVO,keyBatchEntitlement);
					}
					//userEntitlementVO.setId(keyBatchEntitlement.getId());
				}
				else{
					userEntitlementVO = new UserEntitlementVO();
					userEntitlementVO.setCredits(keyBatchEntitlement.getEntCredits());
					mapKey=keyBatchEntitlement.getEntName().toLowerCase();
					userEntitlementVO.setEntitlementName(mapKey);
					userEntitlementVO.setId(keyBatchEntitlement.getId());	
					Boolean isReusbaleCredit = keyBatchEntitlement.getEntIsReusableCredit()!=null ?keyBatchEntitlement.getEntIsReusableCredit() :Boolean.FALSE;
					userEntitlementVO.setUsed(bridgeUserBookAssignDAO.getCountForUsedEntitlementType(keyAssigedIds, keyBatchEntitlement.getId(),isReusbaleCredit));
					
				}
				entitlementMap.put(mapKey, userEntitlementVO);				
			}
			return this.populateEntitlements(entitlementMap);
		}
		return null;
	}

	private List<UserEntitlementVO> populateEntitlements(Map<String, UserEntitlementVO> entitlementMap) {
		List<UserEntitlementVO> userEntitlementList= new ArrayList<>();
		Set<String> entitlementKeysSet=entitlementMap.keySet();
		for(String entitlementKey:entitlementKeysSet){
			UserEntitlementVO concUserEntitlementVO=entitlementMap.get(entitlementKey);
			concUserEntitlementVO.setEntitlementName(StringUtils.capitalize(concUserEntitlementVO.getEntitlementName()));
			userEntitlementList.add(concUserEntitlementVO);
		}
		return userEntitlementList;
	}

	private Integer calculateUserUsedCredits(UserEntitlementVO userEntitlementVO, List<Integer> keyAssigedIds,KeyBatchEntitlement keyBatchEntitlement) {
		Integer credits=userEntitlementVO.getCredits()!=null ? userEntitlementVO.getCredits() :0;
		if(credits==-1){
			return 0;
		}
		Integer usedCredits=userEntitlementVO.getUsed()!=null ? userEntitlementVO.getUsed() :0;
		if(userEntitlementVO.getId()!=null && keyBatchEntitlement.getId()!=null && userEntitlementVO.getId()!=keyBatchEntitlement.getId())
			usedCredits= usedCredits + bridgeUserBookAssignDAO.getCountForUsedEntitlementType(keyAssigedIds, keyBatchEntitlement.getId(),keyBatchEntitlement.getEntIsReusableCredit());
		return usedCredits;
	}

	private Integer calculateUserTotalCredits(UserEntitlementVO userEntitlementVO,
			KeyBatchEntitlement keyBatchEntitlement) {
		Integer credits=userEntitlementVO.getCredits()!=null ? userEntitlementVO.getCredits() :0;
		if(credits==-1){
			credits = -1;	
		}
		else if(keyBatchEntitlement.getEntCredits() != null && keyBatchEntitlement.getEntCredits() != -1) {
			credits = credits + keyBatchEntitlement.getEntCredits();
		} else if (keyBatchEntitlement.getEntCredits() != null && keyBatchEntitlement.getEntCredits() == -1) {
			credits = -1;			
		}
		
		return credits;
	}

	private List<Integer> getKeyBatchList(List<Keys> keysAssiged) {
		List<Integer> keyBatchList = new ArrayList<Integer>();
		for(Keys key :keysAssiged){
			if(key.getKeyBatch()!=null)
				keyBatchList.add(key.getKeyBatch().getId());
		}
		return keyBatchList;
	}

	private List<Integer> getIds(List<BridgeUserKey> userKeysAssigned) {
		List<Integer> keys = null;
		if (null != userKeysAssigned && userKeysAssigned.size() > 0) {
			keys = new ArrayList<Integer>();
			for (BridgeUserKey userKey : userKeysAssigned) {
				keys.add(userKey.getId());
			}
		}
		return keys;
	}

	private List<Keys> getUserKeys(List<BridgeUserKey> userKeysAssigned) {
		List<Keys> keys = null;
		if (null != userKeysAssigned && userKeysAssigned.size() > 0) {
			keys = new ArrayList<Keys>();
			for (BridgeUserKey userKey : userKeysAssigned) {
				keys.add(userKey.getKey());
			}
		}
		return keys;
	}

	protected KeyBatch populateKeyBatchforAutoRedeem(Bridge bridge) {
		KeyBatch keyBatch = new KeyBatch();
		keyBatch.setBridge(bridge);
		keyBatch.setNote(ApplicationConstants.AUTO_GENERATED);
		keyBatch.setRole(bridgeUserRoleDAO.getForName(ApplicationConstants.BRIDGE_USER_ROLE_STUDENT));
		keyBatch.setNoOfUsers(1);
		String createdByEmail = adminUserDAO.getSuperAdmins().get(0).getEmail();
		keyBatch.setCreatedBy(adminUserDAO.getForEmail(createdByEmail));

		return keyBatch;
	}

}
