package com.vst.bridge.rest.response.vo.books;

public class BridgeBookVO {
	private String vbid;
	private Boolean selected;
	public String getVbid() {
		return vbid;
	}
	public void setVbid(String vbid) {
		this.vbid = vbid;
	}
	public Boolean getSelected() {
		return selected;
	}
	public void setSelected(Boolean selected) {
		this.selected = selected;
	}
	@Override
	public String toString() {
		return "BridgeBookVO [vbid=" + vbid + ", selected=" + selected + "]";
	}
}
