package com.vst.bridge.rest.response.vo.user;

public class ConcurrentBookLicenseInfoVO extends BookLicenseInfoVO {
	private Boolean isAvailable=Boolean.TRUE;

	public Boolean getIsAvailable() {
		return isAvailable;
	}

	public void setIsAvailable(Boolean isAvailable) {
		this.isAvailable = isAvailable;
	}

	

	

}
