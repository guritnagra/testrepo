package com.vst.bridge.dao.bridge.config;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.bridge.BridgeConfig;
import com.vst.bridge.util.exception.BridgeException;

@Repository("bridgeConfigDAO")
public class BridgeConfigDAOImpl extends GenericDAO<BridgeConfig, Integer> implements IBridgeConfigDAO{

	public BridgeConfigDAOImpl() {
		super(BridgeConfig.class);
	}

	@Override
	public List<BridgeConfig> getAllConfigForBridgeId(Integer bridgeId) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		return executeCriteira(criteria);
	}

	@Override
	public BridgeConfig getBridgeConfigByKeyName(Integer bridgeId, String keyName) throws BridgeException {
		Criteria criteria = getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.eq("deleted", Boolean.FALSE));
		criteria.add(Restrictions.eq("keyName", keyName));
		List<BridgeConfig> result = executeCriteira(criteria);
		return null != result && result.size() > 0 ? result.get(0) : null;
	}	
}
