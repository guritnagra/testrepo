package com.vst.bridge.dao.key;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.vst.bridge.dao.generic.GenericDAO;
import com.vst.bridge.entity.keys.KeyBatch;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.BridgeException;
@Repository("keyBatchDAO")
public class KeyBatchDAOImpl extends GenericDAO<KeyBatch, Integer> implements IKeyBatchDAO{

	public KeyBatchDAOImpl() {
		super(KeyBatch.class);
	}

	@Override
	public List<KeyBatch> getAllKeyBatches(Integer id) throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("bridge.id", id));
		criteria.add(Restrictions.ne("note",ApplicationConstants.AUTO_GENERATED));
		return executeCriteira(criteria);
	}

	@Override
	public List<Integer> getAllKeyBatchesIds(Integer bridgeId) throws BridgeException {
		List<Integer>  batcheIds = null;
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("bridge.id", bridgeId));
		criteria.add(Restrictions.ne("note",ApplicationConstants.AUTO_GENERATED));
		List<KeyBatch> batches = executeCriteira(criteria);
		if(null != batches && batches.size() > 0){
			batcheIds = new ArrayList<Integer>();
			for(KeyBatch keyBatch : batches){
				batcheIds.add(keyBatch.getId());
			}
		}
		return batcheIds;
	}
	
	
	@Override
	public KeyBatch getKeyBatchForAutoRedeem(Integer id) throws BridgeException {
		Criteria criteria= getCriteria();
		criteria.add(Restrictions.eq("bridge.id", id));
		criteria.add(Restrictions.eq("note",ApplicationConstants.AUTO_GENERATED));
		List<KeyBatch> result = executeCriteira(criteria);
		return null != result && result.size() > 0 ? result.get(0) : null;
	}
}
