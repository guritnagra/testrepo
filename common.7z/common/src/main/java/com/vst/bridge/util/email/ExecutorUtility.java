package com.vst.bridge.util.email;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * Class is used to create and manage Executors
 * 
 * @author Irfan.Tamboli
 * 
 */
public class ExecutorUtility {

	public static final int THREAD_POOL_DEFAULT_SIZE = 10;

	/**
	 * Method will create a Executor of size THREAD_POOL_DEFAULT_SIZE
	 * 
	 * @return {@link Executor}
	 */
	public static ExecutorService getExecutorInstance() {
		final ExecutorService pool = Executors.newFixedThreadPool(THREAD_POOL_DEFAULT_SIZE);
		configureExecutor(pool);
		return pool;
	}

	/**
	 * Method will create a Executor of size
	 * 
	 * @param size
	 * @return {@link Executor}
	 */
	public static ExecutorService getExecutorInstance(final int size) {
		final ExecutorService pool = Executors.newFixedThreadPool(size);
		configureExecutor(pool);
		return pool;
	}

	/**
	 * Private method used to configure the executor
	 * 
	 * @param executor
	 */
	private static void configureExecutor(final Executor executor) {
		if (executor instanceof ThreadPoolExecutor) {
			((ThreadPoolExecutor) executor).setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
		}
	}
}
