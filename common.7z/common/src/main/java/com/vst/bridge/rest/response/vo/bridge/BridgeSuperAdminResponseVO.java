package com.vst.bridge.rest.response.vo.bridge;

public class BridgeSuperAdminResponseVO extends BridgeAdminResponseVO{
	
	private String apiKey;
	
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
}
