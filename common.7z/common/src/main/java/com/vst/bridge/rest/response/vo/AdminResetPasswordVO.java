package com.vst.bridge.rest.response.vo;

public class AdminResetPasswordVO {
	private String email;
	//private String returnPath;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	/*public String getReturnPath() {
		return returnPath;
	}
	public void setReturnPath(String returnPath) {
		this.returnPath = returnPath;
	}*/
}
