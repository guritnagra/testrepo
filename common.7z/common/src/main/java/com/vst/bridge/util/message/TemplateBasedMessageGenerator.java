package com.vst.bridge.util.message;

import java.util.Locale;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.tools.generic.DateTool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.velocity.VelocityEngineUtils;

/**
 * Class encapsulates the logic to generate strings from velocity template files
 * 
 * @author Irfan.Tamboli
 * 
 */
@Component("messageGenerator")
public class TemplateBasedMessageGenerator {

	@Autowired
	private VelocityEngine velocityEngine;

	private static final  Logger logger = LogManager.getLogger(TemplateBasedMessageGenerator.class);

	/**
	 * Method parses the template source for the passed map of objects and
	 * generates the resultant text
	 * 
	 * @param vmSrc
	 * @param paramMap
	 * @return {@link String}
	 */
	@SuppressWarnings("deprecation")
	public String getMessage(final String vmSrc, final Map<String, Object> paramMap, final Locale locale) {
		final String localeVmSrc = vmSrc + "." + locale.toString();
		this.addDateToolToMap(paramMap);
		final String text = VelocityEngineUtils.mergeTemplateIntoString(this.velocityEngine, localeVmSrc, paramMap);
		if (logger.isTraceEnabled()) {
			logger.trace("generating content from vmSrc {} with parameter map as {}. Content generated is {} ",
					new Object[] { localeVmSrc, paramMap, text });
		}
		return text;
	}

	/**
	 * Overloaded method - assumes locale as en,US
	 * 
	 * @see getMessage
	 * 
	 * @param vmSrc
	 * @param paramMap
	 * @return {@link String}
	 */
	public String getMessage(final String vmSrc, final Map<String, Object> paramMap) {
		final String content = this.getMessage(vmSrc, paramMap, Locale.US);
		return content;
	}

	/**
	 * Method will add the date tool to the map
	 * 
	 * @param paramMap
	 */
	private void addDateToolToMap(final Map<String, Object> paramMap) {
		paramMap.put("dateTool", new DateTool());
	}
}
