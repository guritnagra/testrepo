package com.vst.bridge.util.html;

import java.io.StringReader;
import java.io.StringWriter;

import org.apache.commons.lang.StringUtils;
import org.w3c.tidy.Tidy;

public class HTMLParserUtil {

	private HTMLParserUtil() {

	}

	private static Tidy tidy;

	static {
		tidy = new Tidy();
		tidy.setInputEncoding("UTF-8");
		tidy.setOutputEncoding("UTF-8");
		tidy.setWraplen(Integer.MAX_VALUE);
		tidy.setPrintBodyOnly(true);
		tidy.setQuiet(true);
		tidy.setShowErrors(0);
		tidy.setShowWarnings(false);
		// tidy.setXmlOut(true);
		// tidy.setSmartIndent(true);
	}

	public static String parseHTML(String html) {
		String result = null;
		if (StringUtils.isNotBlank(html)) {
			StringWriter sw = new StringWriter();
			tidy.parseDOM(new StringReader(html), sw);
			result = sw.toString();
			result = result.replace("\n", "").replace("\r", "");
		}
		return result;
	}
}
