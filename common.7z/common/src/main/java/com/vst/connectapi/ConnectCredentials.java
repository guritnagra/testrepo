package com.vst.connectapi;

public class ConnectCredentials 
{
	private String guid;
	private String accesstoken;
	
	public ConnectCredentials(String guid, String accesstoken)
	{
		this.guid = guid;
		this.accesstoken = accesstoken;
	}
	
	public String getGuid()
	{
		return guid;
	}
	public String getAccessToken()
	{
		return accesstoken;
	}

	@Override
	public String toString() {
		return "ConnectCredentials [guid=" + guid + ", accesstoken=" + accesstoken + "]";
	}
}
