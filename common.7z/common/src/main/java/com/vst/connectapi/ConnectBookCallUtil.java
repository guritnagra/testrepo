package com.vst.connectapi;

import java.util.concurrent.Callable;

import org.jdom2.Document;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS)
@Component("connectBookCallUtil")
public class ConnectBookCallUtil implements Callable<Document> {
	private ApiKeys key;
	private int currentPage;
	private int totalPerPage;
	public ConnectBookCallUtil(ApiKeys key, int currentPage, int totalPerPage){
		this.key=key;
		this.currentPage=currentPage;
		this.totalPerPage=totalPerPage;
	}
	@Override
	public Document call() throws Exception {
		return ConnectApiWrapper.getBooksFromCatalog(key, currentPage, totalPerPage);
	}

}
