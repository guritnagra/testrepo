package com.vst.connectapi;

import java.io.IOException;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.XMLOutputter;

import com.vst.bridge.VstException;
import com.vst.bridge.entity.bridge.Bridge;
import com.vst.bridge.entity.bridge.CodeTypes;
import com.vst.bridge.entity.bridge.user.BridgeUserKey;
import com.vst.bridge.rest.response.vo.RedeemBookVO;
import com.vst.bridge.rest.response.vo.user.AccessCodeResponseVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.constant.ApplicationConstants.CodeType;
import com.vst.bridge.util.date.DateUtility;

public class StoriaUtils 
{
	private static Logger log = LogManager.getLogger(StoriaUtils.class);
	
	public enum XML_ERROR_CODES {
		INVALID_LICENSE_TYPE(104),
		INVALID_EXPIRATION_DATE(105),
		NUMBER_OF_DAYS_CANNOT_BE_ZERO(106),
		QUESTION_IS_INVALID(463),
		ACCOUNT_ALREADY_EXISTS(464),
		DATA_VALIDATION_ERROR(465),
		EMAIL_OR_PASSWORD_WAS_NOT_ACCEPTED(466),
		BUNDLE_IS_INVALID(467),
		REDEMPTION_CODE_IS_INVALID(468),
		CODE_HAS_BEEN_REDEEMED(469),
		REDEPTION_FAILED(470),
		INVALID_OR_EXPIRED_SIGN_IN_TOKEN(473),
		USER_COULD_NOT_BE_FOUND(474),
		MALFORMED_CREATE_USER_REQUEST(482),
		MALFORMED_REDEMPTION_REQUEST(483),
		MALFORMED_UPDATE_USER_REQUEST(484),
		REFERENCE_OR_EMAIL_AND_PASSWORD_ARE_REQUIRED(485),
		INVALID_ACCESS_TOKEN_REFERENCE(601),
		INVALID_GUID_REFERENCE(602),
		INVALID_REFERENCE_VALUE(603),
		MALFORMED_CREDENTIALS_REQUEST(650),
		INSUFFICIENT_PERMISSIONS(900),
		MALFORMED_XML_REQUEST(901),
		//ACCESS_TOKEN_DOESNT_MATCH_USER(902),
		PRODUCT_SKU_COULD_NOT_BE_FOUND(902),	//Incorrect in documentation
		//USER_REFERENCE_ALREADY_EXISTS(903),
		ACCESS_TOKEN_DOESNT_MATCH_USER(903),	//Incorrect in documentation
		USER_REFERENCE_ALREADY_EXISTS(904),		//Incorrect in documentation
		INVALID_CODE_REQUEST(905),
		INSUFFICIENT_REQUIREMENTS_FOR_USER_CREATE(906),
		INSUFFICIENT_REQUIREMENTS_FOR_USER_UPDATE(907),
		CODE_PRICE_MUST_BE_POSITIVE(908),
		UNABLE_TO_MERGE_USERS(990),
		UNABLE_TO_MERGE_USER_WITH_ITSELF(991),
		API_USER_COMPANY_IS_MISCONFIGURED(992), //has multiple companies
		PAKAGE_CONTAINS_NON_EXISTANT_SKU(993),
		INSUFIECIENT_REQUIREMENTS_FOR_PACKAGE_CREATE(994),
		LIBRARY_ID_NOT_ACCEPTABLE(995),
		PRODUCT_SKU_ALREADY_EXISTS(996)
		;
		
        private int code;
    	
        private XML_ERROR_CODES(int code) {
                this.code = code;
        }
        
        public int getStatusCode() {
        	return code;
        }
	}
	
	public static String createRedirectUrl(String url, String accesskey, String connectApiKey) throws VstException
	{
		HttpPost post1 = null;
		try
		{
			SAXBuilder saxBuilder = new SAXBuilder();
			
			Document redirectdoc = new Document();
			Element redirect = new Element(ApplicationConstants.REDIRECT);
			Element destination = new Element(ApplicationConstants.DESTINATION);
			destination.setText(url);
			redirect.addContent(destination);
			redirectdoc.setRootElement(redirect);
			
			post1 = new HttpPost(ApiKeys.getConnectUrl(ApplicationConstants.getApiMode())+ApplicationConstants.URL_GETREDIRECTS);
			post1.setHeader(ApplicationConstants.APIKEY_HEADER, connectApiKey);
			post1.setHeader(ApplicationConstants.ACCESSSTOKEN_HEADER, accesskey);
			post1.setEntity(new ByteArrayEntity(new XMLOutputter().outputString(redirectdoc).getBytes("UTF-8")));
			
			HttpClient httpclient = HttpClientBuilder.create().build();
			HttpContext context = new BasicHttpContext();
			HttpResponse response = httpclient.execute(post1, context);
	
			if(response.getStatusLine().getStatusCode() != HttpURLConnection.HTTP_OK)
			{
				throw new VstException("An error occured",ERRORS.ConnectKeyException);
			}
			
			String result = EntityUtils.toString(response.getEntity());
			
			Document d = saxBuilder.build(new StringReader(result));
			
			if(d.getRootElement().getName().equals("redirect"))
			{
				return d.getRootElement().getAttributeValue("auto-signin");
			}
			else
			{
				throw new VstException("An error occured",new Exception("Connect exception " + response.getStatusLine().getStatusCode()+" "+result), ERRORS.ConnectKeyException);
			}
		}
		catch(Exception e) {
			throw new VstException("Unable to create a reference account",e, ERRORS.ConnectKeyException);
		}
		finally
		{
			post1.releaseConnection();
		}
	}

/*	public static String createReferenceUser(String env, String role, int studentId, String connectApiKey) throws VstException 
	{
		HttpPost post1 = null;
		HttpPost post2 = null;
		try
		{
			SAXBuilder saxBuilder = new SAXBuilder();
			
			StringBuilder refid = new StringBuilder();
			refid.append("storia_");
			refid.append(env);
			refid.append("_");
			refid.append(role);
			refid.append("_");
			refid.append(studentId);
			
			Document userdoc = new Document();
			Element user = new Element("user");
			
			Element reference = new Element("reference");
			reference.setText(refid.toString());
			user.addContent(reference);
			
			Element firstName = new Element("first-name");
			firstName.setText(role);
			user.addContent(firstName);
			
			Element lastName = new Element("last-name");
			lastName.setText(studentId+"");
			user.addContent(lastName);
			
			userdoc.setRootElement(user);
			
			post1 = new HttpPost(ApiKeys.getConnectUrl(Constants.CONNECT_KEYS.getApiMode())+Constants.CONNECT_KEYS.URL_CREATEUSER);
			post1.setHeader(Constants.CONNECT_KEYS.APIKEY_HEADER, connectApiKey);
			post1.setEntity(new ByteArrayEntity(new XMLOutputter().outputString(userdoc).getBytes("UTF-8")));
			
			HttpClient httpclient = HttpClientBuilder.create().build();
			HttpContext context = new BasicHttpContext();
			HttpResponse response = httpclient.execute(post1, context);
			
			if(response.getStatusLine().getStatusCode() == XML_ERROR_CODES.USER_REFERENCE_ALREADY_EXISTS.getStatusCode())
			{
				Document credentialdoc = new Document();
				Element credentials = new Element("credentials");
				Element credential = new Element("credentials");
				credential.setAttribute("reference", refid.toString());
				credentials.addContent(credential);
				credentialdoc.setRootElement(credentials);
				
				post2 = new HttpPost(ApiKeys.getConnectUrl(Constants.CONNECT_KEYS.getApiMode())+Constants.CONNECT_KEYS.URL_GETCREDENTIALS);
				post2.setHeader(Constants.CONNECT_KEYS.APIKEY_HEADER, connectApiKey);
				post2.setEntity(new ByteArrayEntity(new XMLOutputter().outputString(credentialdoc).getBytes("UTF-8")));
				
				response = httpclient.execute(post2, context);
			}
			if(response.getStatusLine().getStatusCode()==HttpURLConnection.HTTP_OK)
			{
				String result = EntityUtils.toString(response.getEntity());
				Document d = saxBuilder.build(new StringReader(result));
				
				if(d.getRootElement().getName().equals("error-response"))
				{
					if(d.getRootElement().getChild("error-code").getText().equals(""+XML_ERROR_CODES.USER_REFERENCE_ALREADY_EXISTS.getStatusCode()))
					{
						Document credentialdoc = new Document();
						Element credentials = new Element("credentials");
						Element credential = new Element("credential");
						credential.setAttribute("reference", refid.toString());
						credentials.addContent(credential);
						credentialdoc.setRootElement(credentials);
						
						post2 = new HttpPost(ApiKeys.getConnectUrl(Constants.CONNECT_KEYS.getApiMode())+Constants.CONNECT_KEYS.URL_GETCREDENTIALS);
						post2.setHeader(Constants.CONNECT_KEYS.APIKEY_HEADER, connectApiKey);
						post2.setEntity(new ByteArrayEntity(new XMLOutputter().outputString(credentialdoc).getBytes("UTF-8")));
						
						response = httpclient.execute(post2, context);
						String result2 = EntityUtils.toString(response.getEntity());
						d = saxBuilder.build(new StringReader(result2));
					}
				}
				if(d.getRootElement().getName().equals("credentials"))
				{
					return d.getRootElement().getChild("credential").getAttributeValue("access-token");
				}
				else if(d.getRootElement().getName().equals("user"))
				{
					return d.getRootElement().getChild("access-token").getText();
				}
				else
				{
					throw new VstException("An error occured",new Exception("Connect exception " + response.getStatusLine().getStatusCode()+" "+result), ERRORS.ConnectKeyException);
				}
			}
			else
			{
				throw new VstException("An error occured",new Exception("Connect exception " + response.getStatusLine().getStatusCode()+" "+EntityUtils.toString(response.getEntity())), ERRORS.ConnectKeyException);
			}
		} catch(Exception ex) {
			throw new VstException("An error occured",ex,ERRORS.ConnectKeyException);
		} finally {
			try{post1.releaseConnection();}catch(Exception ex){}
			try{post2.releaseConnection();}catch(Exception ex){}
		}
	}*/

	
	/*public static void giveAccess(String connectApiKey, String userAccessToken, String vbid, Integer daysForTrial,Boolean isTrial,Integer rentalDays) throws VstException, IOException, JDOMException, ParseException
	{
 		HttpGet  get1 = null;
		HttpPost post2 = null;
		HttpPost post3 = null;
		try
		{
			SAXBuilder saxBuilder = new SAXBuilder();

			get1 = new HttpGet(ApiKeys.getConnectUrl(ApplicationConstants.getApiMode())+ApplicationConstants.URL_GETLICENSE+"?sku="+vbid);
			get1.setHeader(ApplicationConstants.APIKEY_HEADER, connectApiKey); //connectApiKey);
			get1.setHeader(ApplicationConstants.ACCESSSTOKEN_HEADER, userAccessToken);
			
			HttpClient httpclient = HttpClientBuilder.create().build();
			HttpContext context = new BasicHttpContext();

			HttpResponse response = httpclient.execute(get1, context);

			String result = EntityUtils.toString(response.getEntity());
			
			if(response.getStatusLine().getStatusCode()!=HttpURLConnection.HTTP_OK)
			{
				throw new VstException("Connect exception " + response.getStatusLine().getStatusCode()+" "+result, ERRORS.ConnectKeyException);
			}
			
			Document d = saxBuilder.build(new StringReader(result));
			
			boolean has_license = false;
			
			List<Element> licences = d.getRootElement().getChildren("license");
			log.info("{} Licenses from ConnectAPI", licences.size());
			
			for(Element license: licences)
			{
				String sku = license.getAttributeValue("sku");
				if(sku.equals(vbid))
				{
					String type   = license.getAttributeValue(ApplicationConstants.TYPE);
					if(type.equals(ApplicationConstants.ONLINE))
					{
						String expire = license.getAttributeValue("expiration");
						
						DateFormat simpledateformat=new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z");
						
						Date exp = simpledateformat.parse(expire);
						
						if(exp.after(new Date()))
						{
							has_license = true;
						}
						
					}
					
				}
			}
			
			
			if(!has_license)
			{
				Document codereqdoc = new Document();
				Element codes = new Element(ApplicationConstants.CODES);
				codes.setAttribute(ApplicationConstants.SKU,vbid);
				
				//if(-1 == daysForTrial) codes.setAttribute(Constants.CONNECT_KEYS.LICENSE_TYPE,Constants.CONNECT_KEYS.PERPETUAL);
				codes.setAttribute(ApplicationConstants.LICENSE_TYPE,ApplicationConstants.NUMDAYS);
				codes.setAttribute(ApplicationConstants.NUM_CODES,"1");
				
				Integer numberOfDays = 365;
				
				if(isTrial){
					numberOfDays = -1 == daysForTrial ? 365 : daysForTrial;
				}else if(rentalDays != null&&rentalDays>0){
					numberOfDays = -1==rentalDays ? 365 : rentalDays;
				}
				
				
				codes.setAttribute(ApplicationConstants.NUM_DAYS,numberOfDays.toString());
				codes.setAttribute(ApplicationConstants.ONLINE_NUM_DAYS,numberOfDays.toString());
				
				//if(-1 == daysForTrial) codes.setAttribute(Constants.CONNECT_KEYS.ONLINE_LICENSE_TYPE,Constants.CONNECT_KEYS.PERPETUAL);
				codes.setAttribute(ApplicationConstants.ONLINE_LICENSE_TYPE,ApplicationConstants.NUMDAYS);
				if(isTrial) {
					codes.setAttribute(ApplicationConstants.CODE_TYPE, "comp");
				}
				
				codereqdoc.setRootElement(codes);
				
				post2 = new HttpPost(ApiKeys.getConnectUrl(ApplicationConstants.getApiMode())+ApplicationConstants.URL_CREATECODES);
				post2.setHeader(ApplicationConstants.APIKEY_HEADER, connectApiKey);
				post2.setEntity(new ByteArrayEntity(new XMLOutputter().outputString(codereqdoc).getBytes("UTF-8")));

				log.info("No License, for sku({}), so create code in ConnectAPI: {}", vbid, codes.toString());
				
				HttpResponse response2 = httpclient.execute(post2, context);
				
				String result2 = EntityUtils.toString(response2.getEntity());
				
				if(response2.getStatusLine().getStatusCode()!=HttpURLConnection.HTTP_OK)
				{
					throw new VstException("Connect exception " + response2.getStatusLine().getStatusCode()+" "+result2, ERRORS.ConnectKeyException);
				}
				
				Document d2 = saxBuilder.build(new StringReader(result2));
				
				if(d2.getRootElement().getName().equals("error-response"))
				{
					throw new VstException(d2.getRootElement().getChildText("error-text")+"; Connect exception " + response2.getStatusLine().getStatusCode()+" "+result2, ERRORS.ConnectKeyException);
				}
				
				String code = d2.getRootElement().getChild(ApplicationConstants.CODE).getText();
				
				Document redemptiondoc = new Document();
				Element redemption = new Element(ApplicationConstants.REDEMPTION);
				Element redemptioncode = new Element(ApplicationConstants.CODE);
				redemptioncode.setText(code);
				redemption.addContent(redemptioncode);
				redemptiondoc.setRootElement(redemption);
				
				post3 = new HttpPost(ApiKeys.getConnectUrl(ApplicationConstants.getApiMode())+ApplicationConstants.URL_REDEMPTIONS);
				post3.setHeader(ApplicationConstants.APIKEY_HEADER, connectApiKey);
				post3.setHeader(ApplicationConstants.ACCESSSTOKEN_HEADER, userAccessToken);
				post3.setEntity(new ByteArrayEntity(new XMLOutputter().outputString(redemptiondoc).getBytes("UTF-8")));
				
				HttpResponse response3 = httpclient.execute(post3, context);
				
				Document d3 = checkResponse(response3, connectApiKey);
				
				//String result3 = EntityUtils.toString(response3.getEntity());
				
				if(!d3.getRootElement().getName().equals("library"))
				{
					throw new VstException("Connect exception " + response3.getStatusLine().getStatusCode()+" "+d3.toString(), ERRORS.ConnectKeyException);
				}
			}
		} finally {
			try{get1.releaseConnection();}catch(Exception ex){}
			try{post2.releaseConnection();}catch(Exception ex){}
			try{post3.releaseConnection();}catch(Exception ex){}
		}
		
	}*/
	
	private static Document checkResponse(HttpResponse response, String connectApiKey) throws VstException
	{
		try {
			String result = EntityUtils.toString(response.getEntity());
			
			if(response.getStatusLine().getStatusCode()!=HttpURLConnection.HTTP_OK)
			{
				throw new VstException("An error occured",new Exception("Connect exception " + response.getStatusLine().getStatusCode()+" "+result), ERRORS.ConnectKeyException);
			}
			
			SAXBuilder saxBuilder = new SAXBuilder();
			Document d = saxBuilder.build(new StringReader(result));
			
			if(d.getRootElement().getName().equals("error-response"))
			{
				throw new VstException("An error occured",new Exception("Connect exception " + response.getStatusLine().getStatusCode()+" "+result), ERRORS.ConnectKeyException);
			}
			
			return d;
		}
		catch(Exception ex)
		{
			throw new VstException("An error occured",ex, ERRORS.ConnectKeyException);
		}
	}

	public static boolean checkUser(String accesskey, String connectApiKey) throws VstException 
	{
		HttpGet get1 = null;
		try
		{
			get1 = new HttpGet(ApiKeys.getConnectUrl(ApplicationConstants.getApiMode())+ApplicationConstants.URL_GETUSER+accesskey);
			get1.setHeader(ApplicationConstants.APIKEY_HEADER, connectApiKey);
			
			HttpClient httpclient = HttpClientBuilder.create().build();
			HttpContext context = new BasicHttpContext();
			HttpResponse response = httpclient.execute(get1, context);

			if(response.getStatusLine().getStatusCode()==404)
			{
				return false;
			}
			else if(response.getStatusLine().getStatusCode()==HttpURLConnection.HTTP_OK)
			{
				return true;
			}
			return false;
		}
		catch(Exception ex)
		{
			throw new VstException("An error occured",ex, ERRORS.ConnectKeyException);
		}	
	}
	
	/*public static void main(String[] a) {
		final String getText= "904";
		if(getText.equals(""+XML_ERROR_CODES.USER_REFERENCE_ALREADY_EXISTS.getStatusCode())) {
			System.out.println("==getStatusCode()");
		}
		if(getText.equals(""+XML_ERROR_CODES.USER_REFERENCE_ALREADY_EXISTS)) {
			System.out.println("==USER_REFERENCE_ALREADY_EXISTS");
		}

		
		final int getStatusCode= 904;

		if(getStatusCode != HttpURLConnection.HTTP_OK) {
			System.out.println("!= HTTP_OK");
		}
		
		if(getStatusCode == XML_ERROR_CODES.USER_REFERENCE_ALREADY_EXISTS.getStatusCode())	//Use this!
		{
			System.out.println("getStatus==USER_REFERENCE_ALREADY_EXISTS.getStatusCode()");
		}
		if(XML_ERROR_CODES.USER_REFERENCE_ALREADY_EXISTS.equals(getStatusCode))
		{
			System.out.println("XML_ERROR_CODES.USER_REFERENCE_ALREADY_EXISTS.equals(getStatusCode)");
		}
		if(getStatusCode == 904)
		{
			System.out.println("904==getStatusCode");
		}
		if(XML_ERROR_CODES.USER_REFERENCE_ALREADY_EXISTS.equals(904))
		{
			System.out.println("XML_ERROR_CODES.USER_REFERENCE_ALREADY_EXISTS.equals(903)");
		}
	}*/
	/**
	 * Gives access to user to book.  The duration of this license until expiration is determined by ConnectAPI, including whether the vbid is a rental when it ends with R###.
	 * @param connectApiKey ConnectAPI key
	 * @param userAccessToken user token
	 * @param vbid book id
	 * @param codeType Type of trial rental/try/full
	 * @param bridge user bridge
	 * @param key user key
	 * @throws VstException
	 * @throws IOException
	 * @throws JDOMException
	 * @throws ParseException
	 **/
	public static AccessCodeResponseVO giveAccess(String connectApiKey, String userAccessToken, String vbid,CodeType codeType,Bridge bridge,BridgeUserKey key) throws VstException, IOException, JDOMException, ParseException
	{
		Integer calcNumberOfDays=null;
		Date calcExpireDate=null;
		String redeemCodeType=null;
		Integer offlineCalcNumberOfDays=null;
		Date offlineCalcExpireDate=null;
			if(codeType==CodeType.TRIAL){
				if(null!=bridge.getTrialDays() || null !=bridge.getTrialExpires()){					
					calcNumberOfDays=bridge.getTrialDays();
					calcExpireDate=bridge.getTrialExpires();
				}
				else{
					//calcNumberOfDays= null != bridge.getBridgeType() && ApplicationConstants.BRIDGE_TYPE_SAMPLER.equals(bridge.getBridgeType().getType()) ? 1:30 ;
					//if(null!= bridge.getBridgeType() && ApplicationConstants.BRIDGE_TYPE_SAMPLER.equals(bridge.getBridgeType().getType())){
					if(null!= bridge.getIsSampler() && bridge.getIsSampler()){
						calcNumberOfDays=1;
					}
					else{
						calcNumberOfDays=30;
					}
				}
				if(null!=bridge.getOfflineTrialDays() || null !=bridge.getOfflineTrialExpires()){					
					offlineCalcNumberOfDays=bridge.getOfflineTrialDays();
					offlineCalcExpireDate=bridge.getOfflineTrialExpires();
				}
				else{
					//if(null!= bridge.getBridgeType() && ApplicationConstants.BRIDGE_TYPE_SAMPLER.equals(bridge.getBridgeType().getType())){
					if(null!= bridge.getIsSampler() && bridge.getIsSampler()){
						offlineCalcNumberOfDays=1;
					}
					else{
						offlineCalcNumberOfDays=30;
					}
				}
				redeemCodeType=ApplicationConstants.REDEEM_TYPE_COMP;
			}
			else if(codeType==CodeType.RENTAL){
				Integer keysRentalDays = key.getKey().getRentalDays();				
				if(null!=keysRentalDays){
					calcNumberOfDays=keysRentalDays;
				}
				else if(null!=bridge.getRentalDays() || null!=bridge.getRentalExpires()){
					calcNumberOfDays=bridge.getRentalDays();
					calcExpireDate=bridge.getRentalExpires();
				}
				calcNumberOfDays= null != calcNumberOfDays && calcNumberOfDays > 0 ? calcNumberOfDays : 30;
				
				if(null!=bridge.getOfflineRentalDays() || null!=bridge.getOfflineRentalExpires()){
					offlineCalcNumberOfDays=bridge.getOfflineRentalDays();
					offlineCalcExpireDate=bridge.getOfflineRentalExpires();
				}
				offlineCalcNumberOfDays= null != offlineCalcNumberOfDays && offlineCalcNumberOfDays > 0 ? offlineCalcNumberOfDays : 30;
				
			}
			else if(codeType==CodeType.FULL){
				if(null !=bridge.getFullDays() || null !=bridge.getFullExpires()){
					calcNumberOfDays=bridge.getFullDays();
					calcExpireDate=bridge.getFullExpires();
				}
				else{
					calcNumberOfDays=365;
				}
				if(null !=bridge.getOfflineFullDays() || null !=bridge.getOfflineFullExpires()){
					offlineCalcNumberOfDays=bridge.getOfflineFullDays();
					offlineCalcExpireDate=bridge.getOfflineFullExpires();
				}
				else{
					offlineCalcNumberOfDays=365;
				}
			}
			else if(codeType==CodeType.CONCURRENCY){
				CodeTypes codeTypes=bridge.getCodeType();
				
				if(codeTypes!=null){
					redeemCodeType=codeTypes.getType();			
				}
				else{
					redeemCodeType=ApplicationConstants.REDEEM_TYPE_COMP;
				}				
				if(null !=bridge.getConcurrencyDays() || null !=bridge.getConcurrencyExpires()){
					calcNumberOfDays=bridge.getConcurrencyDays();
					calcExpireDate=bridge.getConcurrencyExpires();
				}
				else{
					calcNumberOfDays=365;
				}
				if(null !=bridge.getOfflineConcurrencyDays() || null !=bridge.getOfflineConcurrencyExpires()){
					offlineCalcNumberOfDays=bridge.getOfflineConcurrencyDays();
					offlineCalcExpireDate=bridge.getOfflineConcurrencyExpires();
				}
				else{
					offlineCalcNumberOfDays=365;
				}
			}
			return giveAccess(connectApiKey, userAccessToken, vbid, calcNumberOfDays, calcExpireDate,offlineCalcNumberOfDays,offlineCalcExpireDate,redeemCodeType);
	}

	private static AccessCodeResponseVO  giveAccess(String connectApiKey, String userAccessToken, String vbid,
			Integer numberOfDays, Date expireDate,Integer offlineNumberOfDays, Date offlineExpireDate,String redeemCodeType) throws VstException, IOException, JDOMException, ParseException {
		String code = null;
		AccessCodeResponseVO accessCodeResponseVO= new AccessCodeResponseVO();
 		//HttpGet  get1 = null;
		HttpPost post2 = null;
		HttpPost post3 = null;
		try
		{
			SAXBuilder saxBuilder = new SAXBuilder();
			HttpContext context = new BasicHttpContext();
			HttpClient httpclient = HttpClientBuilder.create().build();
			/*get1 = new HttpGet(ApiKeys.getConnectUrl(ApplicationConstants.getApiMode())+ApplicationConstants.URL_GETLICENSE+"?sku="+vbid);
			get1.setHeader(ApplicationConstants.APIKEY_HEADER, connectApiKey); //connectApiKey);
			get1.setHeader(ApplicationConstants.ACCESSSTOKEN_HEADER, userAccessToken);
			
			HttpClient httpclient = HttpClientBuilder.create().build();
			

			HttpResponse response = httpclient.execute(get1, context);

			String result = EntityUtils.toString(response.getEntity());
			
			if(response.getStatusLine().getStatusCode()!=HttpURLConnection.HTTP_OK)
			{
				throw new VstException("Connect exception " + response.getStatusLine().getStatusCode()+" "+result, ERRORS.ConnectKeyException);
			}*/
			
			//Document d = saxBuilder.build(new StringReader(result));
			
			/*boolean has_license = false;
			
			List<Element> licences = d.getRootElement().getChildren("license");
			log.info("{} Licenses from ConnectAPI", licences.size());
			
			for(Element license: licences)
			{
				String sku = license.getAttributeValue("sku");
				if(sku.equals(vbid))
				{
					String type   = license.getAttributeValue(ApplicationConstants.TYPE);
					if(type.equals(ApplicationConstants.ONLINE))
					{
						String expire = license.getAttributeValue("expiration");
						
						DateFormat simpledateformat=new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z");
						
						Date exp = simpledateformat.parse(expire);
						
						if(exp.after(new Date()))
						{
							has_license = true;
						}
						
					}
					
				}
			}*/
			
			
			/*if(!has_license)
			{*/
				Document codereqdoc = new Document();
				Element codes = new Element(ApplicationConstants.CODES);
				codes.setAttribute(ApplicationConstants.SKU,vbid);
				codes.setAttribute(ApplicationConstants.NUM_CODES, "1");
				
				//if(-1 == daysForTrial) codes.setAttribute(Constants.CONNECT_KEYS.LICENSE_TYPE,Constants.CONNECT_KEYS.PERPETUAL);
				
				
				
				/*if( null!=numberOfDays && (codeType==CodeType.TRIAL || codeType==CodeType.RENTAL)){
					numberOfDays = -1 == numberOfDays ? 365 : numberOfDays;
					numberOfDays =  0 == numberOfDays ? 30 :numberOfDays;
				}*/
				
				//TODO add condition for numberOfDays=0 and CodeType.RENTAL then give numDays as 30 or whatever new default value
				
				if(expireDate!=null) {
					Calendar cal = Calendar.getInstance();
					cal.setTime(expireDate);
					Integer year = cal.get(Calendar.YEAR);
					Integer month = cal.get(Calendar.MONTH)+1;  
					Integer day = cal.get(Calendar.DAY_OF_MONTH);					
					codes.setAttribute(ApplicationConstants.ONLINE_LICENSE_TYPE, ApplicationConstants.ABSDATE);
					//codes.setAttribute(ApplicationConstants.NUM_CODES, "1");
					codes.setAttribute(ApplicationConstants.ONLINE_EXP_YEAR, year.toString());
					codes.setAttribute(ApplicationConstants.ONLINE_EXP_MONTH, month.toString());
					codes.setAttribute(ApplicationConstants.ONLINE_EXP_DAY, day.toString());
				}
				else if (numberOfDays != null) {
					//codes.setAttribute(ApplicationConstants.LICENSE_TYPE, ApplicationConstants.NUMDAYS);
					codes.setAttribute(ApplicationConstants.ONLINE_LICENSE_TYPE,ApplicationConstants.NUMDAYS);
					//codes.setAttribute(ApplicationConstants.NUM_CODES, "1");
					//codes.setAttribute(ApplicationConstants.NUM_DAYS, numberOfDays.toString());
					codes.setAttribute(ApplicationConstants.ONLINE_NUM_DAYS, numberOfDays.toString());
				}
				else {
					throw new VstException("Invalid trial days or Expiry date",ERRORS.RequiredFieldsException);
					
				}
				if(offlineExpireDate!=null){
					Calendar calOffline = Calendar.getInstance();
					calOffline.setTime(offlineExpireDate);
					Integer offlineYear = calOffline.get(Calendar.YEAR);
					Integer offlineMonth = calOffline.get(Calendar.MONTH)+1;  
					Integer offlineDay = calOffline.get(Calendar.DAY_OF_MONTH);
					codes.setAttribute(ApplicationConstants.LICENSE_TYPE, ApplicationConstants.ABSDATE);
					codes.setAttribute(ApplicationConstants.EXP_YEAR, offlineYear.toString());
					codes.setAttribute(ApplicationConstants.EXP_MONTH, offlineMonth.toString());
					codes.setAttribute(ApplicationConstants.EXP_DAY, offlineDay.toString());
				}
				else if(offlineNumberOfDays != null){
					if(offlineNumberOfDays==0){
						codes.setAttribute(ApplicationConstants.LICENSE_TYPE, ApplicationConstants.NO_ACCESS);
					}
					else if(offlineNumberOfDays==-1){
						codes.setAttribute(ApplicationConstants.LICENSE_TYPE, ApplicationConstants.PERPETUAL);
					}
					else{
						codes.setAttribute(ApplicationConstants.LICENSE_TYPE, ApplicationConstants.NUMDAYS);
						codes.setAttribute(ApplicationConstants.NUM_DAYS, offlineNumberOfDays.toString());
					}
					
				}
				else {
					throw new VstException("Invalid offline trial days or Expiry date",ERRORS.RequiredFieldsException);
					
				}
				
				
				//if(-1 == daysForTrial) codes.setAttribute(Constants.CONNECT_KEYS.ONLINE_LICENSE_TYPE,Constants.CONNECT_KEYS.PERPETUAL);
				
				if(redeemCodeType!=null && ApplicationConstants.REDEEM_TYPE_COMP.equals(redeemCodeType)) {
					codes.setAttribute(ApplicationConstants.CODE_TYPE, ApplicationConstants.REDEEM_TYPE_COMP);
				}
				
				codereqdoc.setRootElement(codes);
				
				post2 = new HttpPost(ApiKeys.getConnectUrl(ApplicationConstants.getApiMode())+ApplicationConstants.URL_CREATECODES);
				post2.setHeader(ApplicationConstants.APIKEY_HEADER, connectApiKey);
				post2.setEntity(new ByteArrayEntity(new XMLOutputter().outputString(codereqdoc).getBytes("UTF-8")));

				log.info("No , for sku({}), so create code in ConnectAPI: {}", vbid, codes.toString());
				
				HttpResponse response2 = httpclient.execute(post2, context);
				
				String result2 = EntityUtils.toString(response2.getEntity());
				
				if(response2.getStatusLine().getStatusCode()!=HttpURLConnection.HTTP_OK)
				{
					throw new VstException("Connect exception " + response2.getStatusLine().getStatusCode()+" "+result2, ERRORS.ConnectKeyException);
				}
				
				Document d2 = saxBuilder.build(new StringReader(result2));
				
				if(d2.getRootElement().getName().equals("error-response"))
				{
					throw new VstException(d2.getRootElement().getChildText("error-text")+"; Connect exception " + response2.getStatusLine().getStatusCode()+" "+result2, ERRORS.ConnectKeyException);
				}
				
				code = d2.getRootElement().getChild(ApplicationConstants.CODE).getText();
				
				Document redemptiondoc = new Document();
				Element redemption = new Element(ApplicationConstants.REDEMPTION);
				Element redemptioncode = new Element(ApplicationConstants.CODE);
				redemptioncode.setText(code);
				redemption.addContent(redemptioncode);
				redemptiondoc.setRootElement(redemption);
				accessCodeResponseVO.setRedeemCode(code);
				accessCodeResponseVO.setExpires(getCodeExpireDate(expireDate,numberOfDays));
				post3 = new HttpPost(ApiKeys.getConnectUrl(ApplicationConstants.getApiMode())+ApplicationConstants.URL_REDEMPTIONS);
				post3.setHeader(ApplicationConstants.APIKEY_HEADER, connectApiKey);
				post3.setHeader(ApplicationConstants.ACCESSSTOKEN_HEADER, userAccessToken);
				post3.setEntity(new ByteArrayEntity(new XMLOutputter().outputString(redemptiondoc).getBytes("UTF-8")));
				
				HttpResponse response3 = httpclient.execute(post3, context);
				
				Document d3 = checkResponse(response3, connectApiKey);
				
				//String result3 = EntityUtils.toString(response3.getEntity());
				
				if(!d3.getRootElement().getName().equals("library"))
				{
					throw new VstException("Connect exception " + response3.getStatusLine().getStatusCode()+" "+d3.toString(), ERRORS.ConnectKeyException);
				}
			//}
		} finally {
			//try{get1.releaseConnection();}catch(Exception ex){}
			try{post2.releaseConnection();}catch(Exception ex){}
			try{post3.releaseConnection();}catch(Exception ex){}
		}
		
	
		return accessCodeResponseVO;
	}

	private static Date getCodeExpireDate(Date expireDate, Integer numberOfDays) {
		Date returnDate=null;
		if(expireDate!=null){
			returnDate=expireDate;
		}
		else if(numberOfDays!=null && numberOfDays>0){
			returnDate=DateUtility.addDays(numberOfDays);
		}		
		return returnDate;
		
	}
	
	public static boolean refundCode(String code, String connectApiKey) throws VstException
	{
		HttpDelete delete = null;
		
		try
		{
			String encodedRefundCode = URLEncoder.encode(code, "ISO-8859-1");
			delete = new HttpDelete(ApiKeys.getConnectUrl(ApplicationConstants.getApiMode())+ApplicationConstants.REFUND_CODE_URL+encodedRefundCode+ApplicationConstants.XML_EXTN);
			delete.setHeader(ApplicationConstants.APIKEY_HEADER, connectApiKey);
			
			HttpClient httpclient = HttpClientBuilder.create().build();
			HttpContext context = new BasicHttpContext();
			HttpResponse response = httpclient.execute(delete, context);
			if(response.getStatusLine().getStatusCode()==404)
			{
				return false;
			}
			else if(response.getStatusLine().getStatusCode()==HttpURLConnection.HTTP_OK)
			{
				return true;
			}
			return false;
		}
		catch(Exception ex)
		{
			throw new VstException("An error occured",ex, ERRORS.ConnectKeyException);
		}	
	}
	
	public static AccessCodeResponseVO giveAccess(String connectApiKey, String userAccessToken, String vbid,RedeemBookVO redeemBookVO,Bridge bridge) throws VstException, IOException, JDOMException, ParseException
	{
		Integer calcNumberOfDays=redeemBookVO.getOnlineDays();
		Date calcExpireDate=redeemBookVO.getOnlineDate();
		String redeemCodeType=redeemBookVO.getCodeType()!=null ? redeemBookVO.getCodeType() : ApplicationConstants.REDEEM_TYPE_COMP;
		Integer offlineCalcNumberOfDays=redeemBookVO.getOfflineDays();
		Date offlineCalcExpireDate=redeemBookVO.getOfflineDate();
		
		if(redeemCodeType!=null && ApplicationConstants.REDEEM_TYPE_COMP.equalsIgnoreCase(redeemCodeType)){			
			if(calcNumberOfDays==null && calcExpireDate!=null){			
				calcNumberOfDays= 30;
			}
			if(offlineCalcNumberOfDays==null && offlineCalcExpireDate==null){
				offlineCalcNumberOfDays=30;
			}
			
		}
		else if(redeemCodeType!=null && ApplicationConstants.REDEEM_TYPE_STANDARD.equalsIgnoreCase(redeemCodeType)){
			if(calcNumberOfDays==null && calcExpireDate!=null){			
				calcNumberOfDays= 365;
			}
			if(offlineCalcNumberOfDays==null && offlineCalcExpireDate==null){
				offlineCalcNumberOfDays=365;
			}
		}
		return giveAccess(connectApiKey, userAccessToken, vbid,calcNumberOfDays, calcExpireDate,offlineCalcNumberOfDays,offlineCalcExpireDate,redeemCodeType);
	}
}
