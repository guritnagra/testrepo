package com.vst.connectapi;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.http.Consts;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.XMLOutputter;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.vst.bridge.JsonUtils;
import com.vst.bridge.StringUtils;
import com.vst.bridge.VstException;
import com.vst.bridge.entity.bridge.user.BridgeUser;
import com.vst.bridge.rest.input.vo.LoginInfoVO;
import com.vst.bridge.rest.response.vo.ConnectCompanyVO;
import com.vst.bridge.rest.response.vo.SystemUserLoginResponseVO;
import com.vst.bridge.rest.response.vo.user.UserDetailsVO;
import com.vst.bridge.util.constant.ApplicationConstants;
import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;
import com.vst.connectapi.ApiKeys.API_MODE;


/**
 * Wrapper functions for interacting with ConnectAPI.
 * TODO: separate ConnectAPI into separate project
 * TODO: re-write these functions
 **/
public class ConnectApiWrapper 
{
	private static Logger log = LogManager.getLogger(ConnectApiWrapper.class);
	
	private enum HttpMethod {POST,GET,PUT,DELETE};
	
	private static Map<String,CacheObject> cache = new HashMap<String,CacheObject>();
	
	public static ConnectCredentials verifyCredentials(ApiKeys apikeys, String email, String password) throws ConnectApiException, ConnectApiHttpException
	{
		Element credentials = new Element("credentials");
		Element credential  = new Element("credential");
		credential.setAttribute("email", email);
		credential.setAttribute("password",password);
		credentials.addContent(credential);
		Document doc = new Document(credentials);
		
		Document response = callConnectApi(apikeys, HttpMethod.POST,"/v3/credentials.xml",doc);
		
		List<Element> response_children = response.getRootElement().getChildren();
		
		Element response_child = response_children.get(0);
		
		if(response_child.getName().equals("error"))
		{
			int code = Integer.valueOf(response_child.getAttributeValue("code"));
			String message = response_child.getAttributeValue("message");
			
			switch(code)
			{
				case 403:	//Response.Status.FORBIDDEN.getStatusCode()
					throw new ConnectApiException("don't have permission (could be API Key, Action permission)");
				case 992:	//StoriaUtils.XML_ERROR_CODES.PRODUCT_SKU_COULD_NOT_BE_FOUND
					throw new ConnectApiException("API user company is misconfigured (has multiple companies)");
				case 466:	//StoriaUtils.XML_ERROR_CODES.EMAIL_OR_PASSWORD_WAS_NOT_ACCEPTED
					throw new ConnectApiException("Email or password was not accepted");
				case 601:	//StoriaUtils.XML_ERROR_CODES.INVALID_ACCESS_TOKEN_REFERENCE
					throw new ConnectApiException("Invalid access token reference");
				case 603:	//StoriaUtils.XML_ERROR_CODES.INVALID_REFERENCE_VALUE
					throw new ConnectApiException("Invalid reference value");
				case 650:	//StoriaUtils.XML_ERROR_CODES.MALFORMED_CREDENTIALS_REQUEST
					throw new ConnectApiException("Malformed credentials request");
				case 901:	//StoriaUtils.XML_ERROR_CODES.MALFORMED_XML_REQUEST
					throw new ConnectApiException("Malformed XML request");
				case 900:	//StoriaUtils.XML_ERROR_CODES.INSUFFICIENT_PERMISSIONS
					throw new ConnectApiException("Insufficient permission to perform this action");
				default:
					throw new ConnectApiException("Connect returned an unexpected error: "+code+": " + message);
			}
		}
		else if(response_child.getName().equals("credential"))
		{
			String resp_guid        = response_child.getAttributeValue("guid");
			String resp_accesstoken = response_child.getAttributeValue("access-token");
			
			if(resp_guid==null||resp_guid.length()==0 || resp_accesstoken == null || resp_accesstoken.length()==0)
			{
				log.error("Connect returned an unexpected response: \n\n" + new XMLOutputter().outputString(response));
				throw new ConnectApiException("Connect returned and unexpected response: " + response_child.getName());
			}
			else
			{
				return new ConnectCredentials(resp_guid,resp_accesstoken);
			}
		}
		
		log.error("Connect returned an unexpected response: \n\n" + new XMLOutputter().outputString(response));
		throw new ConnectApiException("Connect returned and unexpected response: " + response_child.getName());
	}
	
	public static boolean checkUserExists(ApiKeys apikeys, String email) throws ConnectApiException
	{
		String encoded_email = null;
		try 
		{
			encoded_email = URLEncoder.encode(email, "ISO-8859-1");
		} 
		catch (UnsupportedEncodingException e) 
		{
			log.error("Unable to encode email address with ISO-8859-1",e);
			throw new ConnectApiException("An error occured",e);
		}
		
		try
		{
			Document response = callConnectApi(apikeys, HttpMethod.GET,"/v3/users.xml/"+encoded_email+"?full=true",null);
			
			Element response_element = response.getRootElement();
			
			if(response_element.getName().equals("user"))
			{
				String resp_email = response_element.getChildText("email");
				
				if(resp_email.equals(email))
				{
					return true;
				}
			}
			
			return false;
		}
		catch(ConnectApiHttpException e)
		{
			if(e.getCode()==HttpURLConnection.HTTP_NOT_FOUND)
			{
				//User not found;
				
				return false;
			}
			else
			{
				throw new ConnectApiException("An error occured",e);
			}
		}
	}
	
	public static ConnectUser updateReferenceId(ApiKeys apikeys, ConnectUser connectuser) throws ConnectApiXmlException, ConnectApiFieldException, ConnectApiException
	{
		try
		{
			Element user = new Element("user");
			
			user.addContent(new Element("reference").setText(ConnectApiWrapper.generateReferenceId(connectuser)));
			
			Document request = new Document(user);
			
			Document response = callConnectApi(apikeys, HttpMethod.PUT,"/v3/users.xml/"+connectuser.getEmail()+"?full=true",request,connectuser.getAccessToken());
			
			Element response_element = response.getRootElement();
			
			if(response_element.getName().equals("user"))
			{
				//user updated successfully - get the guid
				
				String resp_email       = response_element.getChildText("email");
				String resp_firstname   = response_element.getChildText("first-name");
				String resp_lastname    = response_element.getChildText("last-name");
				String resp_reference   = response_element.getChildText("reference");
				int resp_questionid     = -1;
				try{resp_questionid     = Integer.valueOf(response_element.getChildText("question-id"));}catch(Exception e){}
				String resp_answer      = response_element.getChildText("question-response");
				boolean resp_promote    = false;
				try{resp_promote        = response_element.getChildText("promote-option").equals("true");}catch(Exception e){}
				boolean resp_survey     = false;
				try{resp_survey         = response_element.getChildText("survey-option").equals("true");}catch(Exception e){}
				
				
				ConnectUser u = new ConnectUser(connectuser.getGuid(), connectuser.getAccessToken(), resp_reference, resp_email,resp_firstname,resp_lastname, resp_questionid, resp_answer, resp_promote, resp_survey);
				
				return u;
			}
			else if(response_element.getName().equals("error-response"))
			{
				String serrorcode = response_element.getChildText("error-code");
				String errortext = response_element.getChildText("error-text");
				try
				{
					int errorcode = Integer.valueOf(serrorcode);
					switch(errorcode)
					{
						case 463:// - Question is invalid
						case 464:// - Account already exists
						case 467:// - Bundle is invalid
						case 468:// - Redemption code is invalid
						case 469:// - Code has been redeemed
						case 470:// - Redemption failed
						case 482:// - Malformed create user request
						case 904:// - User reference already exists
						case 906:// - Insufficient requirements for user create
							throw new ConnectApiXmlException(errorcode,errortext);
						case 465:// - Data validation error (a more complex response which denotes field-specific errors)
							ConnectApiFieldException e = new ConnectApiFieldException(465,"Data validation error");
							List<Element> errors = response_element.getChildren("error");
							for(int i = 0; i < errors.size(); i++)
							{
								String field   = errors.get(i).getChildText("field");
								String message = errors.get(i).getChildText("message");
								
								e.addField(field, message);
							}
							throw e;
						default:
							//throw new ConnectApiException("Connect returned an unexpected error code: " + errorcode);
							log.error("Connect returned and unexpected response when creating a user: " + serrorcode + " : " +errortext);
							throw new ConnectApiXmlException(errorcode,errortext);
					}
				}
				catch(NumberFormatException e)
				{
					log.error("Connect returned and unexpected response when creating a user: " + serrorcode + " : " +errortext);
					throw new ConnectApiException("An error occured",e);
				}
			}
			else
			{
				log.error("Connect returned an unexpected response: \n\n" + new XMLOutputter().outputString(response));
				throw new ConnectApiException("Connect returned and unexpected response: " + response_element.getName());
			}
		}
		catch(ConnectApiXmlException e)
		{
			throw e;
		}
		catch(ConnectApiFieldException e)
		{
			throw e;
		}
		catch(Exception e)
		{
			throw new ConnectApiException("An error occured",e);
		}
	}
	
	public static ConnectUser updateUser(ApiKeys apikeys, BridgeUser bridgeUser,UserDetailsVO userDetailsVO) throws ConnectApiXmlException, ConnectApiFieldException, ConnectApiException
	{
		try
		{
			Element user = new Element("user");
			
			user.addContent(new Element("email").setText(userDetailsVO.getEmail()));
			if(userDetailsVO.getPassword()!=null)
					user.addContent(new Element("password").setText(userDetailsVO.getPassword()));
			user.addContent(new Element("first-name").setText(userDetailsVO.getFirstName()));
			user.addContent(new Element("last-name").setText(userDetailsVO.getLastName()));
			user.addContent(new Element("question-id").setText(userDetailsVO.getQuestionId()+""));
			user.addContent(new Element("question-response").setText(userDetailsVO.getQuestionResponse()));
			user.addContent(new Element("promote-option").setText(StringUtils.booleanToOneOrZero(userDetailsVO.getPromotionSubscription())));
			user.addContent(new Element("survey-option").setText(StringUtils.booleanToOneOrZero(userDetailsVO.getSurveySubscription())));
			
			Document request = new Document(user);
			
			log.debug("updateUser : " + new XMLOutputter().outputString(request));
			
			Document response = callConnectApi(apikeys, HttpMethod.PUT,"/v3/users.xml/"+bridgeUser.getEmail()+"?full=true",request,bridgeUser.getAccessToken());
			
			Element response_element = response.getRootElement();
			
			if(response_element.getName().equals("user"))
			{
				//user updated successfully - get the guid
				
				String resp_email       = response_element.getChildText("email");
				String resp_firstname   = response_element.getChildText("first-name");
				String resp_lastname    = response_element.getChildText("last-name");
				String resp_reference   = response_element.getChildText("reference");
				int resp_questionid     = -1;
				try{resp_questionid     = Integer.valueOf(response_element.getChildText("question-id"));}catch(Exception e){}
				String resp_answer      = response_element.getChildText("question-response");
				boolean resp_promote    = false;
				try{resp_promote        = response_element.getChildText("promote-option").equals("true");}catch(Exception e){}
				boolean resp_survey     = false;
				try{resp_survey         = response_element.getChildText("survey-option").equals("true");}catch(Exception e){}
				
				
				ConnectUser u = new ConnectUser(bridgeUser.getGuid(), bridgeUser.getAccessToken(), resp_reference, resp_email,resp_firstname,resp_lastname, resp_questionid, resp_answer, resp_promote, resp_survey);
				
				//ConnectUser u = new ConnectUser(connectuser.getEmail(), connectuser.getAccessToken(), resp_reference, resp_email,resp_firstname,resp_lastname);
				
				return u;
			}
			else if(response_element.getName().equals("error-response"))
			{
				String serrorcode = response_element.getChildText("error-code");
				String errortext = response_element.getChildText("error-text");
				try
				{
					int errorcode = Integer.valueOf(serrorcode);
					switch(errorcode)
					{
						case 463:// - Question is invalid
						case 464:// - Account already exists
						case 467:// - Bundle is invalid
						case 468:// - Redemption code is invalid
						case 469:// - Code has been redeemed
						case 470:// - Redemption failed
						case 482:// - Malformed create user request
						case 904:// - User reference already exists
						case 906:// - Insufficient requirements for user create
							throw new ConnectApiXmlException(errorcode,errortext);
						case 465:// - Data validation error (a more complex response which denotes field-specific errors)
							ConnectApiFieldException e = new ConnectApiFieldException(465,"Data validation error");
							
							List<Element> errors = response_element.getChildren("error");
							for(int i = 0; i < errors.size(); i++)
							{
								String field   = errors.get(i).getChildText("field");
								String message = errors.get(i).getChildText("message");
								
								e.addField(field, message);
							}
							throw e;
						default:
							//throw new ConnectApiException("Connect returned an unexpected error code: " + errorcode);
							log.error("Connect returned and unexpected response when creating a user: " + serrorcode + " : " +errortext);
							throw new ConnectApiXmlException(errorcode,errortext);
					}
				}
				catch(NumberFormatException e)
				{
					log.error("Connect returned and unexpected response when creating a user: " + serrorcode + " : " +errortext);
					throw new ConnectApiException("An error occured",e);
				}
			}
			else
			{
				log.error("Connect returned an unexpected response: \n\n" + new XMLOutputter().outputString(response));
				throw new ConnectApiException("Connect returned and unexpected response: " + response_element.getName());
			}
		}
		catch(ConnectApiXmlException e)
		{
			throw e;
		}
		catch(ConnectApiFieldException e)
		{
			throw e;
		}
		catch(Exception e)
		{
			throw new ConnectApiException("An error occured",e);
		}
	}
	public static ConnectUser getUser(ApiKeys apikeys, String guid, String accesstoken, Boolean isFull) throws ConnectApiException
	{
		if(null == guid){
			log.error("Empty guid detected");
			return null;
		}
		String encoded_guid = null;		
		
		try 
		{
			encoded_guid = URLEncoder.encode(guid, "ISO-8859-1");
		} 
		catch (UnsupportedEncodingException e) 
		{
			log.error("Unable to encode email address with ISO-8859-1",e);
			throw new ConnectApiException("An error occured",e);
		}
		try
		{
			String url="/v3/users.xml/"+encoded_guid;
			if(isFull)
				url =url.concat("?full=true");
			Document response = callConnectApi(apikeys, HttpMethod.GET,url,null);
		
			Element response_element = response.getRootElement();
			
			if(response_element.getName().equals("user"))
			{
				String resp_email = response_element.getChildText("email");
				String resp_firstname = response_element.getChildText("first-name");
				String resp_lastname = response_element.getChildText("last-name");
				String resp_reference = response_element.getChildText("reference");
				
				int resp_questionid     = -1;
				try{resp_questionid     = Integer.valueOf(response_element.getChildText("question-id"));}catch(Exception e){}
				String resp_answer      = response_element.getChildText("question-response");
				boolean resp_promote    = false;
				try{resp_promote        = response_element.getChildText("promote-option").equals("true");}catch(Exception e){}
				boolean resp_survey     = false;
				try{resp_survey         = response_element.getChildText("survey-option").equals("true");}catch(Exception e){}
				
				
				ConnectUser u = new ConnectUser(guid, accesstoken, resp_reference, resp_email,resp_firstname,resp_lastname, resp_questionid, resp_answer, resp_promote, resp_survey);
				
				//ConnectUser u = new ConnectUser(guid, accesstoken, resp_reference,resp_email,resp_firstname,resp_lastname);
				
				return u;
			}
			
			//throw new ConnectApiError("User not found",HttpURLConnection.HTTP_NOT_FOUND);
			return null;
		}
		catch(ConnectApiHttpException e)
		{
			if(e.getCode()==HttpURLConnection.HTTP_NOT_FOUND)
			{
				//User not found;
				
				return null;
			}
			else
			{
				throw new ConnectApiException("An error occured",e);
			}
		}
	}
	/*
	public static ConnectUser getUserByEmail(ApiKeys apikeys, String email) throws ConnectApiException
	{
		String encoded_email = null;
		try 
		{
			encoded_email = URLEncoder.encode(email, "ISO-8859-1");
		} 
		catch (UnsupportedEncodingException e) 
		{
			log.error("Unable to encode email address with ISO-8859-1",e);
			throw new ConnectApiException("An error occured",e);
		}
		try
		{
			Document response = callConnectApi(apikeys, HttpMethod.GET,"/v3/users.xml/"+encoded_email+"?full=true",null);
		
			Element response_element = response.getRootElement();
			
			if(response_element.getName().equals("user"))
			{
				String resp_email = response_element.getChildText("email");
				String resp_firstname = response_element.getChildText("first-name");
				String resp_lastname = response_element.getChildText("last-name");
				String resp_reference = response_element.getChildText("reference");
				
				int resp_questionid     = -1;
				try{resp_questionid     = Integer.valueOf(response_element.getChildText("question-id"));}catch(Exception e){}
				String resp_answer      = response_element.getChildText("question-response");
				boolean resp_promote    = false;
				try{resp_promote        = response_element.getChildText("promote-option").equals("true");}catch(Exception e){}
				boolean resp_survey     = false;
				try{resp_survey         = response_element.getChildText("survey-option").equals("true");}catch(Exception e){}
				
				
				ConnectUser u = new ConnectUser(guid, accesstoken, resp_reference, resp_email,resp_firstname,resp_lastname, resp_questionid, resp_answer, resp_promote, resp_survey);
				
				//ConnectUser u = new ConnectUser(guid, accesstoken, resp_reference,resp_email,resp_firstname,resp_lastname);
				
				return u;
			}
			
			//throw new ConnectApiError("User not found",HttpURLConnection.HTTP_NOT_FOUND);
			return null;
		}
		catch(ConnectApiHttpException e)
		{
			if(e.getCode()==HttpURLConnection.HTTP_NOT_FOUND)
			{
				//User not found;
				
				return null;
			}
			else
			{
				throw new ConnectApiException("An error occured",e);
			}
		}
	}
	*/
	
	public static ConnectUserInfo getUserInfo(ApiKeys apikeys, String email) throws ConnectApiException
	{
		String encoded_email = null;
		try 
		{
			encoded_email = URLEncoder.encode(email, "ISO-8859-1");
		} 
		catch (UnsupportedEncodingException e) 
		{
			log.error("Unable to encode email address with ISO-8859-1",e);
			throw new ConnectApiException("An error occured",e);
		}
		try
		{
			Document response = callConnectApi(apikeys, HttpMethod.GET,"/v3/users.xml/"+encoded_email,null);
		
			Element response_element = response.getRootElement();
			
			if(response_element.getName().equals("user"))
			{
				String resp_email = response_element.getChildText("email");
				String resp_firstname = response_element.getChildText("first-name");
				String resp_lastname = response_element.getChildText("last-name");
					
				ConnectUserInfo u = new ConnectUserInfo(resp_email,resp_firstname,resp_lastname);
				
				return u;
			}
			
			//throw new ConnectApiError("User not found",HttpURLConnection.HTTP_NOT_FOUND);
			return null;
		}
		catch(ConnectApiHttpException e)
		{
			if(e.getCode()==HttpURLConnection.HTTP_NOT_FOUND)
			{
				//User not found;
				
				return null;
			}
			else
			{
				throw new ConnectApiException("An error occured",e);
			}
		}
	}

	public static ConnectUserInfo getUserInfoWithGuid(ApiKeys apikeys, String email) throws ConnectApiException
	{
		String encoded_email = null;
		try 
		{
			encoded_email = URLEncoder.encode(email, "ISO-8859-1");
		} 
		catch (UnsupportedEncodingException e) 
		{
			log.error("Unable to encode email address with ISO-8859-1",e);
			throw new ConnectApiException("An error occured",e);
		}
		try
		{
			Document response = callConnectApi(apikeys, HttpMethod.GET,"/v3/users.xml/"+encoded_email,null);
		
			Element response_element = response.getRootElement();
			
			if(response_element.getName().equals("user"))
			{
				String resp_email = response_element.getChildText("email");
				String resp_firstname = response_element.getChildText("first-name");
				String resp_lastname = response_element.getChildText("last-name");
					
				ConnectUserInfo u = new ConnectUserInfo(resp_email,resp_firstname,resp_lastname);
				
				return u;
			}
			
			//throw new ConnectApiError("User not found",HttpURLConnection.HTTP_NOT_FOUND);
			return null;
		}
		catch(ConnectApiHttpException e)
		{
			if(e.getCode()==HttpURLConnection.HTTP_NOT_FOUND)
			{
				//User not found;
				
				return null;
			}
			else
			{
				throw new ConnectApiException("An error occured",e);
			}
		}
	}

	public static ConnectUser addUser(ApiKeys apikeys,UserDetailsVO userDetailsVO,Boolean isReferenceUser) throws ConnectApiException, ConnectApiXmlException, ConnectApiFieldException 
	{
		try
		{
			Element user = new Element("user");
			
			
			String firstName = userDetailsVO.getFirstName();
			if(org.apache.commons.lang.StringUtils.isNotBlank(firstName)){
				user.addContent(new Element("first-name").setText(org.apache.commons.lang.StringUtils.capitalize(firstName.toLowerCase())));
			}
			
			String lastName = userDetailsVO.getLastName();
			if(org.apache.commons.lang.StringUtils.isNotBlank(lastName)){
				user.addContent(new Element("last-name").setText(org.apache.commons.lang.StringUtils.capitalize(lastName.toLowerCase())));
			}
			
			String email = userDetailsVO.getEmail();
			
			if(null != isReferenceUser && isReferenceUser){
				
				user.addContent(new Element("reference").setText(email));
				
			}else{

				if(org.apache.commons.lang.StringUtils.isNotBlank(email)){
					user.addContent(new Element("email").setText(email.toLowerCase()));
				}
				
				String password = userDetailsVO.getPassword();
				if(org.apache.commons.lang.StringUtils.isNotBlank(password)){
					user.addContent(new Element("password").setText(password));
				}
				
				Integer questionId = userDetailsVO.getQuestionId();
				if(questionId != null && questionId > 0){
					user.addContent(new Element("question-id").setText(questionId.toString()));
				}
				
				String questionResponse = userDetailsVO.getQuestionResponse();
				if(org.apache.commons.lang.StringUtils.isNotBlank(questionResponse)){
					user.addContent(new Element("question-response").setText(questionResponse));
				}
				
				Boolean promotioSubscription = userDetailsVO.getPromotionSubscription();
				if(null != promotioSubscription){
					user.addContent(new Element("promote-option").setText(StringUtils.booleanToOneOrZero(promotioSubscription)));
				}
				
				Boolean surveySubscription = userDetailsVO.getPromotionSubscription();
				if(null != surveySubscription){
					user.addContent(new Element("survey-option").setText(StringUtils.booleanToOneOrZero(surveySubscription)));
				}
				
			}
			
			
			
			
			
			Document request = new Document(user);
			
			Document response = callConnectApi(apikeys, HttpMethod.POST,"/v3/users.xml",request);
			
			Element response_element = response.getRootElement();
			
			if(response_element.getName().equals("user"))
			{
				//user created successfully - get the guid
				
				String resp_email       = response_element.getChildText("email");
				String resp_firstname   = response_element.getChildText("first-name");
				String resp_lastname    = response_element.getChildText("last-name");
				String resp_guid        = response_element.getChildText("guid");
				String resp_accesstoken = response_element.getChildText("access-token");
				String resp_reference   = response_element.getChildText("reference");
				
				int resp_questionid     = -1;
				try{resp_questionid     = Integer.valueOf(response_element.getChildText("question-id"));}catch(Exception e){}
				String resp_answer      = response_element.getChildText("question-response");
				boolean resp_promote    = false;
				try{resp_promote        = response_element.getChildText("promote-option").equals("true");}catch(Exception e){}
				boolean resp_survey     = false;
				try{resp_survey         = response_element.getChildText("survey-option").equals("true");}catch(Exception e){}
				
				
				ConnectUser u = new ConnectUser(resp_guid, resp_accesstoken, resp_reference, resp_email,resp_firstname,resp_lastname, resp_questionid, resp_answer, resp_promote, resp_survey);
					
				//ConnectUser u = new ConnectUser(resp_guid,resp_accesstoken,resp_reference,resp_email,resp_firstname,resp_lastname);
				
				return u;
			}
			else if(response_element.getName().equals("error-response"))
			{
				String serrorcode = response_element.getChildText("error-code");
				String errortext = response_element.getChildText("error-text");
				try
				{
					int errorcode = Integer.valueOf(serrorcode);
					switch(errorcode)
					{
						case 463:// - Question is invalid
						case 464:// - Account already exists
							throw new BridgeException(ApplicationCode.USER_ALREADY_EXIST);
						case 467:// - Bundle is invalid
						case 468:// - Redemption code is invalid
						case 469:// - Code has been redeemed
						case 470:// - Redemption failed
						case 482:// - Malformed create user request
						case 904:// - User reference already exists
						case 906:// - Insufficient requirements for user create
							throw new ConnectApiXmlException(errorcode,errortext);
						case 465:// - Data validation error (a more complex response which denotes field-specific errors)
							ConnectApiFieldException e = new ConnectApiFieldException(465,"Data validation error");
							
							List<Element> errors = response_element.getChildren("error");
							for(int i = 0; i < errors.size(); i++)
							{
								String field   = errors.get(i).getChildText("field");
								String message = errors.get(i).getChildText("message");
								
								e.addField(field, message);
							}
							throw e;
						default:
							//throw new ConnectApiException("Connect returned an unexpected error code: " + errorcode);
							log.error("Connect returned and unexpected response when creating a user: " + serrorcode + " : " +errortext);
							throw new ConnectApiXmlException(errorcode,errortext);
					}
				}
				catch(NumberFormatException e)
				{
					log.error("Connect returned and unexpected response when creating a user: " + serrorcode + " : " +errortext);
					throw new ConnectApiException("An error occured",e);
				}
			}
			else
			{
				log.error("Connect returned an unexpected response: \n\n" + new XMLOutputter().outputString(response));
				throw new ConnectApiException("Connect returned and unexpected response: " + response_element.getName());
			}
		}
		catch(BridgeException e){
			throw e;
		}
		catch(ConnectApiXmlException e)
		{
			throw e;
		}
		catch(ConnectApiFieldException e)
		{
			throw e;
		}
		catch(Exception e)
		{
			throw new ConnectApiException("An error occured",e);
		}
		
		
	}
	
	public static List<ConnectBook> getBooks(ApiKeys apikeys, String guid) throws ConnectApiException, ConnectApiXmlException
	{
		try
		{
			Document response = callConnectApi(apikeys, HttpMethod.GET,"/v3/products/available.xml",null,true);
			
			Element response_element = response.getRootElement();

			if(response_element.getName().equals("products"))
			{
				List<ConnectBook> books = new ArrayList<ConnectBook>();
				List<Element> products_children = response_element.getChildren();
				for(Element product : products_children)
				{
					if(!product.getName().equals("product")) {
						continue;
					}

					final String name          = product.getAttributeValue("name");
					final String authorname    = product.getAttributeValue("author-name");
					final String sku           = product.getAttributeValue("sku");
					String isbn = null;
					 isbn = cleanString(product.getAttributeValue("eisbn"));
					if(isbn == null){
						isbn = cleanString(product.getAttributeValue("isbn13"));
					}
					
					final String printisbn     = cleanString(product.getAttributeValue("print-isbn"));
					final String description   = product.getAttributeValue("description");
					
					final String coverimageurl = product.getAttributeValue("cover-image-url");
				
					final String edition 	   = product.getAttributeValue("edition");
					final String subject	   = null; //NYI, use bisac
					final String type=product.getAttributeValue("type");
					if(null != sku && "Rental".equals(type)){
						continue;
					}
		//			if(!isEncoded(description)){
						final ConnectBook b = new ConnectBook(sku, name, printisbn, isbn, authorname, description, coverimageurl, edition, subject,null,null,null,null);
						books.add(b);
	//				}
					
				}

				return books;
			}
			else if(response_element.getName().equals("error-response"))
			{
				String serrorcode = response_element.getChildText("error-code");
				String errortext = response_element.getChildText("error-text");
				
				throw new ConnectApiXmlException(Integer.valueOf(serrorcode),errortext);
				//throw new ConnectApiXmlException(Response.Status.BAD_REQUEST.getStatusCode(),errortext);
				
			}
			else
			{
				log.error("Connect returned an unexpected response: \n\n" + new XMLOutputter().outputString(response));
				throw new ConnectApiException("Connect returned and unexpected response: " + response_element.getName());
			}
			
		}
		catch(ConnectApiHttpException e)
		{
			//throw new ConnectApiException("An error occured",e);
			throw new BridgeException(ApplicationCode.INVALID_BRIDGE_KEY);
		}
	}
	
	
	
	public static Document getBooksFromCatalog(ApiKeys apikeys, Integer pageNo, Integer itemsPerPage) throws ConnectApiException, ConnectApiXmlException, ConnectApiHttpException{
		
		//Document response = callConnectApi(apikeys, HttpMethod.POST,"/v3/catalog",null,true);
		 Document document = null;
		 HttpClient httpClient = HttpClientBuilder.create().build();
		 String url = apikeys.getConnectUrl()+"/v3/catalog";
		 HttpPost httppost = new HttpPost(url);
		 String inputXML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
		 										+ "<catalog> "
		 										+ "	<page>"+pageNo+"</page> "
		 										+ "	<per-page>"+itemsPerPage+"</per-page> "
		 										+ "	<updated>ge 20051001</updated> "
		 										+ "	<created>ge 20050101</created> "
		 										+ "	<include-packages>FALSE</include-packages> "
		 										+ "</catalog>";
		 StringEntity entity = new StringEntity(inputXML, ContentType.create("text/xml", Consts.UTF_8));
		 entity.setChunked(true);
		 httppost.setEntity(entity);
		 httppost.setHeader("X-VitalSource-API-Key",apikeys.getConnectKey());
	
		 HttpResponse response;
			try {
				response = httpClient.execute(httppost);
				  final int statusCode = response.getStatusLine().getStatusCode();
				  if(statusCode != 200){
					   throw new ConnectApiHttpException(statusCode, "Error calling catalog");
				  }
				   String responseJson = ConnectApiWrapper.getResponseAsString(response);	
				   responseJson=stripNonValidXMLCharacters(responseJson);
				   SAXBuilder sxb = new SAXBuilder();
				   document = sxb.build(new StringReader(responseJson));
			} catch (IOException e) {
				e.printStackTrace();
			} catch (JDOMException e) {
				e.printStackTrace();
			}
			   return document;
		
	}
			   
	private static String stripNonValidXMLCharacters(String in) {
        StringBuffer out = new StringBuffer(); 
        char current; 
        if (in == null || ("".equals(in))) return ""; 
        for (int i = 0; i < in.length(); i++) {
            current = in.charAt(i);
            if(current==0x00A0)
            	current=0x0020;
            if ((current == 0x9) ||
                (current == 0xA) ||
                (current == 0xD) ||
                ((current >= 0x20) && (current <= 0xD7FF)) ||
                ((current >= 0xE000) && (current <= 0xFFFD)) ||
                ((current >= 0x10000) && (current <= 0x10FFFF)))
                out.append(current);
        }
        return out.toString();
    }	
		

	public static String getResponseAsString(final HttpResponse httpResponse) {
		final String exceptionMsg = "Failed to read response ";
		String responseStr = "";
		try {
			final BufferedReader br = new BufferedReader(new InputStreamReader((httpResponse.getEntity().getContent()),"UTF-8"));
			String output;
			final StringWriter obj = new StringWriter();
			while ((output = br.readLine()) != null) {
				obj.append(output);
			}
			responseStr = obj.toString();
		} catch (final IllegalStateException e) {
			throw new BridgeException(exceptionMsg, ApplicationCode.UNEXPECTED_ERROR, e);
		} catch (final IOException e) {
			throw new BridgeException(exceptionMsg, ApplicationCode.UNEXPECTED_ERROR, e);
		}
		return responseStr;
	}
	
	
	public static boolean isEncoded(String text){
	    Charset charset = Charset.forName("US-ASCII");
	    String checked=new String(text.getBytes(charset),charset);
	    return !checked.equals(text);

	}
/*	
	public static ConnectBook getBook(ApiKeys apikeys, String guid, String vbid) throws ConnectApiException, ConnectApiXmlException, VstException
	{
		try
		{
			Document response = callConnectApi(apikeys, HttpMethod.GET,"/v3/products/available.xml",null,true);
			
			Element response_element = response.getRootElement();
			
			if(response_element.getName().equals("products"))
			{
				List<Element> products_children = response_element.getChildren();
				for(Element product : products_children)
				{
					if(!product.getName().equals("product")) {
						continue;
					}
						
					final String sku           = product.getAttributeValue("sku");
					
					if(sku.equalsIgnoreCase(vbid))
					{
						final String name          = product.getAttributeValue("name");
						final String authorname    = product.getAttributeValue("author-name");
						
						//String isbn          = cleanString(product.getAttributeValue("eisbn"));
						String isbn = null;
						 isbn= cleanString(product.getAttributeValue("eisbn"));
						if(isbn == null){
							isbn = cleanString(product.getAttributeValue("isbn13"));
						}
						final String printisbn     = cleanString(product.getAttributeValue("print-isbn"));
						final String description   = product.getAttributeValue("description");
						final String coverimageurl = product.getAttributeValue("cover-image-url");
						final String edition 	   = product.getAttributeValue("edition");
						final String subject	   = null; //NYI, use bisac

						return new ConnectBook(sku, name, printisbn, isbn, authorname, description, coverimageurl, edition, subject);
					}
					
				}
				throw new VstException(vbid+" not found", ERRORS.BookNotFoundException);
			}
			else if(response_element.getName().equals("error-response"))
			{
				String serrorcode = response_element.getChildText("error-code");
				String errortext = response_element.getChildText("error-text");
				
				throw new ConnectApiXmlException(Integer.valueOf(serrorcode),errortext);
			}
			else
			{
				log.error("Connect returned an unexpected response: \n\n" + new XMLOutputter().outputString(response));
				throw new ConnectApiException("Connect returned and unexpected response: " + response_element.getName());
			}
			
		}
		catch(ConnectApiHttpException e)
		{
			throw new ConnectApiException("An error occured",e);
		}
		
		
		
		try
		{
			Document response = callConnectApi(apikeys, HttpMethod.GET,"/v3/products/"+vbid,null);
			
			Element response_element = response.getRootElement();
			
			if(response_element.getName().equals("product"))
			{
				Element product      = response_element;
				
				String name          = product.getChildText("title");
				String authorname    = product.getChildText("author");
				//String listprice     = product.getChildText("list-price");
				//String publisher     = product.getChildText("publisher");
				String sku           = vbid;//product.getChildText("sku");
				String isbn          = product.getChildText("isbn13");
				String printisbn     = product.getChildText("print-isbn");
				String description   = product.getChildText("description");
				String coverimageurl = product.getChildText("icon-url");
				//String printdrmtext  = product.getChildText("print-drm-text");
				//String copydrmtext   = product.getChildText("copy-drm-text");
				//String edition       = product.getChildText("edition");
				
				
				
				ConnectBook b = new ConnectBook(name, authorname, isbn, printisbn, sku, description, coverimageurl );
				return b;
			}
			else if(response_element.getName().equals("error-response"))
			{
				String serrorcode = response_element.getChildText("error-code");
				String errortext = response_element.getChildText("error-text");
				
				throw new ConnectApiXmlException(Integer.valueOf(serrorcode),errortext);
			}
			else
			{
				log.error("Connect returned an unexpected response: \n\n" + new XMLOutputter().outputString(response));
				throw new ConnectApiException("Connect returned and unexpected response: " + response_element.getName());
			}
			
		}
		catch(ConnectApiHttpException e)
		{
			throw new ConnectApiException("An error occured",e);
		}
	}*/
	
	public static Map<String, List<ConnectLicense>> getLicenses(ApiKeys apikeys, String accesstoken,String vbid) throws ConnectApiException
	{
		try
		{
			
			String url = "/v3/licenses.xml?license_type=online";
			
			if(org.apache.commons.lang.StringUtils.isNotBlank(vbid)){
				url += "&sku="+vbid;
			}
						
			Document response = callConnectApi(apikeys, HttpMethod.GET,url,null,accesstoken);
			
			Element response_element = response.getRootElement();
			
			Map<String, List<ConnectLicense>> licenses = new HashMap<String, List<ConnectLicense>>();
			
			if(response_element.getName().equals("licenses"))
			{
			
				List<Element> products_children = response_element.getChildren();
				for(Element product : products_children) {
					if(!product.getName().equals("license")) {
						continue;
					}
					
					String sku = product.getAttributeValue("sku");
					String type = product.getAttributeValue("type");
					String name = product.getAttributeValue("name");
					String expiration = product.getAttributeValue("expiration");
					String publisher = product.getAttributeValue("publisher");
					String useCode = product.getAttributeValue("code-use");

					ConnectLicense lic = new ConnectLicense(type, sku, name, expiration, publisher, useCode);
					
					//TODO: replace with map.putIfAbsent() in Java8
					if(licenses.get(sku)==null) {
						licenses.put(sku, new ArrayList<ConnectLicense>());
					}
					licenses.get(sku).add(lic);
				}
			}
			else if(response_element.getName().equals("error-response"))
			{
				String serrorcode = response_element.getChildText("error-code");
				String errortext = response_element.getChildText("error-text");
				
				throw new ConnectApiXmlException(Integer.valueOf(serrorcode),errortext);
			}
			return licenses;
		}
		catch(ConnectApiHttpException e)
		{
			throw new ConnectApiException("An error occured",e);
		} 
		catch (ConnectApiXmlException e) 
		{
			throw new ConnectApiException("An error occured",e);
		}
	}
	
/*	public static List<ConnectLicense> getLicenses(ApiKeys apikeys, String accesstoken,String vbid) throws ConnectApiException, ConnectApiHttpException, NumberFormatException, ConnectApiXmlException
	{
		//try {
			Document response = callConnectApi(apikeys, HttpMethod.GET,"/v3/licenses.xml?license_type=online&sku="+vbid,null,accesstoken);
			
			Element response_element = response.getRootElement();
			
			ArrayList<ConnectLicense> licenses = new ArrayList<ConnectLicense>();
			
			if(response_element.getName().equals("licenses"))
			{
			
				List<Element> products_children = response_element.getChildren();
				for(Element product : products_children)
				{
					if(!product.getName().equals("license")) {
						continue;
					}
						
					final String sku = vbid;//product.getAttributeValue("sku");
					final String type = product.getAttributeValue("type");
					final String name = product.getAttributeValue("name");
					final String expiration = product.getAttributeValue("expiration");
					final String publisher = product.getAttributeValue("publisher");
					final String useCode = product.getAttributeValue("code-use");
					
					ConnectLicense lic = new ConnectLicense(type, sku, name, expiration, publisher, useCode);
					
					licenses.add(lic);
				}
			}
			else if(response_element.getName().equals("error-response"))
			{
				String serrorcode = response_element.getChildText("error-code");
				String errortext = response_element.getChildText("error-text");
				
				throw new ConnectApiXmlException(Integer.valueOf(serrorcode),errortext);
			}
			return licenses;
			}
		catch(ConnectApiHttpException e)
		{
			throw new ConnectApiException("An error occured",e);
		} 
		catch (ConnectApiXmlException e) 
		{
			throw new ConnectApiException("An error occured",e);
		}
	}*/
	
	
	private static Document callConnectApi(ApiKeys apikeys, HttpMethod method, String path, Document requestbody) throws ConnectApiException, ConnectApiHttpException
	{
		return callConnectApi(apikeys, method, path, requestbody,null, false);
	}
	
	private static Document callConnectApi(ApiKeys apikeys, HttpMethod method, String path, Document requestbody,String accesstoken) throws ConnectApiException, ConnectApiHttpException
	{
		return callConnectApi(apikeys, method, path, requestbody,accesstoken, false);
	}
	
	private static Document callConnectApi(ApiKeys apikeys, HttpMethod method, String path, Document requestbody, boolean allowcache) throws ConnectApiException, ConnectApiHttpException
	{
		return callConnectApi(apikeys, method, path, requestbody,null, allowcache);
	}
	
	private static Document callConnectApi(ApiKeys apikeys, HttpMethod method, String path, Document requestbody, String accesstoken, boolean allowcache) throws ConnectApiException, ConnectApiHttpException
	{
		log.debug("callConnectApi(accessKey:{}-url:{}, method:{}, path:{}, request:{}, accessToken:{}, cache:s{})", apikeys.getConnectKey(), apikeys.getConnectUrl(), method, path, requestbody, accesstoken, allowcache);
		InputStreamReader resultStream = null;
		DataOutputStream dataStream = null;
		try
		{
			log.debug("Connect->"+method.toString()+": "+apikeys.getConnectUrl()+path);
			
			URL serviceURL = new URL( apikeys.getConnectUrl()+path );
		    HttpURLConnection connection = ( HttpURLConnection ) serviceURL.openConnection( );
		    connection.setRequestMethod( method.toString() );
		    connection.setRequestProperty( "Content-Type", "application/xml" );
		    connection.setRequestProperty( "X-VitalSource-API-Key", apikeys.getConnectKey() );
		    if(accesstoken!=null)
		    {
		    	connection.setRequestProperty( "X-VitalSource-Access-Token", accesstoken );
		    }
		    String cache_key = method.toString()+"_"+apikeys.getConnectUrl()+path+"_"+apikeys.getConnectKey()+"_"+accesstoken;
		    CacheObject co = cache.get(cache_key);
		    if(allowcache && co!=null)
		    {
	    		connection.setRequestProperty("If-None-Match", co.getEtag());
		    }
		    
		    connection.setUseCaches( false );
		    connection.setDoInput( true );
		    if(method==HttpMethod.POST || method.equals(HttpMethod.PUT))
		    {
		    	connection.setDoOutput( true );
		    	dataStream = new DataOutputStream ( connection.getOutputStream () );
			    try
			    {
			    	String body = new XMLOutputter().outputString(requestbody);
			    	dataStream.write( body.getBytes() );
			    }
			    finally
			    {
			      dataStream.close();
			    }
		    }
		    else
		    {
		    	connection.setDoOutput( false );
		    }
		    
		    
		    connection.connect();
		    
		    String resp = null;
		    
		    if(allowcache && connection.getResponseCode()==HttpURLConnection.HTTP_NOT_MODIFIED)
		    {
		    	//Use the cached version
		    	
		    	resp = co.getData();
		    	log.debug("Books from cache");
		    	
		    }
		    else if(connection.getResponseCode()!=HttpURLConnection.HTTP_OK)
		    {
		    	if(co!=null)
		    	{
		    		resp = co.getData();
		    		log.debug("Connect threw a Response.Status.INTERNAL_SERVER_ERROR, returning books from cache");
		    	}
		    	else
		    	{
		    		throw new ConnectApiHttpException(connection.getResponseCode(),connection.getResponseMessage());
		    	}
		    }
		    else
		    {
		    	
		    	
			    // get the encoding if possible from response
			    // TODO: more work needed here around HTTP response code (handling not 201 values)
			    resultStream = new InputStreamReader( new BufferedInputStream( connection.getInputStream () ), "UTF-8" );
			    StringBuilder result = new StringBuilder( );
			    char[ ] readChars= new char[ 512 ];
			    int numCharsRead = resultStream.read( readChars );
			    while ( numCharsRead != -1 /*eof*/ )
			    {
			    	result.append( Arrays.copyOf( readChars, numCharsRead ) );
			    	numCharsRead = resultStream.read( readChars );
			    }
			    try{resultStream.close();}catch(Exception ex){}
			    
			    resp = result.toString();
			    if(allowcache)
			    {
				    String newEtag = connection.getHeaderField("ETag");
			    	if(newEtag!=null)
			    	{
			    		cache.put(cache_key,new CacheObject(newEtag,resp));
			    	}
			    }
			    log.debug(resp);
		    }
		    
		    
		    
		    SAXBuilder sxb = new SAXBuilder();
		    return sxb.build(new StringReader(resp));
		}
		catch(JDOMException ex)
		{
			log.error("Connect call failed: "+ex.getMessage(),ex);
			throw new ConnectApiException("Unable to parse Bookshelf data",ex);
			
		}
		catch(IOException ex)
		{
			log.error("Connect call failed: "+ex.getMessage(),ex);
			throw new ConnectApiException("Unable to communicate with Bookshelf",ex);
		}
		finally
	    {
	      try{dataStream.close();}catch(Exception ex){}
	      try{resultStream.close();}catch(Exception ex){}
	    }
	
	}
	
	public static String cleanString(String str)
	{
		if(str==null||str.trim().length()==0)
		{
			return null;
		}
		return str.trim();
	}
	
	public static class ConnectApiException extends Exception
	{
		private static final long serialVersionUID = 8641253634148719408L;

		public ConnectApiException(String message)
		{
			super(message);
		}
		public ConnectApiException(String message,Exception ex)
		{
			super(message,ex);
		}
	}
	
	public static class ConnectApiHttpException extends Exception
	{
		private static final long serialVersionUID = 1L;
		private int code;
		
		public ConnectApiHttpException(int code, String message)
		{
			super(message);
			this.code = code;
		}
		public int getCode()
		{
			return code;
		}
		
	}
	public static class ConnectApiXmlException extends Exception
	{
		private static final long serialVersionUID = 1L;
		private int code;
		
		public ConnectApiXmlException(int code, String message)
		{
			super(message);
			this.code = code;
		}
		public int getCode()
		{
			return code;
		}
		
	}
	public static class ConnectApiFieldException extends Exception
	{
		private static final long serialVersionUID = 1L;
		private int code;
		
		private LinkedHashMap<String,String> fields = new LinkedHashMap<String,String>();
		
		public ConnectApiFieldException(int code, String message)
		{
			super(message);
			this.code = code;
		}
		public void addField(String field,String message)
		{
			fields.put(field, message);
		}
		public Set<String> getFields()
		{
			return fields.keySet();
		}
		public String getField(String field)
		{
			return fields.get(field);
		}
		public int getCode()
		{
			return code;
		}
		
	}
	/*
	public static class ConnectApiError extends Exception
	{
		private static final long serialVersionUID = 8641253634148719408L;

		private int code;
		
		public ConnectApiError(String message,int code)
		{
			super(message);
			this.code = code;
		}
		public int getCode()
		{
			return code;
		}
	}
	*/
	public static String generateReferenceId(ConnectUser connectuser) 
	{
		String guid = connectuser.getGuid();
		
		return "vsb-"+guid;
	}
/*
	public static boolean updateUserPassword(ApiKeys apikeys, String email,String password) throws ConnectApiXmlException, ConnectApiFieldException, ConnectApiException 
	{
		try
		{
			Element user = new Element("user");
			
			user.addContent(new Element("password").setText(password));
			
			Document request = new Document(user);
			
			Document response = callConnectApi(apikeys, HttpMethod.PUT,"/v3/users.xml/"+email+"?full=true",request,null);
			
			Element response_element = response.getRootElement();
			
			if(response_element.getName().equals("user"))
			{
				//user updated successfully - get the guid
				
				String resp_email       = response_element.getChildText("email");
				String resp_firstname   = response_element.getChildText("first-name");
				String resp_lastname    = response_element.getChildText("last-name");
				String resp_reference   = response_element.getChildText("reference");
				int resp_questionid     = -1;
				try{resp_questionid     = Integer.valueOf(response_element.getChildText("question-id"));}catch(Exception e){}
				String resp_answer      = response_element.getChildText("question-response");
				boolean resp_promote    = false;
				try{resp_promote        = response_element.getChildText("promote-option").equals("true");}catch(Exception e){}
				boolean resp_survey     = false;
				try{resp_survey         = response_element.getChildText("survey-option").equals("true");}catch(Exception e){}
				
				return resp_email.trim().toLowerCase().equals(email.trim().toLowerCase());
				
				
				//ConnectUser u = new ConnectUser(connectuser.getGuid(), connectuser.getAccessToken(), resp_reference, resp_email,resp_firstname,resp_lastname, resp_questionid, resp_answer, resp_promote, resp_survey);
				
				//ConnectUser u = new ConnectUser(connectuser.getEmail(), connectuser.getAccessToken(), resp_reference, resp_email,resp_firstname,resp_lastname);
				
				//return u;
			}
			else if(response_element.getName().equals("error-response"))
			{
				String serrorcode = response_element.getChildText("error-code");
				String errortext = response_element.getChildText("error-text");
				try
				{
					int errorcode = Integer.valueOf(serrorcode);
					switch(errorcode)
					{
						case 463:// - Question is invalid
						case 464:// - Account already exists
						case 467:// - Bundle is invalid
						case 468:// - Redemption code is invalid
						case 469:// - Code has been redeemed
						case 470:// - Redemption failed
						case 482:// - Malformed create user request
						case 904:// - User reference already exists
						case 906:// - Insufficient requirements for user create
							throw new ConnectApiXmlException(errorcode,errortext);
						case 465:// - Data validation error (a more complex response which denotes field-specific errors)
							ConnectApiFieldException e = new ConnectApiFieldException(465,"Data validation error");
							
							List<Element> errors = response_element.getChildren("error");
							for(int i = 0; i < errors.size(); i++)
							{
								String field   = errors.get(i).getChildText("field");
								String message = errors.get(i).getChildText("message");
								
								e.addField(field, message);
							}
							throw e;
						default:
							//throw new ConnectApiException("Connect returned an unexpected error code: " + errorcode);
							log.error("Connect returned and unexpected response when creating a user: " + serrorcode + " : " +errortext);
							throw new ConnectApiXmlException(errorcode,errortext);
					}
				}
				catch(NumberFormatException e)
				{
					log.error("Connect returned and unexpected response when creating a user: " + serrorcode + " : " +errortext);
					throw new ConnectApiException("An error occured",e);
				}
			}
			else
			{
				log.error("Connect returned an unexpected response: \n\n" + new XMLOutputter().outputString(response));
				throw new ConnectApiException("Connect returned and unexpected response: " + response_element.getName());
			}
		}
		catch(ConnectApiXmlException e)
		{
			throw e;
		}
		catch(ConnectApiFieldException e)
		{
			throw e;
		}
		catch(Exception e)
		{
			throw new ConnectApiException("An error occured",e);
		}
	}
	
*/
	
	public static class CacheObject
	{
		private String etag;
		private String data;
		
		public CacheObject(String etag, String data)
		{
			this.etag = etag;
			this.data = data;
		}
		
		public String getEtag()
		{
			return etag;
		}
		public String getData()
		{
			return data;
		}
	}
	
	public static String verifyMail(API_MODE apiMode,String email) throws VstException, ConnectApiException 
	{
		HttpGet get = null;
		String encodedMail=null;
		try
		{
			encodedMail = URLEncoder.encode(email, "ISO-8859-1");			
			get = new HttpGet(ApiKeys.getJigsawConnectUrl(apiMode)+encodedMail+ApplicationConstants.EXISTS_JSON);		
			HttpClient httpclient = HttpClientBuilder.create().build();
			HttpContext context = new BasicHttpContext();
			HttpResponse response = httpclient.execute(get, context);
			
			String jsonResponse=JsonUtils.getResponseAsString(response);
			
			
			return jsonResponse;
		}
		catch (UnsupportedEncodingException e) 
		{
			log.error("Unable to encode email address with ISO-8859-1",e);
			throw new ConnectApiException("An error occured",e);
		}
		catch(Exception ex)
		{
			throw new VstException("An error occured",ex, ERRORS.ConnectKeyException);
		}	
	}

	public static String getConnectCompany(String apiKey) throws VstException{
		String connectCompany=null;
		HttpGet httpGet = new HttpGet(ApiKeys.getConnectUrl(ApplicationConstants.getApiMode())+ApplicationConstants.URL_COMPANY);
		httpGet.setHeader(ApplicationConstants.APIKEY_HEADER, apiKey);
		HttpClient httpclient = HttpClientBuilder.create().build();
		HttpContext context = new BasicHttpContext();
		try{
			HttpResponse response = httpclient.execute(httpGet, context);
			String responseString=	  EntityUtils.toString(response.getEntity());	
			SAXBuilder saxBuilder = new SAXBuilder();
						  
			Document doc = saxBuilder.build(new StringReader(responseString));
			connectCompany = doc.getRootElement().getChild("name").getText();
			if(doc.getRootElement().getName().equals("error-response"))
			{
				throw new VstException(doc.getRootElement().getChildText("error-text")+"; Connect exception " + response.getStatusLine().getStatusCode()+" "+response, ERRORS.ConnectKeyException);
			}			
		
		}
		catch(Exception ex)
		{
			throw new VstException("An error occured",ex, ERRORS.ConnectKeyException);
		}
		return connectCompany;
	}
	
	public static ConnectCompanyVO getV4ConnectCompany(String apiKey) throws VstException{
		RestTemplate restTemplate = new RestTemplate();
		ConnectCompanyVO connectCompanyVO=null;
		String url=ApiKeys.getConnectUrl(ApplicationConstants.getApiMode())+"/v4/companies";
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<ConnectCompanyVO> response=null;
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add(ApplicationConstants.APIKEY_HEADER, apiKey);
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		
		try{
			response=restTemplate.exchange(url,org.springframework.http.HttpMethod.GET, entity, ConnectCompanyVO.class);
			if(HttpStatus.OK==response.getStatusCode()){
				connectCompanyVO=response.getBody();
			}
			else{
				throw new BridgeException(ApplicationCode.COMPANY_NOT_FOUND);
			}
		}
		catch(Exception e){
			throw new BridgeException(ApplicationCode.COMPANY_NOT_FOUND);
		}
		
		return connectCompanyVO;
	}
	
	public static SystemUserLoginResponseVO checkAdminFromConnect(LoginInfoVO loginInfoVO) throws VstException {
		String loginUrl = ApiKeys.getVitalBookServicesUrl(ApplicationConstants.getApiMode())+"/user/system";				
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));	
		MultiValueMap<String, String> bodyMap = new LinkedMultiValueMap<>();
		bodyMap.add("login", loginInfoVO.getEmail());
		bodyMap.add("pass", loginInfoVO.getPassword());
		bodyMap.add("api_key", ApiKeys.getSystemUserKey(ApplicationConstants.getApiMode()));
		Map<String, String> paramMap = new HashMap<String, String>();
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(bodyMap,headers);
		ResponseEntity<String> systemUserResponse=null;
		try{
			systemUserResponse = restTemplate.exchange(loginUrl,org.springframework.http.HttpMethod.POST , request, String.class, paramMap);
		}
		catch(HttpClientErrorException e){
			throw new BridgeException(ApplicationCode.USER_AUTHENTICATION_FAILED);
		}	
		
		String responseBody=systemUserResponse.getBody();
		SAXBuilder saxBuilder = new SAXBuilder();
		  
		Document doc=null;
		try {
			doc = saxBuilder.build(new StringReader(responseBody));
		} catch (JDOMException | IOException e) {
			// TODO Auto-generated catch block
			throw new VstException("An error occured",e, ERRORS.ConnectKeyException);
		}
		String rootName= doc.getRootElement().getName();
		if(rootName!=null && "user".equals(rootName)){			
			Element rootNode = doc.getRootElement();
			//List<Element> userListElements = rootNode.getChildren("user");
			SystemUserLoginResponseVO systemUserLoginResponseVO = null;
			if(rootNode!=null) {
				systemUserLoginResponseVO=new SystemUserLoginResponseVO();
				systemUserLoginResponseVO.setSystemUserId(Integer.parseInt(rootNode.getAttributeValue("id")));
				systemUserLoginResponseVO.setFirstName(rootNode.getAttributeValue("first_name"));
				systemUserLoginResponseVO.setLastName(rootNode.getAttributeValue("last_name"));
				systemUserLoginResponseVO.setEmail(rootNode.getAttributeValue("email"));
			}
			return systemUserLoginResponseVO;
		}
		else if(rootName!=null && "error".equals(rootName)){
			throw new BridgeException(ApplicationCode.UNAUTHORISED_CONNECT_USER);
		}
		
		return null;
		
	}
	
	
	
}

