package com.vst.connectapi;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * see: <a href="https://wiki.ingramcontent.com/pages/viewpage.action?title=VitalSource%20API%20Version%203&spaceKey=apidocs">BookShelf Doc</a>
 
 * Fields:
		access-token (required) - the user's current (and unexpired) access token. the token can be retrieved (in bulk, if necessary) from the
		Credentials call

		sku (required) - product identifier for the product for which we are granting access
		term (required) - the desired license length to grant the user for downloadable access (two options: # of days, like "1825", or "Perpetual"
		for access that never expires)
		
		online-term (optional) - the desired license length to grant the user for online access. If this field is not specified, term will be used in
		place of online-term. (two options: # of days, like "1825", or "Perpetual" for access that never expires)
		
		tag (optional) - arbitrary tag which will be attached to any redemption code which is created (for reporting purposes)
		
		ensure-years (optional) - refers to the minimum number of years you wish for this user to have the product before giving a new license.
		defaults to 3 years. if the account holder does not already have this number of years available, a new redemption code will be created
		and redeemed which grants the user access for the requested term length. To force the redemption to happen regardless of the current
		state of the user's content, pass an ensure-years value of -1.
		
		ensure-days (optional) - refers to the minimum number of days you wish for this user to have the product before giving a new license. if
		the account holder does not already have this number of days available, a new redemption code will be created and redeemed which
		grants the user access for the requested term length. it checks ensure-days before the ensure-years default. meaning, if you omit
		ensure-years and include ensure-online-days, that could take precedence on the skip logic. If you include ensure-years and need it to be
		ignored, pass a value of 0.
		
		callback (optional) - if this attribute is present, it registers your desire to receive the status of this bulk request posted back to you at this
		URL. If this is not specified, you will receive no details of the bulk redemption execution.
		
		code-type (optional) - comp, add-drop,p-plus-e are valid values. if code-type is missing or blank, the code type will be "code-api".
		
		status (in bulk redemption response body) - processing
		
		status (individual redemption in callback response body) - skipped, redeemed, or error
		
		message - explanatory message about the particular redemption request
		
	Notes:
		If a user already has a Perpetual license to a product, requests to auto-redeem for that product will be ignored.
 **/
public class ConnectLicense 
{
	private String type = null;
	private String sku = null;
	private String name = null;
	private Long expiration = null;
	private String publisher = null;
	private boolean expired;
	private String codeUse= null;
	
	public ConnectLicense(String type, String sku, String name, String expiration, String publisher, String codeUse)
	{
		this.type = type;
		this.sku = sku;
		this.name = name;
		this.publisher = publisher;
		this.codeUse= codeUse;
		
		try
		{
			if(expiration.equals("never"))
			{
				this.expiration = null;
				this.expired = false;
			}
			else
			{
				SimpleDateFormat formatter = new SimpleDateFormat("EEE, d MMM yyyy hh:mm:ss zzz");
		        this.expiration = formatter.parse(expiration).getTime();
		        long now  = new Date().getTime();
		        
		        if(this.expiration < now)
		        {
		        	this.expired = true;
		        }
		        else
		        {
		        	this.expired = false;
		        }
			}
		}
		catch(Exception e)
		{
			//If the server does not give us a valid date then we assume not expired
			this.expired = false;
		}
	}

	public String getType() {
		return type;
	}

	public String getSku() {
		return sku;
	}

	public String getName() {
		return name;
	}

	public Long getExpiration() {
		return expiration;
	}

	public String getPublisher() {
		return publisher;
	}
	
	public boolean getExpired()
	{
		return expired;
	}
	
	public String getCodeUse() {
		return codeUse;
	}

	@Override
	public String toString() {
		return "ConnectLicense [type=" + type + ", sku=" + sku + ", name=" + name + ", expiration=" + expiration
				+ ", publisher=" + publisher + ", expired=" + expired + ", codeUse=" + codeUse + "]";
	}
}
