package com.vst.connectapi;

import org.apache.commons.lang.StringUtils;

import com.vst.bridge.util.exception.ApplicationCode;
import com.vst.bridge.util.exception.BridgeException;

public class ApiKeys 
{
	public static enum API_MODE {local, stage, dev, prod, test, none};
	
	private String connect_url = null;
	private String connect_key = null;

	private String lti_url     = null;
	private String lti_key     = null;
	private String lti_secret  = null;
	private String password_url = null;

	
	public ApiKeys(API_MODE mode, String connectkey, String lti_key,String lti_secret) throws BridgeException
	{
		
		if(null ==connectkey || StringUtils.isEmpty(connectkey)){
			throw new BridgeException(ApplicationCode.INVALID_BRIDGE_KEY);
		}
		this.connect_key = connectkey;
		this.lti_key     = lti_key;
		this.lti_secret  = lti_secret;
		
		this.connect_url= getConnectUrl(mode);
		switch(mode)
		{
			case local:
				this.lti_url      = "http://localhost/vsbportal/lti.php";
				this.password_url = "http://localhost/vsbportal/forgot.php";
				break;
			case test:
				break;
			case dev:
				this.lti_url     = "https://api-dev.vitalsource.com/";
				this.password_url = "http://online-dev.vitalsource.com/forgot";
				break;
			case stage:
				this.lti_url     = "http://bc-staging.vitalsource.com/";
				this.password_url = "http://online-staging.vitalsource.com/forgot";
				break;
			case prod:
				this.lti_url     = "http://bc.vitalsource.com/";
				this.password_url = "http://online.vitalsource.com/forgot";
				break;
			default:
				throw new BridgeException(ApplicationCode.INVALID_BRIDGE_ACTION);
		}
	}
	public String getConnectUrl() 
	{
		return connect_url;
	}
	public String getConnectKey() {
		return connect_key;
	}
	public String getLtiUrl() {
		return lti_url;
	}
	public String getLtiKey() {
		return lti_key;
	}
	public String getLtiSecret() {
		return lti_secret;
	}
	public String getPasswordUrl() {
		return password_url;
	}
	
	static public String getConnectUrl(API_MODE mode) throws BridgeException {			

		switch(mode)
		{
			case local:
				return "http://api-vitalsource.localhost";
			case test:
				return "https://api-dev.vitalsource.com";
			case dev:
				return "https://api-dev.vitalsource.com";
			case stage:
				return "https://api-staging.vitalsource.com";
			case prod:
				return "https://api.vitalsource.com";
			default:
				throw new BridgeException(ApplicationCode.INVALID_BRIDGE_ACTION);
		}
	}
	
	static public String getJigsawConnectUrl(API_MODE mode) throws BridgeException {			

		switch(mode)
		{
			case dev:
				return "https://jigsaw-dev.vitalsource.com/user/";
			case stage:
				return "https://jigsaw-staging.vitalsource.com/user/";
			case prod:
				return "https://jigsaw.vitalsource.com/user/";
			default:
				throw new BridgeException(ApplicationCode.INVALID_BRIDGE_ACTION);
		}
	}
	
	static public String getBusinessCenterUrl(API_MODE mode) throws BridgeException {			

		switch(mode)
		{
		case dev:
			return "https://bc-dev.vitalsource.com/";			
		case stage:
			return "https://bc-staging.vitalsource.com/";
		case prod:
			return "https://bc.vitalsource.com/";
			
		default:
				throw new BridgeException(ApplicationCode.INVALID_BRIDGE_ACTION);
		}
	}
	
	static public String getJigsawDomainUrl(API_MODE mode) throws BridgeException {			

		switch(mode)
		{
			case dev:
				return "https://jigsaw-dev.vitalsource.com/";				
			case stage:
				return "https://jigsaw-staging.vitalsource.com/";				
			case prod:
				return "https://jigsaw.vitalsource.com/";				
			default:
				throw new BridgeException(ApplicationCode.INVALID_BRIDGE_ACTION);
				
		}
	}
	
	static public String getAncillaryServiceUrl(API_MODE mode) throws BridgeException {
		switch(mode)
		{
		case dev:
			return "https://ancillaries-dev.gc.vitalbook.com";
		case stage:
			return "https://ancillaries-stage.gc.vitalbook.com";
		case prod:
			return "https://ancillaries.vitalsource.com";
		default:
			throw new BridgeException(ApplicationCode.INVALID_BRIDGE_ACTION);
		}
	}
	
	static public String getEmbeddedBridgeReaderBrand(API_MODE mode) throws BridgeException {
		switch(mode)
		{
		case dev:
			return "https://embeddedbridgereader-dev.vitalsource.com";
		case stage:
			return "https://embeddedbridgereader-staging.vitalsource.com";
		case prod:
			return "https://embeddedbridgereader.vitalsource.com";
		default:
			throw new BridgeException(ApplicationCode.INVALID_BRIDGE_ACTION);
		}
	}
	static public String getSystemUserKey(API_MODE mode) throws BridgeException {			

		switch(mode)
		{
			case dev:
				return "MVAKAWHK85QKVMRW";			
			case stage:
				return "BWETH7CSV83XM5GF";				
			case prod:
				return "JC3HXCRQBCPUX47W";				
			default:
				throw new BridgeException(ApplicationCode.INVALID_BRIDGE_ACTION);
				
		}
	}
	
	static public String getVitalBookServicesUrl(API_MODE mode) throws BridgeException {			

		switch(mode)
		{
			case dev:
				return "https://services-dev.vitalbook.com";			
			case stage:
				return "https://services-staging.vitalbook.com";				
			case prod:
				return "https://services.vitalbook.com";				
			default:
				throw new BridgeException(ApplicationCode.INVALID_BRIDGE_ACTION);
				
		}
	}
	
	static public String getHipChatToken(API_MODE mode) throws BridgeException {
		switch(mode)
		{
		case dev:
			return "https://ingramcontent.hipchat.com/v2/room/4030581/notification";
		case stage:
			return "https://ingramcontent.hipchat.com/v2/room/4030581/notification";
		case prod:
			return "https://ingramcontent.hipchat.com/v2/room/3846592/notification";
		default:
			throw new BridgeException(ApplicationCode.INVALID_BRIDGE_ACTION);
		}
	}
	
}
