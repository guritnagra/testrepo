package com.vst.connectapi;

import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;

import org.apache.commons.lang.StringUtils;

public class ConnectBook 
{
	
	private String vbid;
	private String title;
	private String textBookIsbn;
	private String eBookIsbn;
	private String author;
	private String description;
	private URL coverImageUrl;
	private String edition;
	private String sku;
	private String digitalPrice;
	private String publisherPrice;
	private String type;

	public ConnectBook(String vbid, String title, String textbookisbn, String ebookisbn, String author, String description, URL coverImageUrl,String edition,String sku,String publisherPrice,String digitalPrice,String type) {
		super();
		this.vbid = vbid;
		this.title = title;
		this.textBookIsbn = textbookisbn;
		this.eBookIsbn = ebookisbn;
		this.author = author;
		this.description= null != description ? description.toString() : "";
		this.coverImageUrl= coverImageUrl;
		this.edition = edition;
		this.sku=sku;
		this.digitalPrice=digitalPrice;
		this.publisherPrice=publisherPrice;
		this.type=type;
	}
	
	
	
	public ConnectBook(String vbid, String title, String textbookisbn, String ebookisbn, String author, String description, String coverImageUrl, String edition, String subject,String sku,String publisherPrice,String digitalPrice,String type) {
		this(vbid, title, textbookisbn, ebookisbn, author, description, (URL)null,edition,sku,publisherPrice,digitalPrice,type);
		
		try {
			if(null != coverImageUrl && StringUtils.isNotEmpty(coverImageUrl)){
				this.setCoverImageUrl(new URL(coverImageUrl));
			}
		} catch (MalformedURLException e) {
		}
	}
	
	public boolean isEncoded(String text){
	    Charset charset = Charset.forName("US-ASCII");
	    String checked=new String(text.getBytes(charset),charset);
	    return !checked.equals(text);

	}
	
	
	@Override
	public String toString() {
		return "\nConnectBook [vbid=" + vbid + ", title=" + title + ", textBookIsbn=" + textBookIsbn + ", eBookIsbn="
				+ eBookIsbn + ", author=" + author + /*", description=" + description + ", coverImageUrl=" + coverImageUrl
				+ */", edition=" + edition + ", sku=" + sku + ", digitalPrice=" + digitalPrice + ", publisherPrice="
				+ publisherPrice + ", type="
						+ type + "]";
	}
	
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	public String getVbid() {
		return vbid;
	}
	public void setVbid(String vbid) {
		this.vbid = vbid;
	}
	public URL getCoverImageUrl() {
		return coverImageUrl;
	}
	public void setCoverImageUrl(URL coverImageUrl) {
		this.coverImageUrl = coverImageUrl;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTextbookIsbn() {
		return textBookIsbn;
	}
	public void setTextbookIsbn(String textbookisbn) {
		this.textBookIsbn = textbookisbn;
	}
	public String getEBookIsbn() {
		return eBookIsbn;
	}
	public void setEBookIsbn(String ebookisbn) {
		this.eBookIsbn = ebookisbn;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public String getEdition() {
		return edition;
	}

	public void setEdition(String edition) {
		this.edition = edition;
	}
	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getDigitalPrice() {
		return digitalPrice;
	}

	public void setDigitalPrice(String digitalPrice) {
		this.digitalPrice = digitalPrice;
	}

	public String getPublisherPrice() {
		return publisherPrice;
	}

	public void setPublisherPrice(String publisherPrice) {
		this.publisherPrice = publisherPrice;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}


	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((sku == null) ? 0 : sku.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result + ((vbid == null) ? 0 : vbid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ConnectBook other = (ConnectBook) obj;
		if (sku == null) {
			if (other.sku != null)
				return false;
		} else if (!sku.equals(other.sku))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		if (vbid == null) {
			if (other.vbid != null)
				return false;
		} else if (!vbid.equals(other.vbid))
			return false;
		return true;
	}
	
}
