package com.vst.connectapi;

public enum ERRORS {
	UNKNOWN_CAUSE, JSON_FORMAT_INVALID, NO_SUCH_USER, NO_SUCH_WEBSITE, NO_SESSION, NO_PORTAL_ACCESS, NO_LIBRARY_ACCESS, REQUEST_DATA_INVALID,
	AccountAlreadyExistsException,
	BookAlreadyLicensedException,
	BookLicensedExpiredException,
	BookNotFoundException,
	BookNotLicensedException,
	EmailNotSentException,
	InvalidPortalTypeException,
	InvalidUrlException,
	KeyAlreadyRegisteredException,
	KeyExpiredException,
	KeyNotFoundException,
	LTIServiceException,
	LoginFailedException,
	NoCreditsAvailableException,
	PortalException,
	RequiredFieldsException,
	SessionExpiredException,
	SessionNotFoundException,
	TokenNotFoundException,
	UnableToRedeemCreditException,
	UserNotFoundException,
	Invalid_Case, AWS, ConnectKeyException, KeyNotRedeemedException, NO_SESSION_ID_GIVEN,
	
}
