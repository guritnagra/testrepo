package com.vst.connectapi;

public class ConnectUserInfo 
{
	private String email;
	private String firstname;
	private String lastname;
	
	public ConnectUserInfo(String email, String firstname, String lastname)
	{
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
	}

	public String getFirstName() {
		return firstname;
	}

	public void setFirstName(String firstname) {
		this.firstname = firstname;
	}

	public String getLastName() {
		return this.lastname;
	}

	public void setLastName(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFullName() 
	{
		return firstname +" " + lastname;
	}
}
