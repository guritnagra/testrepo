package com.vst.connectapi;

public class ConnectUser extends ConnectUserInfo
{
	private String guid;
	private String accesstoken;
	private String reference;
	private int questionid;
	private String answer;
	private boolean promotionsubscription;
	private boolean surveysubscription;

	public ConnectUser(String guid, String accesstoken, String reference, String email, String firstname, String lastname, int questionid, String answer, boolean promotionsubscription, boolean surveysubscription)
	{
		super(email, firstname, lastname);
		this.guid = guid;
		this.accesstoken = accesstoken;
		this.reference   = reference;
		this.questionid = questionid;
		this.answer = answer;
		this.promotionsubscription = promotionsubscription;
		this.surveysubscription = surveysubscription;
	}
	public String getGuid()
	{
		return guid;
	}
	public void setGuid(String guid)
	{
		this.guid = guid;
	}
	public String getAccessToken()
	{
		return accesstoken;
	}
	public void setAccessToken(String accesstoken)
	{
		this.accesstoken = accesstoken;
	}
	public String getReference()
	{
		return this.reference;
	}
	public void setReference(String reference)
	{
		this.reference = reference;
	}

	public int getQuestionId() 
	{
		return this.questionid;
	}

	public String getQuestionResponse() 
	{
		return this.answer;
	}

	public boolean getPromotionSubscription() {
		return this.promotionsubscription;
	}

	public boolean getSurveySubscription() {
		// TODO Auto-generated method stub
		return this.surveysubscription;
	}
	@Override
	public String toString() {
		return "ConnectUser [guid=" + guid + ", accesstoken=" + accesstoken + ", reference=" + reference
				+ ", questionid=" + questionid + ", answer=" + answer + ", promotionsubscription="
				+ promotionsubscription + ", surveysubscription=" + surveysubscription + "]";
	}
	
	
	
}
