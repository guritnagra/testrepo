ALTER TABLE `tbl_admingroups_companyassign` CHANGE `library_id` `company_id` INT(8) NOT NULL; 

ALTER TABLE `tbl_adminuser_companyassign` CHANGE `library_id` `company_id` INT(8) NOT NULL; 

ALTER TABLE `tbl_adminuser_favoritebridges` CHANGE `portal_id` `bridge_id` INT(8) NULL; 

ALTER TABLE `tbl_adminuser_companyassign` CHANGE `user_id` `admin_id` INT(8) NOT NULL;

ALTER TABLE `tbl_adminuser_groupassign` CHANGE `user_id` `admin_id` INT(8) NOT NULL; 

ALTER TABLE `tbl_adminuser_sessions` CHANGE `user_id` `admin_id` INT(8) DEFAULT 0 NOT NULL; 

ALTER TABLE `tbl_bridge_books` CHANGE `portal_id` `bridge_id` INT(8) NOT NULL;

ALTER TABLE `tbl_keybatches` CHANGE `portal_id` `bridge_id` INT(8) NOT NULL;

ALTER TABLE `tbl_bridge` CHANGE `library_id` `company_id` INT(8) DEFAULT 0 NOT NULL; 

ALTER TABLE `tbl_bridgeuser` CHANGE `portal_id` `bridge_id` INT(8) DEFAULT 0 NOT NULL; 