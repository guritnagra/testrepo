
UPDATE `tbl_adminuser` SET `password`= MD5(`password`);