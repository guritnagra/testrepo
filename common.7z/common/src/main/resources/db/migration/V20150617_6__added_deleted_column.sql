ALTER TABLE `tbl_keybatches_keys` ADD COLUMN `deleted` TINYINT(1) DEFAULT 0 NULL AFTER `expire_months`; 

ALTER TABLE `tbl_admingroups` ADD COLUMN `deleted` TINYINT(1) DEFAULT 0 NULL AFTER `created`;

ALTER TABLE `tbl_admingroups_companyassign` ADD COLUMN `deleted` TINYINT(1) DEFAULT 0 NULL AFTER `company_id`; 

ALTER TABLE `tbl_adminuser_companyassign` ADD COLUMN `deleted` TINYINT(1) DEFAULT 0 NULL AFTER `company_id`;

ALTER TABLE `tbl_adminuser_groupassign` ADD COLUMN `id` INT(8) NOT NULL AUTO_INCREMENT FIRST, 
ADD COLUMN `deleted` TINYINT(1) DEFAULT 0 NULL AFTER `group_id`, ADD PRIMARY KEY (`id`); 

ALTER TABLE `tbl_bridge` ADD COLUMN `deleted` TINYINT(0) DEFAULT 0 NULL AFTER `purchase_textbook_url`; 

ALTER TABLE `tbl_bridge_config` CHANGE `portal_id` `bridge_id` INT(8) NULL, 
ADD COLUMN `deleted` TINYINT(1) DEFAULT 0 NULL AFTER `bridge_id`, 
DROP INDEX `portal_id`, 
ADD CONSTRAINT `tbl_bridge_config_ibfk_1` FOREIGN KEY (`bridge_id`) REFERENCES `tbl_bridge`(`id`);

ALTER TABLE `tbl_bridgeuser_sessions` ADD COLUMN `deleted` TINYINT(1) DEFAULT 0 NULL AFTER `last_access`; 

ALTER TABLE `tbl_bridgeuser_bookassign` ADD COLUMN `deleted` TINYINT(1) DEFAULT 0 NULL AFTER `last_access`;

ALTER TABLE `tbl_bridgeuser_keyassign` ADD COLUMN `deleted` TINYINT(1) DEFAULT 0 NULL AFTER `activation_date`; 

ALTER TABLE `tbl_adminuser_sessions` ADD COLUMN `deleted` TINYINT(1) DEFAULT 0 NULL AFTER `last_access`;

ALTER TABLE `tbl_adminuser_favoritebridges` CHANGE `user_id` `admin_id` INT(8) NULL, ADD COLUMN `deleted` TINYINT(1) DEFAULT 0 NULL AFTER `favorite`; 

ALTER TABLE `tbl_adminuser_passwordresets` ADD COLUMN `id` INT(8) NOT NULL AUTO_INCREMENT FIRST, 
CHANGE `user_id` `admin_id` INT(11) NOT NULL, 
ADD COLUMN `deleted` TINYINT(1) DEFAULT 0 NULL AFTER `created`, 
ADD PRIMARY KEY (`id`); 