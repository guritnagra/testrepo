ALTER TABLE `tbl_admingroups` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `deleted`;

ALTER TABLE `tbl_admingroups_companyassign` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `deleted`;

ALTER TABLE `tbl_adminuser` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `creator_id`; 

ALTER TABLE `tbl_adminuser_companyassign` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `deleted`; 

ALTER TABLE `tbl_adminuser_favoritebridges` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `deleted`; 

ALTER TABLE `tbl_adminuser_groupassign` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `deleted`; 

ALTER TABLE `tbl_adminuser_passwordresets` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `deleted`; 

ALTER TABLE `tbl_adminuser_roles` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `code`; 

ALTER TABLE `tbl_adminuser_sessions` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `deleted`; 

ALTER TABLE `tbl_bridge` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `deleted`; 

ALTER TABLE `tbl_bridge_books` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `is_selected`;

ALTER TABLE `tbl_bridge_config` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `deleted`; 

ALTER TABLE `tbl_bridge_log` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `created`; 

ALTER TABLE `tbl_bridgeuser` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `created`;

ALTER TABLE `tbl_bridgeuser_bookassign` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `deleted`; 

ALTER TABLE `tbl_bridgeuser_keyassign` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `deleted`; 

ALTER TABLE `tbl_bridgeuser_roles` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `code`; 

ALTER TABLE `tbl_bridgeuser_sessions` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `deleted`;

ALTER TABLE `tbl_company` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `creator_id`; 

ALTER TABLE `tbl_keybatches` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `creator_id`;

ALTER TABLE `tbl_keybatches_keys` ADD COLUMN `version_id` INT DEFAULT 0 NULL AFTER `deleted`;