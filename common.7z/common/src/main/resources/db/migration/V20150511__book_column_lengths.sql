ALTER TABLE tblcache_library_books CHANGE author author varchar(512) DEFAULT NULL;
ALTER TABLE tblcache_library_books CHANGE name name varchar(512) DEFAULT NULL;
ALTER TABLE tblcache_library_books CHANGE cover_image_url cover_image_url varchar(512) DEFAULT NULL;
