UPDATE `tbl_keybatches_keys` AS k 
	INNER JOIN ( 
		SELECT `id`,`purchase_credits`,`num_users_per_key`,`trial_credits`,`expires` 
		FROM `tbl_keybatches` 
	) AS batch 
	ON k.`key_batch_id`= batch.`id` 
	SET k.`purchase_credits` = batch.`purchase_credits`, 
		k.`num_users_per_key`= batch.`num_users_per_key`, 
		k.`trial_credits`=batch.`trial_credits`, 
		k.`expires`=batch.`expires`; 