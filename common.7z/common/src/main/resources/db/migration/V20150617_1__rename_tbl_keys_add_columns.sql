ALTER TABLE `tbl_keys` 
RENAME TO  `tbl_keybatches_keys`;

ALTER TABLE `tbl_keybatches_keys` 
DROP FOREIGN KEY `tbl_keybatches_keys_ibfk_3`;

ALTER TABLE `tbl_keybatches_keys` 
ADD COLUMN `purchase_credits` INT(4) NOT NULL DEFAULT 0 AFTER `key_batch_id`;

ALTER TABLE `tbl_keybatches_keys` 
ADD COLUMN `num_users_per_key` INT(4) NOT NULL DEFAULT 0 AFTER `purchase_credits`;

ALTER TABLE `tbl_keybatches_keys` 
ADD COLUMN `trial_credits` INT(4) NOT NULL DEFAULT 0 AFTER `num_users_per_key`;

ALTER TABLE `tbl_keybatches_keys` 
ADD COLUMN `expires` TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00' AFTER `trial_credits`;

ALTER TABLE `tbl_keybatches_keys` 
ADD COLUMN `expire_days` INT(4) NULL AFTER `expires`;

ALTER TABLE `tbl_keybatches_keys` 
ADD COLUMN `expire_months` INT(4) NULL AFTER `expire_days`;

ALTER TABLE `tbl_keybatches_keys` 
ADD CONSTRAINT `tbl_keybatches_keys_ibfk_1`
  FOREIGN KEY (`key_batch_id`)
  REFERENCES `tbl_keybatches` (`id`);